import { compactText, rowsText, styledSpans } from "../native/spans";
import { node } from "../native/describe";
import type { DescribeContext, NativeNode } from "../native/node";
import type { Component } from "../tui";
import { Ellipsis, getWidthConfigEpoch, replaceTabs, truncateToWidth, visibleWidth } from "../utils";

function isComponent(body: Component | readonly string[]): body is Component {
	return !Array.isArray(body);
}

function finiteWidth(width: number): number {
	return Number.isFinite(width) ? Math.max(0, Math.trunc(width)) : 0;
}

function singleLine(text: string): string {
	return replaceTabs(text).replace(/[\r\n]+/g, " ");
}

function fillCells(glyph: string, width: number): string {
	const cleanGlyph = singleLine(glyph);
	const glyphWidth = visibleWidth(cleanGlyph);
	if (glyphWidth <= 0) return " ".repeat(width);
	const count = Math.floor(width / glyphWidth);
	return `${cleanGlyph.repeat(count)}${" ".repeat(width - count * glyphWidth)}`;
}

/** Explicit heading/rule/spacing policy for a data section. */
export interface SectionOptions {
	readonly title: string;
	readonly body: Component | readonly string[];
	readonly titleStyle?: (text: string) => string;
	readonly ruleStyle?: (text: string) => string;
	readonly ruleGlyph: string;
	readonly ruleWidth: number | "fill";
	readonly blankAfter?: boolean;
}

/** Compose a width-bounded heading, rule, child rows, and optional trailing blank line. */
export class Section implements Component {
	readonly #options: SectionOptions;
	#cache: { width: number; epoch: number; child: readonly string[]; lines: readonly string[] } | undefined;
	#disposed = false;
	#native: { title: string; node: NativeNode } | undefined;

	constructor(options: SectionOptions) {
		this.#options = options;
	}

	invalidate(): void {
		if (isComponent(this.#options.body)) this.#options.body.invalidate?.();
		this.#cache = undefined;
	}

	releaseRenderCaches(): void {
		this.#cache = undefined;
		if (isComponent(this.#options.body)) this.#options.body.releaseRenderCaches?.();
	}

	dispose(): void {
		if (this.#disposed) return;
		this.#disposed = true;
		if (isComponent(this.#options.body)) this.#options.body.dispose?.();
	}

	/** A `section` headed by the styled title; the rule is the terminal's. */
	describe(_cx: DescribeContext): NativeNode {
		const options = this.#options;
		const rawTitle = singleLine(options.title);
		const title = options.titleStyle?.(rawTitle) ?? rawTitle;
		if (this.#native?.title === title) return this.#native.node;
		const body = isComponent(options.body) ? options.body : rowsText(options.body);
		const described = node("section", { head: compactText(styledSpans(title)) }, [body]);
		this.#native = { title, node: described };
		return described;
	}

	render(width: number): readonly string[] {
		const renderWidth = finiteWidth(width);
		const epoch = getWidthConfigEpoch();
		const child = isComponent(this.#options.body) ? this.#options.body.render(renderWidth) : this.#options.body;
		if (this.#cache?.width === renderWidth && this.#cache.epoch === epoch && this.#cache.child === child) {
			return this.#cache.lines;
		}
		const desiredRuleWidth = this.#options.ruleWidth === "fill" ? renderWidth : finiteWidth(this.#options.ruleWidth);
		const rawTitle = singleLine(this.#options.title);
		const styledTitle = this.#options.titleStyle?.(rawTitle) ?? rawTitle;
		const rawRule = fillCells(this.#options.ruleGlyph, Math.min(renderWidth, desiredRuleWidth));
		const styledRule = this.#options.ruleStyle?.(rawRule) ?? rawRule;
		const lines = [
			truncateToWidth(singleLine(styledTitle), renderWidth, Ellipsis.Omit),
			truncateToWidth(singleLine(styledRule), renderWidth, Ellipsis.Omit),
			...child.map(line => truncateToWidth(singleLine(line), renderWidth, Ellipsis.Omit)),
		];
		if (this.#options.blankAfter === true) lines.push("");
		this.#cache = { width: renderWidth, epoch, child, lines };
		return lines;
	}
}
