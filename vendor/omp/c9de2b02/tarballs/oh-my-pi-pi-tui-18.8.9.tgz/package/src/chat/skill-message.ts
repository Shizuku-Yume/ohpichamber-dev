import { pathToFileURL } from "node:url";
import type { TextContent } from "@oh-my-pi/pi-ai";
import { type Component } from "../tui";
import { Box } from "../components/box";
import { Disclosure } from "../components/disclosure";
import { Container } from "../tui";
import { Markdown } from "../components/markdown";
import { Spacer } from "../components/spacer";
import { Text } from "../components/text";
import { getMarkdownTheme, theme } from "../theme";
import type { CustomMessage, SkillPromptDetails } from "./messages";
import { fileHyperlink } from "../render";
import { collapseSkillTokens, skillChipLabel, skillChipStyle, skillToken } from "../prompt/composer-attachments";
import { type UserBubbleOptions, UserMessageComponent, userBubbleColor } from "./user-message";
import type { TspSpan } from "@oh-my-pi/pi-wire";
import { card, md, node, span, text } from "../native/describe";
import { type NativeChild, type NativeNode, type NativeUiEvent, rootToggleExpanded } from "../native/node";
import { Memo } from "../native/memo";

/**
 * Transcript row for a user-invoked skill. Two layouts, chosen by where the
 * `/skill:<name>` token sat in the submitted draft:
 *
 * - **Callout** (token first): a user bubble with a skill-colored left rail,
 *   the skill chip and prompt size as its header, then the rest of the draft
 *   as full Markdown.
 * - **Inline** (token mid-prompt): a plain user bubble with the token drawn
 *   as the same soft-pill chip the composer showed.
 *
 * In both, the chip is an OSC 8 link to the SKILL.md. Expanding (tool-output
 * toggle) appends the rendered skill prompt.
 */
export class SkillMessageComponent extends Container {
	// Canonical and replayed skill cards finalize immediately so they retire to
	// native scrollback like any settled block. An optimistically-painted
	// `/skill:` row (issue #11217) is instead held live until its canonical
	// `message_start` reconciles it, so it stays removable and never leaves a
	// duplicate behind in scrollback if reconcile swaps it out.
	#transcriptBlockFinalized = true;
	// Controlled expansion delegate. In callout mode it is the prompt-only
	// disclosure nested inside the single continuous SkillCallout rail; in
	// inline mode it pairs the user bubble summary with a lazy SkillCallout
	// body. Rebuilt (unmaterialized) on invalidate so header/body pick up the
	// current theme without eagerly constructing the expanded prompt.
	#disclosure: Disclosure | undefined;

	readonly #message: CustomMessage<SkillPromptDetails>;
	readonly #imageLinks?: readonly (string | undefined)[];
	#expanded = false;
	readonly #native = new Memo();

	constructor(message: CustomMessage<SkillPromptDetails>, imageLinks?: readonly (string | undefined)[]) {
		super();
		this.#message = message;
		this.#imageLinks = imageLinks;

		this.#rebuild();
	}

	setExpanded(expanded: boolean): void {
		this.#expanded = expanded;
		this.#disclosure?.setExpanded(expanded);
	}

	handleNativeEvent(event: NativeUiEvent): void {
		const expanded = rootToggleExpanded(event);
		if (expanded !== undefined) this.setExpanded(expanded);
	}

	/**
	 * A user-toned card (role `omp.skill`): the skill chip (linked to its
	 * SKILL.md) and prompt size in the head, the user's draft as markdown, and
	 * the loaded skill prompt, described only while expanded because it can
	 * be large.
	 */
	override describe(): NativeNode {
		return this.#native.get([this.#expanded], () => {
			const details = this.#message.details;
			const name = details?.name?.trim() || "unknown";
			const token = skillToken(name);
			const prompt = details?.prompt ?? (details?.args ? `${token} ${details.args}` : token);
			const display = collapseSkillTokens(
				prompt,
				candidate => candidate === name,
				() => {},
			);
			const label = skillChipLabel(name);
			const leading = display.startsWith(label) && /^\s*$/.test(display.charAt(label.length));
			const draft = leading ? display.slice(label.length).trim() : display;
			const head: TspSpan[] = [
				span(
					label,
					"customMessageLabel strong",
					details?.path ? { href: pathToFileURL(details.path).href } : undefined,
				),
			];
			if (typeof details?.lineCount === "number") {
				head.push(span(`  ${details.lineCount} ${details.lineCount === 1 ? "line" : "lines"}`, "muted"));
			}
			const children: NativeChild[] = [];
			if (draft) children.push(md(draft));
			const promptText = this.#expanded ? this.#extractText() : "";
			if (promptText) {
				children.push(
					node(
						"section",
						{ head: [span("prompt", "muted")], role: "omp.skill.prompt" },
						[md(promptText)],
						"prompt",
					),
				);
			}
			return card(
				{ role: "omp.skill", tone: "user", head, collapsible: true, collapsed: !this.#expanded },
				children.length > 0 ? children : [text([span(label, "muted")])],
			);
		});
	}

	/**
	 * Transcript finalization contract (see `FinalizableBlock`): an optimistic
	 * `/skill:` row reports `false` so the container keeps it live and removable
	 * until reconcile; every other skill card is finalized on creation.
	 */
	isTranscriptBlockFinalized(): boolean {
		return this.#transcriptBlockFinalized;
	}

	/** Hold this card live as an unreconciled optimistic `/skill:` row (#11217). */
	markTranscriptBlockPending(): void {
		this.#transcriptBlockFinalized = false;
	}

	/** Finalize an optimistic row adopted in place after it already retired to
	 *  scrollback before its canonical `message_start` arrived (#11217). */
	markTranscriptBlockFinalized(): void {
		this.#transcriptBlockFinalized = true;
	}

	override invalidate(): void {
		this.#rebuild();
	}

	override dispose(): void {
		this.#disclosure?.dispose();
		super.dispose();
	}

	#rebuild(): void {
		const expanded = this.#disclosure?.expanded ?? false;
		this.#disclosure?.dispose();
		this.clear();
		const details = this.#message.details;
		const name = details?.name?.trim() || "unknown";
		const token = skillToken(name);
		const prompt = details?.prompt ?? (details?.args ? `${token} ${details.args}` : token);
		// Display-only collapse: only the invoked skill becomes a chip; a second `/skill:` token the
		// dispatcher ignored stays literal so the transcript never claims a skill that never loaded.
		const display = collapseSkillTokens(
			prompt,
			candidate => candidate === name,
			() => {},
		);
		const label = skillChipLabel(name);
		const leading = display.startsWith(label) && /^\s*$/.test(display.charAt(label.length));
		const bubble: UserBubbleOptions = {
			imageLinks: this.#imageLinks,
			skillPath: candidate => (candidate === name ? details?.path : undefined),
		};

		if (!leading) {
			this.#disclosure = new Disclosure({
				summary: new UserMessageComponent(display, bubble),
				// Prompt extraction and Markdown layout stay lazy: the factory
				// runs on the first expanded render, reading the current theme.
				body: () =>
					new SkillCallout([new Text(this.#header(label, details), 0, 0), ...this.#promptSection(bubble)]),
				expanded,
			});
			this.addChild(this.#disclosure);
			return;
		}

		const body = display.slice(label.length).trim();
		const children: Component[] = [new Text(this.#header(label, details), 0, 0)];
		if (body) children.push(new Spacer(1), this.#markdown(body, bubble));
		// The prompt disclosure nests inside the one callout so the
		// skill-colored rail stays continuous across summary and detail.
		const promptDisclosure = new Disclosure({
			body: () => this.#promptFragment(bubble),
			expanded,
		});
		// The rail box and its Markdown always ignore tight viewports.
		promptDisclosure.setIgnoreTight(true);
		this.#disclosure = promptDisclosure;
		children.push(promptDisclosure);
		this.addChild(new SkillCallout(children));
	}

	/**
	 * Expanded prompt section (leading mode detail slot): raw rows appended to
	 * the outer callout, matching the pre-Disclosure layout of a single rail
	 * with no duplicate header.
	 */
	#promptFragment(bubble: UserBubbleOptions): Component {
		const fragment = new Container();
		for (const child of this.#promptSection(bubble)) fragment.addChild(child);
		return fragment;
	}

	#markdown(text: string, bubble: UserBubbleOptions): Markdown {
		const md = new Markdown(text, 0, 0, getMarkdownTheme(), {
			bgColor: value => theme.bg("userMessageBg", value),
			color: userBubbleColor(bubble),
		});
		md.setIgnoreTight(true);
		return md;
	}

	/** Chip linked to its SKILL.md, then the muted prompt size. */
	#header(label: string, details: SkillPromptDetails | undefined): string {
		const chip = skillChipStyle(label, bubbleReset());
		const parts = [details?.path ? fileHyperlink(details.path, chip, { line: 1 }) : chip];
		if (typeof details?.lineCount === "number") {
			parts.push(theme.fg("muted", `${details.lineCount} ${details.lineCount === 1 ? "line" : "lines"}`));
		}
		return parts.join("  ");
	}

	/** The rendered SKILL.md prompt under a calm subheader (expanded view only). */
	#promptSection(bubble: UserBubbleOptions): Component[] {
		const text = this.#extractText();
		if (!text) return [];
		return [new Spacer(1), new Text(theme.fg("muted", "prompt"), 0, 0), new Spacer(1), this.#markdown(text, bubble)];
	}

	#extractText(): string {
		if (typeof this.#message.content === "string") {
			return this.#message.content;
		}
		return this.#message.content
			.filter((c): c is TextContent => c.type === "text")
			.map(c => c.text)
			.join("\n");
	}
}

/** Bubble foreground + background to re-arm after an inline chip. */
function bubbleReset(): string {
	return `${theme.getFgOnBgAnsi("userMessageText", "userMessageBg")}${theme.getBgAnsi("userMessageBg")}`;
}

/**
 * A user-bubble box with a skill-colored rail down its left edge. Memoized on the
 * inner box's render so the transcript's incremental assembly sees stable rows.
 */
class SkillCallout implements Component {
	readonly #box: Box;
	#source: readonly string[] | undefined;
	#lines: string[] | undefined;

	constructor(children: readonly Component[]) {
		this.#box = new Box(1, 1, value => theme.bgFill("userMessageBg", value));
		this.#box.setIgnoreTight(true);
		for (const child of children) this.#box.addChild(child);
	}

	invalidate(): void {
		this.#box.invalidate();
		this.#source = undefined;
		this.#lines = undefined;
	}

	releaseRenderCaches(): void {
		this.#source = undefined;
		this.#lines = undefined;
		this.#box.releaseRenderCaches();
	}

	render(width: number): readonly string[] {
		const inner = this.#box.render(Math.max(1, width - 1));
		if (this.#source === inner && this.#lines !== undefined) return this.#lines;
		const rail = theme.bg("userMessageBg", theme.fg("customMessageLabel", theme.symbol("skill.rail")));
		const lines = inner.map(line => rail + line);
		this.#source = inner;
		this.#lines = lines;
		return lines;
	}
}
