import * as os from "node:os";
import * as path from "node:path";
import { ThinkingLevel } from "@oh-my-pi/pi-agent-core";
import { getTimeBasedPricingPeriod } from "@oh-my-pi/pi-catalog/models";
import { SPINNER_ADVANCE_MS, TERMINAL } from "../index";
import {
	formatDuration,
	formatNumber,
	getProjectDir,
	normalizePathForComparison,
	relativePathWithinNormalizedRoot,
} from "@oh-my-pi/pi-utils";
import { type SymbolKey, type Theme, type ThemeColor, theme } from "../theme";
import { shortenPath, TRUNCATE_LENGTHS, truncateToWidth } from "../render/render-utils";
import { fileHyperlink } from "../render/hyperlink";
import { getSessionAccentAnsi, getSessionAccentHex } from "../theme/session-color";
import { summarizeLoopCondition } from "./loop";
import { formatMetric } from "../components/metric";
import { formatBillingSummary } from "./metrics";
import { sanitizeStatusText } from "../chrome/shared";
import {
	formatContextUsage,
	getContextUsageLevel,
	getContextUsageThemeColor,
	getContextUsageTone,
} from "../chrome/context-thresholds";
import type { TspSpan, TspTone } from "@oh-my-pi/pi-wire";
import { node, span } from "../native/describe";
import { thinkingLevelToken } from "../theme/theme-class";
import type { StatusLineSession } from "./host";
import type { RenderedSegment, SegmentContext, SegmentView, StatusLineSegment, StatusLineSegmentId } from "./types";

export type { SegmentContext } from "./types";

// ═══════════════════════════════════════════════════════════════════════════
// Helpers
// ═══════════════════════════════════════════════════════════════════════════

function withIcon(icon: string, text: string): string {
	return icon ? `${icon} ${text}` : text;
}

/** Native segment description helper. */
function segView(spans: readonly TspSpan[], icon?: string, tone?: TspTone): SegmentView {
	return tone === undefined ? (icon === undefined ? { spans } : { spans, icon }) : { spans, icon, tone };
}

/** Span token for accent-role text; the session accent is a raw hue, so it travels as `accent`. */
function accentToken(ctx: SegmentContext, color: ThemeColor): string {
	return sessionAccentAnsi(ctx) ? "accent" : color;
}

/** Tone of a status/usage theme color, for the segment chrome. */
function toneOf(color: ThemeColor): TspTone | undefined {
	switch (color) {
		case "warning":
			return "warning";
		case "error":
			return "error";
		case "success":
			return "success";
		default:
			return undefined;
	}
}

/**
 * Hash-derived accent ANSI for the session title (or preview stand-in title).
 * Undefined when `statusLine.sessionAccent` is off or the session is unnamed,
 * so callers fall back to their theme color.
 */
function sessionAccentAnsi(ctx: SegmentContext): string | undefined {
	if (ctx.sessionAccent === false) return undefined;
	const name = ctx.session?.sessionManager?.getSessionName() || ctx.previewTitle;
	if (!name) return undefined;
	return getSessionAccentAnsi(getSessionAccentHex(name, theme.sessionAccentInputs));
}
/**
 * `theme.fg` for accent-role text: the hash-derived session accent when
 * enabled, else the given theme color. Callers route only the parts that
 * should carry the session identity color through this (pi icon, model name,
 * PR link, mode badges, session title) — status colors stay `theme.fg`.
 */
function accentFg(ctx: SegmentContext, color: ThemeColor, text: string): string {
	return `${sessionAccentAnsi(ctx) ?? theme.getFgAnsi(color)}${text}\x1b[39m`;
}

/** Left-truncate a path/label to `maxLen`, prefixing an ellipsis when clipped. */
function clampPathLength(pwd: string, maxLen: number): string {
	if (pwd.length <= maxLen) return pwd;
	const ellipsis = "…";
	return `${ellipsis}${pwd.slice(-Math.max(0, maxLen - ellipsis.length))}`;
}

/**
 * Leading glyph of a thinking-level display string (e.g. "◉ xhigh" → "◉").
 * Compact mode promotes this glyph to the model-segment icon so the level
 * stays visible without the verbose " · <level>" tail.
 */
function leadingGlyph(display: string): string {
	const space = display.indexOf(" ");
	return space === -1 ? display : display.slice(0, space);
}

/**
 * Single-field usage counter (`token_in`, `token_out`, `cache_read`,
 * `cache_write`). Hidden on zero, startup-placeholder aware, icon omitted when
 * the symbol preset leaves it empty — mirroring {@link withIcon}.
 */
function singleStatSegment(
	id: StatusLineSegmentId,
	field: "input" | "output" | "cacheRead" | "cacheWrite",
	iconKey: "input" | "output" | "cache",
	color: ThemeColor,
): StatusLineSegment {
	return {
		id,
		render(ctx) {
			const value = ctx.usageStats[field];
			if (!value) return { content: "", visible: false };
			const content = formatMetric({
				leading: theme.icon[iconKey] || undefined,
				value: formatNumber(value),
			});
			return { content: theme.fg(color, content ?? ""), visible: true };
		},
		describe(ctx) {
			const value = ctx.usageStats[field];
			if (!value) return null;
			return segView([span(formatNumber(value), color)], iconKey);
		},
	};
}

const NORMALIZED_SCRATCH_ROOTS: readonly string[] = (() => {
	const roots = new Set<string>([os.tmpdir(), path.join(os.homedir(), "tmp")]);
	if (process.platform === "win32") {
		const { TEMP, TMP, SystemRoot } = process.env;
		if (TEMP) roots.add(TEMP);
		if (TMP) roots.add(TMP);
		if (SystemRoot) roots.add(path.join(SystemRoot, "Temp"));
	} else {
		roots.add("/tmp");
		roots.add("/var/tmp");
		if (process.platform === "darwin") {
			roots.add("/private/tmp");
			roots.add("/private/var/tmp");
		}
	}
	return [...new Set(Array.from(roots, normalizePathForComparison))];
})();

interface ProjectDirDisplay {
	projectDir: string;
	homeDir: string;
	displayRoots: readonly string[] | undefined;
	scratch: boolean;
	displayPath: string;
}

let projectDirDisplay: ProjectDirDisplay | undefined;

/**
 * Retain only the active directory: switching cwd re-resolves its aliases,
 * while repeated paints reuse both scratch classification and root stripping.
 * Display roots remain normalized while the home directory is unchanged.
 */
function getProjectDirDisplay(projectDir: string): ProjectDirDisplay {
	const cached = projectDirDisplay;
	if (cached?.projectDir === projectDir) return cached;

	const homeDir = os.homedir();
	let displayRoots = cached?.homeDir === homeDir ? cached.displayRoots : undefined;
	const normalizedProjectDir = normalizePathForComparison(projectDir);
	let scratch = false;
	let displayPath = projectDir;
	for (const normalizedRoot of NORMALIZED_SCRATCH_ROOTS) {
		const relative = relativePathWithinNormalizedRoot(normalizedRoot, normalizedProjectDir);
		if (relative !== null) {
			scratch = true;
			displayPath = relative || projectDir;
			break;
		}
	}
	if (!scratch) {
		displayRoots ??= [path.join(homeDir, "Projects"), path.join(homeDir, "repos"), "/work"].map(
			normalizePathForComparison,
		);
		for (const root of displayRoots) {
			const relative = relativePathWithinNormalizedRoot(root, normalizedProjectDir);
			if (relative) {
				displayPath = relative;
				break;
			}
		}
	}
	projectDirDisplay = { projectDir, homeDir, displayRoots, scratch, displayPath };
	return projectDirDisplay;
}

// ═══════════════════════════════════════════════════════════════════════════
// Segment Implementations
// ═══════════════════════════════════════════════════════════════════════════

const piSegment: StatusLineSegment = {
	id: "pi",
	render(ctx) {
		if (ctx.focusedAgentId) {
			const icon = theme.icon.ghost ? `${theme.icon.ghost} ` : "";
			return {
				content: theme.fg("warning", `${icon}${ctx.focusedAgentId}`),
				visible: true,
			};
		}
		// Brand fg fades between dim gray (idle) and the accent (working) across
		// turn edges; the component samples the tween into `brandFgAnsi`.
		const fgAnsi = ctx.brandFgAnsi ?? theme.getFgAnsi("dim");
		// While a turn runs the brand icon becomes a braille spinner plus a
		// whole-unit turn timer (port of rust omp's status-band active brand).
		// No trailing pad: the group renderer owns inter-segment spacing, so a
		// trailing space here would double the gap at the first separator (#11103).
		const content =
			ctx.turnElapsedMs != null
				? `${brandSpinnerFrame(ctx.now?.getTime())} ${brandTimer(ctx.turnElapsedMs)}`
				: theme.icon.omp
					? theme.icon.omp
					: "";
		return { content: `${fgAnsi}${content}\x1b[39m`, visible: true };
	},
	describe(ctx) {
		if (ctx.focusedAgentId) return segView([span(ctx.focusedAgentId, "warning")], "ghost", "warning");
		// The dock's working row owns activity natively: the brand stays still.
		return segView([], "omp", "muted");
	},
};
/** Current braille-spinner glyph on the shared clock, at the Loader's 80ms cadence. */
function brandSpinnerFrame(nowMs = Date.now()): string {
	const frames = theme.getSpinnerFrames("activity");
	return frames[Math.floor(nowMs / SPINNER_ADVANCE_MS) % frames.length] ?? "";
}

/** Turn timer in omp's brand format: whole seconds → minutes → hours (capped at 99h). */
function brandTimer(elapsedMs: number): string {
	const seconds = Math.floor(elapsedMs / 1000);
	if (seconds < 60) return `${seconds}s`;
	if (seconds < 3600) return `${Math.floor(seconds / 60)}m`;
	return `${Math.min(99, Math.floor(seconds / 3600))}h`;
}

const statusSegment: StatusLineSegment = {
	id: "status",
	render(ctx) {
		let text = "";
		for (const status of ctx.hookStatuses ?? []) {
			const sanitized = sanitizeStatusText(status);
			if (!sanitized) continue;
			text += text ? `${theme.sep.dot}${sanitized}` : sanitized;
		}
		return {
			content: text ? accentFg(ctx, "accent", text) : "",
			visible: text.length > 0,
		};
	},
	describe(ctx) {
		let text = "";
		for (const status of ctx.hookStatuses ?? []) {
			const sanitized = sanitizeStatusText(status);
			if (!sanitized) continue;
			text += text ? `${theme.sep.dot}${sanitized}` : sanitized;
		}
		return text ? segView([span(text, accentToken(ctx, "accent"))]) : null;
	},
};

/** Display name of the active model (`Claude ` prefix dropped). */
function modelDisplayName(ctx: SegmentContext): string {
	const state = ctx.session.state;
	const modelName = state.model?.name || state.model?.id || "no-model";
	return modelName.startsWith("Claude ") ? modelName.slice(7) : modelName;
}

/**
 * The thinking-effort word (`high`, `off`; `auto` until auto thinking resolves
 * a level), or undefined when the model has no thinking. Drives the native
 * model segment and the composer's effort chip.
 */
export function thinkingLevelWord(
	session: Pick<StatusLineSession, "state" | "isAutoThinking" | "autoResolvedThinkingLevel">,
): string | undefined {
	const state = session.state;
	if (!state.model?.thinking) return undefined;
	if (session.isAutoThinking) return session.autoResolvedThinkingLevel() ?? "auto";
	return state.thinkingLevel ?? ThinkingLevel.Off;
}

/** Thinking-level display ("◉ xhigh", "⟳ auto", …), or "" when hidden or unsupported. */
function modelThinkingDisplay(ctx: SegmentContext): string {
	const state = ctx.session.state;
	const opts = ctx.options.model ?? {};
	if (opts.showThinkingLevel === false || !state.model?.thinking) return "";
	if (ctx.session.isAutoThinking) {
		// Pending (no turn classified yet / classifying) shows a symbol-theme
		// question-box marker; once resolved it shows `<level>`.
		const resolved = ctx.session.autoResolvedThinkingLevel();
		return resolved
			? (theme.thinking[resolved as keyof Theme["thinking"]] ?? resolved)
			: `${theme.thinking.autoPending} auto`;
	}
	const level = state.thinkingLevel ?? ThinkingLevel.Off;
	return level === ThinkingLevel.Off
		? `${theme.status.disabled} off`
		: (theme.thinking[level as keyof Theme["thinking"]] ?? level);
}

/**
 * Advisor symbol, colored by the worst status in the roster: success = all
 * running, warning = quota-exhausted, error = failed, dim = everything
 * paused/no-model. Undefined when no advisor is configured.
 */
function modelAdvisorBadge(ctx: SegmentContext): { icon: string; color: ThemeColor } | undefined {
	// Optional chaining: lightweight session doubles (test mocks) that don't
	// implement getAdvisorStatusOverview skip the badge instead of crashing.
	const advisorStats = ctx.session.getAdvisorStatusOverview?.();
	if (!advisorStats?.configured || advisorStats.advisors.length === 0) return undefined;
	const statuses = advisorStats.advisors.map(a => a.status);
	const color: ThemeColor = statuses.includes("error")
		? "error"
		: statuses.includes("quota_exhausted")
			? "warning"
			: statuses.includes("running")
				? "success"
				: "dim";
	// Closed eye once every advisor has finished reviewing the yielded
	// turn — no more comments until a new primary turn starts.
	const allYielded = advisorStats.advisors.every(a => a.yielded);
	const icon = allYielded ? theme.icon.advisorClosed || theme.icon.advisor : theme.icon.advisor;
	return icon ? { icon, color } : undefined;
}

const modelSegment: StatusLineSegment = {
	id: "model",
	render(ctx) {
		const modelName = modelDisplayName(ctx);
		const thinkingDisplay = modelThinkingDisplay(ctx);

		// Compact mode swaps the model icon for the thinking-level glyph and drops
		// the " · <level>" tail, keeping the level visible as a single icon.
		const compact = ctx.compactThinkingLevel && thinkingDisplay !== "";
		const modelIcon = compact ? leadingGlyph(thinkingDisplay) : theme.icon.model;

		// Fast-mode icon and thinking-level suffix trail the model name and are
		// colored together with it as `statusLineModel`. The advisor symbol sits
		// between the name and that tail, so it reads as a distinct marker.
		// theme.fg resets only the fg, so the spans are concatenated (not
		// nested) to keep each color intact.
		let tail = "";
		if (ctx.session.isFastModeActive() && theme.icon.fast) {
			tail += ` ${theme.icon.fast}`;
		}
		if (!compact && thinkingDisplay) {
			tail += `${theme.sep.dot}${thinkingDisplay}`;
		}

		// `statusLineModel` is aliased to `accent` in many themes, so the badge
		// uses status colors to stay visibly distinct from the model name color.
		let content = accentFg(ctx, "statusLineModel", withIcon(modelIcon, modelName));
		// Per-advisor detail lives in `/advisor status`.
		const advisor = modelAdvisorBadge(ctx);
		if (advisor) content += theme.fg(advisor.color, ` ${advisor.icon}`);
		if (tail) {
			content += accentFg(ctx, "statusLineModel", tail);
		}

		// Anthropic usage-limit stage (wrap-up allowance or low priority): a
		// warning-colored badge so past-the-limit service is never mistaken for normal.
		const slowModeLabel = ctx.session.getAnthropicSlowModeLabel?.();
		if (slowModeLabel) content += theme.fg("warning", `${theme.sep.dot}${slowModeLabel}`);
		return { content, visible: true };
	},
	describe(ctx) {
		// Name, then the thinking level as a word in its level colour after a
		// quiet separator; the terminal draws the model icon.
		const token = accentToken(ctx, "statusLineModel");
		const spans: TspSpan[] = [span(modelDisplayName(ctx), token)];
		const advisor = modelAdvisorBadge(ctx);
		if (advisor) spans.push(span(` ${advisor.icon}`, advisor.color));
		if (ctx.session.isFastModeActive() && theme.icon.fast) spans.push(span(` ${theme.icon.fast}`, token));
		const level = ctx.options.model?.showThinkingLevel === false ? undefined : thinkingLevelWord(ctx.session);
		if (level !== undefined) spans.push(span(" · ", "dim"), span(level, thinkingLevelToken(level)));
		const slowModeLabel = ctx.session.getAnthropicSlowModeLabel?.();
		if (slowModeLabel) spans.push(span(`${theme.sep.dot}${slowModeLabel}`, "warning"));
		return segView(spans, "model", slowModeLabel ? "warning" : undefined);
	},
};

function formatGoalBudget(current: number, budget?: number): string {
	const used = formatNumber(current);
	if (budget === undefined) return used;
	return `${used}/${formatNumber(budget)}`;
}

/** Native twin of {@link renderGoalMode}: the status names its icon instead of drawing a glyph. */
function describeGoalMode(ctx: SegmentContext, mode: { enabled: boolean; paused: boolean }): SegmentView {
	const goal = ctx.session.getGoalModeState()?.goal;
	const status = goal?.status ?? (mode.paused ? "paused" : "active");
	let icon = "goal";
	let color: ThemeColor = "accent";
	switch (status) {
		case "paused":
			icon = "pause";
			color = "warning";
			break;
		case "complete":
			icon = "success";
			color = "success";
			break;
		case "budget-limited":
			icon = "warning";
			color = "warning";
			break;
		case "dropped":
			icon = "aborted";
			color = "dim";
			break;
		default:
			break;
	}
	let label = "Goal";
	if (ctx.goalStatusInFooter === true && goal) label += ` ${formatGoalBudget(goal.tokensUsed, goal.tokenBudget)}`;
	const token = color === "accent" ? accentToken(ctx, color) : color;
	return segView([span(label, token)], icon, toneOf(color));
}

function renderGoalMode(ctx: SegmentContext, mode: { enabled: boolean; paused: boolean }): RenderedSegment {
	const goal = ctx.session.getGoalModeState()?.goal;
	const status = goal?.status ?? (mode.paused ? "paused" : "active");

	let icon: string = theme.icon.goal;
	let color: ThemeColor = "accent";
	switch (status) {
		case "paused":
			icon = theme.icon.pause || theme.symbol("status.pending");
			color = "warning";
			break;
		case "complete":
			icon = theme.symbol("status.success");
			color = "success";
			break;
		case "budget-limited":
			icon = theme.symbol("status.warning");
			color = "warning";
			break;
		case "dropped":
			icon = theme.symbol("status.aborted");
			color = "dim";
			break;
		default:
			break;
	}

	const parts: string[] = [withIcon(icon, "Goal")];
	const showBudget = ctx.goalStatusInFooter === true;
	if (showBudget && goal) {
		parts.push(formatGoalBudget(goal.tokensUsed, goal.tokenBudget));
	}
	return {
		content: color === "accent" ? accentFg(ctx, color, parts.join(" ")) : theme.fg(color, parts.join(" ")),
		visible: true,
	};
}

function formatLoopLimit(
	limit: NonNullable<SegmentContext["loopMode"]>["limit"],
	nowMs = Date.now(),
): string | undefined {
	if (!limit) return undefined;
	if (limit.kind === "iterations") return `${limit.remaining}/${limit.initial}`;

	const totalSeconds = Math.max(0, Math.ceil((limit.deadlineMs - nowMs) / 1_000));
	const hours = Math.floor(totalSeconds / 3_600);
	const minutes = Math.floor((totalSeconds % 3_600) / 60);
	const seconds = totalSeconds % 60;
	if (hours > 0) return `${hours}h${minutes > 0 ? `${minutes}m` : ""} left`;
	if (minutes > 0) return `${minutes}m${seconds > 0 ? `${seconds}s` : ""} left`;
	return `${seconds}s left`;
}

const modeSegment: StatusLineSegment = {
	id: "mode",
	render(ctx) {
		const pauseSuffix = theme.icon.pause ? ` ${theme.icon.pause}` : " (paused)";

		const plan = ctx.planMode;
		if (plan && (plan.enabled || plan.paused)) {
			const label = plan.paused ? `Plan${pauseSuffix}` : "Plan";
			const content = withIcon(theme.icon.plan, label);
			return {
				content: plan.paused ? theme.fg("warning", content) : accentFg(ctx, "accent", content),
				visible: true,
			};
		}

		const prewalk = ctx.prewalk;
		if (prewalk?.enabled) {
			const content = withIcon(theme.icon.prewalk, "Prewalk");
			return { content: accentFg(ctx, "accent", content), visible: true };
		}

		const goal = ctx.goalMode;
		if (goal && (goal.enabled || goal.paused)) {
			return renderGoalMode(ctx, goal);
		}

		const vibe = ctx.vibeMode;
		if (vibe?.enabled) {
			const content = withIcon(theme.icon.agents, "Vibe");
			return { content: accentFg(ctx, "accent", content), visible: true };
		}

		const loop = ctx.loopMode;
		if (loop) {
			const icon = loop.state === "paused" ? theme.icon.pause || theme.icon.loop : theme.icon.loop;
			const color: ThemeColor = loop.state === "paused" ? "warning" : "customMessageLabel";
			const stateLabel = loop.state === "waiting" ? "next prompt repeats" : loop.state;
			const label = `Loop${loop.state === "waiting" ? ":" : ""} ${stateLabel}`;
			const parts = [withIcon(icon, label)];
			const limit = formatLoopLimit(loop.limit, ctx.now?.getTime());
			if (limit) parts.push(limit);
			if (loop.condition) {
				parts.push(summarizeLoopCondition(loop.condition, TRUNCATE_LENGTHS.SHORT));
			}
			return { content: theme.fg(color, parts.join(" ")), visible: true };
		}

		return { content: "", visible: false };
	},
	describe(ctx) {
		const plan = ctx.planMode;
		if (plan && (plan.enabled || plan.paused)) {
			return plan.paused
				? segView([span("Plan (paused)", "warning")], "plan", "warning")
				: segView([span("Plan", accentToken(ctx, "accent"))], "plan");
		}
		if (ctx.prewalk?.enabled) return segView([span("Prewalk", accentToken(ctx, "accent"))], "prewalk");
		const goal = ctx.goalMode;
		if (goal && (goal.enabled || goal.paused)) return describeGoalMode(ctx, goal);
		if (ctx.vibeMode?.enabled) return segView([span("Vibe", accentToken(ctx, "accent"))], "agents");
		const loop = ctx.loopMode;
		if (loop) {
			const paused = loop.state === "paused";
			const stateLabel = loop.state === "waiting" ? "next prompt repeats" : loop.state;
			const parts = [`Loop${loop.state === "waiting" ? ":" : ""} ${stateLabel}`];
			const limit = formatLoopLimit(loop.limit, ctx.now?.getTime());
			if (limit) parts.push(limit);
			if (loop.condition) parts.push(summarizeLoopCondition(loop.condition, TRUNCATE_LENGTHS.SHORT));
			return segView(
				[span(parts.join(" "), paused ? "warning" : "customMessageLabel")],
				paused ? "pause" : "loop",
				paused ? "warning" : undefined,
			);
		}
		return null;
	},
};

const pathSegment: StatusLineSegment = {
	id: "path",
	render(ctx) {
		const opts = ctx.options.path ?? {};
		const stripPrefix = opts.stripWorkPrefix !== false;

		// Linked git worktree: the on-disk path nests the worktree base, the
		// project, and a worktree dir that usually duplicates the branch (already
		// shown by the git segment). Collapse to the project name, appending the
		// worktree dir only when it diverges from the branch.
		if (stripPrefix && ctx.worktree) {
			const { projectName, worktreeName } = ctx.worktree;
			const label = ctx.git.branch === worktreeName ? projectName : `${projectName}/${worktreeName}`;
			const text = fileHyperlink(getProjectDir(), clampPathLength(label, opts.maxLength ?? 40));
			const content = withIcon(theme.icon.worktree, text);
			return { content: theme.fg("statusLinePath", content), visible: true };
		}

		const projectDir = ctx.activeRepo?.cwd ?? getProjectDir();
		const { scratch, displayPath } = getProjectDirDisplay(projectDir);
		let pwd = stripPrefix ? displayPath : projectDir;
		const repoSuffix = ctx.activeRepo ? ` ↳ ${ctx.activeRepo.relativeRepoRoot}` : "";
		if (opts.abbreviate !== false) {
			pwd = shortenPath(pwd);
		}

		pwd = clampPathLength(pwd, opts.maxLength ?? 40);

		const showScratchIcon = scratch && stripPrefix;
		const icon = showScratchIcon ? theme.icon.scratchFolder : theme.icon.folder;
		const text = `${fileHyperlink(projectDir, pwd)}${repoSuffix}`;
		const content = withIcon(icon, text);
		return { content: theme.fg("statusLinePath", content), visible: true };
	},
	describe(ctx) {
		const opts = ctx.options.path ?? {};
		const stripPrefix = opts.stripWorkPrefix !== false;
		// The parent dims and the leaf reads strong; a click opens the directory.
		if (stripPrefix && ctx.worktree) {
			const { projectName, worktreeName } = ctx.worktree;
			const label = ctx.git.branch === worktreeName ? projectName : `${projectName}/${worktreeName}`;
			return segView(pathSpans(label), "worktree");
		}
		const projectDir = ctx.activeRepo?.cwd ?? getProjectDir();
		const { scratch, displayPath } = getProjectDirDisplay(projectDir);
		let pwd = stripPrefix ? displayPath : projectDir;
		if (opts.abbreviate !== false) pwd = shortenPath(pwd);
		// `maxLength` is the user's configured cap; width fitting is the terminal's.
		if (opts.maxLength !== undefined) pwd = clampPathLength(pwd, opts.maxLength);
		const spans = pathSpans(pwd);
		if (ctx.activeRepo) spans.push(span(` ↳ ${ctx.activeRepo.relativeRepoRoot}`, "statusLinePath dim"));
		return segView(spans, scratch && stripPrefix ? "scratch-folder" : "folder");
	},
};

/** A path as its dim parent directories and its strong leaf. */
function pathSpans(value: string): TspSpan[] {
	const slash = value.lastIndexOf("/", value.length - 2);
	if (slash < 0 || slash + 1 >= value.length) return [span(value, "statusLinePath strong")];
	const leaf = span(value.slice(slash + 1), "statusLinePath strong");
	return [span(value.slice(0, slash + 1), "statusLinePath dim"), leaf];
}

const gitSegment: StatusLineSegment = {
	id: "git",
	render(ctx) {
		const { branch, status } = ctx.git;
		if (!branch && !status) return { content: "", visible: false };

		const opts = ctx.options.git ?? {};
		const gitStatus = status;
		const isDirty = gitStatus && (gitStatus.staged > 0 || gitStatus.unstaged > 0 || gitStatus.untracked > 0);

		const showBranch = opts.showBranch !== false;
		let content = "";
		if (showBranch && branch) {
			content = withIcon(theme.icon.branch, branch);
		}

		// Add status indicators
		if (gitStatus) {
			const indicators: string[] = [];
			if (opts.showUnstaged !== false && gitStatus.unstaged > 0) {
				indicators.push(theme.fg("statusLineDirty", `*${gitStatus.unstaged}`));
			}
			if (opts.showStaged !== false && gitStatus.staged > 0) {
				indicators.push(theme.fg("statusLineStaged", `+${gitStatus.staged}`));
			}
			if (opts.showUntracked !== false && gitStatus.untracked > 0) {
				indicators.push(theme.fg("statusLineUntracked", `?${gitStatus.untracked}`));
			}
			if (indicators.length > 0) {
				const indicatorText = indicators.join(" ");
				if (!content && showBranch === false) {
					content = withIcon(theme.icon.git, indicatorText);
				} else {
					content += content ? ` ${indicatorText}` : indicatorText;
				}
			}
		}

		if (!content) return { content: "", visible: false };

		const colorName = isDirty ? "statusLineGitDirty" : "statusLineGitClean";
		return { content: theme.fg(colorName, content), visible: true };
	},
	describe(ctx) {
		const { branch, status } = ctx.git;
		if (!branch && !status) return null;
		const opts = ctx.options.git ?? {};
		const isDirty = status !== null && (status.staged > 0 || status.unstaged > 0 || status.untracked > 0);
		const colorName = isDirty ? "statusLineGitDirty" : "statusLineGitClean";
		const showBranch = opts.showBranch !== false;
		const spans: TspSpan[] = [];
		if (showBranch && branch) spans.push(span(branch, colorName));
		if (status) {
			// Spans join as one text: each count after the branch or a previous count leads with a space.
			const push = (text: string, token: string): void => {
				spans.push(span(spans.length > 0 ? ` ${text}` : text, token));
			};
			if (opts.showUnstaged !== false && status.unstaged > 0) push(`*${status.unstaged}`, "statusLineDirty");
			if (opts.showStaged !== false && status.staged > 0) push(`+${status.staged}`, "statusLineStaged");
			if (opts.showUntracked !== false && status.untracked > 0) push(`?${status.untracked}`, "statusLineUntracked");
		}
		if (spans.length === 0) return null;
		return segView(spans, showBranch && branch ? "branch" : "git", isDirty ? "warning" : undefined);
	},
};

const prSegment: StatusLineSegment = {
	id: "pr",
	render(ctx) {
		const { pr } = ctx.git;
		if (!pr) return { content: "", visible: false };

		const label = withIcon(theme.icon.pr, `#${pr.number}`);
		const content = TERMINAL.hyperlinks ? `\x1b]8;;${pr.url}\x07${label}\x1b]8;;\x07` : label;
		return { content: accentFg(ctx, "accent", content), visible: true };
	},
	describe(ctx) {
		const { pr } = ctx.git;
		if (!pr) return null;
		return segView([span(`#${pr.number}`, `${accentToken(ctx, "accent")} link`, { href: pr.url })], "pr");
	},
};

const subagentsSegment: StatusLineSegment = {
	id: "subagents",
	render(ctx) {
		if (ctx.subagentCount === 0) {
			return { content: "", visible: false };
		}
		const content = withIcon(theme.icon.agents, `${ctx.subagentCount}`);
		return { content: theme.fg("statusLineSubagents", content), visible: true };
	},
	describe(ctx) {
		if (ctx.subagentCount === 0) return null;
		return segView([span(`${ctx.subagentCount}`, "statusLineSubagents")], "agents");
	},
};

const tokenInSegment: StatusLineSegment = singleStatSegment("token_in", "input", "input", "statusLineSpend");

const tokenOutSegment: StatusLineSegment = singleStatSegment("token_out", "output", "output", "statusLineOutput");

const tokenTotalSegment: StatusLineSegment = {
	id: "token_total",
	render(ctx) {
		// Excludes cacheRead: that field re-reads the full cached context every
		// turn, making the cumulative sum N×context_size. Orchestration cache read
		// follows the same rule; orchestration input/output remain in the total so
		// provider-side service work is preserved without labeling it prompt input.
		const { input, output, cacheWrite, orchestrationInput, orchestrationOutput } = ctx.usageStats;
		const total = input + output + cacheWrite + orchestrationInput + orchestrationOutput;
		if (!total) return { content: "", visible: false };

		const content = formatMetric({
			leading: theme.icon.tokens || undefined,
			value: formatNumber(total),
		});
		return { content: theme.fg("statusLineSpend", content ?? ""), visible: true };
	},
	describe(ctx) {
		const { input, output, cacheWrite, orchestrationInput, orchestrationOutput } = ctx.usageStats;
		const total = input + output + cacheWrite + orchestrationInput + orchestrationOutput;
		if (!total) return null;
		return segView([span(formatNumber(total), "statusLineSpend")], "tokens");
	},
};

const tokenRateSegment: StatusLineSegment = {
	id: "token_rate",
	render(ctx) {
		const { tokensPerSecond } = ctx.usageStats;
		if (!tokensPerSecond) return { content: "", visible: false };

		const content = formatMetric({
			leading: theme.icon.throughput || undefined,
			value: `${tokensPerSecond.toFixed(1)} tok/s`,
		});
		return { content: theme.fg("statusLineOutput", content ?? ""), visible: true };
	},
	describe(ctx) {
		const { tokensPerSecond } = ctx.usageStats;
		if (!tokensPerSecond) return null;
		// The terminal eases the readout between updates.
		return {
			spans: [],
			icon: "throughput",
			motion: [node("rate", { value: Number(tokensPerSecond.toFixed(1)), unit: "tok/s" }, undefined, "rate")],
		};
	},
};

/** Billing summary for the `cost` segment, or undefined when there is nothing to bill. */
function costSummary(ctx: SegmentContext): string | undefined {
	const { cost, premiumRequests } = ctx.usageStats;
	// `cost` folds in completed task results; show the session's own spend and
	// the subagent tree separately. The hub-projected tree total also covers
	// grandchildren and running/async agents, but it lags persisted-roster
	// hydration after resume, so the task-result sum is its floor.
	const taskResultCost = ctx.usageStats.subagentCost ?? 0;
	const ownCost = Math.max(0, cost - taskResultCost);
	const subagentCost = Math.max(ctx.subagentTreeCost ?? 0, taskResultCost);
	const advisorCost = ctx.session.getAdvisorCost?.() ?? 0;
	const state = ctx.session.state;
	const pricingPeriod = state.model?.cost
		? getTimeBasedPricingPeriod(state.model.cost, ctx.now?.getTime())
		: undefined;
	const usingSubscription = state.model ? (ctx.session.modelRegistry?.isUsingOAuth(state.model) ?? false) : false;
	// Resolve the advisor subscription flag lazily: with no active advisor
	// it walks the whole model catalog (getAvailable → hasAuth per provider
	// → credential-file reads), and the status line re-renders at the
	// working-spinner cadence, so an eager per-frame probe pinned CPU (#10129).
	return formatBillingSummary(
		{
			cost: ownCost,
			subagentCost,
			usingSubscription,
			premiumRequests,
			fractionDigits: 2,
			pricingPeriod,
			advisor: advisorCost
				? { cost: advisorCost, usingSubscription: ctx.session.isAdvisorUsingSubscription?.() ?? false }
				: undefined,
		},
		theme,
	);
}

const costSegment: StatusLineSegment = {
	id: "cost",
	render(ctx) {
		const billing = costSummary(ctx);
		if (!billing) return { content: "", visible: false };

		return { content: theme.fg("statusLineCost", billing), visible: true };
	},
	describe(ctx) {
		const billing = costSummary(ctx);
		return billing ? segView([span(billing, "statusLineCost")]) : null;
	},
};

const contextPctSegment: StatusLineSegment = {
	id: "context_pct",
	render(ctx) {
		const pct = ctx.contextPercent;
		const window = ctx.contextWindow;

		const color = getContextUsageThemeColor(getContextUsageLevel(pct ?? 0, window));
		// Async-compaction indicator: pulse the auto icon while a background
		// speculation runs, hold it in accent once a result is armed.
		let autoIcon = "";
		if (ctx.autoCompactEnabled && theme.icon.auto) {
			const speculation = ctx.compactionSpeculation;
			const accentIcon = accentFg(ctx, "accent", theme.icon.auto);
			autoIcon = ` ${
				speculation === "running"
					? ctx.speculationBlinkOn
						? accentIcon
						: theme.fg("muted", theme.icon.auto)
					: speculation === "armed"
						? accentIcon
						: theme.fg(color, theme.icon.auto)
			}`;
		}
		// A known window with unknown usage (startup prepaint) shows the window alone.
		const text = theme.fg(
			color,
			pct === null && window > 0 ? formatNumber(window) : formatContextUsage(pct, window, ctx.contextTokens),
		);
		const content = withIcon(theme.icon.context, `${text}${autoIcon}`);

		return { content, visible: true };
	},
	describe(ctx) {
		const pct = ctx.contextPercent;
		const window = ctx.contextWindow;
		const level = getContextUsageLevel(pct ?? 0, window);
		const color = getContextUsageThemeColor(level);
		const spans: TspSpan[] = [
			span(
				pct === null && window > 0 ? formatNumber(window) : formatContextUsage(pct, window, ctx.contextTokens),
				color,
			),
		];
		if (ctx.autoCompactEnabled && theme.icon.auto) {
			// Async-compaction indicator: the terminal pulses the auto icon while a
			// background speculation runs; an armed result holds it in accent.
			const speculation = ctx.compactionSpeculation;
			if (speculation === "running") {
				spans.push(span(` ${theme.icon.auto}`, accentToken(ctx, "accent"), { fx: "pulse" }));
			} else {
				spans.push(span(` ${theme.icon.auto}`, speculation === "armed" ? accentToken(ctx, "accent") : color));
			}
		}
		return segView(spans, "context", getContextUsageTone(level));
	},
};

const contextTotalSegment: StatusLineSegment = {
	id: "context_total",
	render(ctx) {
		const window = ctx.contextWindow;
		if (!window) return { content: "", visible: false };
		return {
			content: theme.fg("statusLineContext", withIcon(theme.icon.context, formatNumber(window))),
			visible: true,
		};
	},
	describe(ctx) {
		const window = ctx.contextWindow;
		return window ? segView([span(formatNumber(window), "statusLineContext")], "context") : null;
	},
};

/**
 * Total time the agent was actively processing this session — the union of
 * every `agent_start`→`agent_end` window plus the currently-running window,
 * sourced from {@link SegmentContext.activeMs}. Idle wall-clock between turns
 * never accumulates, so the displayed total reflects how long the agent has
 * been working for the user, not how long the session has been open. Hidden
 * before the first second of activity to avoid flashing `0s` at session start.
 */
const timeSpentSegment: StatusLineSegment = {
	id: "time_spent",
	render(ctx) {
		if (ctx.activeMs < 1000) return { content: "", visible: false };
		return { content: withIcon(theme.icon.time, formatDuration(ctx.activeMs)), visible: true };
	},
	describe(ctx) {
		const running = ctx.turnElapsedMs != null;
		if (!running && ctx.activeMs < 1000) return null;
		// Ticks on the terminal's clock during a turn; frozen between turns.
		const elapsed = running
			? node("elapsed", { age: ctx.activeMs, format: "short" }, undefined, "timer")
			: node("elapsed", { age: ctx.activeMs, stopped: ctx.activeMs, format: "short" }, undefined, "timer");
		return { spans: [], icon: "time", motion: [elapsed] };
	},
};

/** Wall-clock label for the `time` segment. */
function formatClock(ctx: SegmentContext): string {
	const opts = ctx.options.time ?? {};
	const now = ctx.now ?? new Date();
	let hours = now.getHours();
	let suffix = "";
	if (opts.format === "12h") {
		suffix = hours >= 12 ? "pm" : "am";
		hours = hours % 12 || 12;
	}
	let timeStr = `${hours}:${now.getMinutes().toString().padStart(2, "0")}`;
	if (opts.showSeconds) timeStr += `:${now.getSeconds().toString().padStart(2, "0")}`;
	return timeStr + suffix;
}

const timeSegment: StatusLineSegment = {
	id: "time",
	render(ctx) {
		return { content: withIcon(theme.icon.time, formatClock(ctx)), visible: true };
	},
	describe(ctx) {
		return segView([span(formatClock(ctx))], "time");
	},
};

const sessionSegment: StatusLineSegment = {
	id: "session",
	render(ctx) {
		const sessionManager = ctx.session.sessionManager;
		const sessionId = sessionManager?.getSessionId?.();
		const display = sessionId?.slice(0, 8) || "new";

		return { content: withIcon(theme.icon.session, display), visible: true };
	},
	describe(ctx) {
		const sessionId = ctx.session.sessionManager?.getSessionId?.();
		return segView([span(sessionId?.slice(0, 8) || "new")], "session");
	},
};

/** Short (first-label) machine hostname; resolved once — `os.hostname()` is a syscall per call. */
let shortHostname: string | undefined;

const hostnameSegment: StatusLineSegment = {
	id: "hostname",
	render(ctx) {
		const name = ctx.hostname ?? (shortHostname ??= os.hostname().split(".")[0]);
		const content = withIcon(theme.icon.host, name);
		const ansi = sessionAccentAnsi(ctx);
		return { content: ansi ? `${ansi}${content}\x1b[39m` : content, visible: true };
	},
	describe(ctx) {
		const name = ctx.hostname ?? (shortHostname ??= os.hostname().split(".")[0]);
		return segView([span(name, sessionAccentAnsi(ctx) ? "accent" : undefined)], "host");
	},
};

const cacheReadSegment: StatusLineSegment = singleStatSegment("cache_read", "cacheRead", "cache", "statusLineSpend");

const cacheWriteSegment: StatusLineSegment = singleStatSegment(
	"cache_write",
	"cacheWrite",
	"cache",
	"statusLineOutput",
);

const cacheHitSegment: StatusLineSegment = {
	id: "cache_hit",
	render(ctx) {
		const { cacheRead, cacheWrite, input } = ctx.usageStats;
		if (!cacheRead) return { content: "", visible: false };

		// Hit rate = cacheRead / total prompt tokens. The prompt is the sum of
		// cacheRead (served from cache), cacheWrite (newly cached this turn) and
		// input (uncached). Including uncached input keeps the denominator honest
		// for Anthropic/OpenRouter; DeepSeek reports its miss as input with
		// cacheWrite 0, so this still yields hit/(hit+miss).
		const total = cacheRead + cacheWrite + input;

		const rate = (cacheRead / total) * 100;
		const rateStr = rate.toFixed(2);

		const parts: string[] = [theme.icon.cache];
		parts.push(theme.fg("statusLineSpend", `${rateStr}%`));
		return { content: parts.join(" "), visible: true };
	},
	describe(ctx) {
		const { cacheRead, cacheWrite, input } = ctx.usageStats;
		if (!cacheRead) return null;
		const rate = (cacheRead / (cacheRead + cacheWrite + input)) * 100;
		return segView([span(`${rate.toFixed(2)}%`, "statusLineSpend")], "cache");
	},
};

const sessionNameSegment: StatusLineSegment = {
	id: "session_name",
	render(ctx) {
		const sessionManager = ctx.session.sessionManager;
		const name = sessionManager?.getSessionName() || ctx.previewTitle;
		if (!name) return { content: "", visible: false };

		const content = sanitizeStatusText(name);
		return { content: accentFg(ctx, "accent", content), visible: true };
	},
	describe(ctx) {
		const name = ctx.session.sessionManager?.getSessionName() || ctx.previewTitle;
		const content = name ? sanitizeStatusText(name) : "";
		// Plain: the terminal styles the title by its role.
		return content ? segView([span(content)]) : null;
	},
};

const collabSegment: StatusLineSegment = {
	id: "collab",
	render(ctx) {
		if (!ctx.collab) return { content: "", visible: false };
		const participants = `${ctx.collab.participantCount}`;
		const label = ctx.collab.role === "host" ? `⇄ collab:${participants}` : `⇄ collab guest:${participants}`;
		return { content: accentFg(ctx, "accent", label), visible: true };
	},
	describe(ctx) {
		if (!ctx.collab) return null;
		const participants = `${ctx.collab.participantCount}`;
		const label = ctx.collab.role === "host" ? `collab:${participants}` : `collab guest:${participants}`;
		return segView([span(label, accentToken(ctx, "accent"))], "collab");
	},
};

const streamSegment: StatusLineSegment = {
	id: "stream",
	render(ctx) {
		const badges: string[] = [];
		if (ctx.stream) badges.push(`● LIVE ${ctx.stream.viewers}`);
		if (ctx.recording) badges.push("● REC");
		if (badges.length === 0) return { content: "", visible: false };
		return { content: theme.fg("thinkingHigh", badges.join(" ")), visible: true };
	},
	describe(ctx) {
		const badges: string[] = [];
		if (ctx.stream) badges.push(`LIVE ${ctx.stream.viewers}`);
		if (ctx.recording) badges.push("REC");
		if (badges.length === 0) return null;
		return segView([span(badges.join(" "), "thinkingHigh")], "live", "error");
	},
};

/**
 * Vim modal state, in the shape Vim itself uses: the mode, the half-typed command echoed beside it
 * (`showcmd`), and the Visual selection size. Hidden entirely when `tui.vimMode` is off, so it
 * costs nothing for everyone else. `tui.vimModeDisplay` picks the mode's presentation.
 */
const VIM_MODE_LABELS: Record<NonNullable<SegmentContext["vim"]>["mode"], string> = {
	insert: "INSERT",
	normal: "NORMAL",
	visual: "VISUAL",
	"visual-line": "V-LINE",
	replace: "REPLACE",
};

/**
 * The `icon` display resolves through the theme's symbol map, so each mode picks up the active
 * symbol preset (nerd / unicode / ascii) and honours per-theme `symbols` overrides — same mechanism
 * as every other status-line icon. Glyph choices live in `SYMBOL_PRESETS`.
 */
const VIM_MODE_ICON_KEYS: Record<NonNullable<SegmentContext["vim"]>["mode"], SymbolKey> = {
	insert: "icon.vimInsert",
	normal: "icon.vimNormal",
	visual: "icon.vimVisual",
	"visual-line": "icon.vimVisualLine",
	replace: "icon.vimReplace",
};

const VIM_MODE_COLORS: Record<NonNullable<SegmentContext["vim"]>["mode"], ThemeColor> = {
	insert: "success",
	normal: "accent",
	visual: "warning",
	"visual-line": "warning",
	replace: "accent",
};

const vimSegment: StatusLineSegment = {
	id: "vim",
	render(ctx) {
		const vim = ctx.vim;
		if (!vim || vim.display === "none") return { content: "", visible: false };
		let label = vim.display === "icon" ? theme.symbol(VIM_MODE_ICON_KEYS[vim.mode]) : VIM_MODE_LABELS[vim.mode];
		// The selection height rides along in both presentations — it is the one part of the
		// indicator with no other on-screen source.
		if (vim.selectedLines > 1) label += ` ${vim.selectedLines}L`;
		const content = theme.fg(VIM_MODE_COLORS[vim.mode], label);
		// Pending echoes to the right of the mode, dimmed, exactly like Vim's showcmd.
		const pending = vim.pending ? theme.fg("muted", ` ${vim.pending}`) : "";
		return { content: `${content}${pending}`, visible: true };
	},
	describe(ctx) {
		const vim = ctx.vim;
		if (!vim || vim.display === "none") return null;
		const color = VIM_MODE_COLORS[vim.mode];
		const spans: TspSpan[] = [];
		const lines = vim.selectedLines > 1 ? `${vim.selectedLines}L` : "";
		if (vim.display === "icon") {
			if (lines) spans.push(span(lines, color));
		} else {
			spans.push(span(lines ? `${VIM_MODE_LABELS[vim.mode]} ${lines}` : VIM_MODE_LABELS[vim.mode], color));
		}
		if (vim.pending) spans.push(span(` ${vim.pending}`, "muted"));
		return segView(spans, vim.display === "icon" ? `vim-${vim.mode}` : undefined, toneOf(color));
	},
};

function pickUsageColor(percent: number): "muted" | "warning" | "error" {
	if (percent >= 80) return "error";
	if (percent >= 50) return "warning";
	return "muted";
}

/**
 * One quota window (`5h`, `1d`, `7d`, `mo`). The integer policy (round vs
 * floor) and the reset unit (minutes vs hours) stay explicit at each call site:
 * monthly floors like the Cursor/OpenCode dashboards, the rest round, and
 * short windows reset in minutes while long windows reset in hours.
 */
function formatQuotaWindow(
	ctx: SegmentContext,
	label: string,
	percent: number,
	reset: number | undefined,
	resetUnit: "m" | "h",
	integer: "round" | "floor",
): string {
	const whole = integer === "floor" ? Math.floor(percent) : Math.round(percent);
	const pctText = theme.fg(pickUsageColor(percent), `${whole}%`);
	const resetText = reset !== undefined ? theme.fg("muted", ` (${formatUsageReset(reset, resetUnit)})`) : "";
	return `${label} ${pctText}${resetText}`;
}

/** Native twin of {@link formatQuotaWindow}. */
function describeQuotaWindow(
	label: string,
	percent: number,
	reset: number | undefined,
	resetUnit: "m" | "h",
	integer: "round" | "floor",
): TspSpan[] {
	const whole = integer === "floor" ? Math.floor(percent) : Math.round(percent);
	const spans = [span(`${label} `), span(`${whole}%`, pickUsageColor(percent))];
	if (reset !== undefined) spans.push(span(` (${formatUsageReset(reset, resetUnit)})`, "muted"));
	return spans;
}

function formatUsageReset(value: number, unit: "m" | "h"): string {
	if (unit === "m") {
		// Short-window reset timers retain minute precision.
		if (value < 60) return `${value}m`;
		const hours = Math.floor(value / 60);
		const mins = value % 60;
		return mins > 0 ? `${hours}h ${mins}m` : `${hours}h`;
	}
	// total hours (7d window: max 168)
	if (value < 24) return `${value}h`;
	const days = Math.floor(value / 24);
	const hours = value % 24;
	return hours > 0 ? `${days}d ${hours}h` : `${days}d`;
}

/** Expiring saved resets outrank the usable/unusable color: red within 24 hours, yellow within 7 days. */
function resetCreditsColor(resets: NonNullable<NonNullable<SegmentContext["usage"]>["resetCredits"]>): ThemeColor {
	if (resets.expiring) return resets.expiring.tier === "imminent" ? "error" : "warning";
	return resets.redeemableCount > 0 ? "success" : "warning";
}

const usageSegment: StatusLineSegment = {
	id: "usage",
	render(ctx) {
		const u = ctx.usage;
		if (!u || (!u.fiveHour && !u.daily && !u.sevenDay && !u.monthly && !u.resetCredits)) {
			return { content: "", visible: false };
		}
		const parts: string[] = [];
		if (u.tier) {
			const tier = truncateToWidth(sanitizeStatusText(u.tier), TRUNCATE_LENGTHS.SHORT);
			if (tier) parts.push(accentFg(ctx, "accent", tier));
		}
		if (u.fiveHour) {
			parts.push(formatQuotaWindow(ctx, "5h", u.fiveHour.percent, u.fiveHour.resetMinutes, "m", "round"));
		}
		if (u.daily) {
			parts.push(formatQuotaWindow(ctx, "1d", u.daily.percent, u.daily.resetMinutes, "m", "round"));
		}
		if (u.sevenDay) {
			parts.push(formatQuotaWindow(ctx, "7d", u.sevenDay.percent, u.sevenDay.resetHours, "h", "round"));
		}
		if (u.monthly) {
			// Monthly-subscription providers only (the normalizer gates the class).
			// Cursor and QwenCloud floor used percents upstream (Cursor's dashboard
			// shows 1.88 → "1% used"; OpenCode's endpoint emits floored integers).
			parts.push(formatQuotaWindow(ctx, "mo", u.monthly.percent, u.monthly.resetHours, "h", "floor"));
		}
		if (u.resetCredits) {
			const resets = u.resetCredits;
			let resetText = `✦ ${resets.bankedCount}`;
			if (resets.redeemableCount !== resets.bankedCount) {
				resetText += ` (${resets.redeemableCount} usable)`;
			}
			if (resets.expiryHours !== undefined) {
				const expiring = resets.expiring ? `▲ ${resets.expiring.count} ` : "";
				resetText += ` ${expiring}exp ${formatUsageReset(resets.expiryHours, "h")}`;
			} else if (resets.expired) {
				resetText += " expired";
			}
			if (resets.redeemableCount === 0 && resets.unavailableReason) {
				const reason = truncateToWidth(sanitizeStatusText(resets.unavailableReason), TRUNCATE_LENGTHS.SHORT);
				if (reason) resetText += ` ${reason}`;
			}
			parts.push(theme.fg(resetCreditsColor(resets), resetText));
		}
		const content = withIcon(theme.icon.time, parts.join(theme.sep.dot));
		return { content, visible: true };
	},
	describe(ctx) {
		const u = ctx.usage;
		if (!u || (!u.fiveHour && !u.daily && !u.sevenDay && !u.monthly && !u.resetCredits)) return null;
		const parts: TspSpan[][] = [];
		if (u.tier) {
			const tier = sanitizeStatusText(u.tier);
			if (tier) parts.push([span(tier, accentToken(ctx, "accent"))]);
		}
		if (u.fiveHour) {
			parts.push(describeQuotaWindow("5h", u.fiveHour.percent, u.fiveHour.resetMinutes, "m", "round"));
		}
		if (u.daily) parts.push(describeQuotaWindow("1d", u.daily.percent, u.daily.resetMinutes, "m", "round"));
		if (u.sevenDay) {
			parts.push(describeQuotaWindow("7d", u.sevenDay.percent, u.sevenDay.resetHours, "h", "round"));
		}
		if (u.monthly) parts.push(describeQuotaWindow("mo", u.monthly.percent, u.monthly.resetHours, "h", "floor"));
		if (u.resetCredits) {
			const resets = u.resetCredits;
			let resetText = `✦ ${resets.bankedCount}`;
			if (resets.redeemableCount !== resets.bankedCount) resetText += ` (${resets.redeemableCount} usable)`;
			if (resets.expiryHours !== undefined) {
				const expiring = resets.expiring ? `▲ ${resets.expiring.count} ` : "";
				resetText += ` ${expiring}exp ${formatUsageReset(resets.expiryHours, "h")}`;
			} else if (resets.expired) resetText += " expired";
			if (resets.redeemableCount === 0 && resets.unavailableReason) {
				const reason = sanitizeStatusText(resets.unavailableReason);
				if (reason) resetText += ` ${reason}`;
			}
			parts.push([span(resetText, resetCreditsColor(resets))]);
		}
		const spans: TspSpan[] = [];
		for (const part of parts) {
			if (spans.length > 0) spans.push(span(theme.sep.dot, "dim"));
			spans.push(...part);
		}
		return segView(spans, "time");
	},
};

// ═══════════════════════════════════════════════════════════════════════════
// Segment Registry
// ═══════════════════════════════════════════════════════════════════════════

export const SEGMENTS: Record<StatusLineSegmentId, StatusLineSegment> = {
	pi: piSegment,
	status: statusSegment,
	model: modelSegment,
	mode: modeSegment,
	path: pathSegment,
	git: gitSegment,
	pr: prSegment,
	subagents: subagentsSegment,
	token_in: tokenInSegment,
	token_out: tokenOutSegment,
	token_total: tokenTotalSegment,
	token_rate: tokenRateSegment,
	cost: costSegment,
	context_pct: contextPctSegment,
	context_total: contextTotalSegment,
	time_spent: timeSpentSegment,
	time: timeSegment,
	session: sessionSegment,
	hostname: hostnameSegment,
	cache_read: cacheReadSegment,
	cache_write: cacheWriteSegment,
	cache_hit: cacheHitSegment,
	session_name: sessionNameSegment,
	usage: usageSegment,
	collab: collabSegment,
	stream: streamSegment,
	vim: vimSegment,
};

export function renderSegment(id: StatusLineSegmentId, ctx: SegmentContext): RenderedSegment {
	const segment = SEGMENTS[id];
	if (!segment) {
		return { content: "", visible: false };
	}
	return segment.render(ctx);
}

/** Native description of one segment; null when it is hidden or unknown. */
export function describeSegment(id: StatusLineSegmentId, ctx: SegmentContext): SegmentView | null {
	return SEGMENTS[id]?.describe(ctx) ?? null;
}

export const ALL_SEGMENT_IDS: StatusLineSegmentId[] = Object.keys(SEGMENTS) as StatusLineSegmentId[];
