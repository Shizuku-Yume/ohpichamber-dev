/**
 * The async background jobs of a session as {@link JobsSheet}: the dismissable
 * sheet the native jobs pill and `/jobs` open. A master–detail split lists
 * every job of the session's agent and its subagents as a tree (see
 * {@link buildJobTree}) beside the selected one's status, command (drawn
 * live from its shell trace: what runs now, ran and failed), facts (cwd, live
 * pids, exit code, artifact) and live output, read from wherever the command
 * sends it: its own stdout, a pipe a later stage holds back, a file it
 * redirects into. The command's steps pick the output (see {@link ShellSteps}).
 */
import type { ShellTrace, ShellVizPreferences, ShellVizPresentation, TspSpan, TspTone } from "@oh-my-pi/pi-wire";
import { formatDuration, sanitizeText, spillUrl } from "@oh-my-pi/pi-utils";
import { jobDisplayLabel } from "../tools/job-label";
import type { Component } from "../tui";
import { matchesSelectCancel, matchesSelectDown, matchesSelectUp } from "../keybinding-matchers";
import { matchesKey } from "../keys";
import { replaceTabs, truncateToWidth, wrapTextWithAnsi } from "../utils";
import { collapseCommand } from "../apps/ps-data";
import { chatTranscriptDisplayPreferences } from "../chat/display-preferences";
import { PREVIEW_LIMITS, shortenEmbeddedPaths } from "../render/render-utils";
import { ansi, code, col, compact, item, keyed, node, row, span, stableKey, text } from "../native/describe";
import { type DescribeContext, leafKey, type NativeChild, type NativeNode, type NativeUiEvent } from "../native/node";
import { actionBar, actionButton, quietButton, selectList } from "../native/overlay";
import { theme } from "../theme/theme";
import { buildJobTree, type JobTreeAgent, type JobTreeRow, jobTreeGuide } from "./job-tree";
import { describeJobWidget, type JobWidgetView, renderJobWidgetLines } from "../tools/job-widget";
import { changeShellVizPreferences, shellVizEventAction } from "../tools/shell-trace";
import { type ShellStepView, ShellSteps, type ShellStream } from "../tools/shell-steps";
import { defaultShellVizPreferences, readShellPresentation, shellVisualization } from "../tools/shell-viz";

/** One async job as the session snapshots it. */
export interface JobsPanelJob {
	readonly id: string;
	readonly type: string;
	readonly status: "running" | "completed" | "failed" | "cancelled";
	readonly label: string;
	/** What the job is for, in the model's words; rows and the detail lead with it over a command `label`. */
	readonly intent?: string;
	/** One line on what a command does and when it ends, from the cheap model; the detail shows it under the intent. */
	readonly caption?: string;
	readonly startTime: number;
	readonly endTime?: number;
	/** Registry id of the agent that owns the job. */
	readonly ownerId?: string;
	/** Registry id of the subagent a task job runs. */
	readonly agentId?: string;
}

/** Running and recently settled jobs of an agent and its subagents. */
export interface JobsPanelSnapshot {
	readonly running: readonly JobsPanelJob[];
	readonly recent: readonly JobsPanelJob[];
	/** The agent the sheet is for: its jobs sit at the top level, and only they can be cancelled. */
	readonly rootId?: string;
	/** Subagents owning listed jobs, with the ancestors linking them to the root. */
	readonly agents?: readonly JobTreeAgent[];
}

/** What the sheet shows about the selected job beyond its row. */
export interface JobsPanelDetail {
	/** Full command line of a job that runs a process (rows show the cut label). */
	readonly command?: string;
	readonly cwd?: string;
	/** Live pids the job's command spawned. */
	readonly pids: readonly number[];
	readonly exitCode?: number;
	/** Output tail while running; the final text once settled. */
	readonly output?: string;
	/** Milliseconds since the UNIX epoch the command last wrote `output`; undefined when unknown. */
	readonly outputModified?: number;
	/** Artifact holding the full output when `output` is cut. */
	readonly artifactId?: string;
	/** The job's live widget (frozen once it settles), drawn above the output. */
	readonly widget?: JobWidgetView;
	/** The command's shell trace, live while it runs: the command is drawn from it, the running step marked. */
	readonly trace?: ShellTrace;
	/** Where the command's output goes besides `output`, oldest first. */
	readonly streams?: readonly ShellStream[];
}

/** The session behind a {@link JobsSheet}. */
export interface JobsSheetSource {
	/** Current jobs; runs once per frame. */
	load(): JobsPanelSnapshot;
	/** The selected job's detail; runs once per frame, undefined once the job is gone. */
	inspect(id: string): JobsPanelDetail | undefined;
	/**
	 * Cancel a running job. Omitted by a read-only sheet (a focused subagent
	 * view, which only watches that agent): it lists the jobs and offers no way
	 * to stop them.
	 */
	cancel?(id: string): void;
	/** Dismiss the sheet. */
	close(): void;
}

/** A job's status as the sheet names it. */
const STATUS_LABEL: Record<JobsPanelJob["status"], string> = {
	running: "Running",
	completed: "Done",
	failed: "Failed",
	cancelled: "Cancelled",
};

/** A job's status color: the list row's icon and the detail's status pill. */
const STATUS_TONE: Record<JobsPanelJob["status"], TspTone> = {
	running: "pending",
	completed: "success",
	failed: "error",
	cancelled: "muted",
};

/** The status pill's lead glyph; a running job's pulses. */
const STATUS_GLYPH: Record<JobsPanelJob["status"], TspSpan> = {
	running: { t: "●", fx: "pulse" },
	completed: { t: "✓" },
	failed: { t: "✕" },
	cancelled: { t: "⊘" },
};

/** The list row's icon per job type (Tern icon names); other types read as a generic job. */
const TYPE_ICON: Record<string, string> = { bash: "bash", task: "agent" };

/** Output tail rows the terminal fallback shows under the selected job. */
const FALLBACK_TAIL_LINES = 8;

/** Lines of the selected job's command shown before Expand; a traced command keeps its running step among them. */
const COMMAND_PREVIEW_LINES = 6;

/** Key of the selected job's command node, the shell visualization's events arrive under. */
const COMMAND_KEY = "command";
/** Prefix of the source menu's entries: `source:<id>` pins that source. */
const SOURCE_ACT = "source:";

/**
 * The jobs pill's sheet: a centred `lg` glass sheet titled Background jobs.
 * A master–detail split (it stacks in a narrow pane): the selectable job tree
 * beside the selected job's detail — a status pill with live elapsed and
 * Cancel job, what it is for, its command (the shell visualization of its
 * trace where the terminal draws one, the running step in view) or task, one
 * line of facts (agent, cwd, live pids, exit code, artifact) and a
 * tail-following output pane. The pane follows whatever the command writes
 * now (its own output, a pipe a stage feeds, a file it redirects into), its
 * step highlighted in the command; clicking a step shows that step's output
 * until it is clicked again or Follow live, and the source menu picks any
 * stream. A job whose own output is empty still shows what it is doing. With no jobs it shows an empty state. It re-reads the session every
 * frame, so the caller re-renders it on a timer while it is open. ↑/↓
 * select, X cancels the selected running job, Esc or Close dismisses;
 * nothing enters the transcript. A source without `cancel` renders
 * read-only, and a subagent's job never offers Cancel: only the root's own
 * jobs can be stopped here.
 */
export class JobsSheet implements Component {
	readonly nativeOverlay = {
		role: "omp.overlay.jobs",
		size: "lg",
		anchor: "center",
		head: "Background jobs",
	} as const;
	readonly #source: JobsSheetSource;
	#selectedId: string | undefined;
	#native: { key: string; output: string | undefined; node: NativeNode } | undefined;
	/** Which output the selected job's pane shows: the step or source the user chose, else what flows now. */
	#steps: { job: string; steps: ShellSteps } | undefined;
	/**
	 * The selected job's shell visualization: the view preferences its controls
	 * changed (`revision` counts the changes) and the presentation last read.
	 */
	#shell:
		| {
				job: string;
				preferences: ShellVizPreferences;
				revision: number;
				read?: { trace: ShellTrace; revision: number; presentation: ShellVizPresentation | undefined };
		  }
		| undefined;
	/** Fallback output tail, reused while the selected job's output is unchanged. */
	#tail: { id: string; output: string; lines: readonly string[] } | undefined;
	/**
	 * The selected job as last seen: its row, detail and the subagents placing
	 * it. The session evicts settled jobs on its own clock; while the user keeps
	 * one selected it stays listed with its last output, until they select another.
	 */
	#held: { job: JobsPanelJob; detail: JobsPanelDetail | undefined; agents: readonly JobTreeAgent[] } | undefined;

	/** `selected`: the job to open on, when it is listed; else the first, as always. */
	constructor(source: JobsSheetSource, options: { selected?: string } = {}) {
		this.#source = source;
		this.#selectedId = options.selected;
	}

	describe(cx: DescribeContext): NativeNode {
		const { rows, jobs, selected, cancellable } = this.#current();
		const detail = selected && this.#inspect(selected.id);
		const now = Date.now();
		const presentation =
			selected && cx.supports("shell") ? this.#presentation(selected.id, detail?.trace) : undefined;
		const view = selected && { cancellable, presentation, shown: this.#shownOutput(selected, detail, presentation) };
		// Elapsed nodes tick on their own; list values and the output pane redraw
		// when a job starts, settles, leaves or moves in the tree, gets its
		// caption (it can land after the job settles), its process changes, its
		// command moves on, a stream opens, grows or ends, the shown source,
		// its pin, flow or step changes, its output grows, or (while one runs)
		// once a second.
		const key = [
			rows
				.map(
					entry =>
						`${jobTreeGuide(entry, theme)}${entry.kind === "job" ? `${entry.job.id}:${entry.job.status}:${entry.job.caption ?? ""}` : entry.agent.id}`,
				)
				.join(","),
			selected?.id,
			detail?.pids.join(" "),
			detail?.exitCode,
			detail?.artifactId,
			detail?.widget ? `${detail.widget.updatedAt}:${detail.widget.state}` : "",
			detail?.streams?.map(stream => `${stream.id}:${stream.bytes}:${stream.open}`).join(" "),
			view && `${view.shown.id}:${view.shown.pinned}:${view.shown.flowing}:${view.shown.focus.join(" ")}`,
			view?.presentation ? `${detail?.trace?.seq}:${this.#shell?.revision}` : "",
			jobs.some(job => job.status === "running") ? Math.floor(now / 1000) : "",
		].join("|");
		const output = view?.shown.text;
		if (this.#native?.key === key && this.#native.output === output) return this.#native.node;
		const close = actionButton("Close", "close", { keys: "escape" });
		const described =
			selected && view
				? col([
						node(
							"row",
							{ role: "omp.jobs.split" },
							[
								node("col", { role: "omp.jobs.master" }, [describeJobList(rows, selected, now)], "master"),
								describeDetail(selected, detail, now, view),
							],
							"split",
						),
						actionBar([describeSummary(jobs), null, close]),
					])
				: col([describeEmpty(), actionBar([null, close])]);
		this.#native = { key, output, node: described };
		return described;
	}

	/** Rows for a terminal without the native surface: the job tree, then the selected job's facts and output tail. */
	render(width: number): readonly string[] {
		const { rows, jobs, selected } = this.#current();
		const now = Date.now();
		const running = jobs.filter(job => job.status === "running").length;
		const lines = [truncateToWidth(` Background jobs · ${running} running`, width)];
		if (jobs.length === 0) lines.push(" No background jobs");
		for (const entry of rows) {
			const guide = jobTreeGuide(entry, theme);
			if (entry.kind === "agent") {
				lines.push(truncateToWidth(`  ${guide}${entry.agent.id}`, width));
				continue;
			}
			const { job } = entry;
			const cursor = job === selected ? ">" : " ";
			const age = formatDuration(jobAge(job, now));
			const agent = entry.agent && entry.agent.id !== job.label ? `${entry.agent.id}: ` : "";
			// The intent is model-written: strip terminal controls and flatten it to one row like the command.
			const title = shortenEmbeddedPaths(collapseCommand(sanitizeText(jobDisplayLabel(job))));
			lines.push(truncateToWidth(`${cursor} ${guide}${job.status}  ${job.type} ${age}  ${agent}${title}`, width));
		}
		const detail = selected && this.#inspect(selected.id);
		if (detail) {
			if (selected.caption) {
				for (const line of wrapTextWithAnsi(
					shortenEmbeddedPaths(sanitizeText(selected.caption)),
					Math.max(1, width - 3),
				)) {
					lines.push(`   ${theme.fg("muted", line)}`);
				}
			}
			// Rows show the cut label; the selected job's command wraps here,
			// bounded so a long script never pushes the facts and output off the sheet.
			if (detail.command) {
				const commandRows = wrapTextWithAnsi(
					shortenEmbeddedPaths(replaceTabs(sanitizeText(detail.command))),
					Math.max(1, width - 3),
				);
				for (const line of commandRows.slice(0, PREVIEW_LIMITS.EXPANDED_LINES)) lines.push(`   ${line}`);
				const hidden = commandRows.length - PREVIEW_LIMITS.EXPANDED_LINES;
				if (hidden > 0) lines.push(truncateToWidth(`   … ${hidden} more command lines`, width));
			}
			const facts = compact([
				detail.cwd && `cwd ${detail.cwd}`,
				detail.pids.length > 0 && `pid ${detail.pids.join(", ")}`,
				detail.exitCode !== undefined && `exit ${detail.exitCode}`,
				detail.artifactId && spillUrl(detail.artifactId),
			]);
			if (facts.length > 0) lines.push(truncateToWidth(`   ${facts.join(" · ")}`, width));
			if (detail.widget && widgetHasData(detail.widget)) {
				for (const line of renderJobWidgetLines(detail.widget, Math.max(0, width - 3), theme)) {
					lines.push(`   ${line}`);
				}
			}
			// The tail is of the source the output pane shows.
			const shown = this.#shownOutput(selected, detail, undefined);
			if (shown.note) {
				lines.push(truncateToWidth(`   ${theme.fg("muted", `→ ${shown.label} · ${shown.note}`)}`, width));
			}
			for (const line of this.#tailLines(`${selected.id}|${shown.id}`, shown.text ?? "")) {
				if (line) lines.push(truncateToWidth(`   ${line}`, width));
			}
		}
		return lines;
	}

	invalidate(): void {
		this.#native = undefined;
	}

	handleInput(data: string): void {
		if (matchesSelectCancel(data)) this.#source.close();
		else if (matchesSelectUp(data)) this.#move(-1);
		else if (matchesSelectDown(data)) this.#move(1);
		else if (matchesKey(data, "x")) this.#cancelSelected();
	}

	/**
	 * Clicks select a row; a step of the command shows its output (again:
	 * follows the command), as Follow live and the source menu do; the
	 * command's own controls change how it is drawn; Close and Cancel job run
	 * what Esc and X run.
	 */
	handleNativeEvent(event: NativeUiEvent): void {
		if (leafKey(event.key) === COMMAND_KEY) this.#changeShell(event);
		else if (event.type === "select" || event.type === "activate") this.#selectedId = event.item;
		else if (event.type !== "action") return;
		else if (event.act === "close") this.#source.close();
		else if (event.act === "cancel") this.#cancelSelected();
		else if (event.act === "follow") this.#selectedSteps()?.follow();
		else if (event.act.startsWith(SOURCE_ACT)) this.#selectedSteps()?.pick(event.act.slice(SOURCE_ACT.length));
	}

	/**
	 * The selected job's command as its shell visualization, read again when
	 * the trace moved on or a control changed the view. Undefined without a
	 * trace, with the visualization turned off, or for a trace the engine
	 * cannot restore: the command then shows as plain code.
	 */
	#presentation(job: string, trace: ShellTrace | undefined): ShellVizPresentation | undefined {
		if (!trace || !chatTranscriptDisplayPreferences.shellVisualization) return undefined;
		if (this.#shell?.job !== job) this.#shell = { job, preferences: defaultShellVizPreferences(), revision: 0 };
		const shell = this.#shell;
		if (shell.read?.trace !== trace || shell.read.revision !== shell.revision) {
			const source = shellVisualization(trace);
			shell.read = {
				trace,
				revision: shell.revision,
				presentation: source && readShellPresentation(source, shell.preferences, trace),
			};
		}
		return shell.read.presentation;
	}

	/**
	 * A control of the command's visualization: a clicked step (its output
	 * shows), the view, a layer, an expanded chip. Replay and the full
	 * inspector belong to the transcript's card, so those actions change
	 * nothing here.
	 */
	#changeShell(event: NativeUiEvent): void {
		const shell = this.#shell;
		if (!shell) return;
		const action = shellVizEventAction(event, shell.preferences);
		if (action?.startsWith("select:")) {
			this.#selectedSteps()?.select(action.slice("select:".length));
			return;
		}
		if (!action || !/^(?:view|layer|expand):|^split$/.test(action)) return;
		shell.preferences = changeShellVizPreferences(shell.preferences, action, 0);
		shell.revision++;
	}

	/** The output choice of `job`, made fresh when another job is selected. */
	#stepsOf(job: JobsPanelJob): ShellSteps {
		if (this.#steps?.job !== job.id) this.#steps = { job: job.id, steps: new ShellSteps() };
		return this.#steps.steps;
	}

	/** The output choice of the selected job; undefined without jobs. */
	#selectedSteps(): ShellSteps | undefined {
		const job = this.#current().selected;
		return job && this.#stepsOf(job);
	}

	/** The source the output pane shows for `job` and its text now. */
	#shownOutput(
		job: JobsPanelJob,
		detail: JobsPanelDetail | undefined,
		presentation: ShellVizPresentation | undefined,
	): ShellStepView {
		return this.#stepsOf(job).show({
			trace: detail?.trace,
			presentation,
			streams: detail?.streams ?? [],
			output: detail?.output ?? "",
			outputModified: detail?.outputModified,
			settled: job.status !== "running",
		});
	}

	/**
	 * The job tree, its jobs in tree order, the selected one (the first when
	 * the selection left) and whether the sheet can stop it: a job the root
	 * owns, with a source that cancels.
	 */
	#current(): {
		rows: readonly JobTreeRow<JobsPanelJob>[];
		jobs: readonly JobsPanelJob[];
		selected: JobsPanelJob | undefined;
		cancellable: boolean;
	} {
		const snapshot = this.#source.load();
		const { running, rootId } = snapshot;
		let { recent, agents = [] } = snapshot;
		// A settled job the session evicted stays listed while it is selected.
		const held = this.#held?.job.id === this.#selectedId ? this.#held : undefined;
		const evicted =
			held !== undefined &&
			held.job.status !== "running" &&
			!running.some(job => job.id === held.job.id) &&
			!recent.some(job => job.id === held.job.id);
		if (evicted) {
			recent = [...recent, held.job];
			const known = new Set(agents.map(agent => agent.id));
			agents = [...agents, ...held.agents.filter(agent => !known.has(agent.id))];
		}
		const rows = buildJobTree([...running, ...recent], agents, rootId);
		const jobs = rows.flatMap(entry => (entry.kind === "job" ? [entry.job] : []));
		const selected = jobs.find(job => job.id === this.#selectedId) ?? jobs[0];
		this.#selectedId = selected?.id;
		if (!selected) this.#held = undefined;
		else if (!evicted) {
			const detail = held?.job.id === selected.id ? held.detail : undefined;
			this.#held = { job: selected, detail, agents: snapshot.agents ?? [] };
		}
		const owned = selected?.ownerId === undefined || selected.ownerId === rootId;
		return { rows, jobs, selected, cancellable: this.#source.cancel !== undefined && owned };
	}

	/** The job's detail from the source, else the last one seen while it was held. */
	#inspect(id: string): JobsPanelDetail | undefined {
		const detail = this.#source.inspect(id);
		const held = this.#held?.job.id === id ? this.#held : undefined;
		if (!held) return detail;
		if (detail) held.detail = detail;
		return held.detail;
	}

	#tailLines(id: string, output: string): readonly string[] {
		const cached = this.#tail;
		if (cached?.id === id && cached.output === output) return cached.lines;
		const lines = tailLines(output, FALLBACK_TAIL_LINES);
		this.#tail = { id, output, lines };
		return lines;
	}

	#move(delta: number): void {
		const { jobs, selected } = this.#current();
		if (!selected) return;
		const index = Math.max(0, Math.min(jobs.length - 1, jobs.indexOf(selected) + delta));
		this.#selectedId = jobs[index]?.id;
	}

	#cancelSelected(): void {
		const { selected, cancellable } = this.#current();
		if (cancellable && selected?.status === "running") this.#source.cancel?.(selected.id);
	}
}

/** How long a job ran, or has been running. */
function jobAge(job: JobsPanelJob, nowMs: number): number {
	return Math.max(0, (job.endTime ?? nowMs) - job.startTime);
}

/** Whether a widget draws more than its title: one without data only repeats the job's heading. */
function widgetHasData(widget: JobWidgetView): boolean {
	return widget.blocks.length > 0 || widget.headline !== undefined || Boolean(widget.stage);
}

/**
 * The last `count` pieces of `text.trimEnd().split("\n")`, found by scanning
 * back from the end so a long running output is never split as a whole.
 */
function tailLines(text: string, count: number): string[] {
	const trimmed = text.trimEnd();
	const lines: string[] = [];
	let end = trimmed.length;
	while (lines.length < count) {
		const newline = end > 0 ? trimmed.lastIndexOf("\n", end - 1) : -1;
		lines.push(trimmed.slice(newline + 1, end));
		if (newline < 0) break;
		end = newline;
	}
	return lines.reverse();
}

/**
 * The master list: the job tree, connectors leading each label. A subagent
 * without a listed task job heads its jobs as a quiet label (a plain text
 * child: no row behavior, so ↑/↓ and clicks pass it by).
 */
function describeJobList(rows: readonly JobTreeRow<JobsPanelJob>[], selected: JobsPanelJob, nowMs: number): NativeNode {
	const children: NativeChild[] = rows.map(entry => {
		const guide = jobTreeGuide(entry, theme);
		if (entry.kind === "job") return describeJobItem(entry.job, entry.agent?.id, guide, nowMs);
		return node(
			"text",
			{
				role: "omp.jobs.group",
				spans: compact([guide !== "" && span(guide, "mono dim"), span(entry.agent.id)]),
				wrap: "none",
			},
			undefined,
			`agent-${stableKey(entry.agent.id)}`,
		);
	});
	return selectList("jobs", children, { selected: selected.id, max: { lines: 12 } });
}

/**
 * One list row: the type icon tinted by status, the tree connector, the
 * subagent a task job runs, the one-line label (what the job is for when the
 * model said, else a process job's command in mono or a task's work in prose)
 * and how long it ran.
 */
function describeJobItem(job: JobsPanelJob, agentName: string | undefined, guide: string, nowMs: number): NativeNode {
	const status = STATUS_LABEL[job.status];
	const age = formatDuration(jobAge(job, nowMs));
	return item(job.id, {
		label: compact([
			guide !== "" && span(guide, "mono dim"),
			agentName !== undefined && agentName !== job.label && span(`${agentName} `, "strong"),
			job.intent
				? span(jobDisplayLabel(job))
				: job.type === "task"
					? span(job.label)
					: span(collapseCommand(job.label), "mono"),
		]),
		value: [span(age, "mono")],
		icon: TYPE_ICON[job.type] ?? "job",
		tone: STATUS_TONE[job.status],
		title: `${job.intent ? `${job.intent}\n` : ""}${job.caption ? `${job.caption}\n` : ""}${job.label}\n${status} · ${job.type} · ${job.id}`,
		aria: `${jobDisplayLabel(job)}, ${status.toLowerCase()}, ${age}`,
	});
}

/** The footer's at-a-glance count. */
function describeSummary(jobs: readonly JobsPanelJob[]): NativeNode {
	const running = jobs.filter(job => job.status === "running").length;
	const parts = compact([
		running > 0 && `${running} running`,
		jobs.length > running && `${jobs.length - running} recent`,
	]);
	return node("text", { role: "omp.jobs.summary", text: parts.join(" · "), wrap: "none" }, undefined, "summary");
}

/** No jobs: what the sheet is for, in place of the split. */
function describeEmpty(): NativeNode {
	return node(
		"col",
		{ role: "omp.jobs.empty", align: "center" },
		[
			node("icon", { name: "jobs" }),
			text("No background jobs", { role: "omp.jobs.empty.title" }),
			text("Commands and subagent tasks started in the background show up here while they run.", {
				role: "omp.jobs.empty.note",
				wrap: "word",
			}),
		],
		"empty",
	);
}

/** What the output pane says in the well's place when the shown source has no text to draw. */
function emptyOutputNote(shown: ShellStepView, settled: boolean): string | undefined {
	if (shown.text === undefined) return "Binary data";
	if (shown.text.trim() !== "") return undefined;
	if (shown.stream) return shown.open ? "Nothing written yet" : "Nothing written";
	return settled ? "No output" : "No output yet";
}

/**
 * The output pane's head: a menu naming the shown source and listing the
 * job's own output and every stream (a plain label while there is nothing to
 * choose), what the shown source is, and whether the pane follows the
 * command (while it runs) or offers Follow live.
 */
function describeSource(shown: ShellStepView, settled: boolean): NativeNode {
	const choosable = shown.sources.length > 1 || shown.pinned;
	const menu = node(
		"menu",
		{
			role: "omp.jobs.sources",
			text: shown.label,
			caret: true,
			trigger: "quiet",
			title: "Output source",
			align: "start",
			items: shown.sources.map(source => ({
				id: `${SOURCE_ACT}${source.id}`,
				label: source.label,
				...(source.detail ? { detail: source.detail } : {}),
				radio: "source",
				checked: source.id === shown.id,
			})),
		},
		undefined,
		"sources",
	);
	const following = text("Following", {
		role: "omp.jobs.follow",
		wrap: "none",
		title: "Shows what the command writes now; click a step of the command to show its output",
		...(shown.flowing ? { tone: "pending" } : {}),
	});
	return keyed(
		row(
			compact<NativeChild>([
				choosable ? menu : text(shown.label, { role: "omp.jobs.label" }),
				shown.note !== undefined &&
					keyed(
						text([span(shown.note, "mono")], { role: "omp.jobs.stream", wrap: "none", truncate: "end" }),
						"stream",
					),
				node("spacer", { grow: 1 }),
				shown.pinned
					? quietButton("Follow live", "follow", "Show what the command writes now")
					: !settled && keyed(following, "follow"),
			]),
			{ role: "omp.jobs.source", gap: "sm", align: "center" },
		),
		"source",
	);
}

/**
 * The output pane: its source head (see {@link describeSource}) over the
 * shown source's text. Empty sources and binary streams say so in the well's
 * place.
 */
function describeOutput(shown: ShellStepView, settled: boolean): NativeNode {
	const empty = emptyOutputNote(shown, settled);
	return node(
		"col",
		{ role: "omp.jobs.out", gap: "sm" },
		[
			describeSource(shown, settled),
			empty !== undefined
				? keyed(text(empty, { role: "omp.jobs.nooutput" }), "empty")
				: keyed(
						ansi(shown.text ?? "", { follow: shown.open, role: "omp.jobs.output", max: { h: "16lines" } }),
						`text-${stableKey(shown.id)}`,
					),
		],
		"out",
	);
}

/**
 * The selected job: a status line (pill, live elapsed, type · id, Cancel job
 * when `cancellable`), what it is for and what its command does (the cheap
 * model's caption), its command (its shell visualization when `presentation`
 * is given, else the plain text), its facts on one line, its widget when it
 * has data to draw and the output pane.
 */
function describeDetail(
	job: JobsPanelJob,
	detail: JobsPanelDetail | undefined,
	nowMs: number,
	view: { cancellable: boolean; presentation: ShellVizPresentation | undefined; shown: ShellStepView },
): NativeNode {
	const { cancellable, presentation, shown } = view;
	const settled = job.status !== "running";
	const exit = detail?.exitCode;
	const age = Math.round(jobAge(job, nowMs));
	const command = detail?.command ?? (job.type === "task" ? undefined : job.label);
	const title = job.intent ?? (command ? undefined : job.label);
	const pids = detail?.pids ?? [];
	const facts = compact([
		job.agentId ? { k: "Agent", v: [span(job.agentId, "mono")] } : undefined,
		detail?.cwd ? { k: "Directory", v: [span(detail.cwd, "path")] } : undefined,
		pids.length > 0 && { k: pids.length > 1 ? "PIDs" : "PID", v: [span(pids.join(", "), "num")] },
		exit !== undefined && { k: "Exit code", v: [span(String(exit), exit === 0 ? "success" : "error")] },
		detail?.artifactId ? { k: "Full output", v: [span(spillUrl(detail.artifactId), "mono")] } : undefined,
	]);
	const children = compact<NativeChild>([
		row(
			compact<NativeChild>([
				text([STATUS_GLYPH[job.status], span(` ${STATUS_LABEL[job.status]}`)], {
					role: "omp.jobs.state",
					tone: STATUS_TONE[job.status],
					wrap: "none",
				}),
				node("elapsed", {
					age,
					...(settled ? { stopped: age } : {}),
					format: "short",
					role: "omp.jobs.age",
					title: settled ? "Ran for" : "Running for",
				}),
				text([span(`${job.type} · ${job.id}`, "mono")], { role: "omp.jobs.id", wrap: "none", truncate: "end" }),
				node("spacer", { grow: 1 }),
				cancellable && !settled && actionButton("Cancel job", "cancel", { keys: "x", tone: "error" }),
			]),
			{ role: "omp.jobs.status", gap: "sm", align: "center" },
		),
		// The intent is the calling model's and can run to a paragraph: the terminal clamps it, the tooltip has it whole.
		title || job.caption
			? node(
					"col",
					{ role: "omp.jobs.about", gap: "xs" },
					compact<NativeChild>([
						title ? text(jobDisplayLabel(job), { role: "omp.jobs.title", wrap: "word", title }) : undefined,
						job.caption
							? text([span(job.caption, "muted")], {
									role: "omp.jobs.caption",
									wrap: "word",
									title: job.caption,
								})
							: undefined,
					]),
					"about",
				)
			: undefined,
		presentation
			? node(
					"shell",
					{
						role: "omp.jobs.command",
						presentation,
						lang: "bash",
						liveOrigin: !settled,
						preview: { lines: COMMAND_PREVIEW_LINES },
						steps: true,
						focus: shown.focus,
					},
					undefined,
					COMMAND_KEY,
				)
			: command
				? code(command, {
						lang: "bash",
						wrap: true,
						preview: { lines: COMMAND_PREVIEW_LINES },
						role: "omp.jobs.command",
					})
				: undefined,
		facts.length > 0 && node("kv", { items: facts, layout: "inline", role: "omp.jobs.facts" }),
		detail?.widget &&
			widgetHasData(detail.widget) &&
			node("col", { role: "omp.jobs.widget" }, [describeJobWidget(detail.widget)], "widget"),
		describeOutput(shown, settled),
	]);
	return node("col", { role: "omp.jobs.detail" }, children, stableKey(job.id));
}
