import type { Component } from "../tui";
import { Ellipsis, renderStatusLine, renderTreeList, truncateToWidth } from "../render";
import { visibleWidth } from "../utils";
import {
	cappedHeadLines,
	formatBadge,
	formatDuration,
	formatErrorDetail,
	formatExpandHint,
	formatStatusIcon,
	PREVIEW_LIMITS,
	TRUNCATE_LENGTHS,
	type ToolUIColor,
	wrapTextWithAnsi,
} from "../render/render-utils";
import type { Theme } from "../theme/theme";
import type { NativeToolView, RenderResultOptions } from "./renderer";
import type { TspSpan, TspTone } from "@oh-my-pi/pi-wire";
import { ansi, compact, node, span, text } from "../native/describe";
import type { NativeChild, NativeNode } from "../native/node";
import { errorText, noteText, toolHead } from "./native-view";
import type { AgentActivitySnapshot, CoordinationDetails, JobSnapshot } from "./wait";
import { jobDisplayLabel } from "./job-label";
import type { IrcDeliveryReceipt } from "./irc";
import { type PersistedSnapshot, type ServiceView, serviceView } from "./daemon";
import { styleTerminalRow } from "./terminal-output";
import { card, type CardToolResult as ToolResult, firstText, safe } from "./result-card";

export interface ProcReadDetails {
	jobs?: JobSnapshot[];
	agents?: AgentActivitySnapshot[];
	daemons?: PersistedSnapshot[];
	job?: JobSnapshot;
	daemon?: PersistedSnapshot;
	log?: string;
	terminalRows?: string[];
}

export type ProcWriteDetails =
	| CoordinationDetails
	| { action: "stop" | "stdin" | "mode"; daemon: PersistedSnapshot; input?: string; mode?: string };

/** Process operation selected by a write URL, independent of its content. */
export type ProcWriteAction = "stdin" | "mode" | "kill";

function preview(
	body: string,
	expanded: boolean,
	theme: Theme,
	tone: "dim" | "toolOutput" = "dim",
	width?: number,
): string[] {
	if (!body.trim()) return [];
	const quote = theme.fg("dim", theme.md.quoteBorder);
	const prefix = `  ${quote} `;
	const source = body.split("\n").filter(line => line.trim());
	// An expanded IRC card (the only caller passing a width) shows the whole
	// message. Without a width this is a proc/job card, whose expanded view
	// keeps a budget: a job log with thousands of lines would push the
	// transcript off the screen.
	const ircExpanded = expanded && width !== undefined;
	const limit = expanded ? PREVIEW_LIMITS.EXPANDED_LINES : PREVIEW_LIMITS.COLLAPSED_LINES;
	const shown = ircExpanded ? source : cappedHeadLines(source, limit).lines;
	const hidden = source.length - shown.length;
	// Each row is clipped to the card width, so the text budget is that width
	// minus the quote rail; with no card width the fixed cap stands.
	const contentWidth = width === undefined ? TRUNCATE_LENGTHS.LINE : Math.max(1, width - visibleWidth(prefix));
	const cap = Math.min(TRUNCATE_LENGTHS.LINE, contentWidth);
	let cut = false;
	const lines: string[] = [];
	for (const line of shown) {
		const text = safe(line.trim());
		// IRC cards pass the card width: an expanded body soft-wraps instead of
		// being cut. Collapsed rows keep the fixed cap, narrowed to the card.
		if (ircExpanded) {
			for (const row of wrapTextWithAnsi(text, contentWidth)) lines.push(`${prefix}${theme.fg(tone, row)}`);
			continue;
		}
		cut ||= visibleWidth(text) > cap;
		lines.push(`${prefix}${theme.fg(tone, truncateToWidth(text, cap, Ellipsis.Unicode))}`);
	}
	// The hint is not width-gated: a caller that passes no width (the proc/job
	// card) still elides lines, and a silent cap reads as if the log ended there.
	if (hidden > 0 || cut) {
		const hint = formatExpandHint(theme, expanded, true);
		const marker = hidden > 0 ? `… +${hidden} more lines` : "…";
		lines.push(`${prefix}${theme.fg("dim", `${marker}${hint ? ` ${hint}` : ""}`)}`);
	}
	return lines;
}

function receiptColor(outcome: IrcDeliveryReceipt["outcome"]): ToolUIColor {
	return outcome === "failed" ? "error" : outcome === "revived" ? "warning" : "success";
}

export function renderAgentWrite(
	to: string,
	body: string,
	result: ToolResult | undefined,
	details: CoordinationDetails | undefined,
	options: RenderResultOptions,
	theme: Theme,
): Component {
	return card((width, expanded) => {
		const recipient = safe(details?.to || to || "…");
		const title = `IRC ${theme.nav.selected} ${recipient}`;
		const receipts = details?.receipts ?? [];
		const delivered = receipts.filter(receipt => receipt.outcome !== "failed").length;
		const failed = receipts.length - delivered;
		const error = result?.isError || (failed > 0 && delivered === 0);
		const meta: string[] = [];
		if (recipient === "all") meta.push("broadcast");
		if (receipts.length === 1) meta.push(theme.fg(receiptColor(receipts[0]!.outcome), receipts[0]!.outcome));
		else if (receipts.length > 1) {
			if (delivered) meta.push(theme.fg("success", `${delivered} delivered`));
			if (failed) meta.push(theme.fg("error", `${failed} failed`));
		}
		const header = renderStatusLine(
			result === undefined
				? { icon: "pending", title, meta }
				: error
					? { icon: "error", title, meta }
					: { iconOverride: theme.styledSymbol("tool.irc", "accent"), title, meta },
			theme,
		);
		if (result?.isError && receipts.length === 0)
			return [header, formatErrorDetail(firstText(result) || "Message delivery failed.", theme)];
		const lines = [header, ...preview(body, expanded, theme, "dim", width)];
		if (result && receipts.length === 0)
			lines.push(theme.fg("muted", firstText(result) || "No live peers to broadcast to."));
		if (receipts.length > 1 || failed > 0) {
			lines.push(
				...renderTreeList(
					{
						items: receipts,
						expanded,
						maxCollapsed: PREVIEW_LIMITS.COLLAPSED_ITEMS,
						itemType: "recipient",
						renderItem: receipt =>
							`${theme.fg("toolOutput", safe(receipt.to))} ${formatBadge(receipt.outcome, receiptColor(receipt.outcome), theme)}${receipt.error ? ` ${theme.fg("error", `${theme.format.dash} ${safe(receipt.error)}`)}` : ""}`,
					},
					theme,
				),
			);
		}
		return lines.map(line => truncateToWidth(line, width, Ellipsis.Unicode));
	}, options);
}

function daemonMeta(daemon: ServiceView, theme: Theme): string[] {
	const stateColor =
		daemon.state === "ready" || daemon.state === "running"
			? "success"
			: daemon.state === "failed"
				? "error"
				: "warning";
	return [theme.fg(stateColor, daemon.state), ...serviceFacts(daemon)];
}

/** A service's facts after its state: pid, run time, and what keeps it alive. */
function serviceFacts(service: ServiceView): string[] {
	const facts: string[] = [];
	if (service.pid !== undefined) facts.push(`pid ${service.pid}`);
	facts.push(
		`${service.exitedAt === undefined ? "up" : "ran"} ${formatDuration(Math.max(0, (service.exitedAt ?? Date.now()) - service.startedAt))}`,
	);
	if (service.hold === "detached") facts.push("detached");
	else if (service.hold === "persist") facts.push("persistent");
	return facts;
}

function jobRow(job: JobSnapshot, theme: Theme): string {
	const icon = formatStatusIcon(
		job.status === "cancelled"
			? "aborted"
			: job.status === "failed"
				? "error"
				: job.status === "running"
					? "running"
					: "success",
		theme,
	);
	return `${icon} ${formatBadge(job.type, job.status === "failed" ? "error" : job.status === "cancelled" ? "warning" : "accent", theme)} ${theme.fg("toolOutput", safe(job.id))} ${theme.fg("dim", safe(jobDisplayLabel(job)))} ${theme.fg("dim", formatDuration(job.durationMs))}`;
}

/** Render live and completed process writes with the URL-selected operation. */
export function renderProcWrite(
	id: string,
	action: ProcWriteAction,
	content: string | undefined,
	result: ToolResult | undefined,
	details: ProcWriteDetails | undefined,
	options: RenderResultOptions,
	theme: Theme,
): Component {
	return card((_width, expanded) => {
		const title = `Proc ${action} ${safe(id || "…")}`;
		const daemon = details && "daemon" in details ? details.daemon : undefined;
		const header = renderStatusLine(
			{
				icon:
					result === undefined ? "pending" : result.isError ? "error" : action === "kill" ? "aborted" : "success",
				title,
				meta: daemon ? daemonMeta(serviceView(daemon), theme) : action === "mode" && content ? [safe(content)] : [],
			},
			theme,
		);
		if (result?.isError) return [header, formatErrorDetail(firstText(result) || "Process operation failed.", theme)];
		const lines = [header];
		if (content && action === "stdin") lines.push(...preview(content, expanded, theme));
		if (details && "op" in details && details.op === "cancel") {
			const jobs = details.jobs ?? [];
			const outcomes = details.cancelled ?? [];
			lines.push(
				...renderTreeList(
					{
						items: outcomes,
						expanded,
						maxCollapsed: PREVIEW_LIMITS.COLLAPSED_ITEMS,
						itemType: "job",
						renderItem: outcome => {
							const job = jobs.find(item => item.id === outcome.id);
							return `${job ? `${jobRow(job, theme)} ` : `${theme.fg("toolOutput", safe(outcome.id))} `}${formatBadge(outcome.status, outcome.status === "cancelled" ? "warning" : "error", theme)}`;
						},
					},
					theme,
				),
			);
		}
		return lines;
	}, options);
}

export function renderProcRead(
	id: string,
	result: ToolResult | undefined,
	details: ProcReadDetails | undefined,
	options: RenderResultOptions,
	theme: Theme,
): Component {
	return card((_width, expanded) => {
		const title = id ? `Proc ${safe(id)}` : "Proc jobs & services";
		const daemon = details?.daemon;
		const header = renderStatusLine(
			{
				icon: result === undefined ? "pending" : result.isError ? "error" : "info",
				title,
				meta: daemon ? daemonMeta(serviceView(daemon), theme) : [],
			},
			theme,
		);
		if (result?.isError) return [header, formatErrorDetail(firstText(result) || "Process read failed.", theme)];
		if (!result) return [header];
		if (details?.job)
			return [
				header,
				jobRow(details.job, theme),
				...preview(
					details.log ?? details.job.errorText ?? details.job.resultText ?? "",
					expanded,
					theme,
					"toolOutput",
				),
			];
		if (daemon) {
			const output = details.terminalRows ?? (details.log ?? "").split("\n").filter(Boolean);
			const limit = expanded ? PREVIEW_LIMITS.EXPANDED_LINES : PREVIEW_LIMITS.COLLAPSED_LINES;
			const visible = output
				.slice(-limit)
				.map(
					line =>
						`  ${styleTerminalRow(truncateToWidth(safe(line), TRUNCATE_LENGTHS.LINE, Ellipsis.Unicode), theme.fg("toolOutput", ""))}`,
				);
			if (output.length > limit) visible.unshift(theme.fg("dim", `  … ${output.length - limit} earlier lines`));
			return [header, ...visible];
		}
		if (id && !details?.jobs && !details?.daemons && !details?.agents) {
			return [header, ...preview(firstText(result), expanded, theme, "toolOutput")];
		}
		const jobs = details?.jobs ?? [];
		const services = (details?.daemons ?? []).map(serviceView);
		const agents = details?.agents ?? [];
		const meta = [
			`${jobs.length} jobs`,
			`${services.length} services`,
			...(agents.length ? [`${agents.length} agents`] : []),
		];
		const listHeader = renderStatusLine({ icon: "info", title, meta }, theme);
		const items = [
			...jobs.map(job => ({ label: jobRow(job, theme) })),
			...services.map(service => ({
				label: `${formatBadge("service", "accent", theme)} ${theme.fg("toolOutput", safe(service.name))} ${formatBadge(service.state, service.state === "failed" ? "error" : service.state === "ready" || service.state === "running" ? "success" : "warning", theme)} ${serviceFacts(service).join(theme.sep.dot)}`,
			})),
			...agents.map(agent => ({
				label: `${formatBadge("agent", agent.live ? "accent" : "warning", theme)} ${theme.fg("toolOutput", safe(agent.id))} ${theme.fg("dim", formatDuration(agent.ageMs))}`,
			})),
		];
		return [
			listHeader,
			...renderTreeList(
				{
					items,
					expanded,
					maxCollapsed: PREVIEW_LIMITS.COLLAPSED_ITEMS,
					itemType: "process",
					renderItem: item => item.label,
				},
				theme,
			),
			...(items.length ? [] : [theme.fg("dim", "No background jobs or services.")]),
		];
	}, options);
}

// =============================================================================
// Native (TSP) views
// =============================================================================

function daemonMetaText(daemon: ServiceView): string {
	return [daemon.state, ...serviceFacts(daemon)].join(" · ");
}

function jobTone(status: JobSnapshot["status"]): TspTone {
	return status === "failed"
		? "error"
		: status === "cancelled"
			? "warning"
			: status === "running"
				? "info"
				: "success";
}

function jobItem(job: JobSnapshot, badge?: { text: string; tone: TspTone }): NativeNode {
	return node(
		"item",
		{
			label: [span(job.type, "accent"), span(" "), span(safe(job.id), "toolOutput")],
			detail: [span(safe(jobDisplayLabel(job)), "muted")],
			value: badge ? [span(badge.text, badge.tone)] : [span(formatDuration(job.durationMs), "muted")],
			tone: badge?.tone ?? jobTone(job.status),
		},
		undefined,
		job.id,
	);
}

function quotedPreview(body: string, tone = "muted"): NativeNode | undefined {
	if (!body.trim()) return undefined;
	return text([span(body, tone)], { wrap: "word", role: "omp.tool.proc.preview" });
}

const RECEIPT_TONE: Record<IrcDeliveryReceipt["outcome"], TspTone> = {
	injected: "success",
	woken: "success",
	revived: "warning",
	failed: "error",
};

/** TSP view of an `agent://` write (IRC message). */
export function describeAgentWrite(
	to: string,
	body: string,
	result: ToolResult | undefined,
	details: CoordinationDetails | undefined,
): NativeToolView {
	const recipient = safe(details?.to || to || "…");
	const receipts = details?.receipts ?? [];
	const delivered = receipts.filter(receipt => receipt.outcome !== "failed").length;
	const failed = receipts.length - delivered;
	const meta: TspSpan[] = [];
	if (recipient === "all") meta.push(span("broadcast", "muted"));
	if (receipts.length === 1) meta.push(span(receipts[0]!.outcome, RECEIPT_TONE[receipts[0]!.outcome]));
	else if (receipts.length > 1) {
		if (delivered) meta.push(span(`${delivered} delivered`, "success"));
		if (failed) meta.push(span(`${failed} failed`, "error"));
	}
	const head = toolHead("IRC", span(recipient, "accent"), ...meta);
	const error = result?.isError === true || (failed > 0 && delivered === 0);
	if (result?.isError && receipts.length === 0) {
		return { head, tone: "error", body: [errorText(firstText(result) || "Message delivery failed.")] };
	}
	const children = compact<NativeChild>([
		quotedPreview(body),
		result !== undefined && receipts.length === 0 && noteText(firstText(result) || "No live peers to broadcast to."),
		(receipts.length > 1 || failed > 0) &&
			node(
				"list",
				{ role: "omp.tool.irc.receipts" },
				receipts.map(receipt =>
					node(
						"item",
						{
							label: [span(safe(receipt.to), "toolOutput")],
							value: [span(receipt.outcome, RECEIPT_TONE[receipt.outcome])],
							detail: receipt.error ? [span(safe(receipt.error), "error")] : undefined,
							tone: RECEIPT_TONE[receipt.outcome],
						},
						undefined,
						receipt.to,
					),
				),
			),
	]);
	return { head, tone: error ? "error" : undefined, body: children };
}

/** TSP view of a `proc://` write (stdin, mode change, kill). */
export function describeProcWrite(
	id: string,
	action: ProcWriteAction,
	content: string | undefined,
	result: ToolResult | undefined,
	details: ProcWriteDetails | undefined,
): NativeToolView {
	const daemon = details && "daemon" in details ? details.daemon : undefined;
	const head = toolHead(
		`Proc ${action}`,
		span(safe(id || "…"), "accent"),
		daemon ? daemonMetaText(serviceView(daemon)) : action === "mode" && content ? safe(content) : undefined,
	);
	if (result?.isError) {
		return { head, tone: "error", body: [errorText(firstText(result) || "Process operation failed.")] };
	}
	const body = compact<NativeChild>([content && action === "stdin" ? quotedPreview(content) : undefined]);
	if (details && "op" in details && details.op === "cancel") {
		const jobs = details.jobs ?? [];
		body.push(
			node(
				"list",
				{ role: "omp.tool.proc.cancelled" },
				(details.cancelled ?? []).map(outcome => {
					const job = jobs.find(item => item.id === outcome.id);
					const badge = {
						text: outcome.status,
						tone: outcome.status === "cancelled" ? "warning" : "error",
					} as const;
					return job
						? jobItem(job, badge)
						: node(
								"item",
								{ label: [span(safe(outcome.id), "toolOutput")], value: [span(badge.text, badge.tone)] },
								undefined,
								outcome.id,
							);
				}),
			),
		);
	}
	return { head, tone: result !== undefined && action === "kill" ? "warning" : undefined, body };
}

/** TSP view of a `proc://` read: job/service detail, logs, or the process table. */
export function describeProcRead(
	id: string,
	result: ToolResult | undefined,
	details: ProcReadDetails | undefined,
): NativeToolView {
	const daemon = details?.daemon;
	const title = id ? "Proc" : "Proc jobs & services";
	const head = toolHead(
		title,
		id ? span(safe(id), "accent") : undefined,
		daemon ? daemonMetaText(serviceView(daemon)) : undefined,
	);
	if (result?.isError) {
		return { head, tone: "error", body: [errorText(firstText(result) || "Process read failed.")] };
	}
	if (!result) return { head };
	if (details?.job) {
		const log = details.log ?? details.job.errorText ?? details.job.resultText ?? "";
		return {
			head,
			body: compact<NativeChild>([
				node("list", {}, [jobItem(details.job)]),
				log.trim().length > 0 && ansi(log, { role: "omp.tool.proc.log" }),
			]),
		};
	}
	if (daemon) {
		const output = details.terminalRows?.join("\n") ?? details.log ?? "";
		return { head, body: [ansi(output, { follow: daemon.exitedAt === undefined, role: "omp.tool.proc.log" })] };
	}
	if (id && !details?.jobs && !details?.daemons && !details?.agents) {
		return { head, body: compact<NativeChild>([quotedPreview(firstText(result), "toolOutput")]) };
	}
	const jobs = details?.jobs ?? [];
	const services = (details?.daemons ?? []).map(serviceView);
	const agents = details?.agents ?? [];
	const items: NativeNode[] = [
		...jobs.map(job => jobItem(job)),
		...services.map(service =>
			node(
				"item",
				{
					label: [span("service", "accent"), span(" "), span(safe(service.name), "toolOutput")],
					detail: [span(daemonMetaText(service), "muted")],
					tone:
						service.state === "failed"
							? "error"
							: service.state === "ready" || service.state === "running"
								? "success"
								: "warning",
				},
				undefined,
				`service:${service.name}`,
			),
		),
		...agents.map(agent =>
			node(
				"item",
				{
					label: [span("agent", agent.live ? "accent" : "warning"), span(" "), span(safe(agent.id), "toolOutput")],
					value: [span(formatDuration(agent.ageMs), "muted")],
				},
				undefined,
				`agent:${agent.id}`,
			),
		),
	];
	const counts = [`${jobs.length} jobs`, `${services.length} services`];
	if (agents.length) counts.push(`${agents.length} agents`);
	return {
		head: toolHead(title, id ? span(safe(id), "accent") : undefined, counts.join(" · ")),
		body: [node("list", { empty: "No background jobs or services.", role: "omp.tool.proc.table" }, items)],
	};
}
