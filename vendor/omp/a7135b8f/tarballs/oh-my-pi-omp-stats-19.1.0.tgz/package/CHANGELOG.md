# Changelog

## [Unreleased]

### Added

- Added `readDailyActivity()`, which reads the stored daily activity through its own connection that never writes, so another process holding the stats database write lock cannot fail or delay it; it returns null when no stats database exists yet ([#19896](https://github.com/can1357/oh-my-pi/pull/19896) by [@Xytronix](https://github.com/Xytronix))

### Fixed

- Fixed opening an already initialized stats database taking the write lock, and daily activity trusting a rollup built by an older version instead of reading the raw rows ([#19896](https://github.com/can1357/oh-my-pi/pull/19896) by [@Xytronix](https://github.com/Xytronix))

## [19.0.1] - 2026-11-19

### Added

- Added 2d and 3d range presets with hourly buckets to the stats dashboard time selector ([#19766](https://github.com/can1357/oh-my-pi/issues/19766), [#19774](https://github.com/can1357/oh-my-pi/pull/19774) by [@thekitaev](https://github.com/thekitaev)).

## [19.0.0] - 2026-11-18

### Breaking Changes

- Spotlight recovery counts reads from local spill files toward recovery counts; reads from artifact references in older sessions continue to count as before.

### Added

- Expanded the Overview's Token mix to include off-transcript model calls—such as title generation, job captions, judge queries, and cache warming—with per-source request counts, token totals, and usage shares.
- Added a Decision models card to the Overview showing requests, tokens, and usage share by judgment use case for native judgment models.
- Request details for title-generation and judge calls now display the generated reply or recorded judge answers.

### Changed

- Token mix shares for the main agent, subagents, and advisor now reflect conversation turns only, excluding side-channel model calls.

### Fixed

- Hardened the dashboard against DNS rebinding by rejecting requests made through unconfigured public host names. IP addresses, localhost, LAN short names, local network domains, and Tailscale names remain supported; configure reverse-proxy or other custom domains with OMP_STATS_ALLOWED_HOSTS, including wildcard subdomains such as *.example.com.

## [18.22.1] - 2026-11-17

### Fixed

- Fixed the Gain tab undercounting savings for sessions that use snapcompact context compaction, including backfilling recent compaction history after upgrading.

## [18.20.1] - 2026-11-14

### Fixed

- Fixed Traces tab timing so background jobs show their actual completion times, including accurate idle periods and turn durations.
- Fixed per-model message counts on the Frustration page to include all answered messages.
- Improved dashboard responsiveness by keeping other pages and Live status available while Spotlight rebuilds.
- Fixed daily usage charts to group activity by the user's local calendar day instead of UTC.

## [18.20.0] - 2026-11-12

### Fixed

- Spotlight stats count a `;`/`,` path `read` once with all its parts, and count a later read of any of its files as a re-read or a needed line ([#18713](https://github.com/can1357/oh-my-pi/pull/18713) by [@eggpeat](https://github.com/eggpeat))

## [18.18.9] - 2026-11-11

### Added

- The Spotlight dashboard's Overhead card breaks failed results down by cause (not signed in, timeout, rate limited, HTTP status, …) and, when results failed for lack of a Stencil sign-in, says how to sign in ([#18850](https://github.com/can1357/oh-my-pi/pull/18850) by [@wolfiesch](https://github.com/wolfiesch))

## [18.18.4] - 2026-11-09

### Fixed

- Fixed `omp stats` re-parsing every unchanged session after a filesystem's device number changes, such as across ZFS remounts ([#14736](https://github.com/can1357/oh-my-pi/issues/14736)) ([#18536](https://github.com/can1357/oh-my-pi/pull/18536) by [@Alex-Wengg](https://github.com/Alex-Wengg)).

## [18.18.2] - 2026-11-08

### Fixed

- Fixed the trace dashboard returning HTTP 431 for sessions with many subagents.

## [18.17.0] - 2026-11-06

### Fixed

- Frustration no longer counts agent-attributed messages as user messages; history is corrected on next sync ([#18183](https://github.com/can1357/oh-my-pi/issues/18183)).
- Sessions sync promptly while an `omp stats` dashboard page is open, without repeated page refreshes during full sync.

## [18.16.0] - 2026-11-02

### Fixed

- Fixed Stats staying at an empty snapshot when the final ingest update arrives during an in-flight dashboard request ([#17754](https://github.com/can1357/oh-my-pi/issues/17754)).

## [18.14.2] - 2026-10-31

### Added

- Added `setStatsCloseHandler`: while a host sets one, the dashboard shows a Close button in its top bar and closes on Esc or Ctrl+C (with no text selected), for hosts that show it in place of their terminal

### Fixed

- Fixed tool error rates counting skipped tool calls that were explicitly marked as not executed ([#17463](https://github.com/can1357/oh-my-pi/pull/17463) by [@Xytronix](https://github.com/Xytronix)).

## [18.14.0] - 2026-10-29

### Changed

- Improved `omp stats` session synchronization performance by approximately 2–5× on large histories. The first sync after upgrading may take up to a minute while the stats database is optimized.

### Fixed

- Fixed `/stats` and `omp stats` failing when another dashboard was syncing sessions or the configured port was already in use; busy dashboards are now reused, and a free port is selected when necessary.

## [18.13.3] - 2026-10-28

### Changed

- Updated Bun engine requirement to ≥1.4.4

## [18.12.0] - 2026-10-17

### Fixed

- Fixed usage stats pricing Google Antigravity and MiniMax Token Plan models at $0 when their catalog rows carry no price; they now use the catalog's pricing peer, as `xai-oauth` already did ([#16092](https://github.com/can1357/oh-my-pi/pull/16092) by [@H4vC](https://github.com/H4vC))

## [18.11.0] - 2026-10-14

### Fixed

- Providers → Subscription windows no longer mixes Codex 5-hour and 7-day quotas across plans: Team and weekly-only (ProLite) accounts now share the 7-day row, the 5-hour row counts only accounts that have one, and labels no longer flip with whichever account reported last ([#15664](https://github.com/can1357/oh-my-pi/issues/15664))

## [18.10.4] - 2026-10-13

### Fixed

- Usage recorded at $0 for a model whose catalog price changes on a date (Gemini 4 Argon, Devin SWE-2) is now priced at the rate in force on the request's date, instead of staying $0 like peak/off-peak tariff usage ([#15620](https://github.com/can1357/oh-my-pi/pull/15620) by [@eggpeat](https://github.com/eggpeat))

## [18.9.0] - 2026-10-11

### Fixed

- Fixed the stats dashboard favicon so dashboard tabs and bookmarks display the OMP icon correctly.

## [18.8.0] - 2026-10-07

### Changed

- Improved dashboard responsiveness and efficiency by reducing unnecessary data refreshes and re-rendering, speeding up session synchronization, database access, package imports, and usage, model, and time-series requests, and avoiding repeated downloads of unchanged traces.
- Dashboard requests are now cancelled when no longer needed, improving responsiveness when switching sessions or closing trace views during loading.

## [18.7.0] - 2026-10-06

### Fixed

- Fixed Ultrafast turns not being counted toward the Premium Requests statistic.
- Fixed the desktop stats dashboard menu button so it no longer appears unnecessarily or dims the page without opening navigation.

## [18.6.0] - 2026-10-03

### Fixed

- Fixed the Frustration page splitting DeepSeek V4 provider variants and the V4.1 Flash alias into separate model-version rows ([#14194](https://github.com/can1357/oh-my-pi/issues/14194)).

## [18.5.1] - 2026-10-03

### Fixed

- Fixed stats dashboard request rows for Judge and other role-model calls so they open correctly and display usage details.
- Fixed stats and summary error-rate formatting so small nonzero percentages are displayed accurately instead of as 0.0%.
- Fixed a visual fringe on the edges of the stats dashboard’s “Classify with judge” button.

## [18.4.4] - 2026-09-29

### Added

- Added the `printStatsSummary` export, shared by `omp-stats --sync` and `omp stats --summary`.

## [18.4.3] - 2026-09-28

### Fixed

- Fixed `omp stats` dashboard numbers following the browser locale while the rest of the UI is English (e.g. `546 B` meaning 546 thousand and `$38.003,33` on a Turkish browser); figures now always use en-US formatting ([#13640](https://github.com/can1357/oh-my-pi/pull/13640) by [@NaC-L](https://github.com/NaC-L))

## [18.4.1] - 2026-09-28

### Fixed

- Fixed `/trace` and `omp stats` dashboards failing to load after operating-system temporary-file cleanup ([#13487](https://github.com/can1357/oh-my-pi/pull/13487) by [@Peter-Tam](https://github.com/Peter-Tam)).

## [18.4.0] - 2026-09-28

### Changed

- Redesigned the dashboard: new layout, navigation (`g` + letter to jump, `1`–`6` to pick a range), sortable tables and in-house charts on every page
- The dashboard opens immediately and ingests sessions in the background, most recent activity first, with live progress in the header; pages update as data lands and new session activity appears within seconds
- Switching time ranges is now near-instant: range queries read hourly rollups instead of scanning every request (seconds → milliseconds on large histories)
- Frustration judge runs now scale how many requests they keep in flight (up to 256, backing off on rate limits and retrying after a short delay) and save verdicts in batches; the progress line shows the rate and requests in flight
- Provider subscription windows load separately from the rest of the Providers page, and the Projects page lists the 2,000 busiest folders
- Replaced the dashboard's Behavior page with a Frustration page showing, per model version, how often users are annoyed, annoyed at the assistant, and angry at it; a button judges unclassified messages with the host's `judge` model (after a cost estimate) and the chart refines live as verdicts arrive

### Fixed

- Made session-statistics synchronization atomic to prevent duplicate entries when synchronization is interrupted.
- Improved the speed and reliability of initial and repeat `omp stats` imports, including large session histories and already-indexed histories.

## [18.2.9] - 2026-09-22

### Fixed

- Fixed background statistics spans to use unique identifiers and close jobs correctly.

## [18.2.5] - 2026-09-17

### Fixed

- Improved session and fork-detection polling performance, reducing unnecessary filesystem and database work when monitoring sessions.

## [18.2.1] - 2026-09-15

### Fixed

- Fixed the sessions API returning an encoded storage key instead of the session working directory ([#12078](https://github.com/can1357/oh-my-pi/pull/12078) by [@Dante-dan](https://github.com/Dante-dan)).
- Fixed Traces search inputs and checkbox using unthemed browser defaults, and iOS viewport zoom on search focus.
- Fixed garbage tool names from provider-side parse failures (e.g. a gateway returning the model's whole invocation text as the tool name) polluting the tools dashboard's per-tool rows and filter dropdown; such names now collapse to their leading identifier, and existing databases re-ingest cleaned on next sync.
- Reduced repeat stats-sync reads to appended transcript data while preserving service-tier accounting across restarts.
- Rebuilt stats for replaced or truncated session files instead of retaining stale totals.
- Reclaimed lingering stats dashboards from older releases using their versioned HTTP identity when process command lines are unavailable, so upgrades no longer leave `omp stats` blocked by an opaque Bun listener.

## [18.1.17] - 2026-09-10

### Fixed

- Fixed historical cost estimates after a scheduled price change: usage is estimated at the request's own time, and charges recorded at the time are preserved.
- Fixed legacy requests that recorded no cost at all being stored as free usage: they are estimated at their request timestamp, and requests without a recoverable timestamp stay unpriced instead of being billed as 1970.
- Fixed a legacy entry whose malformed token counter was summed into an inflated request total; counters that are not finite numbers now count as absent.
- Fixed requests whose timestamp could not be recovered being reported as free usage: they now count as unpriced (`N/A`) rather than `$0`, in both the aggregates and the per-request list, and an existing database re-parses its sessions once so rows stored before this change are repaired.
- Fixed the trace summary showing `$0` instead of `N/A` for legacy scheduled requests that omit their token total: the total is derived from the token buckets before classifying unpriced usage.

## [18.1.3] - 2026-09-02

### Changed

- Provider, tool, and project `<select>` dropdowns are now styled to match the dashboard design, with dark and light theme support.

## [18.1.0] - 2026-09-01

### Added

- Added API for daily activity tracking, including cost, requests, and token usage aggregates
- Added a Traces dashboard for detailed session analysis, including an interactive timeline, searchable and filterable transcripts, token and cost summaries, and aggregate tool-usage and timing insights.

### Fixed

- Fixed `omp stats` omitting usage from online auto-thinking classifier calls.

## [18.0.9] - 2026-08-28

### Fixed

- Fixed inconsistent model colors between the Model Preference chart and Model Statistics table.

## [18.0.4] - 2026-08-24

### Fixed

- Fixed SuperGrok usage appearing as free by applying matching public xAI API pricing (including 200K-token rates), labeling costs as API-equivalent estimates, backfilling existing usage records, and displaying subscription-only models as N/A ([#9512](https://github.com/can1357/oh-my-pi/issues/9512)).

## [18.0.1] - 2026-08-23

### Fixed

- Fixed the Projects dashboard folder endpoint running unrelated dashboard aggregations when loading folder statistics.
- Fixed stats sync crashing with a NOT NULL constraint error when legacy session files carry a partially-populated usage cost.

## [17.4.0] - 2026-08-20

### Changed

- Window token estimates now incorporate broker-reported fleet token burn when an auth broker is configured, accurately tracking fleet-wide usage instead of undercounting with local-only statistics.

### Fixed

- Fixed an issue in subscription-window insights where distinct limits sharing a duration label (such as Anthropic overall vs. model-scoped 7-day windows) were incorrectly merged, which inflated window-equivalents and skewed tokens-per-window estimates. Windows are now grouped by provider limit ID.

## [17.3.6] - 2026-08-17

### Fixed

- Fixed the stats dashboard being unreachable from container hosts by accepting an explicit `--host` bind address while preserving loopback-only binding and same-origin API access by default.

## [17.3.0] - 2026-08-13

### Added

- Added cost-weighted `cacheSavings` metric alongside `cacheRate`, accounting for cache-read discounts and write premiums against equivalent uncached prompt costs.

### Fixed

- Ensured the embedded dashboard archive is byte-reproducible by sorting entries and zeroing tar and gzip timestamps during compilation.

## [17.2.10] - 2026-08-06

### Changed

- Optimized package dependencies by replacing `date-fns` with `@oh-my-pi/pi-utils/dates` and removing unused test dependencies.

## [17.2.9] - 2026-08-05

### Fixed

- Restricted the stats dashboard to IPv4 loopback and removed wildcard CORS access to its API ([#7633](https://github.com/can1357/oh-my-pi/issues/7633)).

## [17.2.4] - 2026-08-01

### Fixed

- Fixed provider usage window stats silently showing no data during SQLite contention by installing a five-second busy timeout on read-only agent database connections ([#7300](https://github.com/can1357/oh-my-pi/issues/7300)).

## [17.1.2] - 2026-07-24

### Added

- Added a Providers dashboard section: per-provider totals, stacked token/cost burn over time, peak-burn-hours histogram, subscription-window insights (windows burned, estimated tokens per window, peak concurrent utilization, ideal account count, exhaustion events), and latest window utilization per account — window analytics read the auth broker's `/v1/usage/history` when a broker is configured (falling back to the local agent DB), since broker deployments record usage history on the broker host

## [17.1.0] - 2026-07-24

### Fixed

- Fixed an issue where malformed persisted content blocks could abort stats ingestion for subsequent projects, and ensured pending full-session migrations are properly settled after successful backfills.

## [17.0.6] - 2026-07-20

### Changed

- Clarified overview token accounting by separating uncached input from cache reads and showing the conversation-token total used by the agent breakdown.

## [17.0.5] - 2026-07-18

### Fixed

- Fixed an EADDRINUSE error by properly reusing the live stats dashboard on the requested port and reclaiming stale listeners (#5970).

## [17.0.2] - 2026-07-17

### Fixed

- Fixed the Recent Errors list to honor the selected dashboard time range before returning the newest 50 failures.

## [16.4.7] - 2026-07-12

### Fixed

- Fixed a `SQLITE_CONSTRAINT_NOTNULL` crash (`messages.stop_reason`) aborting the entire session sync when a persisted assistant message lacks a `stopReason`. Malformed entries — missing stop reason, token counts, or message timestamp — are now coerced at the parser boundary, and entries with no usage or model attribution are skipped instead of failing the batch insert.

## [16.4.2] - 2026-07-10

### Fixed

- Fixed a crash during stats synchronization on legacy session entries that lack a cost breakdown by falling back to catalog pricing when available.

## [16.3.9] - 2026-07-06

### Changed

- Refined behavior metrics to significantly reduce false positives in profanity, yelling, and anguish detection by excluding technical terms (e.g., "dummy", "trash", "garbage"), neutral punctuation (e.g., dot runs), and single-word capitalization (e.g., filenames or environment variables).
- Re-categorized frustration interjections (such as "ugh", "argh", and "grr") from profanity to anguish.
- Improved negation and blame detection to exclude determiners (e.g., "no auto start") and compounds (e.g., "no-op") while adding support for phrases like "why did you" and "makes no sense".
- Added sad emoticons as a signal for anguish while excluding code-like patterns.
- Triggered a one-time automatic re-ingestion of sessions on the next database sync to apply the updated metrics.

## [16.3.7] - 2026-07-05

### Changed

- Optimized session-entry lookup and file reading performance by caching file metadata to avoid repeated full-file scans.

## [16.3.1] - 2026-07-02

### Added

- Added a Tools tab to the `omp stats` dashboard (`/#/tools`): per-tool call counts, error rates, result/argument payload sizes, per-model breakdown, and a stacked calls-over-time chart. Token and cost columns attribute each invoking turn's real provider usage evenly across that turn's tool calls. Existing databases re-parse sessions once on the next sync to backfill historical tool calls.

## [16.2.7] - 2026-06-30

### Fixed

- Improved premium request calculation accuracy by correctly accounting for specific model families.

## [16.2.6] - 2026-06-29

### Fixed

- Fixed application crashes and Bun aborts on macOS and when parsing large stats session files, including during `omp --smoke-test` runs, by utilizing a more resilient serial parser and lenient line scanner.

## [16.2.3] - 2026-06-28

### Added

- Support for parsing named advisor transcripts using the `__advisor.<slug>.jsonl` naming convention.

## [16.2.0] - 2026-06-27

### Added

- Added a Gain tab to the `omp stats` dashboard (`/#/gain`) to display snapcompact token-savings with project scoping from synced session folders.

## [16.1.17] - 2026-06-24

### Fixed

- Stats sync counted the same provider request multiple times when a forked or branched session file copied the parent's entries verbatim. Inserts now skip rows whose `(entry_id, timestamp)` already exists under a different `session_file`, and a one-shot migration on the next `omp stats` run collapses any pre-existing duplicates ([#3370](https://github.com/can1357/oh-my-pi/issues/3370)).

## [16.1.15] - 2026-06-22

### Added

- Added token usage breakdown by agent type (Main, Subagents, Advisor) to the overview dashboard

## [16.0.10] - 2026-06-18

### Changed

- Updated description of moderated content categories to use more inclusive terminology

### Fixed

- Wide data tables (Requests, Errors, Overview, Projects) overflowed the page horizontally at narrow-desktop widths (768-1023px): the `.stats-table-desktop-only` wrapper used for mobile-card tables lacked the `overflow-x: auto` containment that `.stats-table-container` already has. They now scroll within their own bounds instead of spilling the page body.

## [16.0.5] - 2026-06-17

### Added

- New Projects view summarizing usage, cost, and reliability per project folder (backed by the existing `/api/stats/folders` endpoint).
- System-aware light/dark theme toggle — follows the OS by default, and an explicit choice persists across reloads.

### Changed

- Redesigned the local stats dashboard with an OMP-themed product shell, dedicated per-section views, accessible loading/empty/error states, and flicker-free navigation between screens and time ranges.

### Fixed

- The 1h time-range chart rendered an empty/single-point line; it now buckets at 5-minute granularity for a real trend.

## [15.13.3] - 2026-06-15

### Changed

- Renamed `__omp_stats_sync_worker` to `__omp_worker_stats_sync`.

## [15.13.1] - 2026-06-15

### Fixed

- Dropped `git` from the profanity list so normal repository mentions no longer count as profanity

## [15.12.4] - 2026-06-13

### Fixed

- Fixed the stats dashboard's SQLite init never setting `PRAGMA busy_timeout`, so a concurrent `omp` startup hitting WAL recovery could crash `initDb()` with `SQLITE_BUSY` instead of waiting through it. The busy handler is now installed before `PRAGMA journal_mode=WAL` ([#2421](https://github.com/can1357/oh-my-pi/issues/2421)).

## [15.11.0] - 2026-06-10

### Added

- Added support for prebuilt npm bundle mode via `PI_BUNDLED`, allowing the stats server to use an embedded dashboard bundle in packaged CLI distributions

### Fixed

- Fixed handling of legacy `embedded-client.generated.txt` placeholder content so it is treated as missing archive instead of being decoded into invalid bytes
- Fixed ENOENT handling while scanning dashboard source/build directories so missing `client/` or `dist/client` trees no longer crash startup

## [15.10.11] - 2026-06-10

### Changed

- Bundled-model lookups (`getBundledModel`, `GeneratedProvider`) now import from the new `@oh-my-pi/pi-catalog` package instead of the `@oh-my-pi/pi-ai` barrel, which no longer re-exports catalog values
- The session-sync worker re-enters the host CLI entry (`workerHostEntry()` + `__omp_stats_sync_worker` argv selector) when running inside omp — source, npm bundle, or compiled binary — and keeps loading its own `sync-worker.ts` module directly for standalone `omp-stats`, bun test, and SDK hosts

## [15.1.6] - 2026-05-19

### Fixed

- Fixed `omp stats` crashing on first session sync in published `omp-{linux,darwin,windows}-*` binaries with `BuildMessage: ModuleNotFound resolving "./packages/stats/src/sync-worker.ts"`; the release build script now lists the stats sync, browser tab, and JS eval workers as explicit `--compile` entrypoints so Bun emits them into bunfs, matching the dev build script and the AGENTS.md worker spawn contract. ([#1150](https://github.com/can1357/oh-my-pi/issues/1150))

## [15.1.0] - 2026-05-15

### Fixed

- Fixed incremental `parseSessionFile(path, fromOffset)` losing the active service tier when resuming past a `service_tier_change` entry, so priority OpenAI replies appended after the offset are now credited with `premiumRequests: 1` (regression introduced by 13f59162e which stopped folding priority-tier into per-message premium counts)

## [15.0.1] - 2026-05-14

### Breaking Changes

- Raised the minimum required Bun version to >=1.3.14 in package metadata

### Changed

- Changed the "Premium Reqs" dashboard card to also include OpenAI priority service-tier requests (`serviceTier: "priority"`), counting each as 1 premium request alongside GitHub Copilot premium calls. Pre-existing sessions are backfilled on the next `omp stats` run: a one-shot `premium_requests_priority_v1` sentinel wipes `file_offsets` so every session re-parses, and `insertMessageStats` now `UPSERT`s `premium_requests` (other columns untouched) using the `service_tier_change` entries already in the session log to retroactively credit priority traffic.

## [14.9.9] - 2026-05-12

### Added

- Added separate input-token and output-token totals to the overview dashboard cards.

### Fixed

- Fixed `omp stats` in compiled binaries by using the serial sync path instead of spawning a raw file-asset worker that cannot import bundled parser code.
- Fixed behavior backfills after failed compiled-binary sync attempts by marking the backfill sentinel only after a successful full sync.

## [14.9.7] - 2026-05-12

### Breaking Changes

- Broke backward compatibility of behavior stats fields by replacing `yellingSentences`/`dramaRuns` with `yelling`/`anguish` and adding `negation`, `repetition`, `blame` in query result types and persisted `user_messages` schema

### Added

- Added `SyncOptions` to `syncAllSessions` with `onProgress` and `workers` to optionally show per-file sync progress and tune parser concurrency
- Added new frustration behavior metrics (`negation`, `repetition`, `blame`) plus a `frustration` aggregate in behavior charts, model tables, and summary cards

### Changed

- Changed sync ingestion to parse session files through a worker pool while applying parsed results and database writes on the main thread
- Changed behavior analysis to strip code blocks, XML/URLs, quoted lines, and placeholders before scoring and to suppress signals on long structured messages
- Changed dashboard metrics labels and totals to the new signal names, including replacing the old three-signal totals with `yelling`, `profanity`, `anguish`, and `frustration`
- Changed sync output to print a live terminal progress indicator while processing session files

### Fixed

- Fixed user-message attribution so assistant model/provider links are backfilled during incremental sync instead of being left unknown
- Fixed word-boundary regex handling in profanity detection so matching now works as intended in normal prose

## [14.9.5] - 2026-05-12

### Added

- Added time range selection options (1h, 24h, 7d, 30d, 90d, All) to the dashboard header and bound them to reloading statistics for the selected window
- Added a **Behavior** dashboard page that tracks user yelling (CAPS), profanity, and dramatic punctuation (`!!!` / `???`) per day, with by-model comparisons mirroring the cost page
- Added a per-model behavior table to the **Behavior** page mirroring the Models table: sortable rows of CAPS / profanity / drama hits per model with sparkline trend and an expandable per-model breakdown chart
- Added optional `range` query parameter support on stats endpoints to retrieve metrics scoped to a requested time window

### Changed

- Changed the Costs dashboard summary to report totals, average per day, and top model for the selected time range instead of a fixed 30-day window and removed the previous-30-day trend comparison
- Changed behavior metrics ingestion to compute yelling from user message sentence-level uppercase ratios, filtering out short uppercase fragments so the behavior data is attributed to messages more accurately
- Removed per-chart 14/30/90 day pickers on Costs and Behavior pages so every page obeys the single time-range selector in the header
- Changed dashboard and stats queries to return data from the selected time window instead of always using all-time aggregates
- Changed the default displayed range in the UI/API to last 24h
- Added support for returning all data when `range=all` is requested

### Fixed

- Fixed handling of unknown `range` values by falling back to the last 24h instead of returning unscoped data
- Fixed `omp stats` failing to build the client on globally-installed installs by promoting `tailwindcss` from `devDependencies` to `dependencies` (the client build runs at runtime)

## [14.5.4] - 2026-04-28

### Fixed

- Fixed GPT cost reporting by deriving missing OpenAI Codex costs from the model catalog and backfilling existing zero-cost rows.

## [13.6.0] - 2026-03-03

### Fixed

- Include subtask session files in usage stats ([#250](https://github.com/can1357/oh-my-pi/issues/250))
