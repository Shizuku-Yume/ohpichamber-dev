import type { Dirent } from "node:fs";
import * as fs from "node:fs/promises";
import * as path from "node:path";
import { isEnoent, logger } from "@oh-my-pi/pi-utils";
import { $, type Server } from "bun";
import {
	getCostDashboardStats,
	getDashboardStats,
	getFolderStats,
	getModelDashboardStats,
	getOverviewStats,
	getProviderDashboardStats,
	getProviderWindowStats,
	getRecentErrors,
	getRecentRequests,
	getRequestDetails,
	getTimeRangeConfig,
	getToolDashboardStats,
} from "./aggregator";
import { initDb } from "./db";
import { decodeEmbeddedClientArchive, hasEmbeddedClientArchive } from "./embedded-client";
import embeddedClientArchiveTxt from "./embedded-client.generated.txt";
import {
	cancelFrustrationRun,
	estimateFrustrationRun,
	getFrustrationDashboardStats,
	type StatsJudgeProvider,
	setStatsJudgeProvider,
	startFrustrationRun,
} from "./frustration";
import { getGainDashboardStats } from "./gain-aggregator";
import { statsLive } from "./live";
import {
	prepareStatsPort,
	recoverStatsPort,
	STATS_DASHBOARD_HEADER,
	STATS_DASHBOARD_HOSTNAME,
	STATS_DASHBOARD_HOSTNAME_HEADER,
	STATS_DASHBOARD_SECURITY_VERSION,
} from "./port-conflict";
import { getStatsByModel, getTimeSeries } from "./rollup";
import { buildSpotlightDashboardJson, getSpotlightSessionContext } from "./spotlight-aggregator";
import {
	buildSessionTrace,
	getTraceEntry,
	listSessionSummaries,
	TRACE_ETAG_VERSION,
	type TraceFingerprint,
	traceEtagForFingerprint,
	traceFingerprintForEtag,
	TracePathError,
} from "./trace";

const CLIENT_DIR = path.join(import.meta.dir, "client");
const STATIC_DIR = path.join(import.meta.dir, "..", "dist", "client");
const IS_BUN_COMPILED =
	Boolean(process.env.PI_COMPILED || Bun.env.PI_COMPILED) ||
	import.meta.url.includes("$bunfs") ||
	import.meta.url.includes("~BUN") ||
	import.meta.url.includes("%7EBUN");
// The prepacked npm bundle (coding-agent dist/cli.js) constant-folds
// process.env.PI_BUNDLED at build time. Like compiled binaries, it ships no
// dashboard sources or prebuilt dist/client next to the bundle, so the
// embedded archive is the only viable asset source.
const IS_PREBUILT = IS_BUN_COMPILED || Boolean(process.env.PI_BUNDLED || Bun.env.PI_BUNDLED);
// Sniff the base64 gzip magic instead of decoding: importing this module (every
// TUI start) must not pay for a multi-megabyte archive nobody may serve.
const USE_EMBEDDED_CLIENT = hasEmbeddedClientArchive(embeddedClientArchiveTxt) || IS_PREBUILT;

let embeddedClientFilesPromise: Promise<Map<string, Blob>> | null = null;

async function getEmbeddedClientFiles(): Promise<Map<string, Blob>> {
	if (embeddedClientFilesPromise) return embeddedClientFilesPromise;

	const archive = decodeEmbeddedClientArchive(embeddedClientArchiveTxt);
	if (!archive) {
		throw new Error(
			"Embedded stats client bundle missing. Rebuild the omp binary or npm bundle with embedded stats assets.",
		);
	}

	// Keep bundled assets in memory so OS temporary-file cleanup cannot break a live dashboard.
	embeddedClientFilesPromise = new Bun.Archive(archive).files().then(files => {
		for (const [name, file] of files) {
			// Archive entries are untyped blobs; infer MIME types just as disk-backed Bun files do.
			files.set(name, new File([file], name, { type: Bun.file(name).type }));
		}
		return files;
	});

	return embeddedClientFilesPromise;
}

async function getLatestMtime(dir: string): Promise<number> {
	let entries: Dirent[];
	try {
		entries = await fs.readdir(dir, { withFileTypes: true });
	} catch (err) {
		// Tolerate missing source trees (e.g. installs without the dashboard
		// sources); the caller falls back to prebuilt assets or a clear build
		// failure instead of crashing on the scan.
		if (isEnoent(err)) return 0;
		throw err;
	}

	const promises = [];
	for (const entry of entries) {
		const fullPath = path.join(dir, entry.name);
		if (entry.isDirectory()) {
			promises.push(getLatestMtime(fullPath));
		} else if (entry.isFile()) {
			promises.push(fs.stat(fullPath).then(stats => stats.mtimeMs));
		}
	}

	let latest = 0;
	await Promise.allSettled(promises).then(results => {
		for (const result of results) {
			if (result.status === "fulfilled") {
				latest = Math.max(latest, result.value);
			}
		}
	});
	return latest;
}

const ensureClientBuild = async () => {
	if (USE_EMBEDDED_CLIENT) return;
	const indexPath = path.join(STATIC_DIR, "index.html");
	const cssPath = path.join(STATIC_DIR, "index.css");
	const sourceMtime = await getLatestMtime(CLIENT_DIR);
	let shouldBuild = true;
	try {
		const [indexStats, cssStats] = await Promise.all([fs.stat(indexPath), fs.stat(cssPath)]);
		if (
			indexStats.isFile() &&
			cssStats.isFile() &&
			indexStats.mtimeMs >= sourceMtime &&
			cssStats.mtimeMs >= sourceMtime
		) {
			shouldBuild = false;
		}
	} catch {
		shouldBuild = true;
	}

	if (!shouldBuild) return;

	await fs.rm(STATIC_DIR, { recursive: true, force: true });

	logger.debug("Building stats client");
	const packageRoot = path.join(import.meta.dir, "..");
	const buildResult = await $`bun run build.ts`.cwd(packageRoot).quiet().nothrow();
	if (buildResult.exitCode !== 0) {
		const output = buildResult.text().trim();
		const details = output ? `\n${output}` : "";
		throw new Error(`Failed to build stats client (exit ${buildResult.exitCode})${details}`);
	}
};

/**
 * Required on every spending/mutating POST. A custom header forces a CORS
 * preflight, which this server never approves, so a hostile page cannot
 * trigger a paid judge run through a cross-site form or `fetch`.
 */
const STATS_ACTION_HEADER = "X-Omp-Stats-Action";

/** What the page's Close calls; unset, the page offers none. */
let closeHandler: (() => void) | undefined;

/** Longest a Spotlight build serves later requests of its data version: its time range moves with the clock. */
const SPOTLIGHT_VIEW_TTL_MS = 60_000;

/** Spotlight payloads (JSON) of one live data version by `range\0agent`, with when each was requested. */
let spotlightViews: { version: number; views: Map<string, { at: number; json: Promise<string> }> } | null = null;

/** Aborted when the last dashboard of this process stops, ending the Spotlight builds still running for it. */
let spotlightBuilds = new AbortController();

/** Settles when the last queued Spotlight build does: builds run one at a time, as they did on the server's thread. */
let spotlightQueue: Promise<unknown> = Promise.resolve();

/**
 * The Spotlight dashboard as JSON, built once per data version and view. Every open page refetches on each version
 * bump and a build takes seconds of a worker's CPU and memory, so pages showing the same view share one build and
 * different views wait their turn.
 */
function spotlightView(range: string | null, agent: string | null): Promise<string> {
	const version = statsLive().status().version;
	if (spotlightViews?.version !== version) spotlightViews = { version, views: new Map() };
	const views = spotlightViews.views;
	const key = `${range ?? ""}\0${agent ?? ""}`;
	const cached = views.get(key);
	if (cached && Date.now() - cached.at < SPOTLIGHT_VIEW_TTL_MS) return cached.json;
	const { signal } = spotlightBuilds;
	const json = spotlightQueue.then(() => buildSpotlightDashboardJson(range, agent, signal));
	spotlightQueue = json.catch(() => {});
	const entry = { at: Date.now(), json };
	views.set(key, entry);
	// A failed build is not reused.
	json.catch(() => {
		if (views.get(key) === entry) views.delete(key);
	});
	return json;
}

/**
 * Let the page close the dashboard: while `close` is set, it shows a Close
 * button (and takes Esc and Ctrl+C) that calls it. `omp stats` sets it while
 * Tern shows the page in place of the block it runs in, where the page has no
 * way out of its own; `undefined` takes Close away again.
 */
export function setStatsCloseHandler(close: (() => void) | undefined): void {
	closeHandler = close;
}

/**
 * Handle API requests.
 */
export async function handleApi(req: Request): Promise<Response> {
	const url = new URL(req.url);
	const path = url.pathname;

	// Stats reads are DB-only; ingest runs in the background (see `live.ts`).
	const range = url.searchParams.get("range");

	if (path === "/api/status") {
		return Response.json(statsLive().status());
	}

	if (path === "/api/stats") {
		const stats = await getDashboardStats(range);
		return Response.json(stats);
	}

	if (path === "/api/stats/overview") {
		const stats = await getOverviewStats(range);
		return Response.json(stats);
	}

	if (path === "/api/stats/model-dashboard") {
		const stats = await getModelDashboardStats(range);
		return Response.json(stats);
	}

	if (path === "/api/stats/costs") {
		const stats = await getCostDashboardStats(range);
		return Response.json(stats);
	}

	if (path === "/api/stats/frustration") {
		const stats = await getFrustrationDashboardStats(range);
		return Response.json(stats);
	}

	if (path === "/api/frustration/estimate") {
		const estimate = await estimateFrustrationRun(range);
		return Response.json(estimate);
	}

	if (path === "/api/frustration/judge" || path === "/api/frustration/cancel") {
		if (req.method !== "POST") return Response.json({ error: "POST required" }, { status: 405 });
		if (req.headers.get(STATS_ACTION_HEADER) !== "1") {
			return Response.json({ error: `${STATS_ACTION_HEADER}: 1 header required` }, { status: 403 });
		}
		if (path === "/api/frustration/cancel") return Response.json(cancelFrustrationRun());
		const result = await startFrustrationRun(range);
		if (!result.started) return Response.json({ error: result.error }, { status: result.status });
		return Response.json(result.job, { status: 202 });
	}

	if (path === "/api/stats/tools") {
		const stats = await getToolDashboardStats(range);
		return Response.json(stats);
	}

	if (path === "/api/stats/provider-windows") {
		return Response.json(await getProviderWindowStats(range, url.searchParams.get("provider")));
	}

	if (path === "/api/stats/providers") {
		const stats = await getProviderDashboardStats(range);
		return Response.json(stats);
	}

	if (path === "/api/stats/recent") {
		const limit = url.searchParams.get("limit");
		const stats = await getRecentRequests(limit ? parseInt(limit, 10) : undefined);
		return Response.json(stats);
	}

	if (path === "/api/stats/errors") {
		const limit = url.searchParams.get("limit");
		const stats = await getRecentErrors(range, limit ? parseInt(limit, 10) : undefined);
		return Response.json(stats);
	}

	if (path === "/api/stats/models") {
		// Also the port-conflict identity probe: keep it to the one query it serves.
		await initDb();
		return Response.json(getStatsByModel(getTimeRangeConfig(range).cutoff));
	}

	if (path === "/api/stats/folders") {
		const stats = await getFolderStats(range);
		return Response.json(stats);
	}

	if (path === "/api/stats/timeseries") {
		await initDb();
		return Response.json(getTimeSeries(getTimeRangeConfig(range)));
	}

	if (path.startsWith("/api/request/")) {
		const id = path.split("/").pop();
		if (!id) return new Response("Bad Request", { status: 400 });
		const details = await getRequestDetails(parseInt(id, 10));
		if (!details) return new Response("Not Found", { status: 404 });
		return Response.json(details);
	}

	if (path === "/api/close") {
		if (req.method === "GET") return Response.json({ closable: closeHandler !== undefined });
		if (req.method !== "POST") return Response.json({ error: "GET or POST required" }, { status: 405 });
		if (req.headers.get(STATS_ACTION_HEADER) !== "1") {
			return Response.json({ error: `${STATS_ACTION_HEADER}: 1 header required` }, { status: 403 });
		}
		if (!closeHandler) return Response.json({ error: "this dashboard is not closed from its page" }, { status: 404 });
		closeHandler();
		return new Response(null, { status: 202 });
	}

	if (path === "/api/sync") {
		if (req.method !== "POST") return Response.json({ error: "POST required" }, { status: 405 });
		statsLive().requestSync();
		return Response.json(statsLive().status(), { status: 202 });
	}

	if (path === "/api/stats/gain") {
		const project = url.searchParams.get("project");
		const stats = await getGainDashboardStats(range, project);
		return Response.json(stats);
	}
	if (path === "/api/stats/spotlight") {
		return new Response(await spotlightView(range, url.searchParams.get("agent")), {
			headers: { "content-type": "application/json;charset=utf-8" },
		});
	}

	if (path === "/api/stats/spotlight/session") {
		const file = url.searchParams.get("file");
		if (!file) return Response.json({ error: "file required" }, { status: 400 });
		const context = await getSpotlightSessionContext(file);
		if (!context) return Response.json({ error: "not a Spotlight experiment session" }, { status: 404 });
		return Response.json(context);
	}

	if (path === "/api/sessions") {
		const limitParam = Number(url.searchParams.get("limit") ?? "100");
		const limit = Number.isFinite(limitParam) && limitParam > 0 ? Math.floor(limitParam) : 100;
		const q = url.searchParams.get("q") ?? undefined;
		return Response.json(await listSessionSummaries(limit, q));
	}

	if (path === "/api/session/trace") {
		const file = url.searchParams.get("file");
		if (!file) return Response.json({ error: "file required" }, { status: 400 });
		try {
			// ETag-first: compare the client's etag against the
			// root+child fingerprint WITHOUT building the trace. A matching
			// (unchanged) poll returns 304 after stats only; only a changed
			// tree pays the full re-read/re-parse/rebuild in
			// buildSessionTrace (itself memoized for non-conditional polls).
			// The fingerprint covers child transcripts, so a subagent-only
			// append changes the ETag and never 304s stale.
			const clientEtag = req.headers.get("if-none-match");
			let fingerprint: TraceFingerprint | undefined;
			if (clientEtag) {
				fingerprint = await traceFingerprintForEtag(file);
				if (fingerprint !== undefined) {
					const etag = `"${TRACE_ETAG_VERSION}:${traceEtagForFingerprint(fingerprint)}"`;
					if (clientEtag === etag) return new Response(null, { status: 304 });
				}
			}
			const trace = await buildSessionTrace(file, fingerprint);
			const etag = `"${TRACE_ETAG_VERSION}:${trace.etag}"`;
			if (clientEtag === etag) return new Response(null, { status: 304 });
			return Response.json(trace, { headers: { ETag: etag } });
		} catch (err) {
			if (err instanceof TracePathError) return Response.json({ error: err.message }, { status: 400 });
			if (isEnoent(err)) return Response.json({ error: "session not found" }, { status: 404 });
			throw err;
		}
	}

	if (path === "/api/session/entry") {
		const file = url.searchParams.get("file");
		const id = url.searchParams.get("id");
		if (!file || !id) return Response.json({ error: "file and id required" }, { status: 400 });
		try {
			const entry = await getTraceEntry(file, id);
			if (!entry) return Response.json({ error: "entry not found" }, { status: 404 });
			return Response.json({ entry });
		} catch (err) {
			if (err instanceof TracePathError) return Response.json({ error: err.message }, { status: 400 });
			throw err;
		}
	}

	return new Response("Not Found", { status: 404 });
}

/**
 * Handle static file requests.
 */
async function handleStatic(requestPath: string): Promise<Response> {
	if (USE_EMBEDDED_CLIENT) {
		const files = await getEmbeddedClientFiles();
		const file = files.get(requestPath.slice(1)) ?? files.get("index.html");
		return file ? new Response(file) : new Response("Not Found", { status: 404 });
	}

	const filePath = requestPath === "/" ? "/index.html" : requestPath;
	const fullPath = path.join(STATIC_DIR, filePath);

	const file = Bun.file(fullPath);
	if (await file.exists()) {
		return new Response(file);
	}

	// SPA fallback
	const index = Bun.file(path.join(STATIC_DIR, "index.html"));
	if (await index.exists()) {
		return new Response(index);
	}

	return new Response("Not Found", { status: 404 });
}

/** Format a dashboard origin, including brackets required by IPv6 literals. */
export function formatStatsDashboardUrl(hostname: string, port: number): string {
	const urlHostname = hostname.includes(":") && !hostname.startsWith("[") ? `[${hostname}]` : hostname;
	return `http://${urlHostname}:${port}`;
}

/** Extra Host names (comma-separated) the dashboard answers to; `*.example.com` allows its subdomains. */
export const STATS_ALLOWED_HOSTS_ENV = "OMP_STATS_ALLOWED_HOSTS";

/**
 * Suffixes no public DNS server can hand out: loopback, mDNS, private-use names, Tailscale MagicDNS, and the
 * undelegated search domains home routers assign (`.lan`, `.home`, `.corp`, `.localdomain`).
 */
const PRIVATE_NAME_SUFFIXES = [
	".localhost",
	".local",
	".internal",
	".home.arpa",
	".ts.net",
	".lan",
	".home",
	".corp",
	".localdomain",
];
const IPV4_LITERAL = /^\d+\.\d+\.\d+\.\d+$/;

/** Host names allowed beyond the built-in rules: exact names and `.suffix`es. */
interface AllowedHosts {
	exact: Set<string>;
	suffixes: string[];
}

function normalizeHostName(name: string): string {
	return name.trim().toLowerCase().replace(/\.$/, "");
}

/**
 * DNS-rebinding guard. A rebinding page reaches the dashboard under a public name whose DNS the attacker
 * controls, and the browser sends that name as Host; it can never send an IP literal or a name public DNS
 * cannot resolve. So IP literals, `localhost`, single-label names (LAN and MagicDNS short names) and
 * {@link PRIVATE_NAME_SUFFIXES} pass (Tailscale Serve forwards its `*.ts.net` Host unchanged), and any other
 * dotted name must be the bind name or listed in {@link STATS_ALLOWED_HOSTS_ENV}. `hostname` is the parsed
 * request URL's.
 */
function isRebindSafeHost(hostname: string, allowed: AllowedHosts): boolean {
	const name = normalizeHostName(hostname);
	if (name.startsWith("[") || IPV4_LITERAL.test(name) || !name.includes(".")) return true;
	if (allowed.exact.has(name)) return true;
	return [...PRIVATE_NAME_SUFFIXES, ...allowed.suffixes].some(suffix => name.endsWith(suffix));
}

function readAllowedHosts(bindHostname: string): AllowedHosts {
	// The operator chose the bind name, and the printed URL and the reuse probe both use it.
	const allowed: AllowedHosts = { exact: new Set([normalizeHostName(bindHostname)]), suffixes: [] };
	for (const entry of (process.env[STATS_ALLOWED_HOSTS_ENV] ?? "").split(",")) {
		const name = normalizeHostName(entry);
		if (name.startsWith("*.")) {
			if (name.length > 2) allowed.suffixes.push(name.slice(1));
		} else if (name) {
			allowed.exact.add(name);
		}
	}
	return allowed;
}

function createDashboardServer(port: number, hostname: string): Server<undefined> {
	const allowedHosts = readAllowedHosts(hostname);
	const server = Bun.serve({
		port,
		hostname,
		async fetch(req, server) {
			const url = new URL(req.url);
			if (!isRebindSafeHost(url.hostname, allowedHosts)) {
				return new Response(
					`Host not allowed; add it to ${STATS_ALLOWED_HOSTS_ENV} to serve the dashboard under it`,
					{
						status: 403,
					},
				);
			}
			const path = url.pathname;

			// The identity header lets another omp session's reuse probe positively
			// recognize this dashboard without allowing cross-origin API reads.
			const dashboardHeaders: Record<string, string> = {
				[STATS_DASHBOARD_HEADER]: STATS_DASHBOARD_SECURITY_VERSION,
				[STATS_DASHBOARD_HOSTNAME_HEADER]: hostname,
			};

			if (req.method === "OPTIONS") {
				return new Response(null, { headers: dashboardHeaders });
			}

			if (path === "/api/events") {
				// Long-lived stream: exempt from the idle timeout.
				server.timeout(req, 0);
				return liveEventStream(dashboardHeaders, req.signal);
			}
			// A Spotlight build runs on a worker and can outlast the idle timeout, which counts a pending handler.
			if (path === "/api/stats/spotlight") server.timeout(req, 0);

			try {
				let response: Response;

				if (path.startsWith("/api/")) {
					response = await handleApi(req);
				} else {
					response = await handleStatic(path);
				}

				// Add the dashboard identity header to all responses.
				const headers = new Headers(response.headers);
				for (const key in dashboardHeaders) {
					headers.set(key, dashboardHeaders[key]);
				}

				return new Response(response.body, {
					status: response.status,
					headers,
				});
			} catch (error) {
				logger.error("Stats dashboard request failed", { path, error: String(error) });
				return Response.json(
					{ error: error instanceof Error ? error.message : "Unknown error" },
					{ status: 500, headers: dashboardHeaders },
				);
			}
		},
	});
	return server;
}

/** Keep-alive comment cadence so proxies and the browser keep the stream open. */
const EVENT_HEARTBEAT_MS = 15_000;

/**
 * Server-sent events of {@link LiveStatus}: the current status immediately,
 * then every change (sync progress, data version bumps, indexing backlog).
 * Disconnects unsubscribe, so ingest winds down once no page is listening.
 */
function liveEventStream(headers: Record<string, string>, signal: AbortSignal): Response {
	const live = statsLive();
	// Ingest starts when the first page connects, not when the server binds.
	live.start();
	const encoder = new TextEncoder();
	let cleanup = () => {};
	const stream = new ReadableStream<Uint8Array>({
		start(controller) {
			const write = (chunk: string) => {
				try {
					controller.enqueue(encoder.encode(chunk));
				} catch {
					// Stream already closed: the client left without a cancel.
					cleanup();
				}
			};
			write(`data: ${JSON.stringify(live.status())}\n\n`);
			const unsubscribe = live.subscribe((_status, frame) => write(`data: ${frame}\n\n`));
			const heartbeat = setInterval(() => write(": keep-alive\n\n"), EVENT_HEARTBEAT_MS);
			const onAbort = () => cleanup();
			cleanup = () => {
				cleanup = () => {};
				unsubscribe();
				clearInterval(heartbeat);
				signal.removeEventListener("abort", onAbort);
			};
			if (signal.aborted) cleanup();
			else signal.addEventListener("abort", onAbort, { once: true });
		},
		cancel() {
			cleanup();
		},
	});
	return new Response(stream, {
		headers: {
			...headers,
			"Content-Type": "text/event-stream",
			"Cache-Control": "no-cache",
			Connection: "keep-alive",
		},
	});
}

/** A dashboard this process started or found; `reused` distinguishes another process's server from one we own. */
export interface StatsServerHandle {
	hostname: string;
	port: number;
	/** True when the dashboard belongs to another process and this process has no server to keep alive. */
	reused: boolean;
	stop: () => void;
}

// Dashboards this process already bound, keyed by requested and bound
// `hostname:port`. A second in-process start (e.g. `/trace` twice in one
// session, or a caller passing back a fallback port) must return the live
// handle: probing our own port can time out under load and would then start
// yet another dashboard on a fallback port.
const activeServers = new Map<string, StatsServerHandle>();
/** Dashboards bound by this process (any port); background ingest stops when the last one does. */
let liveServers = 0;

export interface StartServerOptions {
	/** Host judge for the Frustration dashboard's judge runs; replaces any previously registered one. */
	judge?: StatsJudgeProvider;
}

/**
 * Start the dashboard on `port`, or reuse the current dashboard already serving it.
 * An older dashboard there is stopped and replaced; any other holder (a foreign
 * program, or a dashboard too busy to answer the identity probe) is left running
 * and the dashboard binds an ephemeral port instead.
 */
export async function startServer(
	port = 3847,
	hostname = STATS_DASHBOARD_HOSTNAME,
	options: StartServerOptions = {},
): Promise<StatsServerHandle> {
	if (options.judge) setStatsJudgeProvider(options.judge);
	const requestedKey = `${hostname}:${port}`;
	if (port !== 0) {
		const active = activeServers.get(requestedKey);
		if (active) return active;
	}
	await ensureClientBuild();
	const register = (server: Server<undefined>): StatsServerHandle => {
		liveServers++;
		let stopped = false;
		const boundPort = server.port ?? port;
		const keys = port === 0 ? [`${hostname}:${boundPort}`] : [requestedKey, `${hostname}:${boundPort}`];
		const handle: StatsServerHandle = {
			hostname,
			port: boundPort,
			reused: false,
			stop: () => {
				for (const key of keys) activeServers.delete(key);
				server.stop(true);
				if (stopped) return;
				stopped = true;
				// The last dashboard in this process takes background ingest and Spotlight builds down with it.
				if (--liveServers === 0) {
					statsLive().stop();
					spotlightBuilds.abort(new Error("Stats dashboard stopped"));
					spotlightBuilds = new AbortController();
				}
			},
		};
		for (const key of keys) activeServers.set(key, handle);
		return handle;
	};

	let claim = await prepareStatsPort(port, hostname);
	if (claim === "bind") {
		const server = bindDashboardServer(port, hostname);
		if (server) return register(server);
		claim = await recoverStatsPort(port, hostname);
	}
	if (claim === "reuse") return { hostname, port, reused: true, stop: () => {} };
	if (claim === "bind") {
		const server = bindDashboardServer(port, hostname);
		if (server) return register(server);
	}
	logger.warn("Stats dashboard port is held by another process; serving on an ephemeral port", { hostname, port });
	return register(createDashboardServer(0, hostname));
}

/** {@link createDashboardServer}, or null when the port is already in use. */
function bindDashboardServer(port: number, hostname: string): Server<undefined> | null {
	try {
		return createDashboardServer(port, hostname);
	} catch (error) {
		if (error instanceof Error && "code" in error && error.code === "EADDRINUSE") return null;
		throw error;
	}
}
