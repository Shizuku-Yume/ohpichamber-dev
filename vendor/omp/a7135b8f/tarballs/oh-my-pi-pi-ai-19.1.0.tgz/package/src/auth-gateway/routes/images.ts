import { calculateCost } from "@oh-my-pi/pi-catalog/models";
import { logger } from "@oh-my-pi/pi-utils";
import { classifyGatewayError } from "../../error/gateway";
import { generateImage } from "../../images";
import { validateImageInput } from "../../images/shared";
import * as imagesServer from "../../providers/images-server";
import { deterministicUuid } from "../../utils/deterministic-id";
import {
	type AuthGatewayRouteOptions,
	buildGatewayApiKeyResolver,
	gatewayRequestLogFields,
	mirrorRequestAbort,
	recordGatewayUsage,
	resolveGatewayApiKey,
} from "../dispatch";
import { gatewayResponseHeaders, json, resolveClientIdentity, codedErrorResponse } from "../http";

function isGatewayImageApi(api: string): boolean {
	return (
		api === "openai-images" ||
		api === "openrouter-images" ||
		api === "google-generative-ai" ||
		api === "google-gemini-cli" ||
		api === "factory-droid-agent"
	);
}

async function handleImages(
	bootOpts: AuthGatewayRouteOptions,
	req: Request,
	peer: string,
	kind: imagesServer.ImageRequestKind,
): Promise<Response> {
	const startedAt = performance.now();
	const requestId = crypto.randomUUID();
	const controller = mirrorRequestAbort(req);
	const aborted = (): Response => codedErrorResponse(499, "request_aborted", "client closed request");
	if (controller.signal.aborted) return aborted();

	let body: unknown | FormData;
	try {
		body =
			kind === "edits" && req.headers.get("content-type")?.includes("multipart/form-data")
				? await req.formData()
				: await req.json();
	} catch (error) {
		if (controller.signal.aborted) return aborted();
		return codedErrorResponse(400, "invalid_request_error", `Invalid request body: ${String(error)}`);
	}
	if (controller.signal.aborted) return aborted();

	let parsed: imagesServer.ImagesParsedRequest;
	try {
		parsed = await imagesServer.parseRequest(body, kind);
		for (const image of parsed.request.inputImages ?? []) validateImageInput(image);
	} catch (error) {
		const message = error instanceof Error ? error.message : String(error);
		return codedErrorResponse(400, "invalid_request_error", message);
	}

	const model = bootOpts.resolveModel(parsed.modelId);
	if (!model) {
		return codedErrorResponse(404, "invalid_request_error", `Unknown model: ${parsed.modelId}`);
	}
	if (model.api === "openai-responses" || model.api === "openai-codex-responses") {
		return codedErrorResponse(
			400,
			"invalid_request_error",
			`Model ${parsed.modelId} requires a hosted image carrier, which the auth gateway cannot resolve`,
		);
	}
	if (!isGatewayImageApi(model.api)) {
		return codedErrorResponse(
			400,
			"invalid_request_error",
			`Model ${parsed.modelId} does not support image generation`,
		);
	}

	const client = resolveClientIdentity(req.headers);
	const sessionId = deterministicUuid(`images\u0000${model.provider}/${model.id}`);
	const apiKey = await resolveGatewayApiKey(bootOpts, model, sessionId, controller.signal, peer);
	if (controller.signal.aborted) return aborted();
	if ("status" in apiKey) return codedErrorResponse(apiKey.status, apiKey.type, apiKey.message);

	logger.info("auth-gateway request", {
		requestId,
		format: "images",
		model: parsed.modelId,
		resolvedProvider: model.provider,
		resolvedModel: model.id,
		stream: false,
		peer,
		...gatewayRequestLogFields(bootOpts, apiKey),
	});

	try {
		const result = await generateImage(model, parsed.request, {
			apiKey: buildGatewayApiKeyResolver(bootOpts, model, sessionId, apiKey, controller.signal, "images", peer),
			fetch: bootOpts.fetch,
			signal: controller.signal,
		});
		if (result.usage.cost.total === 0) calculateCost(model, result.usage);
		recordGatewayUsage(bootOpts.storage, model, client, result.usage);
		return json(
			200,
			imagesServer.encodeResponse(result, parsed.modelId),
			gatewayResponseHeaders(model, { requestId, costUsd: result.usage.cost.total, startedAt }),
		);
	} catch (error) {
		if (controller.signal.aborted) return aborted();
		const classified = classifyGatewayError(error);
		logger.warn("auth-gateway image generation failed", { format: "images", error: classified.message, peer });
		return codedErrorResponse(classified.status, classified.type, classified.message);
	}
}

export function handleImageGenerations(
	bootOpts: AuthGatewayRouteOptions,
	req: Request,
	peer: string,
): Promise<Response> {
	return handleImages(bootOpts, req, peer, "generations");
}

export function handleImageEdits(bootOpts: AuthGatewayRouteOptions, req: Request, peer: string): Promise<Response> {
	return handleImages(bootOpts, req, peer, "edits");
}
