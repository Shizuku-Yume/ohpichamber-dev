import { type Api, IMAGE_GENERATION_APIS, type ImageGenerationApi, type Model } from "@oh-my-pi/pi-catalog/types";
import * as AIError from "../error";
import { assertProviderEnabled } from "../registry/oauth";
import { isFactoryDroidModel } from "../providers/factory-droid";
import { generateFactoryDroidImage } from "./factory-droid";
import { generateAntigravityImage } from "./google-antigravity";
import { generateGoogleImage } from "./google-generative-ai";
import { generateOpenAIImage } from "./openai-images";
import { generateHostedImage } from "./openai-hosted";
import { generateOpenRouterImage } from "./openrouter-images";
import type { ImageGenerationOptions, ImageGenerationRequest, ImageGenerationResult } from "./types";

export * from "./factory-droid";
export * from "./google-antigravity";
export * from "./google-generative-ai";
export * from "./openai-hosted";
export * from "./openai-images";
export * from "./openrouter-images";
export * from "./types";

export type { ImageGenerationApi } from "@oh-my-pi/pi-catalog/types";

/** Whether a catalog API generates images through one of the pi-ai image clients. */
export function isImageGenerationApi(api: Api): api is ImageGenerationApi {
	return (IMAGE_GENERATION_APIS as readonly Api[]).includes(api);
}

/** Generate (or edit, when `request.inputImages` is set) images through the transport selected by the model's `api`. */
export async function generateImage(
	model: Model<Api>,
	request: ImageGenerationRequest,
	options: ImageGenerationOptions,
): Promise<ImageGenerationResult> {
	// A provider turned off in its auth rules is never called, even with a key passed in directly.
	assertProviderEnabled(model.provider);
	if (isFactoryDroidModel(model)) return generateFactoryDroidImage(model, request, options);
	switch (model.api) {
		case "openai-images":
			return generateOpenAIImage(model, request, options);
		case "openrouter-images":
			return generateOpenRouterImage(model, request, options);
		case "google-generative-ai":
			return generateGoogleImage(model, request, options);
		case "google-gemini-cli":
			return generateAntigravityImage(model, request, options);
		case "openai-responses":
		case "openai-codex-responses":
			return generateHostedImage(model, request, options);
		default:
			throw new AIError.ValidationError(`Image generation does not support model API ${model.api}`);
	}
}
