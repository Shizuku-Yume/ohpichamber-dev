import * as path from "node:path";
import type { AgentMessage } from "@oh-my-pi/pi-agent-core";
import type { AssistantMessage, UsageLimit, UsageReport } from "@oh-my-pi/pi-ai";
import {
	getAntigravityCounterKeyForModel,
	scopeAntigravityLimitsForModel,
} from "@oh-my-pi/pi-ai/usage/google-antigravity";
import { getNextTimeBasedPricingTransition } from "@oh-my-pi/pi-catalog/models";
import type { Model, ModelCost } from "@oh-my-pi/pi-catalog/types";
import type { VcsGitRepo, VcsRepo } from "@oh-my-pi/pi-natives";
import * as vcs from "@oh-my-pi/pi-natives/vcs";
import {
	type Component,
	type ComposerStyle,
	claudeComposerStyle,
	padding,
	motionEffectsEnabled,
	spinnerAnimated,
	spinnerInterval,
	spinnerTickDelay,
	truncateToWidth,
	visibleWidth,
} from "../index";
import { adjustHsv, formatNumber, getProjectDir, hexToRgb, rgbToHex } from "@oh-my-pi/pi-utils";
import type {
	ActiveRepoContext,
	StatusAccountIdentity as OAuthAccountIdentity,
	StatusLineHost,
	PromptCacheStatus,
	StatusLineSession,
} from "./host";
import type { Editor } from "../components/editor";
import { getSessionAccentAnsi, getSessionAccentHex } from "../theme/session-color";
import { sanitizeHookStatusText, sanitizeStatusText } from "../chrome/shared";
import { getThemeEpoch, theme } from "../theme";
import { type CompactionBoundaries, EMPTY_STRING_PARTS, getToolSchemaMetadataRevision } from "./context-usage";
import {
	type CodexResetFireworksEvent,
	type CodexResetUsageSnapshot,
	detectCodexResetFireworks,
} from "../overlays/codex-reset-fireworks";
import { canReuseCachedPr, createPrCacheContext, isSamePrCacheContext, type PrCacheContext } from "./git-utils";
import { summarizeUsageResetCredits } from "../overlays/usage-display";
import { getPreset } from "./presets";
import { describeSegment, renderSegment, type SegmentContext } from "./segments";
import { promptCacheBrief } from "./prompt-cache";
import type { TspMeterMark, TspProps } from "@oh-my-pi/pi-wire";
import type { NativeNode, NativeUiEvent } from "../native/node";
import { col, node, propNode, span, text } from "../native/describe";
import { getContextMeterThresholds } from "../chrome/context-thresholds";
import { isNativeRendering, onNativeRenderingChange } from "../native/state";
import { getSeparator } from "./separators";
import { formatJobWidgetGlance, type JobWidgetEntry, latestJobWidget } from "../tools/job-widget";
import type {
	CollabStatus,
	ComposerFacts,
	ComposerFactsSource,
	EffectiveStatusLineSettings,
	SegmentView,
	SeparatorDef,
	StatusLineSegmentId,
	StatusLineSegmentOptions,
	StatusLineSeparatorStyle,
	StatusLineSettings,
	StatusResetExpiry,
} from "./types";

/** Sparkline cells the ANSI jobs segment draws after the freshest widget's headline. */
const JOBS_SEGMENT_SPARK_CELLS = 8;

/** What a click on a native status segment asks omp to open. */
export type StatusLineNativeAction =
	| "status.model"
	| "status.context"
	| "status.git"
	| "status.cost"
	| "status.path"
	| "status.cache";

/** Click action per native segment: quick model picker, `/context`, `/git`, `/usage`, the project directory, `/session`. */
const NATIVE_SEGMENT_ACTIONS: Partial<Record<string, StatusLineNativeAction>> = {
	model: "status.model",
	context_pct: "status.context",
	context_total: "status.context",
	git: "status.git",
	cost: "status.cost",
	path: "status.path",
	cache: "status.cache",
};

/** Segments that outlast every other one as the native bar narrows (model, context, git branch). */
const PINNED_NATIVE_SEGMENTS: Partial<Record<string, true>> = {
	model: true,
	context_pct: true,
	context_total: true,
	git: true,
};
const PINNED_NATIVE_PRIORITY = 1000;

/**
 * Segments a TSP terminal shows outside the composer's facts: the model chip,
 * the context hairline and usage text (context, cost), Tern's pane header
 * (path), the tab title (session name, PR), the HUD pills (subagents), the
 * editor (vim) and the brand (`pi`; while focus-proxied, the viewed agent is
 * the composer's viewing header).
 */
const COMPOSER_HOMED_SEGMENTS: Partial<Record<StatusLineSegmentId, true>> = {
	pi: true,
	model: true,
	context_pct: true,
	context_total: true,
	cost: true,
	path: true,
	pr: true,
	session_name: true,
	subagents: true,
	vim: true,
};

/** Pull request the native tab title carries. */
export interface StatusLinePullRequest {
	readonly number: number;
	readonly url: string;
}

/** Last composer facts and the inputs they were built from. */
interface NativeFactsMemo {
	facts: ComposerFacts;
	/** Structural fingerprint (elapsed ages excluded: the terminal already clocks them). */
	fingerprint: string;
	renderRevision: number;
	inputRevision: number;
	clockTick: number;
	externalInputs: StatusLineExternalInputs;
}

/** JSON replacer dropping `age`: a rebuilt `elapsed` differs only by send time. */
function withoutAges(key: string, value: unknown): unknown {
	return key === "age" ? undefined : value;
}

/**
 * Drop priority of a configured segment: the outer edges matter most, so the
 * leftmost left segment and the rightmost right segment stay longest.
 */
export function statusSegmentPriority(side: "left" | "right", index: number, count: number): number {
	return side === "left" ? count - index : index + 1;
}

/** A native `seg` for a segment view; `dim` fades its spans while focus-proxied. */
function describeSeg(key: string, props: TspProps<"seg">, view: SegmentView, dim: boolean): NativeNode {
	props.spans = dim ? view.spans.map(part => ({ ...part, s: part.s ? `${part.s} dim` : "dim" })) : view.spans;
	if (view.icon !== undefined) props.icon = view.icon;
	if (view.tone !== undefined) props.tone = view.tone;
	if (view.title !== undefined) props.title = view.title;
	return node("seg", props, view.motion, key);
}

/**
 * The `cache` fact's own props: it sits at the facts' right end, beside the
 * usage, names its glyph by the card's first line, and its hover card says
 * until when the next message reads the cache (or why not) and what it sends,
 * in absolute times, since the terminal shows the card later without repainting.
 */
function promptCacheFactProps(status: PromptCacheStatus, nowMs: number): TspProps<"seg"> {
	const [head, next] = promptCacheBrief(status, nowMs);
	const card = col([text(status.state === "cold" ? [span(head, "warning")] : head), text([span(next, "muted")])], {
		role: "omp.composer.cache.card",
	});
	return {
		role: "omp.composer.cache",
		side: "right",
		aria: head,
		title: `${head}\n${next}`,
		hovercard: propNode(card),
	};
}

/**
 * Freshness window for the git segment's working-tree counts. A whole-worktree
 * `git status` costs ~1 CPU-second on large repos and every open session polls
 * it, so edits surface within this window; HEAD moves refetch immediately via
 * {@link StatusLineComponent.invalidateGitCaches}.
 */
const GIT_STATUS_TTL_MS = 10_000;
const JJ_REFRESH_TTL_MS = 5000;
const JJ_COMMAND_TIMEOUT_MS = 5_000;
const WATCHER_FAILURE_POLL_TTL_MS = 5000;
/** Brand-color fade duration across working-state edges (rust omp's `BRAND_FADE`). */
const BRAND_FADE_MS = 450;
/** Repaint cadence while the brand fade is in flight (rust omp's `FADE_FRAME`). */
const BRAND_FADE_FRAME_MS = 40;
/** Shortest repaint cadence while a turn's active-processing window is open: keeps the
 * status bar's clock-driven readouts (pi spinner, turn timer) animating when
 * no other component is requesting renders. The armed period is this rounded up to a
 * whole number of spinner frames, so the ticker lands on the working row's own ticks. */
const ACTIVE_WINDOW_REPAINT_MS = 250;
/** Turn-window repaint cadence under a static spinner: only the one-second timers still move. */
const STATIC_SPINNER_REPAINT_MS = 1_000;

/**
 * Providers whose subscription quota is a single monthly bucket, so their
 * `monthly`/`30d` window is the one the usage segment must show. Providers that
 * merely report a monthly side-counter (GitHub Copilot's premium requests) stay
 * out: their monthly row is not the session quota.
 */
const MONTHLY_SUBSCRIPTION_PROVIDERS: Record<string, true> = {
	"alibaba-token-plan": true,
	cursor: true,
	"opencode-go": true,
};

/** A displayable limit after provider, account, model, and window filtering. */
interface UsageWindowCandidate {
	id?: string;
	windowClass: "5h" | "daily" | "7d" | "monthly";
	fraction: number;
	resetsAt?: number;
}

/** Limits sharing one model/tier scope, ranked as an indivisible display unit. */
interface UsageScopeGroup {
	priority: number;
	tier?: string;
	candidates: UsageWindowCandidate[];
}

function normalizeUsageScopeValue(value: unknown): string | undefined {
	return typeof value === "string" && value.trim() ? value.trim().toLowerCase() : undefined;
}

/**
 * Fireworks are stateful, so their report match must be stricter than the
 * status display's fallback matching: every known credential identifier must
 * be present and equal or a workspace sibling can mutate this account's
 * baseline.
 */
function reportMatchesExactIdentity(report: UsageReport, identity: OAuthAccountIdentity | undefined): boolean {
	if (!identity) return false;
	const accountId = normalizeUsageScopeValue(identity.accountId);
	const email = normalizeUsageScopeValue(identity.email);
	const projectId = normalizeUsageScopeValue(identity.projectId);
	const orgId = normalizeUsageScopeValue(identity.orgId);
	if (!accountId && !email && !projectId && !orgId) return false;

	const metadata = report.metadata ?? {};
	const reportAccountId =
		normalizeUsageScopeValue(metadata.accountId) ?? normalizeUsageScopeValue(metadata.account_id);
	const reportProjectId =
		normalizeUsageScopeValue(metadata.projectId) ?? normalizeUsageScopeValue(metadata.project_id);
	if (accountId && reportAccountId !== accountId) return false;
	if (email && normalizeUsageScopeValue(metadata.email) !== email) return false;
	if (projectId && reportProjectId !== projectId) return false;
	if (orgId && normalizeUsageScopeValue(metadata.orgId) !== orgId) return false;
	return true;
}

// ═══════════════════════════════════════════════════════════════════════════
// Context-usage memo
// ═══════════════════════════════════════════════════════════════════════════

/**
 * Serialized length of tool-call arguments, memoized per arguments object.
 * Streaming providers may grow the same object in place (at any depth), so
 * each entry keeps a shape check — key/element counts plus string and number
 * lengths over the whole tree — and is recomputed when it differs, without
 * re-serializing the whole (possibly multi-KB edit/write) payload on every
 * status-line rebuild.
 */
const toolArgumentsLengthCache = new WeakMap<object, { check: number; length: number }>();

/** Past this depth the check stops descending; JSON.stringify rejects real cycles anyway. */
const SHAPE_CHECK_MAX_DEPTH = 32;

function toolArgumentsShapeCheck(value: unknown, depth = 0): number {
	if (typeof value === "string") return value.length + 1;
	if (typeof value === "number" || typeof value === "bigint") return String(value).length + 1;
	if (value === null || typeof value !== "object" || depth >= SHAPE_CHECK_MAX_DEPTH) return 1;
	let check = 1;
	for (const child of Object.values(value)) check += 1 + toolArgumentsShapeCheck(child, depth + 1);
	return check;
}

function toolArgumentsLength(args: unknown): number {
	if (typeof args === "string") return args.length;
	if (args === null || typeof args !== "object") return String(args).length;
	const check = toolArgumentsShapeCheck(args);
	const cached = toolArgumentsLengthCache.get(args);
	if (cached !== undefined && cached.check === check) return cached.length;
	let length: number;
	try {
		length =
			JSON.stringify(args, (_key, value) => (typeof value === "bigint" ? value.toString() : value))?.length ?? 0;
	} catch {
		length = String(args).length;
	}
	toolArgumentsLengthCache.set(args, { check, length });
	return length;
}

/**
 * Cheap structural fingerprint of a message's tokenizable content. O(blocks) —
 * only reads string `.length`, primitives, and memoized tool-argument sizes;
 * never copies. Detects growth of the streaming tail (in-place text appends,
 * freshly parsed tool arguments) so the cached `getContextUsage()` result is
 * recomputed when — and only when — the numbers it depends on change.
 */
function messageFingerprint(msg: AgentMessage): string {
	const role = (msg as { role?: string }).role ?? "";
	const ts = (msg as { timestamp?: number }).timestamp ?? 0;
	let textLen = 0;
	let blocks = 0;
	let images = 0;
	if (role === "bashExecution") {
		const b = msg as { command?: unknown; output?: unknown };
		if (typeof b.command === "string") textLen += b.command.length;
		if (typeof b.output === "string") textLen += b.output.length;
	} else if (role === "user") {
		const content = (msg as { content?: unknown }).content;
		if (typeof content === "string") {
			textLen += content.length;
		} else if (Array.isArray(content)) {
			blocks = content.length;
			for (const block of content) {
				if (block?.type === "text" && typeof block.text === "string") textLen += block.text.length;
			}
		}
	} else if (role === "assistant") {
		const assistantMsg = msg as AssistantMessage;
		const usageExt = assistantMsg.usage as unknown as { promptTokensDetails?: unknown };
		const usageTotal = assistantMsg.usage?.totalTokens ?? 0;
		const promptBuckets = usageExt?.promptTokensDetails ? 1 : 0;
		const stopReason = assistantMsg.stopReason ?? "";

		let signatureLen = 0;
		let redactedLen = 0;
		const msgExt = assistantMsg as unknown as {
			thinkingSignature?: string;
			textSignature?: string;
			thoughtSignature?: string;
			redactedThinking?: { data?: string };
		};
		const thinkingSignature = msgExt.thinkingSignature;
		if (typeof thinkingSignature === "string") {
			signatureLen += thinkingSignature.length;
		}
		const textSignature = msgExt.textSignature;
		if (typeof textSignature === "string") {
			signatureLen += textSignature.length;
		}
		const thoughtSignature = msgExt.thoughtSignature;
		if (typeof thoughtSignature === "string") {
			signatureLen += thoughtSignature.length;
		}
		const redactedData = msgExt.redactedThinking?.data;
		if (typeof redactedData === "string") {
			redactedLen += redactedData.length;
		}

		const content = (msg as { content?: unknown }).content;
		if (Array.isArray(content)) {
			blocks = content.length;
			for (const block of content) {
				if (!block || typeof block !== "object") continue;
				const b = block as {
					type?: string;
					text?: string;
					thinking?: string;
					thinkingSignature?: string;
					signature?: string;
					textSignature?: string;
					thoughtSignature?: string;
					data?: string;
					name?: string;
					arguments?: unknown;
				};
				if (b.type === "text" && typeof b.text === "string") textLen += b.text.length;
				else if (b.type === "thinking") {
					if (typeof b.thinking === "string") textLen += b.thinking.length;
					if (typeof b.thinkingSignature === "string") signatureLen += b.thinkingSignature.length;
					if (typeof b.signature === "string") signatureLen += b.signature.length;
					if (typeof b.textSignature === "string") signatureLen += b.textSignature.length;
					if (typeof b.thoughtSignature === "string") signatureLen += b.thoughtSignature.length;
				} else if (b.type === "redactedThinking" && typeof b.data === "string") {
					redactedLen += b.data.length;
				} else if (b.type === "toolCall") {
					if (typeof b.name === "string") textLen += b.name.length;
					if (b.arguments !== undefined) textLen += toolArgumentsLength(b.arguments);
				}
			}
		}
		return `${role}:${ts}:${textLen}:${blocks}:${images}:${signatureLen}:${redactedLen}:${usageTotal}:${promptBuckets}:${stopReason}`;
	} else if (role === "toolResult" || role === "hookMessage") {
		const content = (msg as { content?: unknown }).content;
		if (typeof content === "string") {
			textLen += content.length;
		} else if (Array.isArray(content)) {
			blocks = content.length;
			for (const block of content) {
				if (!block || typeof block !== "object") continue;
				const b = block as { type?: string; text?: string };
				if (b.type === "text" && typeof b.text === "string") textLen += b.text.length;
				else if (b.type === "image") images++;
			}
		}
	} else if (role === "branchSummary" || role === "compactionSummary") {
		const s = (msg as { summary?: unknown }).summary;
		if (typeof s === "string") textLen += s.length;
	}
	return `${role}:${ts}:${textLen}:${blocks}:${images}`;
}

interface ContextUsageMemo {
	messagesRef: readonly AgentMessage[];
	length: number;
	lastFingerprint: string | undefined;
	modelContextWindow: number;
	toolSchemasInContext: boolean;
	contextUsageRevision: number;
	toolSchemaMetadataRevision: number;
	settingsRevision: number;
	tokenizerRef: unknown;
	usedTokens: number;
	contextWindow: number;
	/** The session reported `percent: null`: usage is unknown, so no percent is shown. */
	percentUnknown: boolean;
	systemPromptRef: readonly string[] | undefined;
	toolsRef: readonly any[] | undefined;
	skillsRef: readonly any[] | undefined;
}

/**
 * Snapshot of the cheap external inputs a cached bar depends on. Mutable and
 * refilled in place: the per-frame cache probe writes into a recycled
 * instance instead of allocating a fresh ~50-field object every frame.
 */
class StatusLineExternalInputs {
	themeRef: unknown = undefined;
	themeEpoch = 0;
	projectDir = "";
	sessionRef: StatusLineSession | undefined = undefined;
	sessionFile: string | undefined = undefined;
	sessionSettingsRef: unknown = undefined;
	sessionSettingsRevision = 0;
	globalSettingsRevision = 0;
	stateRef: unknown = undefined;
	stateMessagesRef: readonly AgentMessage[] = EMPTY_MESSAGES;
	stateMessagesLength = 0;
	stateLastMessageRef: AgentMessage | undefined = undefined;
	stateLastMessageContentRef: unknown = undefined;
	messagesRef: readonly AgentMessage[] = EMPTY_MESSAGES;
	messagesLength = 0;
	lastMessageRef: AgentMessage | undefined = undefined;
	lastMessageRole: string | undefined = undefined;
	lastMessageTimestamp = 0;
	lastMessageContentSize = 0;
	lastMessageBlockCount = 0;
	lastMessageUsageTotal = 0;
	lastMessageStopReason: string | undefined = undefined;
	modelRef: unknown = undefined;
	sessionModelRef: unknown = undefined;
	sessionModelId: string | undefined = undefined;
	sessionModelContextWindow: Model["contextWindow"] | undefined = undefined;
	modelId: string | undefined = undefined;
	modelName: string | undefined = undefined;
	modelProvider: string | undefined = undefined;
	modelContextWindow: Model["contextWindow"] | undefined = undefined;
	modelThinking: Model["thinking"] = undefined;
	thinkingLevel: unknown = undefined;
	modelCostRef: unknown = undefined;
	contextUsageRevision = 0;
	systemPromptRef: unknown = undefined;
	systemPromptLength = 0;
	systemPromptContentSize = 0;
	toolsRef: readonly unknown[] | undefined = undefined;
	toolsLength = 0;
	toolSchemaMetadataRevision = 0;
	tokenizerRef: unknown = undefined;
	skillsRef: unknown = undefined;
	skillsLength = 0;
	sessionName: string | undefined = undefined;
	sessionId: string | undefined = undefined;
	isStreaming: boolean | undefined = undefined;
	isAutoThinking: boolean | undefined = undefined;
	isFastModeActive = false;
	anthropicSlowModeLabel: string | undefined = undefined;
	compactionSpeculation: unknown = undefined;
	/** The freshest running job widget's view (stable identity while its data is unchanged). */
	jobWidgetRef: unknown = undefined;
}

interface CachedStatusLine {
	content: string;
	dimmedContent: string;
	width: number;
	availableWidth: number;
	renderRevision: number;
	inputRevision: number;
	previewTitle: string | undefined;
	externalInputs: StatusLineExternalInputs;
	/** `#statusLineClock` tick the content was drawn on. */
	clockTick: number;
	/** Wall-clock second of the last full build: every segment but the brand spinner changes only across seconds. */
	builtSecond: number;
	/** The animating `pi` segment as drawn into `content` at `start`, when it appears there once and whole. */
	brand: { ctx: SegmentContext; part: string; start: number } | undefined;
}

/** The `pi` segment's context and rendered part, captured while a full build draws it. */
interface BrandCapture {
	ctx?: SegmentContext;
	part?: string;
}

/** Dot separator of the plain (borderless) layouts; carries no caps. */
const PLAIN_SEPARATOR: SeparatorDef = { left: "·", right: "·" };

/** A separator style's glyphs and cell widths: theme-pure, so measured once per theme. */
interface SeparatorMetrics {
	themeRef: unknown;
	themeEpoch: number;
	style: StatusLineSeparatorStyle;
	def: SeparatorDef;
	leftSepWidth: number;
	rightSepWidth: number;
	/** Left group's closing cap (`endCaps.right`); 0 without caps. */
	leftCapWidth: number;
	/** Right group's opening cap (`endCaps.left`); 0 without caps. */
	rightCapWidth: number;
	/** Band layout's flush-left soft cap; 0 without caps. */
	bandCapWidth: number;
}

interface ActiveRepoCache {
	projectDir: string;
	activeRepo: ActiveRepoContext | null;
	effectiveGitCwd: string;
	repository: VcsRepo | null;
	displayRepository: VcsRepo | null;
	displayRepositoryCheckedAt: number;
	repositoryCheckedAt: number;
	/** Project + worktree dir name when `projectDir` is a linked worktree, else null. */
	worktree: WorktreeContext | null;
}

interface BranchResolveRequest {
	id: number;
	cwd: string;
	controller: AbortController;
}

interface JjResolveRequest {
	id: number;
	controller: AbortController;
}

interface WorktreeContext {
	/** Primary-checkout (project) name shown by the path segment. */
	projectName: string;
	/** Worktree directory name — suppressed from the path when it equals the branch. */
	worktreeName: string;
}

/**
 * Project + worktree-dir names when `cwd` is a linked git worktree, else null.
 * The project name comes from the shared primary checkout; bare-repo worktrees
 * resolve to the shared `foo.git` dir, so a trailing `.git` is stripped.
 */
function resolveWorktreeContext(cwd: string): WorktreeContext | null {
	const worktree = vcs.git(cwd)?.linkedWorktree();
	if (!worktree) return null;
	const base = path.basename(worktree.primaryRoot);
	const projectName = base.endsWith(".git") ? base.slice(0, -4) : base;
	if (!projectName) return null;
	return { projectName, worktreeName: path.basename(worktree.root) };
}

/**
 * Per-{@link StatusLineSession} active-processing meter for the `time_spent`
 * segment. `activeMs` is the union of every completed `agent_start`→
 * `agent_end` window; `activeStartedAt` is the start timestamp of the
 * currently-running window, or `null` when idle.
 *
 * `sessionFile` snapshots the loaded session-file path at meter-creation
 * time. `StatusLineSession.switchSession` (/resume, /move, ACP fork, RPC
 * `switch_session`, extension `switchSession`) mutates the loaded file
 * under the same {@link StatusLineSession} ref, so the WeakMap key alone
 * cannot tell two conversations apart. `#meter()` compares this snapshot
 * against the live `session.sessionFile`, and a real-to-real change
 * starts the meter fresh instead of crediting the new conversation with
 * the previous one's accumulated active time. The undefined → real
 * first-save transition does not reset, since the session identity has
 * not changed.
 */
interface ActiveMeter {
	activeMs: number;
	activeStartedAt: number | null;
	sessionFile: string | undefined;
}

const EMPTY_MESSAGES: readonly AgentMessage[] = [];
const STATUS_USAGE_START_DELAY_MS = 0;
const STATUS_USAGE_REFRESH_TIMEOUT_MS = 2_000;

function isContextSegment(segment: StatusLineSegmentId): boolean {
	return segment === "context_pct" || segment === "context_total";
}

function hasContextSegment(segments: readonly StatusLineSegmentId[]): boolean {
	return segments.includes("context_pct") || segments.includes("context_total");
}

function hasNonContextSegment(segments: readonly StatusLineSegmentId[]): boolean {
	for (const segment of segments) {
		if (!isContextSegment(segment)) return true;
	}
	return false;
}

function removeContextSegments(parts: string[], segments: StatusLineSegmentId[]): void {
	let writeIndex = 0;
	for (let readIndex = 0; readIndex < segments.length; readIndex++) {
		const segment = segments[readIndex];
		if (isContextSegment(segment)) continue;
		parts[writeIndex] = parts[readIndex];
		segments[writeIndex] = segment;
		writeIndex++;
	}
	parts.length = writeIndex;
	segments.length = writeIndex;
}

function formatEmbeddedContextPercent(percent: number): string {
	return `${percent > 0 && percent < 1 ? percent.toFixed(1) : Math.round(percent)}%`;
}

/** Gap width the embedded gauge needs for its labels; an unknown percent (`null`) shows the window label alone. */
function embeddedContextGaugeMinWidth(percent: number | null, contextWindow: number): number {
	const percentWidth = percent === null ? 0 : formatEmbeddedContextPercent(percent).length + 2;
	return percentWidth + formatNumber(contextWindow).length + 2;
}

function hasGitSegment(segments: readonly StatusLineSegmentId[]): boolean {
	return segments.includes("git");
}

function hasPrSegment(segments: readonly StatusLineSegmentId[]): boolean {
	return segments.includes("pr");
}
function hasPathSegment(segments: readonly StatusLineSegmentId[]): boolean {
	return segments.includes("path");
}

function hasGitBackedSegment(segments: readonly StatusLineSegmentId[]): boolean {
	return hasGitSegment(segments) || hasPrSegment(segments);
}

type StatusLineLayout = "box" | "band" | "plain-full" | "plain-left" | "plain-right";

/**
 * Git views of immutable `VcsRepo` handles. `asGit()` mints a fresh napi
 * wrapper around the same backend handle on every call, which the per-frame
 * branch lookup would otherwise pay each render.
 */
const GIT_VIEW = Symbol("status-line.git-view");

interface GitViewTaggedRepo extends VcsRepo {
	[GIT_VIEW]?: VcsGitRepo | null;
}

// ═══════════════════════════════════════════════════════════════════════════
// StatusLineComponent
// ═══════════════════════════════════════════════════════════════════════════

export class StatusLineComponent<TSession extends StatusLineSession = StatusLineSession>
	implements Component, ComposerFactsSource
{
	#standalone: false | "full" | "left-only" = false;
	#topAttachment: ComposerStyle["statusAttachment"] = "top-border";
	#standaloneGap = false;
	#autocompleteActiveProbe: (() => boolean) | undefined;
	#renderRevision = 0;
	/** Fully rendered bars for the current revision/clock tick, keyed by layout. */
	#statusLineRenderCache: Record<StatusLineLayout, CachedStatusLine | undefined> = {
		box: undefined,
		band: undefined,
		"plain-full": undefined,
		"plain-left": undefined,
		"plain-right": undefined,
	};
	#statusLineInputRevision = 0;
	/**
	 * Earliest wall-clock ms at which a TTL-throttled VCS cache the render path
	 * served goes stale (git/jj status, watcher-less branch poll, repository
	 * re-probe, PR activity refresh); `Infinity` when none can. The first frame
	 * past it expires the render memo so the getters refetch — instead of a
	 * fixed polling tick that rebuilt the whole bar every second.
	 */
	#vcsStaleAt = Number.POSITIVE_INFINITY;
	/** Reused probe buffer for {@link #readStatusLineExternalInputs}; handed to the new cache entry on a miss. */
	#externalInputsProbe = new StatusLineExternalInputs();
	/** `adjustHsv` result for the gauge's threshold tint; pure in its source hex. */
	#dimmedAccentMemo: { sourceHex: string; hex: string } | undefined;
	/** Separator widths for the plain and the styled (box/band) layouts; see {@link #separatorMetrics}. */
	#plainSeparatorMetrics: SeparatorMetrics | undefined;
	#styledSeparatorMetrics: SeparatorMetrics | undefined;
	/** Gauge boundary markers; a pure function of the session's compaction settings, model, and window. */
	#compactionBoundariesMemo:
		| {
				sessionRef: StatusLineSession;
				contextWindow: number;
				modelRef: unknown;
				settingsRef: unknown;
				settingsRevision: number;
				globalSettingsRevision: number;
				boundaries: CompactionBoundaries | null;
		  }
		| undefined;
	#settings: StatusLineSettings = {};
	#effectiveSettings: EffectiveStatusLineSettings | undefined;
	#cachedBranch: string | null | undefined = undefined;
	#cachedBranchRepoId: string | null | undefined = undefined;
	#cachedBranchCwd: string | undefined = undefined;
	// In-flight reftable resolve slot. Ownership is the launch id, not the cwd:
	// two live resolves can share a cwd string across an invalidation, and a
	// stale one must never free (or poison) a slot it no longer owns.
	#branchResolveSeq = 0;
	#branchResolveActive: BranchResolveRequest | undefined = undefined;
	// Bumped on every branch-cache reset (#invalidateGitCaches — a HEAD move or
	// repo-context change). An in-flight reftable resolve captures this at
	// launch; a mismatch on resolve means the cache was invalidated underneath
	// it (a newer resolve superseded it), so its result is stale and must be
	// dropped rather than overwrite the value the newer resolve committed.
	// Mirrors #jjCacheGeneration / #getBranchLabel in this file.
	// Timestamp of the latest branch read; only bounds cache freshness when the
	// HEAD watcher could not be installed.
	#branchLastFetch: number | undefined = undefined;
	// Bumped on every branch-cache reset (invalidateGitCaches — a HEAD move or
	// repo-context change). An in-flight reftable resolve captures this at
	// launch; a mismatch on resolve means the cache was invalidated underneath
	// it (a newer resolve superseded it), so its result is stale and must be
	// dropped rather than overwrite the value the newer resolve committed.
	// Mirrors #jjCacheGeneration / #getBranchLabel in this file.
	#branchCacheGeneration = 0;
	#gitUnwatch: (() => void) | null = null;
	#gitWatcherUnavailable = false;
	#onBranchChange: (() => void) | null = null;
	#disposed = false;
	/** Unsubscribe for the native-rendering feed; re-arms the turn-window ticker when a TSP surface is revoked. */
	#unwatchNativeRendering: (() => void) | undefined;
	#autoCompactEnabled: boolean = true;
	/** Pulse timer for the running-speculation indicator; live only while speculation runs. */
	#speculationBlinkTimer: NodeJS.Timeout | undefined;
	#speculationBlinkOn = true;
	/** In-flight brand-color fade across a working-state edge; null when settled. */
	#brandFade: { fromHex: string; toHex: string; startedAt: number } | null = null;
	/** Working flag as of the last brand render, for edge detection. */
	#brandWorking = false;
	/** Frame timer driving repaints while the brand fade is unsettled. */
	#brandFadeTimer: NodeJS.Timeout | undefined;
	/** Repaint ticker while a turn's active-processing window is open (see #syncActiveWindowRepaint). */
	#activeWindowRepaintTimer: NodeJS.Timeout | undefined;
	/** One wall-clock wakeup for the active model's next tariff change, including while idle. */
	#pricingTimer: NodeJS.Timeout | undefined;
	#pricingTimerCost: ModelCost | undefined;
	#pricingTransition: number | undefined;
	/** One wall-clock wakeup when the warm prompt-cache entry expires, so the marker turns without ticking. */
	#promptCacheTimer: NodeJS.Timeout | undefined;
	#promptCacheWakeAt: number | undefined;
	#hookStatuses: Map<string, string> = new Map();
	#sortedHookStatuses: readonly string[] = [];
	#subagentCount: number = 0;
	#runningSubagentIds = new Set<string>();
	#subagentTreeCost = 0;
	#pinnedSessionIds = new Set<string>();
	/**
	 * Active-processing accounting for the `time_spent` segment, keyed per
	 * {@link StatusLineSession} so the focus-controller mid-turn attach path
	 * cannot leak an unmatched synthesized `agent_start` from a subagent
	 * into the main session's meter.
	 *
	 * Each meter is `{ activeMs, activeStartedAt }`: `activeMs` is the union
	 * of every completed `agent_start`→`agent_end` window since
	 * {@link resetActiveTime} last reset it; `activeStartedAt` is the start
	 * timestamp of the currently-running window (or `null` when idle).
	 * `getActiveMs()` returns `activeMs + (now - activeStartedAt)` for the
	 * currently-attached session, so the counter ticks live during a turn
	 * and freezes the instant the agent yields.
	 *
	 * WeakMap so meters die with their session (e.g. a parked subagent
	 * dropped from the registry); the main session's meter survives focus
	 * round-trips because the same {@link StatusLineSession} ref is reused.
	 */
	#activeMeters: WeakMap<TSession, ActiveMeter> = new WeakMap();
	#planModeStatus: { enabled: boolean; paused: boolean } | null = null;
	#loopModeStatus: SegmentContext["loopMode"] = null;
	#goalModeStatus: { enabled: boolean; paused: boolean } | null = null;
	#vibeModeStatus: { enabled: boolean } | null = null;
	#vimStatus: SegmentContext["vim"] = null;
	/**
	 * Injected aggregator that returns the aggregate tok/s of this session's
	 * live vibe worker sessions, or null when no workers are streaming. Kept as
	 * a callback so the render layer doesn't import the heavy vibe/task
	 * dependency graph; interactive-mode wires it to VibeSessionRegistry.
	 */
	#vibeWorkerTokenRate: (() => number | null) | null = null;
	#collabStatus: CollabStatus | null = null;
	#streamStatus: { viewers: number } | null = null;
	#recording = false;
	#awaitingAnswer = false;
	#focusedAgentId: string | undefined;
	#activeRepoCache: ActiveRepoCache | undefined;

	// Git status caching (1s TTL)
	#cachedGitStatus: { staged: number; unstaged: number; untracked: number } | null = null;
	#cachedGitStatusCwd: string | undefined = undefined;
	#gitStatusLastFetch = 0;
	#gitStatusGeneration = 0;
	#gitStatusInFlightCwd: string | undefined = undefined;
	#cachedJjBranch: string | null = null;
	#jjBranchLastFetch = 0;
	#jjResolveSeq = 0;
	#jjBranchActive: JjResolveRequest | undefined = undefined;
	#cachedJjStatus: { staged: number; unstaged: number; untracked: number } | null = null;
	#jjStatusLastFetch = 0;
	#jjStatusActive: JjResolveRequest | undefined = undefined;
	// Bumped on every jj-cache reset — a cwd switch (#applyCwdChange) or a HEAD /
	// bookmark move (#invalidateGitCaches). An in-flight jj query captures this
	// at launch; a mismatch on resolve means the caches were reset underneath it
	// (including a reset that re-resolves to the SAME root, which a root-equality
	// check cannot detect), so the result is stale and must be dropped rather
	// than poison the fresh cache or advance its throttle.
	#jjCacheGeneration = 0;

	// PR lookup cache. `#cachedPrContext` is the branch/repo `#cachedPr` was
	// resolved for; it is never shown for any other branch. Expiry forces a
	// refetch while keeping that branch's PR visible until the lookup lands.
	#cachedPr: { number: number; url: string } | null | undefined = undefined;
	#cachedPrContext: PrCacheContext | undefined = undefined;
	#cachedPrExpired = false;
	#prLookupInFlight = false;
	#defaultBranch?: string;
	#defaultBranchCwd: string | undefined = undefined;
	#lastTokensPerSecond: number | null = null;
	#lastTokensPerSecondTimestamp: number | null = null;

	// Provider usage caching (5-min TTL, OAuth/sub only)
	#cachedUsage: {
		tier?: string;
		fiveHour?: { percent: number; resetMinutes?: number };
		daily?: { percent: number; resetMinutes?: number };
		sevenDay?: { percent: number; resetHours?: number };
		monthly?: { percent: number; resetHours?: number };
		resetCredits?: {
			bankedCount: number;
			redeemableCount: number;
			expiryHours?: number;
			expired?: boolean;
			unavailableReason?: string;
			expiring?: StatusResetExpiry;
		};
	} | null = null;
	#cachedUsageContextKey: string | null = null;
	#usageFetchedAt = 0;
	#usageInFlight = false;
	#usageStartTimer: Timer | null = null;
	// A timed-out request may still resolve. Its result remains eligible only
	// until a newer request has applied.
	#usageRefreshSequence = 0;
	#latestAppliedUsageRefreshSequence = 0;
	#codexResetSnapshots = new Map<string, CodexResetUsageSnapshot>();
	#onCodexResetFireworks: ((event: CodexResetFireworksEvent) => void) | undefined;
	#onResetExpiryNotice: ((notice: string) => void) | undefined;
	// Context-usage memo. The status line redraws on every agent event, so the
	// hot path must not recompute context tokens unless an input changed.
	// `getContextUsage()` anchors on the last assistant's real prompt-token
	// count (matching the provider and the `/context` panel), so a stable
	// message list + model window yields a stable result we can return verbatim.
	#contextUsageCache: ContextUsageMemo | undefined;
	#nativeMemo: NativeFactsMemo | undefined;
	/** Last pull request reported through {@link onNativePullRequest}. */
	#nativePullRequest: StatusLinePullRequest | undefined;
	/** Reused probe buffer for the native memo check; handed to the memo on a rebuild. */
	#nativeInputsProbe = new StatusLineExternalInputs();

	constructor(
		private session: TSession,
		private readonly host: StatusLineHost<TSession>,
	) {
		this.#settings = host.getSettings();
		this.#unwatchNativeRendering = onNativeRenderingChange(() => this.#syncActiveWindowRepaint());
	}

	#gitEnabled(): boolean {
		return this.host.gitEnabled();
	}
	#hasGitBackedSegment(): boolean {
		const effectiveSettings = this.#resolveSettings();
		return (
			hasGitBackedSegment(effectiveSettings.leftSegments) || hasGitBackedSegment(effectiveSettings.rightSegments)
		);
	}

	#resolveActiveRepoCache(): ActiveRepoCache {
		const projectDir = getProjectDir();
		if (this.#activeRepoCache?.projectDir === projectDir) {
			return this.#activeRepoCache;
		}

		const projectRepository = vcs.repo(projectDir);
		const activeRepo = projectRepository ? null : this.host.resolveActiveRepo(projectDir);
		const effectiveGitCwd = activeRepo?.repoRoot ?? projectDir;
		const repository = projectRepository ?? (activeRepo ? vcs.repo(effectiveGitCwd) : null);
		// Presentation follows a second detector whose only policy difference
		// is preferring jj on equal-root ties (see detect_for_display);
		// automation keeps `repository` above. A failed display lookup (or a
		// caller that only stubs the operational detector) degrades to the
		// operational repository rather than hiding the segment.
		let displayRepository: VcsRepo | null;
		try {
			displayRepository = vcs.repoForDisplay(effectiveGitCwd);
		} catch {
			displayRepository = null;
		}
		displayRepository ??= repository;
		// Only collapse the bare-cwd case: a single-direct-child-repo context
		// (activeRepo set) renders `<parent> ↳ <child>`, which we leave intact.
		const worktree = activeRepo ? null : resolveWorktreeContext(effectiveGitCwd);
		this.#activeRepoCache = {
			projectDir,
			activeRepo,
			effectiveGitCwd,
			repository,
			displayRepository,
			displayRepositoryCheckedAt: Date.now(),
			repositoryCheckedAt: Date.now(),
			worktree,
		};
		return this.#activeRepoCache;
	}

	#resolveRepository(cache: ActiveRepoCache): VcsRepo | null {
		if (cache.repository) return cache.repository;
		const now = Date.now();
		if (now - cache.repositoryCheckedAt >= WATCHER_FAILURE_POLL_TTL_MS) {
			cache.repository = vcs.repo(cache.effectiveGitCwd);
			cache.repositoryCheckedAt = now;
		}
		// Still absent: re-probe on the bounded interval so a later `git init` shows up.
		if (!cache.repository) this.#noteVcsStaleAt(cache.repositoryCheckedAt + WATCHER_FAILURE_POLL_TTL_MS);
		return cache.repository;
	}

	#resolveDisplayRepository(cache: ActiveRepoCache): VcsRepo | null {
		if (cache.displayRepository) return cache.displayRepository;
		const now = Date.now();
		if (now - cache.displayRepositoryCheckedAt >= WATCHER_FAILURE_POLL_TTL_MS) {
			let display: VcsRepo | null;
			try {
				display = vcs.repoForDisplay(cache.effectiveGitCwd);
			} catch {
				display = null;
			}
			cache.displayRepository = display ?? cache.repository;
			cache.displayRepositoryCheckedAt = now;
		}
		if (!cache.displayRepository) {
			this.#noteVcsStaleAt(cache.displayRepositoryCheckedAt + WATCHER_FAILURE_POLL_TTL_MS);
		}
		return cache.displayRepository;
	}

	/** Lower {@link #vcsStaleAt} to `at` when a served VCS cache expires sooner. */
	#noteVcsStaleAt(at: number): void {
		if (at < this.#vcsStaleAt) this.#vcsStaleAt = at;
	}

	/** Expire the render memo once a served VCS cache has gone stale, so this frame refetches. */
	#expireStaleVcsRender(nowMs: number): void {
		if (nowMs < this.#vcsStaleAt) return;
		this.#vcsStaleAt = Number.POSITIVE_INFINITY;
		this.#invalidateStatusLineRenderCache();
	}

	/**
	 * Re-point the status line at another session (focus proxy). Invalidate: model/context/usage all derive
	 * from it. `focusedAgentId` is the focused subagent id while the view is proxied, undefined for main.
	 */
	setSession(session: TSession, focusedAgentId?: string): void {
		const sessionChanged = this.session !== session;
		if (!sessionChanged && this.#focusedAgentId === focusedAgentId) return;
		this.session = session;
		this.#focusedAgentId = focusedAgentId;
		if (sessionChanged) {
			this.#invalidateSessionCaches();
			this.#closeStaleActiveWindow();
		}
		// The ticker self-stops once its tick sees no open window for the
		// newly-attached session; re-pointing focus at a session whose turn
		// is still running must re-arm it, and no other path reliably fires
		// here (closeStaleActiveWindow returns early while streaming, and
		// the synthesized agent_start no-ops on an already-open window).
		this.#syncActiveWindowRepaint();
		this.invalidate();
	}

	/**
	 * Drop a meter's in-flight window when the newly-attached session is no
	 * longer streaming. Handles the case where the focus controller
	 * synthesized an `agent_start` on a mid-turn attach but the matching
	 * real `agent_end` never reached us — the user detached before it
	 * fired, and re-focusing later (after the agent finished) would
	 * otherwise tick over the entire detached gap. Crediting that gap to
	 * `activeMs` would be wrong (the agent finished at some point we never
	 * observed), so the window is dropped rather than folded in.
	 */
	#closeStaleActiveWindow(): void {
		const meter = this.#meter();
		if (meter.activeStartedAt === null) return;
		if (this.session.isStreaming) return;
		meter.activeStartedAt = null;
	}

	updateSettings(settings: StatusLineSettings): void {
		this.#settings = settings;
		this.#effectiveSettings = undefined;
		this.#invalidateStatusLineRenderCache();
		if (this.#onBranchChange) this.#setupGitWatcher();
		this.#syncPricingTimer();
	}

	getEffectiveSettingsForTest(): EffectiveStatusLineSettings {
		return this.#resolveSettings();
	}

	setAutoCompactEnabled(enabled: boolean): void {
		if (this.#autoCompactEnabled === enabled) return;
		this.#autoCompactEnabled = enabled;
		this.#invalidateStatusLineRenderCache();
	}

	setRunningSubagents(agentIds: readonly string[]): boolean {
		if (
			agentIds.length === this.#runningSubagentIds.size &&
			agentIds.every(agentId => this.#runningSubagentIds.has(agentId))
		) {
			return false;
		}
		this.#subagentCount = agentIds.length;
		this.#runningSubagentIds = new Set(agentIds);
		this.#invalidateStatusLineRenderCache();
		return true;
	}

	/** Host-computed spend of the main session's whole subagent tree (Agent Hub projection). */
	setSubagentTreeCost(cost: number): boolean {
		const next = Number.isFinite(cost) && cost > 0 ? cost : 0;
		if (next === this.#subagentTreeCost) return false;
		this.#subagentTreeCost = next;
		this.#invalidateStatusLineRenderCache();
		return true;
	}

	/**
	 * Compatibility shim for callers predating the simplified subagent badge.
	 * The status line now intentionally shows only the active count.
	 */
	setSubagentHubHint(_hint: string | undefined): void {}

	/** Active subagent count as currently displayed (collab state mirroring). */
	get subagentCount(): number {
		return this.#subagentCount;
	}

	/**
	 * Running background jobs outside the subagent badge. Task jobs count only
	 * until their AgentRegistry ref appears; once it is running, the subagent
	 * badge represents that same agent. Bash and eval jobs always count.
	 */
	runningBackgroundJobCount(): number {
		return (
			this.session
				.getAsyncJobSnapshot()
				?.running.filter(
					job => job.type !== "task" || job.agentId === undefined || !this.#runningSubagentIds.has(job.agentId),
				).length ?? 0
		);
	}

	/**
	 * Reset the currently-attached session's active-time accumulators so
	 * the `time_spent` segment starts from zero. Called from `/clear`,
	 * fresh-session, and joined-collab paths; both the completed
	 * accumulator and any in-flight window are dropped, so a reset
	 * mid-turn ignores the running window (the matching `markActivityEnd`
	 * will see an idle meter and no-op).
	 */
	resetActiveTime(): void {
		const meter = this.#meter();
		if (meter.activeMs === 0 && meter.activeStartedAt === null) return;
		meter.activeMs = 0;
		meter.activeStartedAt = null;
		this.#invalidateStatusLineRenderCache();
		this.#syncActiveWindowRepaint();
	}

	/**
	 * Mark the currently-attached session as having started a unit of
	 * active processing. Idempotent: a second start while a window is
	 * already open is a no-op, so reentrant `agent_start` events (e.g.
	 * nested auto-compaction loops, focus-controller mid-turn attach onto
	 * an already-running window) do not double-count.
	 */
	markActivityStart(): void {
		const meter = this.#meter();
		if (meter.activeStartedAt !== null) return;
		meter.activeStartedAt = Date.now();
		this.#invalidateStatusLineRenderCache();
		this.#syncActiveWindowRepaint();
	}

	/**
	 * Close the currently-attached session's open active-processing
	 * window, folding its elapsed time into the accumulator. Idempotent
	 * when the meter is already idle so callers can fire it on every
	 * `agent_end` without guarding.
	 */
	markActivityEnd(): void {
		const meter = this.#meter();
		if (meter.activeStartedAt === null) return;
		meter.activeMs += Math.max(0, Date.now() - meter.activeStartedAt);
		meter.activeStartedAt = null;
		this.#invalidateStatusLineRenderCache();
		this.#syncActiveWindowRepaint();
	}

	/**
	 * Snapshot of total active-processing time for the currently-attached
	 * session, including any in-flight window. Exposed for the segment
	 * context builder; tests assert against this too.
	 */
	getActiveMs(): number {
		const meter = this.#meter();
		if (meter.activeStartedAt === null) return meter.activeMs;
		return meter.activeMs + Math.max(0, Date.now() - meter.activeStartedAt);
	}
	/**
	 * Elapsed ms of the currently-open active-processing window, or null when
	 * idle. Feeds the `pi` segment's working spinner + turn timer.
	 */
	getTurnElapsedMs(): number | null {
		const startedAt = this.#meter().activeStartedAt;
		return startedAt === null ? null : Math.max(0, Date.now() - startedAt);
	}

	/**
	 * Return (lazily creating) the meter for the currently-attached
	 * session. Detects an in-place session-file swap under the same
	 * {@link StatusLineSession} ref (`switchSession` paths: `/resume`, `/move`,
	 * ACP fork/load, RPC `switch_session`, extension `switchSession`):
	 * a real-to-real change starts the meter fresh so the new
	 * conversation does not inherit the previous one's accumulated active
	 * time. The undefined → real first-save transition only refreshes the
	 * snapshot — the conversation identity has not changed.
	 */
	#meter(): ActiveMeter {
		const currentFile = this.session.sessionFile;
		let meter = this.#activeMeters.get(this.session);
		if (meter) {
			const switched =
				currentFile !== undefined && meter.sessionFile !== undefined && meter.sessionFile !== currentFile;
			if (switched) {
				meter = undefined;
			} else {
				meter.sessionFile = currentFile;
			}
		}
		if (!meter) {
			meter = { activeMs: 0, activeStartedAt: null, sessionFile: currentFile };
			this.#activeMeters.set(this.session, meter);
		}
		return meter;
	}

	setPlanModeStatus(status: { enabled: boolean; paused: boolean } | undefined): void {
		const next = status ?? null;
		if (
			this.#planModeStatus === next ||
			(this.#planModeStatus?.enabled === next?.enabled && this.#planModeStatus?.paused === next?.paused)
		) {
			return;
		}
		this.#planModeStatus = next;
		this.#invalidateStatusLineRenderCache();
	}

	setLoopModeStatus(status: NonNullable<SegmentContext["loopMode"]> | undefined): void {
		const next = status ?? null;
		if (
			this.#loopModeStatus === next ||
			(this.#loopModeStatus?.state === next?.state &&
				this.#loopModeStatus?.limit === next?.limit &&
				this.#loopModeStatus?.condition === next?.condition)
		) {
			return;
		}
		this.#loopModeStatus = next;
		this.#invalidateStatusLineRenderCache();
	}

	setGoalModeStatus(status: { enabled: boolean; paused: boolean } | undefined): void {
		const next = status ?? null;
		if (
			this.#goalModeStatus === next ||
			(this.#goalModeStatus?.enabled === next?.enabled && this.#goalModeStatus?.paused === next?.paused)
		) {
			return;
		}
		this.#goalModeStatus = next;
		this.#invalidateStatusLineRenderCache();
	}

	setVibeModeStatus(status: { enabled: boolean } | undefined): void {
		const next = status ?? null;
		if (this.#vibeModeStatus === next || this.#vibeModeStatus?.enabled === next?.enabled) return;
		this.#vibeModeStatus = next;
		this.#invalidateStatusLineRenderCache();
	}

	/** Mirror of the editor's modal state; `undefined` clears it (Vim mode off). */
	setVimStatus(status: NonNullable<SegmentContext["vim"]> | undefined): void {
		const next = status ?? null;
		if (
			this.#vimStatus === next ||
			(this.#vimStatus?.mode === next?.mode &&
				this.#vimStatus?.pending === next?.pending &&
				this.#vimStatus?.selectedLines === next?.selectedLines &&
				this.#vimStatus?.display === next?.display)
		) {
			return;
		}
		this.#vimStatus = next;
		this.#invalidateStatusLineRenderCache();
	}

	/**
	 * Inject the aggregator that returns the aggregate tok/s of this session's
	 * live vibe worker sessions (null when no workers are streaming). Wired by
	 * interactive-mode, which owns the VibeSessionRegistry coupling, so the
	 * render layer stays off the heavy vibe/task dependency graph. Pass
	 * `undefined` to clear.
	 */
	setVibeWorkerTokenRateProvider(provider: (() => number | null) | undefined): void {
		this.#vibeWorkerTokenRate = provider ?? null;
		this.#invalidateStatusLineRenderCache();
	}

	setCollabStatus(status: CollabStatus | null): void {
		if (
			!this.#collabStatus?.stateOverride &&
			!status?.stateOverride &&
			this.#collabStatus?.role === status?.role &&
			this.#collabStatus?.participantCount === status?.participantCount
		) {
			return;
		}
		this.#collabStatus = status;
		this.#invalidateStatusLineRenderCache();
	}

	setStreamStatus(status: { viewers: number } | null): void {
		if (this.#streamStatus?.viewers === status?.viewers) return;
		this.#streamStatus = status;
		this.#invalidateStatusLineRenderCache();
	}

	/** Whether the turn waits on an ask the user hasn't answered: the brand's spinner turns into a question mark. */
	setAwaitingAnswer(awaiting: boolean): void {
		if (this.#awaitingAnswer === awaiting) return;
		this.#awaitingAnswer = awaiting;
		this.#invalidateStatusLineRenderCache();
	}

	/** Toggle the `● REC` badge shown while `/record` captures the screen. */
	setRecording(recording: boolean): void {
		if (this.#recording === recording) return;
		this.#recording = recording;
		this.#invalidateStatusLineRenderCache();
	}

	/** Mark one session pinned or unpinned; `session_name` shows the pin for the viewed session. */
	setSessionPinned(sessionId: string, pinned: boolean): void {
		if (this.#pinnedSessionIds.has(sessionId) === pinned) return;
		if (pinned) this.#pinnedSessionIds.add(sessionId);
		else this.#pinnedSessionIds.delete(sessionId);
		this.#invalidateStatusLineRenderCache();
	}

	/** Replace the whole pinned-session set (a fresh read of the pins file). */
	setPinnedSessionIds(sessionIds: ReadonlySet<string>): void {
		this.#pinnedSessionIds = new Set(sessionIds);
		this.#invalidateStatusLineRenderCache();
	}

	isSessionPinned(sessionId: string | undefined): boolean {
		return sessionId !== undefined && this.#pinnedSessionIds.has(sessionId);
	}

	/** Set the callback that presents detected Codex reset celebrations, or clear it with `undefined`. */
	setCodexResetFireworksHandler(handler: ((event: CodexResetFireworksEvent) => void) | undefined): void {
		this.#onCodexResetFireworks = handler;
	}

	/** Set the callback that presents pool-wide saved-reset expiry warnings, or clear it with `undefined`. */
	setResetExpiryNoticeHandler(handler: ((notice: string) => void) | undefined): void {
		this.#onResetExpiryNotice = handler;
	}

	setHookStatus(key: string, text: string | undefined): void {
		if (text === undefined) {
			if (!this.#hookStatuses.delete(key)) return;
		} else {
			if (this.#hookStatuses.get(key) === text) return;
			this.#hookStatuses.set(key, text);
		}
		this.#sortedHookStatuses = Array.from(this.#hookStatuses.entries())
			.sort(([a], [b]) => a.localeCompare(b))
			.map(([, status]) => status);
		this.#invalidateStatusLineRenderCache();
	}

	watchBranch(onBranchChange: () => void): void {
		this.#onBranchChange = onBranchChange;
		this.#setupGitWatcher();
		this.#syncPricingTimer();
	}

	#setupGitWatcher(): void {
		this.#retireGitWatcher();
		this.#gitWatcherUnavailable = false;

		if (!this.#gitEnabled() || !this.#hasGitBackedSegment()) {
			this.invalidateGitCaches();
			return;
		}

		const activeRepoCache = this.#resolveActiveRepoCache();
		const repository = this.#resolveDisplayRepository(activeRepoCache);
		if (!repository) {
			// There is no path to watch yet. Cache the negative result only for the
			// fallback poll interval so a later `git init` becomes visible without
			// generic invalidations or a render-path probe on every paint.
			this.#gitWatcherUnavailable = true;
			return;
		}

		// Backends atomically replace their head markers, so stat-poll the
		// backend-selected target instead of binding a watcher to one inode.
		try {
			const unwatch = vcs.watch(repository, () => {
				if (this.#disposed || this.#gitUnwatch !== unwatch) return;
				this.invalidateGitCaches();
				this.#onBranchChange?.();
			});
			this.#gitUnwatch = unwatch;
		} catch {
			this.#gitWatcherUnavailable = true;
		}
	}

	#retireGitWatcher(): void {
		const unwatch = this.#gitUnwatch;
		this.#gitUnwatch = null;
		unwatch?.();
	}

	dispose(): void {
		this.#disposed = true;
		this.#branchResolveActive?.controller.abort();
		this.#branchResolveActive = undefined;
		this.#resetJjRequests();
		this.#onBranchChange = null;
		this.#stopSpeculationBlink();
		this.#stopBrandFadeTimer();
		this.#stopActiveWindowRepaint();
		this.#stopPricingTimer();
		this.#stopPromptCacheTimer();
		this.#clearUsageStartTimer();
		this.#unwatchNativeRendering?.();
		this.#unwatchNativeRendering = undefined;
		this.#onCodexResetFireworks = undefined;
		this.#onResetExpiryNotice = undefined;
		this.#codexResetSnapshots.clear();
		this.#retireGitWatcher();
	}

	/**
	 * Drive the context segment's pulse while a background speculative
	 * compaction runs: a slow toggle that invalidates and repaints through the
	 * same host callback async git/PR resolves use. Stops (and resets phase)
	 * the first render after speculation leaves the running state.
	 */
	#syncSpeculationBlink(state: "idle" | "running" | "armed"): void {
		// A TSP terminal pulses the icon itself (`fx: "pulse"`, dropped by `quietMotion` when effects are
		// off); here `tui.motion` switches the JS blink off.
		if (state === "running" && !this.#disposed && !isNativeRendering() && motionEffectsEnabled()) {
			this.#speculationBlinkTimer ??= setInterval(() => {
				this.#speculationBlinkOn = !this.#speculationBlinkOn;
				this.invalidate();
				this.#onBranchChange?.();
			}, 600);
			return;
		}
		this.#stopSpeculationBlink();
	}

	#stopSpeculationBlink(): void {
		if (!this.#speculationBlinkTimer) return;
		clearInterval(this.#speculationBlinkTimer);
		this.#speculationBlinkTimer = undefined;
		this.#speculationBlinkOn = true;
	}
	/**
	 * Foreground ANSI for the `pi` brand segment: dim gray while idle, fading
	 * to the accent (session accent when enabled, else theme accent) while a
	 * turn runs — a port of rust omp's status-band brand fade (450ms cubic
	 * ease-in-out). A working-state edge retargets the tween from the color
	 * currently on screen, so interrupting a running fade never jumps, and arms
	 * a 40ms frame timer so the fade keeps animating after the working loader
	 * (the usual repaint driver) has stopped.
	 */
	#brandFgAnsi(working: boolean, sessionAccentEnabled: boolean, brandVisible: boolean): string {
		const sessionName = sessionAccentEnabled ? this.session.sessionManager?.getSessionName() : undefined;
		const idleHex = theme.getColorHex("dim");
		const workingHex =
			(sessionName && getSessionAccentHex(sessionName, theme.sessionAccentInputs)) || theme.getColorHex("accent");
		const now = Date.now();
		if (working !== this.#brandWorking) {
			const previousTargetHex = this.#brandWorking ? workingHex : idleHex;
			this.#brandWorking = working;
			// With decorative motion off the brand snaps to its settled color; otherwise it eases over.
			if (motionEffectsEnabled()) {
				this.#brandFade = {
					fromHex: this.#sampleBrandHex(previousTargetHex, now),
					toHex: working ? workingHex : idleHex,
					startedAt: now,
				};
				// Only a visible `pi` segment needs fade frames; other bars stay quiet.
				if (brandVisible) this.#startBrandFadeTimer();
			} else {
				this.#brandFade = null;
			}
		}
		const hex = this.#sampleBrandHex(working ? workingHex : idleHex, now);
		return getSessionAccentAnsi(hex) ?? theme.getFgAnsi(working ? "accent" : "dim");
	}

	/**
	 * The brand hex at `now`: the eased blend while a fade is in flight,
	 * otherwise `settledHex`. A fade past its deadline is cleared here so the
	 * next frame timer tick shuts the timer down.
	 */
	#sampleBrandHex(settledHex: string, now: number): string {
		const fade = this.#brandFade;
		if (!fade) return settledHex;
		const t = (now - fade.startedAt) / BRAND_FADE_MS;
		if (t >= 1) {
			this.#brandFade = null;
			return settledHex;
		}
		// Cubic ease-in-out, matching rust omp's Easing::EaseInOut.
		const eased = t < 0.5 ? 4 * t * t * t : 1 - (-2 * t + 2) ** 3 / 2;
		const from = hexToRgb(fade.fromHex);
		const to = hexToRgb(fade.toHex);
		return rgbToHex({
			r: Math.round(from.r + (to.r - from.r) * eased),
			g: Math.round(from.g + (to.g - from.g) * eased),
			b: Math.round(from.b + (to.b - from.b) * eased),
		});
	}

	#startBrandFadeTimer(): void {
		// The native brand segment is a terminal-clocked spinner; nothing to repaint.
		if (this.#brandFadeTimer || this.#disposed || isNativeRendering()) return;
		this.#brandFadeTimer = setInterval(() => {
			const fade = this.#brandFade;
			if (!fade || Date.now() - fade.startedAt >= BRAND_FADE_MS) this.#stopBrandFadeTimer();
			// One trailing repaint after the stop paints the settled color.
			this.invalidate();
			this.#onBranchChange?.();
		}, BRAND_FADE_FRAME_MS);
	}

	#stopBrandFadeTimer(): void {
		if (!this.#brandFadeTimer) return;
		clearInterval(this.#brandFadeTimer);
		this.#brandFadeTimer = undefined;
	}

	/**
	 * Keep the status bar repainting while a turn's active-processing window
	 * is open. The `pi` segment's spinner and turn timer are painted from the
	 * wall clock at render time, so they only animate when frames flow; during
	 * a quiet turn the working-row loader's tick is normally the sole
	 * repaint source, and paths that stop or bypass that loader mid-turn (an
	 * error banner, a stale retry/compaction loader reference) froze the
	 * spinner until the next keystroke. The status line owns the active
	 * window, so it owns a repaint source for it; a native surface clocks its
	 * own spinner and needs none.
	 */
	#syncActiveWindowRepaint(): void {
		if (this.#disposed || isNativeRendering() || this.getTurnElapsedMs() === null) {
			this.#stopActiveWindowRepaint();
			return;
		}
		if (!this.#activeWindowRepaintTimer) this.#armActiveWindowRepaint();
	}

	/**
	 * One tick on the shared clock's next boundary (see {@link spinnerTickDelay}); re-arms itself,
	 * re-reading the period. The period is a whole number of spinner frames no shorter than the
	 * 250 ms safety net, so every tick coincides with one of the working row's own and the two cost
	 * one frame; with static spinners it is the turn timer's 1 s.
	 */
	#armActiveWindowRepaint(): void {
		const frameMs = spinnerInterval();
		const periodMs = spinnerAnimated()
			? Math.ceil(ACTIVE_WINDOW_REPAINT_MS / frameMs - 1e-6) * frameMs
			: STATIC_SPINNER_REPAINT_MS;
		const timer = setTimeout(() => {
			this.#activeWindowRepaintTimer = undefined;
			if (this.#disposed || isNativeRendering() || this.getTurnElapsedMs() === null) return;
			this.#onBranchChange?.();
			this.#armActiveWindowRepaint();
		}, spinnerTickDelay(periodMs));
		timer.unref?.();
		this.#activeWindowRepaintTimer = timer;
	}

	#stopActiveWindowRepaint(): void {
		if (!this.#activeWindowRepaintTimer) return;
		clearTimeout(this.#activeWindowRepaintTimer);
		this.#activeWindowRepaintTimer = undefined;
	}

	#stopPricingTimer(): void {
		clearTimeout(this.#pricingTimer);
		this.#pricingTimer = undefined;
		this.#pricingTimerCost = undefined;
		this.#pricingTransition = undefined;
	}

	#syncPricingTimer(): void {
		const cost = this.session.state.model?.cost;
		const effectiveSettings = this.#resolveSettings();
		const costVisible =
			(effectiveSettings.leftSegments.includes("cost") &&
				(this.#standalone !== false ||
					this.#topAttachment === "top-border" ||
					this.#topAttachment === "top-band")) ||
			(effectiveSettings.rightSegments.includes("cost") &&
				(this.#standalone === "full" || this.#topAttachment !== "none"));
		if (this.#disposed || !this.#onBranchChange || !cost?.timeBased || !costVisible) {
			this.#stopPricingTimer();
			return;
		}
		const now = Date.now();
		if (this.#pricingTimerCost === cost && this.#pricingTransition !== undefined && this.#pricingTransition > now) {
			return;
		}
		this.#stopPricingTimer();
		const transition = getNextTimeBasedPricingTransition(cost, now);
		if (transition === undefined) return;
		this.#pricingTimerCost = cost;
		this.#pricingTransition = transition;
		const timer = setTimeout(() => {
			if (this.#disposed || this.#pricingTimer !== timer) return;
			this.#stopPricingTimer();
			this.invalidate();
			this.#onBranchChange?.();
		}, transition - now);
		this.#pricingTimer = timer;
		timer.unref();
	}

	#stopPromptCacheTimer(): void {
		clearTimeout(this.#promptCacheTimer);
		this.#promptCacheTimer = undefined;
		this.#promptCacheWakeAt = undefined;
	}

	/**
	 * One wakeup when the warm prompt cache lapses, so the marker turns without
	 * ticking; a warm refresh moves the expiry and re-arms it on the next build.
	 */
	#syncPromptCacheTimer(status: PromptCacheStatus | undefined, now: number): void {
		const wakeAt =
			status?.state === "warm" && status.ttlMs !== undefined ? status.touchedAt + status.ttlMs : undefined;
		if (this.#disposed || !this.#onBranchChange || wakeAt === undefined || wakeAt <= now) {
			this.#stopPromptCacheTimer();
			return;
		}
		if (this.#promptCacheWakeAt === wakeAt) return;
		this.#stopPromptCacheTimer();
		this.#promptCacheWakeAt = wakeAt;
		const timer = setTimeout(() => {
			if (this.#disposed || this.#promptCacheTimer !== timer) return;
			this.#stopPromptCacheTimer();
			this.invalidate();
			this.#onBranchChange?.();
		}, wakeAt - now);
		this.#promptCacheTimer = timer;
		timer.unref();
	}

	#clearUsageStartTimer(): void {
		if (!this.#usageStartTimer) return;
		clearTimeout(this.#usageStartTimer);
		this.#usageStartTimer = null;
	}

	#invalidateStatusLineRenderCache(): void {
		this.#statusLineInputRevision++;
	}

	invalidate(): void {
		this.#renderRevision++;
		this.#syncPricingTimer();
		// Generic repaint invalidation (theme change, message event, model
		// switch, …). Must NOT abort or restart a live reftable HEAD/PR resolve:
		// the render path self-invalidates via cwd/context cache-miss checks, so
		// a generic paint only needs to re-render — not tear down in-flight VCS
		// work. Aborting here would fan out a new git subprocess on every agent
		// event, re-introducing the render-path spawn churn the async resolve
		// was designed to avoid. Explicit Git/repository invalidation (watcher
		// HEAD-move, cwd/repo switch) goes through {@link invalidateGitCaches}.
		// A tool may open, close, or merge a PR without moving HEAD. Expire the
		// settled PR on ordinary activity while leaving HEAD work intact.
		this.#cachedPrExpired = true;
	}
	#invalidateSessionCaches(): void {
		this.#clearUsageStartTimer();
		this.#cachedUsage = null;
		this.#usageFetchedAt = 0;
		this.#usageInFlight = false;
		this.#contextUsageCache = undefined;
		this.#lastTokensPerSecond = null;
		this.#lastTokensPerSecondTimestamp = null;
	}

	/**
	 * Explicit Git/repository cache invalidation. Aborts any in-flight
	 * reftable HEAD/PR resolve, bumps the stale-result generation, and drops
	 * the branch/PR/jj caches so the next render refetches from disk. Called
	 * by the git watcher on a HEAD move and by {@link applyCwdChange} on a
	 * repo/cwd switch. Generic repaints use {@link invalidate} instead and
	 * must never reach this path.
	 */
	invalidateGitCaches(): void {
		this.#invalidateStatusLineRenderCache();
		this.#cachedBranch = undefined;
		this.#cachedBranchRepoId = undefined;
		this.#cachedBranchCwd = undefined;
		// Abort before releasing the in-flight slot. Releasing alone would allow
		// repeated invalidations to fan out still-running git subprocesses.
		this.#branchResolveActive?.controller.abort();
		this.#branchResolveActive = undefined;
		this.#branchLastFetch = undefined;
		this.#branchCacheGeneration++;
		this.#cachedPrExpired = true;
		// A HEAD move (commit, checkout, reset) changes the dirty counts; keep the
		// stale counts on screen but refetch on the next render. The generation
		// bump stops an in-flight pre-move result from re-stamping freshness.
		this.#gitStatusLastFetch = 0;
		this.#gitStatusGeneration++;
		// jj label/status share the git segment's lifecycle: a HEAD move (e.g. a
		// colocated `jj new`/bookmark move) must drop the throttled jj caches too,
		// so the next render refetches.
		this.#resetJjRequests();
		this.#cachedJjBranch = null;
		this.#jjBranchLastFetch = 0;
		this.#cachedJjStatus = null;
		this.#jjStatusLastFetch = 0;
		this.#jjCacheGeneration++;
	}

	/**
	 * Re-point the status line's VCS watcher and caches at a new cwd/repository.
	 * Atomically retires the old watcher/listeners, invalidates VCS caches and
	 * in-flight controllers, then runs watcher setup for the new cwd and requests
	 * a repaint. Called by {@link InteractiveMode.applyCwdChange} after the
	 * SessionManager's cwd has moved — the watcher ownership always follows the
	 * effective cwd/repo, so a stale watcher for the previous repo can never
	 * invalidate the new one. Generic repaints use {@link invalidate} and must
	 * never retire the watcher or abort a live resolve.
	 */
	applyCwdChange(): void {
		this.#retireGitWatcher();
		this.invalidateGitCaches();
		this.#setupGitWatcher();
		this.#onBranchChange?.();
	}

	#resetJjRequests(): void {
		this.#jjBranchActive?.controller.abort();
		this.#jjBranchActive = undefined;
		this.#jjStatusActive?.controller.abort();
		this.#jjStatusActive = undefined;
	}
	#getBranchLabel(
		activeRepoCache: ActiveRepoCache = this.#resolveActiveRepoCache(),
		// Presentation defaults to the display detector; PR lookup passes the
		// operational repository so a jj label never becomes a GitHub head.
		repository: VcsRepo | null = this.#resolveDisplayRepository(activeRepoCache),
	): string | null {
		if (!this.#gitEnabled()) return null;

		const gitCwd = activeRepoCache.effectiveGitCwd;
		if (!repository) return null;
		const taggedRepository: GitViewTaggedRepo = repository;
		let gitRepository = taggedRepository[GIT_VIEW];
		if (gitRepository === undefined) {
			gitRepository = repository.asGit();
			taggedRepository[GIT_VIEW] = gitRepository;
		}
		if (!gitRepository) {
			if (this.#jjBranchActive) return this.#cachedJjBranch;
			if (Date.now() - this.#jjBranchLastFetch < JJ_REFRESH_TTL_MS) {
				this.#noteVcsStaleAt(this.#jjBranchLastFetch + JJ_REFRESH_TTL_MS);
				return this.#cachedJjBranch;
			}
			const request: JjResolveRequest = {
				id: ++this.#jjResolveSeq,
				controller: new AbortController(),
			};
			this.#jjBranchActive = request;
			const generation = this.#jjCacheGeneration;
			(async () => {
				let next: string | null = null;
				try {
					const raw =
						(await repository.label(
							AbortSignal.any([request.controller.signal, AbortSignal.timeout(JJ_COMMAND_TIMEOUT_MS)]),
						)) ?? null;
					// Repository-controlled jj metadata can carry control
					// characters; sanitize at the cache boundary (the git segment
					// renders the label verbatim).
					next = raw === null ? null : sanitizeStatusText(raw);
				} catch {
					next = null;
				} finally {
					if (this.#jjBranchActive?.id === request.id) this.#jjBranchActive = undefined;
					if (this.#jjCacheGeneration === generation) this.#jjBranchLastFetch = Date.now();
				}
				if (this.#jjCacheGeneration !== generation || this.#disposed) return;
				this.#noteVcsStaleAt(this.#jjBranchLastFetch + JJ_REFRESH_TTL_MS);
				const changed = next !== this.#cachedJjBranch;
				this.#cachedJjBranch = next;
				if (changed) {
					this.#invalidateStatusLineRenderCache();
					this.#onBranchChange?.();
				}
			})();
			return this.#cachedJjBranch;
		}
		const fallbackCacheExpired =
			this.#gitWatcherUnavailable &&
			(this.#branchLastFetch === undefined || Date.now() - this.#branchLastFetch >= WATCHER_FAILURE_POLL_TTL_MS);
		if (this.#cachedBranch !== undefined && this.#cachedBranchCwd === gitCwd && !fallbackCacheExpired) {
			if (this.#gitWatcherUnavailable && this.#branchLastFetch !== undefined) {
				this.#noteVcsStaleAt(this.#branchLastFetch + WATCHER_FAILURE_POLL_TTL_MS);
			}
			return this.#cachedBranch;
		}

		// A reftable repo resolves HEAD by spawning `git symbolic-ref` +
		// `git rev-parse` — the unbounded spawn that froze the render path (F7).
		// A non-reftable repo resolves HEAD with cheap sync filesystem reads, so
		// only the reftable branch moves off the render path, mirroring
		// #getStatus and the Jujutsu label path above.
		const repoInfo = vcs.gitInfo(gitCwd);
		if (repoInfo?.isReftable) {
			if (this.#branchResolveActive !== undefined) {
				return this.#branchResolveActive.cwd === gitCwd && this.#cachedBranchCwd === gitCwd
					? (this.#cachedBranch ?? null)
					: null;
			}
			const request: BranchResolveRequest = {
				id: ++this.#branchResolveSeq,
				cwd: gitCwd,
				controller: new AbortController(),
			};
			this.#branchResolveActive = request;
			// Capture the cache generation at launch. invalidateGitCaches bumps it
			// on a HEAD move and clears the in-flight slot, so a fresher resolve can
			// start while this one is still pending. Without a generation check the
			// older resolve would finish later, install its stale HEAD, and clear the
			// slot — dropping the fresh result and freezing the status line on the
			// pre-change branch. Mirrors #jjCacheGeneration / #getBranchLabel.
			const generation = this.#branchCacheGeneration;
			(async () => {
				let next: string | null = null;
				let repoId: string | null = null;
				try {
					const headState = await gitRepository.head(request.controller.signal);
					repoId = repoInfo.headPath;
					next = headState.kind === "ref" ? (headState.branch ?? headState.refName ?? "HEAD") : "detached";
				} catch {
					next = null;
				} finally {
					// Release the slot only if this resolve still owns it: after an
					// invalidation a fresher resolve may hold it, and freeing that
					// slot here would let a third same-generation resolve launch and
					// race the fresh one to the cache commit.
					if (this.#branchResolveActive?.id === request.id) this.#branchResolveActive = undefined;
				}
				// Only the latest generation may update the cache; a mismatch means a
				// newer resolve superseded this one (or the component disposed).
				if (this.#branchCacheGeneration !== generation || this.#disposed) return;
				const prev = this.#cachedBranchCwd === gitCwd ? this.#cachedBranch : undefined;
				this.#cachedBranchCwd = gitCwd;
				this.#cachedBranchRepoId = repoId;
				this.#cachedBranch = next;
				this.#branchLastFetch = Date.now();
				if (this.#gitWatcherUnavailable) {
					this.#noteVcsStaleAt(this.#branchLastFetch + WATCHER_FAILURE_POLL_TTL_MS);
				}
				if (prev !== next) {
					this.#invalidateStatusLineRenderCache();
					this.#onBranchChange?.();
				}
			})();
			return this.#cachedBranchCwd === gitCwd ? (this.#cachedBranch ?? null) : null;
		}

		// Non-reftable: cheap sync filesystem read, safe on the render path.
		const head = (() => {
			try {
				return gitRepository.headSync();
			} catch {
				return null;
			}
		})();
		const gitHeadPath = repoInfo?.headPath ?? null;
		this.#cachedBranchCwd = gitCwd;
		this.#cachedBranchRepoId = gitHeadPath;
		this.#branchLastFetch = Date.now();
		if (this.#gitWatcherUnavailable) this.#noteVcsStaleAt(this.#branchLastFetch + WATCHER_FAILURE_POLL_TTL_MS);
		if (!head) {
			this.#cachedBranch = null;
			return null;
		}
		this.#cachedBranch = head.kind === "ref" ? (head.branch ?? head.refName ?? "HEAD") : "detached";
		return this.#cachedBranch ?? null;
	}

	#isDefaultBranch(branch: string, effectiveGitCwd: string): boolean {
		if (this.#defaultBranchCwd !== effectiveGitCwd) {
			this.#defaultBranch = undefined;
			this.#defaultBranchCwd = effectiveGitCwd;
		}

		if (this.#defaultBranch === undefined) {
			this.#defaultBranch = "main";
			const lookupCwd = effectiveGitCwd;
			(async () => {
				const resolved = await vcs.git(lookupCwd)?.defaultBranch();
				if (this.#disposed || this.#defaultBranchCwd !== lookupCwd) return;
				if (resolved) {
					this.#defaultBranch = resolved;
					this.#invalidateStatusLineRenderCache();
					this.#onBranchChange?.();
				}
			})();
		}
		return branch === this.#defaultBranch;
	}

	#getStatus(activeRepoCache: ActiveRepoCache = this.#resolveActiveRepoCache()): {
		staged: number;
		unstaged: number;
		untracked: number;
	} | null {
		if (!this.#gitEnabled()) return null;

		const gitCwd = activeRepoCache.effectiveGitCwd;
		const repository = this.#resolveRepository(activeRepoCache);
		if (!repository) return null;
		if (repository.kind() === "jj") {
			if (this.#jjStatusActive) return this.#cachedJjStatus;
			if (Date.now() - this.#jjStatusLastFetch < JJ_REFRESH_TTL_MS) {
				this.#noteVcsStaleAt(this.#jjStatusLastFetch + JJ_REFRESH_TTL_MS);
				return this.#cachedJjStatus;
			}
			const request: JjResolveRequest = {
				id: ++this.#jjResolveSeq,
				controller: new AbortController(),
			};
			this.#jjStatusActive = request;
			const generation = this.#jjCacheGeneration;
			(async () => {
				let next: { staged: number; unstaged: number; untracked: number } | null = null;
				try {
					next = await repository.statusSummary(
						AbortSignal.any([request.controller.signal, AbortSignal.timeout(JJ_COMMAND_TIMEOUT_MS)]),
					);
				} catch {
					next = null;
				} finally {
					if (this.#jjStatusActive?.id === request.id) this.#jjStatusActive = undefined;
					if (this.#jjCacheGeneration === generation) this.#jjStatusLastFetch = Date.now();
				}
				if (this.#jjCacheGeneration !== generation || this.#disposed) return;
				this.#noteVcsStaleAt(this.#jjStatusLastFetch + JJ_REFRESH_TTL_MS);
				const prev = this.#cachedJjStatus;
				this.#cachedJjStatus = next;
				if (JSON.stringify(prev) !== JSON.stringify(next)) {
					this.#invalidateStatusLineRenderCache();
					this.#onBranchChange?.();
				}
			})();
			return this.#cachedJjStatus;
		}

		if (this.#gitStatusInFlightCwd !== undefined) {
			return this.#cachedGitStatusCwd === gitCwd ? this.#cachedGitStatus : null;
		}
		if (this.#cachedGitStatusCwd === gitCwd && Date.now() - this.#gitStatusLastFetch < GIT_STATUS_TTL_MS) {
			this.#noteVcsStaleAt(this.#gitStatusLastFetch + GIT_STATUS_TTL_MS);
			return this.#cachedGitStatus;
		}

		this.#gitStatusInFlightCwd = gitCwd;
		const generation = this.#gitStatusGeneration;

		(async () => {
			let nextStatus: { staged: number; unstaged: number; untracked: number } | null = null;
			try {
				nextStatus = (await repository.statusSummary()) ?? null;
			} catch {
				nextStatus = null;
			} finally {
				if (this.#gitStatusInFlightCwd === gitCwd) {
					const prev = this.#cachedGitStatusCwd === gitCwd ? this.#cachedGitStatus : null;
					this.#cachedGitStatus = nextStatus;
					this.#cachedGitStatusCwd = gitCwd;
					this.#gitStatusLastFetch = this.#gitStatusGeneration === generation ? Date.now() : 0;
					this.#gitStatusInFlightCwd = undefined;
					// A zeroed stamp (superseded generation) is already due: refetch next frame.
					this.#noteVcsStaleAt(this.#gitStatusLastFetch + GIT_STATUS_TTL_MS);
					if (!this.#disposed && JSON.stringify(prev) !== JSON.stringify(nextStatus)) {
						this.#invalidateStatusLineRenderCache();
						this.#onBranchChange?.();
					}
				}
			}
		})();

		return this.#cachedGitStatusCwd === gitCwd ? this.#cachedGitStatus : null;
	}

	/**
	 * Seed working-tree status from the status line this one replaces (the
	 * startup bar), so the dirty counts stay on screen instead of blanking until
	 * this instance's first fetch lands. Normal TTL refreshes follow.
	 */
	adoptGitStatus(source: StatusLineComponent): void {
		if (this.#cachedGitStatusCwd === undefined && source.#cachedGitStatusCwd !== undefined) {
			this.#cachedGitStatus = source.#cachedGitStatus;
			this.#cachedGitStatusCwd = source.#cachedGitStatusCwd;
			this.#gitStatusLastFetch = source.#gitStatusLastFetch;
		}
		if (this.#jjStatusLastFetch === 0 && source.#jjStatusLastFetch !== 0) {
			this.#cachedJjStatus = source.#cachedJjStatus;
			this.#jjStatusLastFetch = source.#jjStatusLastFetch;
		}
		this.#invalidateStatusLineRenderCache();
	}

	#lookupPr(activeRepoCache: ActiveRepoCache = this.#resolveActiveRepoCache()): {
		number: number;
		url: string;
	} | null {
		if (!this.#gitEnabled()) return null;

		const gitCwd = activeRepoCache.effectiveGitCwd;
		if (this.#resolveRepository(activeRepoCache)?.kind() !== "git") return null;
		const branch = this.#getBranchLabel(activeRepoCache, this.#resolveRepository(activeRepoCache));
		const currentContext = branch ? createPrCacheContext(branch, this.#cachedBranchRepoId ?? null) : null;

		if (!this.#cachedPrExpired && canReuseCachedPr(this.#cachedPr, this.#cachedPrContext, currentContext)) {
			return this.#cachedPr ?? null;
		}

		// Keep an expired PR visible during the refetch only on the branch it
		// was resolved for; after a checkout the old PR must not linger.
		const stalePr =
			currentContext && isSamePrCacheContext(this.#cachedPrContext, currentContext)
				? (this.#cachedPr ?? null)
				: null;

		if (!branch) {
			this.#cachedPr = null;
			this.#cachedPrContext = undefined;
			return null;
		}

		// Detached HEAD and the default branch never carry a PR; no lookup.
		if (branch === "detached" || this.#isDefaultBranch(branch, gitCwd)) return null;
		if (this.#prLookupInFlight) return stalePr;

		this.#prLookupInFlight = true;
		const lookupContext = currentContext;
		const lookupCwd = gitCwd;

		// Fire async lookup, keep stale value visible until resolved
		(async () => {
			// Helper: only write cache if branch/repo context hasn't changed since launch
			const setCachedPr = (value: { number: number; url: string } | null) => {
				const latestActiveRepoCache = this.#resolveActiveRepoCache();
				if (latestActiveRepoCache.effectiveGitCwd !== lookupCwd) return;
				const latestBranch = this.#getBranchLabel(
					latestActiveRepoCache,
					this.#resolveRepository(latestActiveRepoCache),
				);
				const latestContext = latestBranch
					? createPrCacheContext(latestBranch, this.#cachedBranchRepoId ?? null)
					: undefined;
				if (lookupContext && isSamePrCacheContext(latestContext, lookupContext)) {
					this.#cachedPr = value;
					this.#cachedPrContext = lookupContext;
					this.#cachedPrExpired = false;
				}
			};
			try {
				// Route through the shared `gh` helper so the child inherits
				// `GH_NON_INTERACTIVE_ENV` (disables terminal/keychain prompts) and
				// hard-terminates on the git command deadline instead of stalling
				// the status-line indefinitely (#4234). Requires `gh repo set-default`;
				// non-zero exit still falls through to the null cache below.
				const result = await this.host.lookupPullRequest(lookupCwd);
				if (this.#disposed) return;
				if (result.exitCode !== 0) {
					setCachedPr(null);
					return;
				}
				const pr = JSON.parse(result.stdout) as { number: number; url: string };
				if (typeof pr.number === "number") {
					setCachedPr({ number: pr.number, url: pr.url });
				} else {
					setCachedPr(null);
				}
			} catch {
				if (this.#disposed) return;
				setCachedPr(null);
			} finally {
				this.#prLookupInFlight = false;
				if (!this.#disposed) {
					this.#invalidateStatusLineRenderCache();
					this.#onBranchChange?.();
				}
			}
		})();

		return stalePr ?? null;
	}

	#getTokensPerSecond(): number | null {
		// Aggregate tok/s across the main session AND every live vibe worker.
		// In vibe mode the director is often idle while workers stream, so the
		// main session's own rate alone would show a stale/zero value while
		// parallel work is actively generating tokens.
		const workerRate = this.#getVibeWorkerTokensPerSecond();
		if (workerRate !== null) {
			// At least one worker is streaming — add the director's live rate
			// only when it is itself streaming (a finalized last-turn rate would
			// double-count and overstate throughput).
			const mainRate = this.session.isStreaming
				? this.host.calculateTokensPerSecond(this.session.state.messages, true)
				: 0;
			return (mainRate ?? 0) + workerRate;
		}

		// No workers streaming — fall back to the main session's own rate with
		// its sticky per-assistant-message cache so the badge doesn't flicker
		// off in the brief gap between stream end and the finalized message.
		return this.#getMainSessionTokensPerSecond();
	}

	/**
	 * Main session's tok/s with sticky caching keyed on the last assistant
	 * message timestamp. Preserves the pre-aggregation behavior when no vibe
	 * workers are active.
	 */
	#getMainSessionTokensPerSecond(): number | null {
		let lastAssistantTimestamp: number | null = null;
		for (let i = this.session.state.messages.length - 1; i >= 0; i--) {
			const message = this.session.state.messages[i];
			if (message?.role === "assistant") {
				lastAssistantTimestamp = message.timestamp;
				break;
			}
		}

		if (lastAssistantTimestamp === null) {
			this.#lastTokensPerSecond = null;
			this.#lastTokensPerSecondTimestamp = null;
			return null;
		}

		const rate = this.host.calculateTokensPerSecond(this.session.state.messages, this.session.isStreaming);
		if (rate !== null) {
			this.#lastTokensPerSecond = rate;
			this.#lastTokensPerSecondTimestamp = lastAssistantTimestamp;
			return rate;
		}

		if (this.#lastTokensPerSecondTimestamp === lastAssistantTimestamp) {
			return this.#lastTokensPerSecond;
		}

		return null;
	}

	/**
	 * Aggregate tok/s across every live vibe worker session owned by this
	 * session. Returns null when no workers are streaming (so the main
	 * session's own rate shines through unchanged). The aggregation itself is
	 * injected via {@link setVibeWorkerTokenRateProvider} to keep this render
	 * layer off the heavy vibe/task dependency graph.
	 */
	#getVibeWorkerTokensPerSecond(): number | null {
		return this.#vibeWorkerTokenRate?.() ?? null;
	}

	#formatUsageContextKey(activeProvider: string | undefined, identity: OAuthAccountIdentity | undefined): string {
		if (!activeProvider) return "";
		// orgId is part of the key: rotating between two same-email Anthropic
		// subscriptions must invalidate the cached usage immediately instead of
		// showing the previous org's quota for the rest of the cache TTL.
		return [
			activeProvider,
			identity?.accountId ?? "",
			identity?.email ?? "",
			identity?.projectId ?? "",
			identity?.orgId ?? "",
			// Credential-scoped identities (API-key accounts) invalidate by row
			// id: rotation to a sibling account must drop the old account's
			// cached usage instead of showing it for the rest of the TTL.
			identity?.credentialId ?? "",
		].join("\0");
	}

	#getUsageContextKey(session: TSession): string {
		const activeProvider = session.state.model?.provider ?? session.model?.provider;
		const identity = activeProvider ? this.host.activeAccount(session, activeProvider) : undefined;
		// Model id is part of the invalidation key (but not the account-scoped
		// fireworks key): normalized usage now selects a model-scoped window group,
		// so switching models must drop the previous model's cached scope instead
		// of showing it for the rest of the TTL.
		const activeModelId = session.state.model?.id ?? session.model?.id ?? "";
		return `${this.#formatUsageContextKey(activeProvider, identity)}\0${activeModelId}`;
	}

	/**
	 * Startup redraws only arm a short-delayed task; timeout releases the render
	 * cadence while a late successful fetch can still refresh the cached segment.
	 */
	refreshUsageInBackground(): void {
		if (this.#disposed) return;
		const now = Date.now();
		const session = this.session;
		const usageContextKey = this.#getUsageContextKey(session);
		if (this.#cachedUsageContextKey !== usageContextKey) {
			this.#cachedUsage = null;
			this.#usageFetchedAt = 0;
			this.#cachedUsageContextKey = usageContextKey;
		}
		if (this.#usageInFlight || this.#usageStartTimer) return;
		if (this.#usageFetchedAt > 0 && now - this.#usageFetchedAt < 5 * 60_000) return;
		if (!this.host.canFetchUsageReports(session)) return;
		this.#usageInFlight = true;
		this.#usageStartTimer = setTimeout(() => {
			this.#usageStartTimer = null;
			void this.#runUsageRefresh(session);
		}, STATUS_USAGE_START_DELAY_MS);
	}

	async #runUsageRefresh(session: TSession): Promise<void> {
		if (this.#disposed || this.session !== session) {
			this.#usageInFlight = false;
			return;
		}
		const sequence = ++this.#usageRefreshSequence;
		const signal = AbortSignal.timeout(STATUS_USAGE_REFRESH_TIMEOUT_MS);
		let reportsPromise: Promise<unknown> | undefined;
		try {
			reportsPromise = this.host.fetchUsageReports(session, signal);
			this.#applyUsageRefreshReports(
				session,
				await this.#raceUsageRefreshWithSignal(reportsPromise, signal),
				sequence,
			);
		} catch {
			if (this.session !== session) return;
			this.#usageFetchedAt = Date.now();
			if (signal.aborted && reportsPromise) {
				this.#observeLateUsageRefresh(session, reportsPromise, sequence);
			}
		} finally {
			if (this.session === session) this.#usageInFlight = false;
		}
	}

	#applyUsageRefreshReports(session: TSession, reports: unknown, sequence: number): void {
		if (this.#disposed || this.session !== session || sequence < this.#latestAppliedUsageRefreshSequence) {
			return;
		}
		this.#latestAppliedUsageRefreshSequence = sequence;
		const activeProvider = session.state.model?.provider ?? session.model?.provider;
		const activeModelId = session.state.model?.id ?? session.model?.id;
		const activeIdentity = activeProvider ? this.host.activeAccount(session, activeProvider) : undefined;
		const normalized = this.#normalizeUsageReports(reports, {
			provider: activeProvider,
			modelId: activeModelId,
			identity: activeIdentity,
		});
		const resetSnapshot =
			activeProvider === "openai-codex" ? this.#normalizeCodexResetSnapshot(reports, activeIdentity) : null;
		const usageChanged = this.#cachedUsage !== normalized;
		this.#cachedUsage = normalized;
		this.#usageFetchedAt = Date.now();
		// Usage fetch is async; without a repaint the top border stays blank until
		// some unrelated event (git resolve, keystroke, …) rebuilds it.
		if (usageChanged) {
			this.#invalidateStatusLineRenderCache();
			this.#onBranchChange?.();
		}
		this.#noticeResetExpiry(session, reports);
		if (!resetSnapshot) return;
		const contextKey = this.#formatUsageContextKey(activeProvider, activeIdentity);
		const previous = this.#codexResetSnapshots.get(contextKey);
		this.#codexResetSnapshots.set(contextKey, resetSnapshot);
		if (!previous || !this.host.codexResetFireworksEnabled()) return;
		const event = detectCodexResetFireworks(previous, resetSnapshot);
		if (event) this.#onCodexResetFireworks?.(event);
	}

	#noticeResetExpiry(session: TSession, reports: unknown): void {
		// A focused subagent's view is not a conversation the user started; leave the warning for their own.
		if (
			this.#focusedAgentId !== undefined ||
			!this.#onResetExpiryNotice ||
			!this.host.resetExpiryNotice ||
			!Array.isArray(reports)
		) {
			return;
		}
		// fetchUsageReports supplies normalized rows; keep only entries shaped like reports.
		const usageReports = reports.filter(
			(report): report is UsageReport =>
				!!report &&
				typeof report === "object" &&
				"provider" in report &&
				"limits" in report &&
				Array.isArray(report.limits),
		);
		const notice = this.host.resetExpiryNotice(session, usageReports, Date.now());
		if (notice) this.#onResetExpiryNotice(notice);
	}

	#observeLateUsageRefresh(session: TSession, reportsPromise: Promise<unknown>, sequence: number): void {
		void reportsPromise
			.then(reports => {
				this.#applyUsageRefreshReports(session, reports, sequence);
			})
			.catch(() => {
				if (this.#disposed || this.session !== session || sequence < this.#latestAppliedUsageRefreshSequence) {
					return;
				}
				this.#usageFetchedAt = Date.now();
			});
	}

	async #raceUsageRefreshWithSignal(promise: Promise<unknown>, signal: AbortSignal): Promise<unknown> {
		if (signal.aborted) throw signal.reason;
		const aborted = Promise.withResolvers<never>();
		const onAbort = () => aborted.reject(signal.reason);
		signal.addEventListener("abort", onAbort, { once: true });
		try {
			return await Promise.race([promise, aborted.promise]);
		} finally {
			signal.removeEventListener("abort", onAbort);
		}
	}

	#normalizeCodexResetSnapshot(
		reports: unknown,
		activeIdentity: OAuthAccountIdentity | undefined,
	): CodexResetUsageSnapshot | null {
		if (!Array.isArray(reports)) return null;
		let matchingReport: UsageReport | undefined;
		for (const report of reports) {
			if (!report || typeof report !== "object") continue;
			if (
				!("provider" in report) ||
				report.provider !== "openai-codex" ||
				!("limits" in report) ||
				!Array.isArray(report.limits)
			) {
				continue;
			}
			// The report boundary above validates the fields this extractor iterates;
			// optional metadata and credit fields are narrowed again before use.
			const usageReport = report as UsageReport;
			if (!reportMatchesExactIdentity(usageReport, activeIdentity)) continue;
			matchingReport = usageReport;
			break;
		}
		if (!matchingReport) return null;

		const plan =
			typeof matchingReport.metadata?.planType === "string" && matchingReport.metadata.planType
				? matchingReport.metadata.planType
				: undefined;
		let sevenDay: CodexResetUsageSnapshot["sevenDay"];
		let sevenDayTier: string | undefined;
		for (const limit of matchingReport.limits) {
			if (!limit || typeof limit !== "object") continue;
			const candidate = limit as {
				scope?: { windowId?: string; tier?: string };
				window?: { resetsAt?: number };
				amount?: { usedFraction?: number };
			};
			const fraction = candidate.amount?.usedFraction;
			if (candidate.scope?.windowId !== "7d" || typeof fraction !== "number" || !Number.isFinite(fraction)) {
				continue;
			}
			const tier =
				typeof candidate.scope?.tier === "string" && candidate.scope.tier ? candidate.scope.tier : undefined;
			if (sevenDay && (sevenDayTier === undefined || tier)) continue;
			const resetsAt = candidate.window?.resetsAt;
			sevenDay = {
				percent: fraction * 100,
				resetsAt: typeof resetsAt === "number" && Number.isFinite(resetsAt) ? resetsAt : undefined,
				tier,
				plan,
			};
			sevenDayTier = tier;
		}

		const fetchedAt = matchingReport.fetchedAt;
		const availableCount = matchingReport.resetCredits?.availableCount;
		const observedAt = typeof fetchedAt === "number" && Number.isFinite(fetchedAt) ? fetchedAt : undefined;
		const savedResets =
			typeof availableCount === "number" && Number.isFinite(availableCount)
				? Math.max(0, Math.trunc(availableCount))
				: undefined;
		if (!sevenDay && savedResets === undefined) return null;
		return { observedAt, sevenDay, savedResets };
	}

	#normalizeUsageReports(
		reports: unknown,
		context: { provider?: string; modelId?: string; identity?: OAuthAccountIdentity },
	): {
		tier?: string;
		fiveHour?: { percent: number; resetMinutes?: number };
		daily?: { percent: number; resetMinutes?: number };
		sevenDay?: { percent: number; resetHours?: number };
		monthly?: { percent: number; resetHours?: number };
		resetCredits?: {
			bankedCount: number;
			redeemableCount: number;
			expiryHours?: number;
			expired?: boolean;
			unavailableReason?: string;
			expiring?: StatusResetExpiry;
		};
	} | null {
		if (!Array.isArray(reports)) return null;
		const now = Date.now();
		const resetReports: UsageReport[] = [];
		const activeModelId = normalizeUsageScopeValue(context.modelId);
		const activeAntigravityCounter =
			context.provider === "google-antigravity" ? getAntigravityCounterKeyForModel(context.modelId) : undefined;
		const monthlySubscriptionProvider =
			context.provider !== undefined && MONTHLY_SUBSCRIPTION_PROVIDERS[context.provider] === true;
		const scopeGroups = new Map<string, UsageScopeGroup>();
		for (const report of reports) {
			if (!report || typeof report !== "object") continue;
			const provider = "provider" in report ? report.provider : undefined;
			if (context.provider && provider !== context.provider) continue;
			const reportLimits = "limits" in report ? report.limits : undefined;
			if (!Array.isArray(reportLimits)) continue;
			// fetchUsageReports supplies normalized rows; the guards above protect
			// the unknown session boundary before the account matcher reads metadata.
			const usageReport = report as UsageReport;
			if (
				usageReport.resetCredits &&
				(!context.identity || reportMatchesExactIdentity(usageReport, context.identity))
			) {
				resetReports.push(usageReport);
			}
			const limits =
				provider === "google-antigravity" && activeAntigravityCounter
					? scopeAntigravityLimitsForModel(usageReport, context)
					: reportLimits;
			for (const limit of limits) {
				if (
					!limit ||
					typeof limit !== "object" ||
					!("scope" in limit) ||
					!limit.scope ||
					typeof limit.scope !== "object" ||
					!("amount" in limit) ||
					!limit.amount ||
					typeof limit.amount !== "object"
				) {
					continue;
				}
				const scope = limit.scope;
				const amount = limit.amount;
				// The matcher only reads scope identity fields, whose object boundary
				// is validated above; other required UsageLimit fields are irrelevant.
				const usageLimit = limit as UsageLimit;
				if (context.identity && !this.host.limitMatchesActiveAccount(usageReport, usageLimit, context.identity))
					continue;

				const fraction = "usedFraction" in amount ? amount.usedFraction : undefined;
				if (typeof fraction !== "number") continue;
				const window =
					"window" in limit && limit.window && typeof limit.window === "object" ? limit.window : undefined;
				const windowId = "windowId" in scope ? scope.windowId : undefined;
				const durationValue = window && "durationMs" in window ? window.durationMs : undefined;
				const durationMs = typeof durationValue === "number" ? durationValue : undefined;
				const subscriptionWindow =
					windowId === "5h" || windowId === "7d"
						? windowId
						: windowId === "daily" || windowId === "24h" || windowId === "1d"
							? "daily"
							: durationMs !== undefined && Math.abs(durationMs - 5 * 3_600_000) <= 60_000
								? "5h"
								: durationMs !== undefined && Math.abs(durationMs - 86_400_000) <= 60_000
									? "daily"
									: durationMs !== undefined && Math.abs(durationMs - 7 * 86_400_000) <= 60_000
										? "7d"
										: undefined;
				const windowClass =
					subscriptionWindow ??
					(monthlySubscriptionProvider && (windowId === "monthly" || windowId === "30d") ? "monthly" : undefined);
				if (!windowClass) continue;

				const modelId = normalizeUsageScopeValue("modelId" in scope ? scope.modelId : undefined);
				if (modelId && modelId !== activeModelId) continue;
				const rawTier = "tier" in scope ? scope.tier : undefined;
				const rawPlanType = usageReport.metadata?.planType;
				// Scoped tiers (Claude Fable, Codex Spark) win; plan-wide tiers
				// (Z.AI `pro`, Codex `pro`) label otherwise-untiered windows.
				const tier =
					(typeof rawTier === "string" && rawTier.trim() ? rawTier.trim() : undefined) ??
					(typeof rawPlanType === "string" && rawPlanType.trim() ? rawPlanType.trim() : undefined);
				const normalizedTier = normalizeUsageScopeValue(tier);
				const scopeKey = `${modelId ?? ""}\0${normalizedTier ?? ""}`;
				// Exact-model groups outrank provider-wide groups; within either
				// specificity, untiered limits preserve the historical preference.
				const priority = modelId ? (normalizedTier ? 1 : 0) : normalizedTier ? 3 : 2;
				const id = "id" in limit && typeof limit.id === "string" ? limit.id : undefined;
				const resetValue = window && "resetsAt" in window ? window.resetsAt : undefined;
				const displayCandidate: UsageWindowCandidate = {
					id,
					windowClass,
					fraction,
					resetsAt: typeof resetValue === "number" ? resetValue : undefined,
				};
				const group = scopeGroups.get(scopeKey);
				if (group) {
					group.candidates.push(displayCandidate);
				} else {
					scopeGroups.set(scopeKey, { priority, tier, candidates: [displayCandidate] });
				}
			}
		}

		let selectedGroup: UsageScopeGroup | undefined;
		for (const group of scopeGroups.values()) {
			if (!selectedGroup || group.priority < selectedGroup.priority) selectedGroup = group;
		}
		const resetReport =
			resetReports.length === 1
				? resetReports[0]
				: context.identity
					? resetReports.find(report => reportMatchesExactIdentity(report, context.identity))
					: undefined;
		const resetSummary = summarizeUsageResetCredits(resetReport?.resetCredits, now);
		const expiring =
			resetSummary && resetSummary.bankedCount > 0 && resetReport
				? this.host.classifyResetExpiry?.(resetReport, now)
				: undefined;
		// The highlighted countdown is the warned reset's, not an earlier one that is not worth warning about.
		const resetExpiryMs = expiring
			? expiring.expiresAtMs - now
			: resetSummary?.soonestExpiry
				? Date.parse(resetSummary.soonestExpiry) - now
				: undefined;
		const resetCredits =
			resetSummary && resetSummary.bankedCount > 0
				? {
						bankedCount: resetSummary.bankedCount,
						redeemableCount: resetSummary.redeemableCount,
						expiryHours:
							resetExpiryMs !== undefined && resetExpiryMs > 0
								? Math.max(1, Math.ceil(resetExpiryMs / 3_600_000))
								: undefined,
						expired: resetExpiryMs !== undefined && resetExpiryMs <= 0,
						unavailableReason: resetSummary.unavailableReason,
						expiring,
					}
				: undefined;
		if (!selectedGroup) return resetCredits ? { resetCredits } : null;

		let fiveHour: { percent: number; resetMinutes?: number } | undefined;
		let daily: { percent: number; resetMinutes?: number } | undefined;
		let sevenDay: { percent: number; resetHours?: number } | undefined;
		let monthly: { percent: number; resetHours?: number } | undefined;
		let monthlyPriority = Number.POSITIVE_INFINITY;
		const cursorMonthlyPriority = (limitId: unknown): number => {
			// When /auth/usage and /api/usage-summary are merged, prefer the personal
			// dashboard rails over legacy per-model request fractions.
			if (limitId === "cursor:usd:individual-auto") return 0;
			if (limitId === "cursor:usd:individual-plan" || limitId === "cursor:usd:individual-overall") return 1;
			if (typeof limitId === "string" && limitId.startsWith("cursor:usd:individual-")) return 2;
			return 3;
		};
		for (const candidate of selectedGroup.candidates) {
			if (candidate.windowClass === "5h" && !fiveHour) {
				fiveHour = {
					percent: candidate.fraction * 100,
					resetMinutes:
						typeof candidate.resetsAt === "number"
							? Math.max(0, Math.round((candidate.resetsAt - now) / 60_000))
							: undefined,
				};
			}
			if (candidate.windowClass === "daily" && !daily) {
				daily = {
					percent: candidate.fraction * 100,
					resetMinutes:
						typeof candidate.resetsAt === "number"
							? Math.max(0, Math.round((candidate.resetsAt - now) / 60_000))
							: undefined,
				};
			}
			if (candidate.windowClass === "7d" && !sevenDay) {
				sevenDay = {
					percent: candidate.fraction * 100,
					resetHours:
						typeof candidate.resetsAt === "number"
							? Math.max(0, Math.round((candidate.resetsAt - now) / 3_600_000))
							: undefined,
				};
			}
			if (candidate.windowClass === "monthly") {
				const priority = cursorMonthlyPriority(candidate.id);
				if (priority < monthlyPriority) {
					monthly = {
						percent: candidate.fraction * 100,
						resetHours:
							typeof candidate.resetsAt === "number"
								? Math.max(0, Math.round((candidate.resetsAt - now) / 3_600_000))
								: undefined,
					};
					monthlyPriority = priority;
				}
			}
		}
		if (!fiveHour && !daily && !sevenDay && !monthly && !resetCredits) return null;
		return { tier: selectedGroup.tier, fiveHour, daily, sevenDay, monthly, resetCredits };
	}

	/**
	 * Used-tokens / context-window totals for the status-line context% segment,
	 * memoized so the per-event redraw stays O(1) when nothing changed.
	 *
	 * The numerator comes from `session.getContextUsage()`, which anchors on the
	 * last assistant's real prompt-token count — so the bar matches the provider
	 * and the `/context` panel — and reports `null` while that count is unknown
	 * (right after compaction, before the next response). Exposed (non-private)
	 * for unit tests and the collab host's state broadcast.
	 */
	getCachedContextBreakdown(): { usedTokens: number; contextWindow: number } {
		const messages = this.session.messages ?? EMPTY_MESSAGES;
		const modelContextWindow = this.session.model?.contextWindow ?? 0;
		const toolSchemasInContext = this.session.model?.toolSchemasInContext !== false;
		const length = messages.length;
		const lastFingerprint = length > 0 ? messageFingerprint(messages[length - 1]!) : undefined;
		// Bumps when the in-flight pending snapshot is set/cleared. Without it a
		// value computed mid-turn (estimate of the active tail) would survive after
		// the turn ends/aborts, since clearing the snapshot touches no message.
		const contextUsageRevision = this.session.contextUsageRevision ?? 0;

		const systemPrompt = this.session.systemPrompt;
		const tools = this.session.agent?.state?.tools;
		const toolSchemaMetadataRevision = tools ? getToolSchemaMetadataRevision(tools) : 0;
		const settingsRevision = this.host.getSessionSettingsRevision(this.session);
		const tokenizer = this.session.agent?.tokenizer;
		const skills = this.session.skills;

		const cache = this.#contextUsageCache;
		if (
			cache &&
			cache.messagesRef === messages &&
			cache.length === length &&
			cache.lastFingerprint === lastFingerprint &&
			cache.modelContextWindow === modelContextWindow &&
			cache.toolSchemasInContext === toolSchemasInContext &&
			cache.contextUsageRevision === contextUsageRevision &&
			cache.systemPromptRef === systemPrompt &&
			cache.toolsRef === tools &&
			cache.toolSchemaMetadataRevision === toolSchemaMetadataRevision &&
			cache.settingsRevision === settingsRevision &&
			cache.tokenizerRef === tokenizer &&
			cache.skillsRef === skills
		) {
			return { usedTokens: cache.usedTokens, contextWindow: cache.contextWindow };
		}

		const usage = typeof this.session.getContextUsage === "function" ? this.session.getContextUsage() : undefined;
		const usedTokens = usage?.tokens ?? 0;
		const contextWindow = usage?.contextWindow ?? modelContextWindow;
		this.#contextUsageCache = {
			percentUnknown: usage?.percent === null,
			messagesRef: messages,
			length,
			lastFingerprint,
			modelContextWindow,
			toolSchemasInContext,
			contextUsageRevision,
			toolSchemaMetadataRevision,
			settingsRevision,
			tokenizerRef: tokenizer,
			usedTokens,
			contextWindow,
			systemPromptRef: systemPrompt,
			toolsRef: tools,
			skillsRef: skills,
		};
		return { usedTokens, contextWindow };
	}

	#buildSegmentContext(
		width: number,
		segmentOptions: StatusLineSettings["segmentOptions"],
		includePath: boolean,
		includeGit: boolean,
		includePr: boolean,
		nowMs: number,
		previewTitle?: string,
	): SegmentContext {
		const state = this.session.state;

		// Trigger background fetch (5-min TTL); render uses cached value
		this.refreshUsageInBackground();

		// Get usage statistics
		const aggregateUsageStats = this.session.sessionManager?.getUsageStatistics() ?? {
			input: 0,
			output: 0,
			cacheRead: 0,
			cacheWrite: 0,
			totalTokens: 0,
			orchestrationInput: 0,
			orchestrationOutput: 0,
			orchestrationCacheRead: 0,
			premiumRequests: 0,
			cost: 0,
		};
		const usageStats = {
			...aggregateUsageStats,
			tokensPerSecond: this.#getTokensPerSecond(),
		};

		let contextWindow = state.model?.contextWindow ?? this.session.model?.contextWindow ?? 0;
		const breakdown = this.getCachedContextBreakdown();
		let contextTokens = breakdown.usedTokens;
		contextWindow = breakdown.contextWindow || contextWindow;
		let contextPercent: number | null =
			contextWindow > 0 && !this.#contextUsageCache?.percentUnknown
				? (breakdown.usedTokens / contextWindow) * 100
				: null;
		// Collab guest: context comes from the host's state frames — the local
		// replica does no accounting of its own.
		const collabState = this.#collabStatus?.stateOverride;
		if (collabState?.contextUsage) {
			contextWindow = collabState.contextUsage.contextWindow || contextWindow;
			contextTokens = collabState.contextUsage.tokens ?? contextTokens;
			contextPercent = collabState.contextUsage.percent ?? contextPercent;
		}

		const shouldResolveActiveRepo = this.#gitEnabled() && (includePath || includeGit || includePr);
		const projectDir = getProjectDir();
		const activeRepoCache = shouldResolveActiveRepo
			? this.#resolveActiveRepoCache()
			: {
					projectDir,
					activeRepo: null,
					effectiveGitCwd: projectDir,
					repository: null,
					displayRepository: null,
					displayRepositoryCheckedAt: Date.now(),
					repositoryCheckedAt: Date.now(),
					worktree: null,
				};
		const gitBranch = includeGit || includePr ? this.#getBranchLabel(activeRepoCache) : null;
		const gitStatus = includeGit ? this.#getStatus(activeRepoCache) : null;
		const gitPr = includePr ? this.#lookupPr(activeRepoCache) : null;
		const compactionSpeculation = this.session.compactionSpeculation ?? "idle";
		this.#syncSpeculationBlink(compactionSpeculation);
		const settings = this.#resolveSettings();
		const sessionAccentEnabled = settings.sessionAccent !== false;
		const brandVisible = settings.leftSegments.includes("pi") || settings.rightSegments.includes("pi");
		const turnElapsedMs = this.getTurnElapsedMs();
		const promptCache =
			settings.leftSegments.includes("cache") || settings.rightSegments.includes("cache")
				? this.session.getPromptCacheStatus?.(nowMs, breakdown.usedTokens)
				: undefined;
		this.#syncPromptCacheTimer(promptCache, nowMs);
		return {
			session: this.session,
			focusedAgentId: this.#focusedAgentId,
			sessionAccent: sessionAccentEnabled,
			previewTitle,
			isPinned: this.isSessionPinned(this.session.sessionManager?.getSessionId?.()),
			activeRepo: activeRepoCache.activeRepo,
			width,
			options: segmentOptions ?? {},
			compactThinkingLevel: this.#resolveSettings().compactThinkingLevel ?? false,
			hookStatuses: this.#sortedHookStatuses,
			planMode: this.#planModeStatus,
			loopMode: this.#loopModeStatus,
			prewalk:
				typeof this.session.getPrewalkState === "function" && this.session.getPrewalkState()
					? { enabled: true }
					: null,
			goalMode: this.#goalModeStatus,
			goalStatusInFooter: this.#goalModeStatus ? this.host.goalStatusInFooter(this.session) : false,
			vibeMode: this.#vibeModeStatus,
			vim: this.#vimStatus,
			collab: this.#collabStatus,
			stream: this.#streamStatus,
			recording: this.#recording,
			usageStats,
			contextPercent,
			contextTokens,
			contextWindow,
			autoCompactEnabled: this.#autoCompactEnabled,
			compactionSpeculation,
			speculationBlinkOn: this.#speculationBlinkOn,
			subagentCount: this.#subagentCount,
			// The tree total describes the main session; a focused subagent's
			// view falls back to its own completed task results.
			subagentTreeCost: this.#focusedAgentId ? 0 : this.#subagentTreeCost,
			activeMs: this.getActiveMs(),
			turnElapsedMs,
			awaitingAnswer: this.#awaitingAnswer,
			now: new Date(nowMs),
			brandFgAnsi: this.#brandFgAnsi(turnElapsedMs !== null, sessionAccentEnabled, brandVisible),
			git: {
				branch: gitBranch,
				status: gitStatus,
				pr: gitPr,
			},
			worktree: activeRepoCache.worktree,
			usage: this.#cachedUsage,
			promptCache,
		};
	}

	#resolveSettings(): EffectiveStatusLineSettings {
		if (this.#effectiveSettings === undefined) {
			this.#effectiveSettings = this.#computeEffectiveSettings();
		}
		return this.#effectiveSettings;
	}

	#computeEffectiveSettings(): EffectiveStatusLineSettings {
		const preset = this.#settings.preset ?? "default";
		const presetDef = getPreset(preset);
		const useCustomSegments = preset === "custom";
		const mergedSegmentOptions: StatusLineSettings["segmentOptions"] = {};

		for (const [segment, options] of Object.entries(presetDef.segmentOptions ?? {})) {
			mergedSegmentOptions[segment as keyof StatusLineSegmentOptions] = { ...(options as Record<string, unknown>) };
		}

		for (const [segment, options] of Object.entries(this.#settings.segmentOptions ?? {})) {
			const current = mergedSegmentOptions[segment as keyof StatusLineSegmentOptions] ?? {};
			mergedSegmentOptions[segment as keyof StatusLineSegmentOptions] = {
				...(current as Record<string, unknown>),
				...(options as Record<string, unknown>),
			};
		}

		const leftSegments = useCustomSegments
			? (this.#settings.leftSegments ?? presetDef.leftSegments)
			: presetDef.leftSegments;
		const rightSegments = useCustomSegments
			? (this.#settings.rightSegments ?? presetDef.rightSegments)
			: presetDef.rightSegments;

		return {
			...this.#settings,
			leftSegments,
			rightSegments,
			separator: this.#settings.separator ?? presetDef.separator,
			segmentOptions: mergedSegmentOptions,
		};
	}

	#subagentBadgeText(): string | undefined {
		if (this.#subagentCount === 0) return undefined;
		return theme.fg("statusLineSubagents", `${theme.icon.agents} ${this.#subagentCount}`);
	}

	/**
	 * Cheap, non-rendering inputs whose mutation can change a segment without
	 * going through this component's setters. This deliberately uses refs,
	 * scalars, and string lengths only: no schema estimation, serialization,
	 * usage aggregation, VCS probing, or segment getters run on a cache hit.
	 * Fills `target` in place so the per-frame probe allocates nothing.
	 */
	#readStatusLineExternalInputs(target: StatusLineExternalInputs): void {
		const state = this.session.state;
		const stateMessages = state.messages ?? EMPTY_MESSAGES;
		const stateLastMessage = stateMessages[stateMessages.length - 1];
		const stateLastMessageContent =
			stateLastMessage && typeof stateLastMessage === "object" && "content" in stateLastMessage
				? stateLastMessage.content
				: undefined;
		const messages = this.session.messages ?? EMPTY_MESSAGES;
		const lastMessage = messages[messages.length - 1];
		const lastMessageView = lastMessage as
			| {
					role?: string;
					timestamp?: number;
					content?: unknown;
					usage?: { totalTokens?: number };
					stopReason?: string;
			  }
			| undefined;
		const content = lastMessageView?.content;
		let lastMessageContentSize = 0;
		let lastMessageBlockCount = 0;
		if (typeof content === "string") {
			lastMessageContentSize = content.length;
		} else if (Array.isArray(content)) {
			lastMessageBlockCount = content.length;
			for (const block of content) {
				if (!block || typeof block !== "object") continue;
				const candidate = block as {
					text?: unknown;
					thinking?: unknown;
					data?: unknown;
					name?: unknown;
					arguments?: unknown;
				};
				if (typeof candidate.text === "string") lastMessageContentSize += candidate.text.length;
				if (typeof candidate.thinking === "string") lastMessageContentSize += candidate.thinking.length;
				if (typeof candidate.data === "string") lastMessageContentSize += candidate.data.length;
				if (typeof candidate.name === "string") lastMessageContentSize += candidate.name.length;
				if (typeof candidate.arguments === "string") lastMessageContentSize += candidate.arguments.length;
			}
		}

		const model = state.model;
		const sessionModel = this.session.model;
		const systemPrompt = this.session.systemPrompt;
		let systemPromptContentSize = 0;
		for (const part of systemPrompt ?? EMPTY_STRING_PARTS) {
			if (typeof part === "string") systemPromptContentSize += part.length;
		}
		const tools = this.session.agent?.state?.tools;
		const skills = this.session.skills;
		target.themeRef = theme;
		target.themeEpoch = getThemeEpoch();
		target.projectDir = getProjectDir();
		target.sessionRef = this.session;
		target.sessionFile = this.session.sessionFile;
		target.sessionSettingsRef = this.host.getSessionSettingsIdentity(this.session);
		target.sessionSettingsRevision = this.host.getSessionSettingsRevision(this.session);
		target.globalSettingsRevision = this.host.getSettingsRevision();
		target.stateRef = state;
		target.stateMessagesRef = stateMessages;
		target.stateMessagesLength = stateMessages.length;
		target.stateLastMessageRef = stateLastMessage;
		target.stateLastMessageContentRef = stateLastMessageContent;
		target.messagesRef = messages;
		target.messagesLength = messages.length;
		target.lastMessageRef = lastMessage;
		target.lastMessageRole = lastMessageView?.role;
		target.lastMessageTimestamp = lastMessageView?.timestamp ?? 0;
		target.lastMessageContentSize = lastMessageContentSize;
		target.lastMessageBlockCount = lastMessageBlockCount;
		target.lastMessageUsageTotal = lastMessageView?.usage?.totalTokens ?? 0;
		target.lastMessageStopReason = lastMessageView?.stopReason;
		target.modelRef = model;
		target.sessionModelRef = sessionModel;
		target.sessionModelId = sessionModel?.id;
		target.sessionModelContextWindow = sessionModel?.contextWindow;
		target.modelId = model?.id;
		target.modelName = model?.name;
		target.modelProvider = model?.provider;
		target.modelContextWindow = model?.contextWindow;
		target.modelThinking = model?.thinking;
		target.thinkingLevel = state.thinkingLevel;
		target.modelCostRef = model?.cost;
		target.contextUsageRevision = this.session.contextUsageRevision ?? 0;
		target.systemPromptRef = systemPrompt;
		target.systemPromptLength = systemPrompt?.length ?? 0;
		target.systemPromptContentSize = systemPromptContentSize;
		target.toolsRef = tools;
		target.toolsLength = tools?.length ?? 0;
		target.toolSchemaMetadataRevision = tools ? getToolSchemaMetadataRevision(tools) : 0;
		target.tokenizerRef = this.session.agent?.tokenizer;
		target.skillsRef = skills;
		target.skillsLength = skills?.length ?? 0;
		target.sessionName = this.session.sessionManager?.getSessionName?.();
		target.sessionId = this.session.sessionManager?.getSessionId?.();
		target.isStreaming = this.session.isStreaming;
		target.isAutoThinking = this.session.isAutoThinking;
		target.isFastModeActive =
			typeof this.session.isFastModeActive === "function" ? this.session.isFastModeActive() : false;
		target.anthropicSlowModeLabel =
			typeof this.session.getAnthropicSlowModeLabel === "function"
				? this.session.getAnthropicSlowModeLabel()
				: undefined;
		target.compactionSpeculation = this.session.compactionSpeculation;
		target.jobWidgetRef = this.#latestJobWidget()?.view;
	}

	/** The running job widget that saw data last; the ANSI jobs segment appends its glance. */
	#latestJobWidget(): JobWidgetEntry | undefined {
		const entries = this.session.getRunningJobWidgets?.();
		return entries ? latestJobWidget(entries) : undefined;
	}

	#sameStatusLineExternalInputs(left: StatusLineExternalInputs, right: StatusLineExternalInputs): boolean {
		return (
			left.themeRef === right.themeRef &&
			left.themeEpoch === right.themeEpoch &&
			left.projectDir === right.projectDir &&
			left.sessionRef === right.sessionRef &&
			left.sessionFile === right.sessionFile &&
			left.sessionSettingsRef === right.sessionSettingsRef &&
			left.sessionSettingsRevision === right.sessionSettingsRevision &&
			left.globalSettingsRevision === right.globalSettingsRevision &&
			left.stateRef === right.stateRef &&
			left.stateMessagesRef === right.stateMessagesRef &&
			left.stateMessagesLength === right.stateMessagesLength &&
			left.stateLastMessageRef === right.stateLastMessageRef &&
			left.stateLastMessageContentRef === right.stateLastMessageContentRef &&
			left.messagesRef === right.messagesRef &&
			left.messagesLength === right.messagesLength &&
			left.lastMessageRef === right.lastMessageRef &&
			left.lastMessageRole === right.lastMessageRole &&
			left.lastMessageTimestamp === right.lastMessageTimestamp &&
			left.lastMessageContentSize === right.lastMessageContentSize &&
			left.lastMessageBlockCount === right.lastMessageBlockCount &&
			left.lastMessageUsageTotal === right.lastMessageUsageTotal &&
			left.lastMessageStopReason === right.lastMessageStopReason &&
			left.modelRef === right.modelRef &&
			left.sessionModelRef === right.sessionModelRef &&
			left.sessionModelId === right.sessionModelId &&
			left.sessionModelContextWindow === right.sessionModelContextWindow &&
			left.modelId === right.modelId &&
			left.modelName === right.modelName &&
			left.modelProvider === right.modelProvider &&
			left.modelContextWindow === right.modelContextWindow &&
			left.modelThinking === right.modelThinking &&
			left.thinkingLevel === right.thinkingLevel &&
			left.modelCostRef === right.modelCostRef &&
			left.contextUsageRevision === right.contextUsageRevision &&
			left.systemPromptRef === right.systemPromptRef &&
			left.systemPromptLength === right.systemPromptLength &&
			left.systemPromptContentSize === right.systemPromptContentSize &&
			left.toolsRef === right.toolsRef &&
			left.toolsLength === right.toolsLength &&
			left.toolSchemaMetadataRevision === right.toolSchemaMetadataRevision &&
			left.tokenizerRef === right.tokenizerRef &&
			left.skillsRef === right.skillsRef &&
			left.skillsLength === right.skillsLength &&
			left.sessionName === right.sessionName &&
			left.sessionId === right.sessionId &&
			left.isStreaming === right.isStreaming &&
			left.isAutoThinking === right.isAutoThinking &&
			left.isFastModeActive === right.isFastModeActive &&
			left.anthropicSlowModeLabel === right.anthropicSlowModeLabel &&
			left.compactionSpeculation === right.compactionSpeculation &&
			left.jobWidgetRef === right.jobWidgetRef
		);
	}

	/**
	 * Smallest wall-clock unit that can change a visible configured segment.
	 * A zero tick keeps truly static bars cached indefinitely; animation, clocks,
	 * and countdowns advance only at their own display cadence. VCS refreshes are
	 * deadline-driven ({@link #expireStaleVcsRender}), not ticked.
	 */
	#statusLineClock(nowMs: number, effectiveSettings: EffectiveStatusLineSettings): number {
		const leftSegments = effectiveSettings.leftSegments;
		const rightSegments = effectiveSettings.rightSegments;
		const turnActive = this.#meter().activeStartedAt !== null;
		// The `pi` brand is the only spinner-rate animation: its braille spinner
		// while a turn runs and its color fade across turn edges. While
		// focus-proxied it shows the viewed agent's id instead.
		if (
			(turnActive || this.#brandFade !== null) &&
			this.#focusedAgentId === undefined &&
			(leftSegments.includes("pi") || rightSegments.includes("pi"))
		) {
			// The brand spinner follows the shared clock. With a static spinner the brand's elapsed
			// timer still advances once a second, and a brand fade repaints on its own frame cadence.
			if (spinnerAnimated()) return Math.floor(nowMs / spinnerInterval());
			return this.#brandFade !== null ? Math.floor(nowMs / BRAND_FADE_FRAME_MS) : Math.floor(nowMs / 1_000);
		}
		const includesTime = leftSegments.includes("time") || rightSegments.includes("time");
		if (
			// A running turn also moves readouts that have no invalidation path of
			// their own (background-job badge, live and vibe-worker tok/s): refresh
			// them once a second instead of on the spinner tick.
			turnActive ||
			leftSegments.includes("time_spent") ||
			rightSegments.includes("time_spent") ||
			(this.#loopModeStatus?.limit?.kind === "duration" &&
				(leftSegments.includes("mode") || rightSegments.includes("mode"))) ||
			(includesTime && effectiveSettings.segmentOptions?.time?.showSeconds === true)
		) {
			return Math.floor(nowMs / 1_000);
		}
		if (includesTime) {
			return Math.floor(nowMs / 60_000);
		}
		return 0;
	}

	#buildStatusLine(width: number, layout: StatusLineLayout = "box", previewTitle?: string): CachedStatusLine {
		const effectiveSettings = this.#resolveSettings();
		const externalInputs = this.#externalInputsProbe;
		this.#readStatusLineExternalInputs(externalInputs);
		const nowMs = Date.now();
		this.#expireStaleVcsRender(nowMs);
		const clockTick = this.#statusLineClock(nowMs, effectiveSettings);

		const cached = this.#statusLineRenderCache[layout];
		if (
			cached &&
			cached.availableWidth === width &&
			cached.renderRevision === this.#renderRevision &&
			cached.inputRevision === this.#statusLineInputRevision &&
			cached.previewTitle === previewTitle &&
			this.#sameStatusLineExternalInputs(cached.externalInputs, externalInputs)
		) {
			if (cached.clockTick === clockTick) return cached;
			const followed = this.#followBrandSpinner(cached, clockTick, nowMs);
			if (followed) {
				this.#statusLineRenderCache[layout] = followed;
				return followed;
			}
		}

		// The probe now belongs to the new cache entry; later probes need their own buffer.
		this.#externalInputsProbe = new StatusLineExternalInputs();
		const brand: BrandCapture = {};
		const content = this.#renderStatusLine(width, layout, previewTitle, nowMs, brand);
		const start = brand.part ? content.indexOf(brand.part) : -1;
		const result = {
			content,
			dimmedContent: this.#dimWhileFocusProxied(content),
			width: visibleWidth(content),
			availableWidth: width,
			renderRevision: this.#renderRevision,
			inputRevision: this.#statusLineInputRevision,
			previewTitle,
			externalInputs,
			clockTick,
			builtSecond: Math.floor(nowMs / 1_000),
			brand:
				brand.ctx && brand.part && start >= 0 && content.indexOf(brand.part, start + 1) < 0
					? { ctx: brand.ctx, part: brand.part, start }
					: undefined,
		};
		this.#statusLineRenderCache[layout] = result;
		return result;
	}

	/**
	 * Follow a spinner-rate clock tick by redrawing only the brand segment.
	 * Within one wall-clock second the spinner glyph is the only thing on the
	 * line that moves (time readouts change across seconds, a brand fade
	 * recolors every frame), so a brand part of unchanged width drops into
	 * the cached line at the same place: the layout around it cannot move.
	 * Returns undefined when that does not hold; the caller rebuilds then.
	 */
	#followBrandSpinner(cached: CachedStatusLine, clockTick: number, nowMs: number): CachedStatusLine | undefined {
		const brand = cached.brand;
		if (!brand || this.#brandFade !== null || Math.floor(nowMs / 1_000) !== cached.builtSecond) return undefined;
		const turnElapsedMs = this.getTurnElapsedMs();
		if (turnElapsedMs === null) return undefined;
		const ctx: SegmentContext = { ...brand.ctx, now: new Date(nowMs), turnElapsedMs };
		const rendered = renderSegment("pi", ctx);
		if (!rendered.visible || visibleWidth(rendered.content) !== visibleWidth(brand.part)) return undefined;
		const content =
			cached.content.slice(0, brand.start) +
			rendered.content +
			cached.content.slice(brand.start + brand.part.length);
		return {
			...cached,
			content,
			dimmedContent: this.#dimWhileFocusProxied(content),
			clockTick,
			brand: { ctx: brand.ctx, part: rendered.content, start: brand.start },
		};
	}

	/**
	 * Separator glyphs and cell widths for the plain or styled layouts, measured
	 * once per theme (and style) instead of on every rebuild.
	 */
	#separatorMetrics(plain: boolean, style: StatusLineSeparatorStyle): SeparatorMetrics {
		const themeEpoch = getThemeEpoch();
		const memo = plain ? this.#plainSeparatorMetrics : this.#styledSeparatorMetrics;
		if (memo && memo.themeRef === theme && memo.themeEpoch === themeEpoch && (plain || memo.style === style)) {
			return memo;
		}
		const def = plain ? PLAIN_SEPARATOR : getSeparator(style, theme);
		const metrics: SeparatorMetrics = {
			themeRef: theme,
			themeEpoch,
			style,
			def,
			leftSepWidth: visibleWidth(def.left),
			rightSepWidth: visibleWidth(def.right),
			leftCapWidth: def.endCaps ? visibleWidth(def.endCaps.right) : 0,
			rightCapWidth: def.endCaps ? visibleWidth(def.endCaps.left) : 0,
			bandCapWidth: def.endCaps ? visibleWidth(theme.sep.powerlineCapLeft) : 0,
		};
		if (plain) this.#plainSeparatorMetrics = metrics;
		else this.#styledSeparatorMetrics = metrics;
		return metrics;
	}

	/**
	 * Build the status bar for one of five layouts:
	 * - `box`: powerline groups joined by the context-reactive gauge line
	 *   (embedded in the editor's top border).
	 * - `band`: the box layout opened by a soft flush-left cap, for the band
	 *   composer's frameless full-width top row.
	 * - `plain-full`: no background, no powerline caps, dot separators, gap is
	 *   plain spaces — the standalone bottom bar for pi/borderless composers.
	 * - `plain-left`: left segments only (claude composer; the right group
	 *   lives in the editor's top rule).
	 * - `plain-right`: right segments only (claude composer's top rule).
	 *
	 * `previewTitle` is a stand-in session title for composer previews; the
	 * `session_name` segment renders it when the session is unnamed.
	 */
	#renderStatusLine(
		width: number,
		layout: StatusLineLayout,
		previewTitle: string | undefined,
		nowMs: number,
		brand: BrandCapture,
	): string {
		const effectiveSettings = this.#resolveSettings();
		this.#syncPricingTimer();
		const plain = layout !== "box" && layout !== "band";
		const includePath =
			hasPathSegment(effectiveSettings.leftSegments) || hasPathSegment(effectiveSettings.rightSegments);
		const gitEnabled = this.#gitEnabled();
		const includeGit =
			gitEnabled &&
			(hasGitSegment(effectiveSettings.leftSegments) || hasGitSegment(effectiveSettings.rightSegments));
		const includePr =
			gitEnabled && (hasPrSegment(effectiveSettings.leftSegments) || hasPrSegment(effectiveSettings.rightSegments));
		const ctx = this.#buildSegmentContext(
			width,
			effectiveSettings.segmentOptions,
			includePath,
			includeGit,
			includePr,
			nowMs,
			previewTitle,
		);
		const separators = this.#separatorMetrics(plain, effectiveSettings.separator ?? "powerline-thin");
		const separatorDef = separators.def;

		// `transparent` reuses the empty-string sentinel (`\x1b[49m`) so the bar
		// inherits the terminal's default background, matching custom themes that
		// set `statusLineBg: ""`. Powerline end caps need a contrasting fill to
		// bridge the bar into the surrounding terminal; without one they read as
		// stray glyphs, so the cap renderer drops them when the fill is empty.
		const TRANSPARENT_BG_ANSI = "\x1b[49m";
		const themeBgAnsi = theme.getBgAnsi("statusLineBg");
		// Plain bottom bars drop the background entirely; the claude top-rule
		// chip (`plain-right`) keeps it so the group reads as a chip on the rule.
		const transparentLayout = layout === "plain-full" || layout === "plain-left";
		const bgAnsi = transparentLayout || effectiveSettings.transparent ? TRANSPARENT_BG_ANSI : themeBgAnsi;
		const transparentBg = bgAnsi === TRANSPARENT_BG_ANSI;
		const fgAnsi = theme.getFgAnsi("text");
		const sepAnsi = theme.getFgAnsi("statusLineSep");
		const subagentBadge = this.#subagentBadgeText();

		// Collect visible segment contents
		const leftParts: string[] = [];
		const leftSegIds: StatusLineSegmentId[] = [];
		const leftSegmentIds = layout === "plain-right" ? [] : effectiveSettings.leftSegments;
		for (const segId of leftSegmentIds) {
			if (subagentBadge && segId === "subagents") continue;
			// The band composer relocates the title to the working row's trailer.
			if (layout === "band" && segId === "session_name") continue;
			const rendered = renderSegment(segId, ctx);
			if (rendered.visible && rendered.content) {
				leftParts.push(rendered.content);
				leftSegIds.push(segId);
				if (segId === "pi") {
					brand.ctx = ctx;
					brand.part = rendered.content;
				}
			}
		}

		const rightParts: string[] = [];
		const rightSegIds: StatusLineSegmentId[] = [];
		const rightSegmentIds = layout === "plain-left" ? [] : effectiveSettings.rightSegments;
		for (const segId of rightSegmentIds) {
			if (subagentBadge && segId === "subagents") continue;
			if (layout === "band" && segId === "session_name") continue;
			const rendered = renderSegment(segId, ctx);
			if (rendered.visible && rendered.content) {
				rightParts.push(rendered.content);
				rightSegIds.push(segId);
				if (segId === "pi") {
					brand.ctx = ctx;
					brand.part = rendered.content;
				}
			}
		}

		const embedContext =
			!plain &&
			effectiveSettings.contextLine === "embedded" &&
			ctx.contextWindow > 0 &&
			(hasContextSegment(leftSegIds) || hasContextSegment(rightSegIds)) &&
			(hasNonContextSegment(leftSegIds) || hasNonContextSegment(rightSegIds));
		if (embedContext) {
			removeContextSegments(leftParts, leftSegIds);
			removeContextSegments(rightParts, rightSegIds);
		}

		if (layout !== "plain-left") {
			const runningBackgroundJobs = this.runningBackgroundJobCount();
			if (runningBackgroundJobs > 0) {
				const widget = this.#latestJobWidget();
				const glance = widget ? formatJobWidgetGlance(widget.view, theme, JOBS_SEGMENT_SPARK_CELLS) : "";
				const count = theme.fg("statusLineSubagents", `${theme.icon.job} ${runningBackgroundJobs}`);
				rightParts.unshift(glance ? `${count} ${glance}` : count);
			}
			if (subagentBadge) rightParts.unshift(subagentBadge);
		}
		const topFillWidth = Math.max(0, width);
		// These arrays are local to this render; overflow handling can mutate them.
		const left = leftParts;
		const right = rightParts;
		const leftWidths = left.map(part => visibleWidth(part));
		const rightWidths = right.map(part => visibleWidth(part));

		const leftSepWidth = separators.leftSepWidth;
		const rightSepWidth = separators.rightSepWidth;
		// Transparent mode drops powerline caps (they need a bg fill to bridge),
		// so the width budget excludes them too.
		const capsVisible = separatorDef.endCaps !== undefined && !transparentBg;
		const leftCapWidth = capsVisible ? separators.leftCapWidth : 0;
		const rightCapWidth = capsVisible ? separators.rightCapWidth : 0;
		// The band layout opens flush against the terminal edge with a soft cap
		// (rust omp's status band). Like the other caps it needs an opaque
		// background to bridge, and only powerline separator styles carry caps.
		const bandCap = layout === "band" && capsVisible ? theme.sep.powerlineCapLeft : "";
		const bandCapWidth = bandCap ? separators.bandCapWidth : 0;

		const groupWidth = (widths: number[], capWidth: number, sepWidth: number): number => {
			if (widths.length === 0) return 0;
			const partsWidth = widths.reduce((sum, partWidth) => sum + partWidth, 0);
			const sepTotal = (widths.length - 1) * (sepWidth + 2);
			return partsWidth + sepTotal + 2 + capWidth;
		};

		let leftWidth = groupWidth(leftWidths, leftCapWidth + bandCapWidth, leftSepWidth);
		let rightWidth = groupWidth(rightWidths, rightCapWidth, rightSepWidth);
		// Embedded mode removes the standalone context segment before overflow
		// handling, so the gauge must reserve enough room for both labels. Without
		// this budget a long path/session title can leave a one-cell gap: the
		// context segment is gone, and the gauge silently omits its labels too.
		const embeddedContextWidth = embedContext
			? embeddedContextGaugeMinWidth(ctx.contextPercent, ctx.contextWindow)
			: 0;
		const minimumGapWidth = (): number => {
			if (!embeddedContextWidth) return left.length > 0 && right.length > 0 ? 1 : 0;
			// If the labels cannot coexist with the last surviving segment, fall
			// back to the original one-cell gauge instead of dropping the entire
			// status line. At this width the labels cannot render either way.
			if (left.length + right.length === 1 && leftWidth + rightWidth + embeddedContextWidth > topFillWidth) {
				return 1;
			}
			return embeddedContextWidth;
		};
		const totalWidth = () => leftWidth + rightWidth + minimumGapWidth();

		if (topFillWidth > 0) {
			// Truncate the session-name segment before dropping right segments —
			// the title is the only elastic one on the right, and dropping it
			// wholesale left narrow bars (and the ≤76-col composer previews)
			// without any title.
			const nameSegIdx = rightSegIds.indexOf("session_name");
			if (nameSegIdx >= 0 && totalWidth() > topFillWidth) {
				// Badge/job parts were unshifted ahead of the tracked segment ids.
				const nameIdx = nameSegIdx + (right.length - rightSegIds.length);
				const currentNameVW = rightWidths[nameIdx];
				const minNameVW = 8;
				const shrinkBy = Math.min(Math.max(0, currentNameVW - minNameVW), totalWidth() - topFillWidth);
				if (shrinkBy > 0) {
					right[nameIdx] = truncateToWidth(right[nameIdx], currentNameVW - shrinkBy);
					const nameWidth = visibleWidth(right[nameIdx]);
					rightWidth += nameWidth - currentNameVW;
					rightWidths[nameIdx] = nameWidth;
				}
			}
			while (totalWidth() > topFillWidth && right.length > 0) {
				const removedWidth = rightWidths[right.length - 1];
				right.pop();
				rightWidths.pop();
				rightWidth = right.length > 0 ? rightWidth - removedWidth - rightSepWidth - 2 : 0;
			}
			// Shrink path before dropping left segments — path is the only elastic segment
			const pathIdx = leftSegIds.indexOf("path");
			if (pathIdx >= 0 && totalWidth() > topFillWidth) {
				const overflow = totalWidth() - topFillWidth;
				const currentPathVW = leftWidths[pathIdx];
				const minPathVW = 8; // icon + ellipsis + a few chars
				const shrinkable = currentPathVW - minPathVW;
				if (shrinkable > 0) {
					const shrinkBy = Math.min(shrinkable, overflow);
					const currentMaxLen = ctx.options.path?.maxLength ?? 40;
					let newMaxLen = Math.max(4, Math.min(currentMaxLen, currentPathVW) - shrinkBy);
					const pathCtx = (maxLen: number): SegmentContext => ({
						...ctx,
						options: { ...ctx.options, path: { ...ctx.options.path, maxLength: maxLen } },
					});
					let reRendered = renderSegment("path", pathCtx(newMaxLen));
					if (reRendered.visible && reRendered.content) {
						let pathWidth = visibleWidth(reRendered.content);
						// maxLength governs path text, not icon prefix; iterate to compensate
						for (let i = 0; i < 8; i++) {
							const saved = currentPathVW - pathWidth;
							if (saved >= shrinkBy) break;
							const nextMaxLen = Math.max(4, newMaxLen - (shrinkBy - saved));
							if (nextMaxLen >= newMaxLen) break; // no progress or hit floor
							newMaxLen = nextMaxLen;
							const adjusted = renderSegment("path", pathCtx(newMaxLen));
							if (!adjusted.visible || !adjusted.content) break;
							reRendered = adjusted;
							pathWidth = visibleWidth(adjusted.content);
						}
						left[pathIdx] = reRendered.content;
						leftWidth += pathWidth - currentPathVW;
						leftWidths[pathIdx] = pathWidth;
					}
				}
			}
			const leftOverflowDropIndex = (): number => {
				// Preserve the current working directory as long as possible. The
				// previous right-to-left pop could collapse a normal-width bar to
				// just the model segment, hiding the path before less-critical left
				// segments such as model/mode/collab were removed.
				for (let i = leftSegIds.length - 1; i >= 0; i--) {
					if (leftSegIds[i] !== "path") return i;
				}
				return left.length - 1;
			};

			while (totalWidth() > topFillWidth && left.length > 0) {
				const dropIdx = leftOverflowDropIndex();
				const removedWidth = leftWidths[dropIdx];
				left.splice(dropIdx, 1);
				leftWidths.splice(dropIdx, 1);
				leftSegIds.splice(dropIdx, 1);
				leftWidth = left.length > 0 ? leftWidth - removedWidth - leftSepWidth - 2 : 0;
			}
		}

		const renderGroup = (parts: string[], direction: "left" | "right"): string => {
			if (parts.length === 0) return "";
			const sep = direction === "left" ? separatorDef.left : separatorDef.right;
			const cap =
				separatorDef.endCaps && !transparentBg
					? direction === "left"
						? separatorDef.endCaps.right
						: separatorDef.endCaps.left
					: "";
			const capPrefix = separatorDef.endCaps?.useBgAsFg ? bgAnsi.replace("\x1b[48;", "\x1b[38;") : bgAnsi + sepAnsi;
			const capText = cap ? `${capPrefix}${this.#focusedAgentId ? "\x1b[22m" : ""}${cap}\x1b[0m` : "";
			const openText =
				direction === "left" && bandCap
					? `${capPrefix}${this.#focusedAgentId ? "\x1b[22m" : ""}${bandCap}\x1b[0m`
					: "";

			let content = bgAnsi + fgAnsi;
			content += ` ${parts.join(` ${sepAnsi}${sep}${fgAnsi} `)} `;
			content += "\x1b[0m";

			if (direction === "right") return capText + content;
			return openText + content + capText;
		};

		const leftGroup = renderGroup(left, "left");
		const rightGroup = renderGroup(right, "right");
		if (!leftGroup && !rightGroup) return "";

		if (topFillWidth === 0 || (plain && (left.length === 0 || right.length === 0))) {
			return leftGroup + (leftGroup && rightGroup ? " " : "") + rightGroup;
		}

		const gapWidth = Math.max(1, topFillWidth - leftWidth - rightWidth);
		if (plain) {
			// Standalone composers: no gauge line between the groups, just air.
			return leftGroup + padding(gapWidth) + rightGroup;
		}
		// Box layout: with one group absent (an unnamed session hides
		// `session_name`, emptying the default preset's right group) the gauge
		// runs to the border edge instead of disappearing, so embedded context
		// labels don't fall back to a context chip until the session is titled.
		return leftGroup + this.#buildContextGaugeFill(gapWidth, ctx, effectiveSettings, embedContext) + rightGroup;
	}

	/**
	 * The gauge line bridging the left and right groups in box layout. Driven
	 * by `statusLine.contextLine`:
	 * - `off`: solid accent line (no context feedback).
	 * - `percentage`: used portion in accent, remainder in the border color.
	 * - `annotated` : percentage plus preset-aware markers where
	 *   speculative compaction starts and where auto-compaction fires.
	 * - `embedded` (default): annotated markers plus percentage/window labels absorbed
	 *   from configured context segments.
	 */
	#buildContextGaugeFill(
		gapWidth: number,
		ctx: SegmentContext,
		effectiveSettings: EffectiveStatusLineSettings,
		embedContext: boolean,
	): string {
		const sessionName =
			effectiveSettings.sessionAccent !== false ? this.session.sessionManager?.getSessionName() : undefined;
		const accentHex = sessionName ? getSessionAccentHex(sessionName, theme.sessionAccentInputs) : undefined;
		const usedColor = getSessionAccentAnsi(accentHex) ?? theme.getFgAnsi("borderAccent");
		const horizontal = theme.boxRound.horizontal;
		const mode = effectiveSettings.contextLine ?? "embedded";
		const pct = ctx.contextPercent;
		if (mode === "off" || (pct === null && ctx.contextWindow <= 0)) {
			return `\x1b[49m${usedColor}${horizontal.repeat(gapWidth)}\x1b[39m`;
		}

		// Unknown usage against a known window (startup prepaint) draws the fresh-session
		// gauge: one lit cell and the window label, no percent.
		const clampedPct = pct === null ? 0 : Math.min(100, Math.max(0, pct));
		let percentLabel = "";
		let windowLabel = "";
		let percentStart = -1;
		let windowStart = -1;
		let scaleWidth = gapWidth;
		// >100%: usage anchored past the active window (e.g. model switch to a
		// smaller window). The bar clamps full, but the embedded label breaks
		// past the window label — `──200K─120%` with the percent in error color.
		const percentOverflow = pct !== null && pct > 100;
		if (embedContext) {
			const candidatePercent = pct === null ? "" : formatEmbeddedContextPercent(percentOverflow ? pct : clampedPct);
			const candidateWindow = formatNumber(ctx.contextWindow);
			if (gapWidth >= embeddedContextGaugeMinWidth(pct, ctx.contextWindow)) {
				percentLabel = candidatePercent;
				windowLabel = candidateWindow;
				if (percentOverflow) {
					percentStart = gapWidth - percentLabel.length;
					windowStart = percentStart - 1 - windowLabel.length;
				} else {
					windowStart = gapWidth - windowLabel.length - 1;
				}
				scaleWidth = windowStart;
			}
		}

		// At least one accent cell: a fresh session still shows the session-accent
		// line starting at the left instead of a fully dim bar.
		const usedCount = Math.min(scaleWidth, Math.max(1, Math.round((clampedPct / 100) * scaleWidth)));
		const unusedColor = theme.getFgAnsi("border");

		// Boundary markers are only meaningful when auto-compaction can fire and
		// the line is long enough for the markers to read as positions.
		let speculationIdx = -1;
		let thresholdIdx = -1;
		if ((mode === "annotated" || mode === "embedded") && ctx.autoCompactEnabled && gapWidth >= 8) {
			const boundaries = this.#compactionBoundaries(ctx.contextWindow);
			if (boundaries) {
				const cellFor = (percent: number) =>
					Math.min(scaleWidth - 1, Math.max(0, Math.round((percent / 100) * scaleWidth)));
				thresholdIdx = cellFor(boundaries.thresholdPercent);
				// null = no background speculation will run (async disabled or the
				// first available method is local/instant) — no tick to show.
				if (boundaries.speculationPercent !== null) speculationIdx = cellFor(boundaries.speculationPercent);
				if (speculationIdx === thresholdIdx) speculationIdx = -1; // threshold wins the cell
			}
		}

		if (percentLabel && percentStart < 0) {
			const maxStart = scaleWidth - percentLabel.length - 1;
			const preferredStart = Math.min(maxStart, Math.max(1, usedCount));
			const overlapsBoundary = (start: number): boolean => {
				const end = start + percentLabel.length;
				return (speculationIdx >= start && speculationIdx < end) || (thresholdIdx >= start && thresholdIdx < end);
			};
			for (let distance = 0; distance <= maxStart; distance++) {
				const left = preferredStart - distance;
				if (left >= 1 && !overlapsBoundary(left)) {
					percentStart = left;
					break;
				}
				if (distance === 0) continue;
				const right = preferredStart + distance;
				if (right <= maxStart && !overlapsBoundary(right)) {
					percentStart = right;
					break;
				}
			}
		}

		const speculationGlyph = theme.symbol("context.speculation");
		const thresholdGlyph = theme.symbol("context.compaction");
		const speculationColor = theme.getFgAnsi("muted");
		const overflowColor = theme.getFgAnsi("error");
		const rawAccentHex = accentHex ?? theme.getColorHex("borderAccent");
		let dimmedAccent = this.#dimmedAccentMemo;
		if (dimmedAccent?.sourceHex !== rawAccentHex) {
			dimmedAccent = { sourceHex: rawAccentHex, hex: adjustHsv(rawAccentHex, { s: 0.7, v: 0.75 }) };
			this.#dimmedAccentMemo = dimmedAccent;
		}
		const thresholdColor = getSessionAccentAnsi(dimmedAccent.hex) ?? usedColor;

		// Emit runs, not cells: each stretch of plain rule between markers and
		// labels is one `repeat`, and color escapes change only at run edges.
		// Precedence per cell: percent label > threshold > speculation > window label.
		const percentEnd = percentStart >= 0 ? percentStart + percentLabel.length : -1;
		const windowEnd = windowStart >= 0 ? windowStart + windowLabel.length : -1;
		let out = "\x1b[49m";
		let activeColor = "";
		let i = 0;
		while (i < gapWidth) {
			let color: string;
			let text: string;
			if (i >= percentStart && i < percentEnd) {
				const end = Math.min(percentEnd, gapWidth);
				color = percentOverflow ? overflowColor : usedColor;
				text = percentLabel.slice(i - percentStart, end - percentStart);
				i = end;
			} else if (i === thresholdIdx) {
				color = thresholdColor;
				text = thresholdGlyph;
				i++;
			} else if (i === speculationIdx) {
				color = speculationColor;
				text = speculationGlyph;
				i++;
			} else {
				const inWindow = i >= windowStart && i < windowEnd;
				let end = Math.min(inWindow ? windowEnd : i < usedCount ? usedCount : gapWidth, gapWidth);
				if (percentStart > i && percentStart < end) end = percentStart;
				if (thresholdIdx > i && thresholdIdx < end) end = thresholdIdx;
				if (speculationIdx > i && speculationIdx < end) end = speculationIdx;
				if (!inWindow && windowStart > i && windowStart < end) end = windowStart;
				if (inWindow) {
					color = thresholdColor;
					text = windowLabel.slice(i - windowStart, end - windowStart);
				} else {
					color = i < usedCount ? usedColor : unusedColor;
					text = horizontal.repeat(end - i);
				}
				i = end;
			}
			if (color !== activeColor) {
				out += color;
				activeColor = color;
			}
			out += text;
		}
		return `${out}\x1b[39m`;
	}

	/** Auto-compaction boundary percents, or null when unavailable (disabled, no window). */
	#compactionBoundaries(contextWindow: number): CompactionBoundaries | null {
		const session = this.session;
		const model = session.state?.model ?? session.model;
		const settingsRef = this.host.getSessionSettingsIdentity(session);
		const settingsRevision = this.host.getSessionSettingsRevision(session);
		const globalSettingsRevision = this.host.getSettingsRevision();
		const memo = this.#compactionBoundariesMemo;
		if (
			memo &&
			memo.sessionRef === session &&
			memo.contextWindow === contextWindow &&
			memo.modelRef === model &&
			memo.settingsRef === settingsRef &&
			memo.settingsRevision === settingsRevision &&
			memo.globalSettingsRevision === globalSettingsRevision
		) {
			return memo.boundaries;
		}
		try {
			const boundaries = this.host.computeCompactionBoundaries(session, contextWindow, model);
			this.#compactionBoundariesMemo = {
				sessionRef: session,
				contextWindow,
				modelRef: model,
				settingsRef,
				settingsRevision,
				globalSettingsRevision,
				boundaries,
			};
			return boundaries;
		} catch {
			return null;
		}
	}

	/**
	 * Wire this bar into `editor` for a composer layout: the matching top-border
	 * provider, the autocomplete probe, the standalone bottom-bar placement, and
	 * the native composer's facts. Callers re-run it whenever the composer shape
	 * changes.
	 */
	attachToEditor(
		editor: Pick<Editor, "isAutocompleteActive" | "setTopBorderProvider" | "setTopBorder"> & {
			composerFacts: ComposerFactsSource | undefined;
		},
		style: Pick<ComposerStyle, "statusAttachment" | "bottomBar" | "bottomBarGap">,
	): void {
		editor.composerFacts = this;
		this.setAutocompleteActiveProbe(() => editor.isAutocompleteActive());
		switch (style.statusAttachment) {
			case "top-border":
				editor.setTopBorderProvider(availableWidth => this.getTopBorder(availableWidth));
				break;
			case "top-band":
				editor.setTopBorderProvider(availableWidth => this.getBandTopBorder(availableWidth));
				break;
			case "top-rule-chip":
				editor.setTopBorderProvider(availableWidth => this.getStandaloneTopBorder(availableWidth));
				break;
			case "none":
				editor.setTopBorderProvider(undefined);
				editor.setTopBorder(undefined);
				break;
		}
		this.setComposerStyle(style);
	}

	getTopBorder(width: number, previewTitle?: string): { content: string; width: number; revision: number } {
		const statusLine = this.#buildStatusLine(width, "box", previewTitle);
		return {
			content: statusLine.dimmedContent,
			width: statusLine.width,
			revision: this.#renderRevision,
		};
	}

	/** Flush-left soft-capped powerline band (the band composer's top row). */
	getBandTopBorder(width: number, previewTitle?: string): { content: string; width: number; revision: number } {
		const statusLine = this.#buildStatusLine(width, "band", previewTitle);
		return {
			content: statusLine.dimmedContent,
			width: statusLine.width,
			revision: this.#renderRevision,
		};
	}

	/** Dim the whole bar while focus-proxied. Group/cap terminators emit full
	 * `\x1b[0m` resets that would cancel faint mid-bar, so re-open it after each. */
	#dimWhileFocusProxied(content: string): string {
		if (!this.#focusedAgentId || !content) return content;
		return `\x1b[2m${content.replaceAll("\x1b[0m", "\x1b[0m\x1b[2m")}\x1b[22m`;
	}
	/**
	 * Standalone bar placement derived from the composer style. `bottomBar`
	 * `"full"` renders both groups on the bottom bar (pi/borderless/field/rail);
	 * `"left"` renders just the left group there — the right group attaches to
	 * the editor's top rule via {@link getStandaloneTopBorder} (claude/rule);
	 * `"none"` returns the bar to the box composer's embedded top border.
	 * `bottomBarGap` inserts a blank spacer row above the bar for styles whose
	 * editor has no bottom chrome.
	 */
	setComposerStyle(style: Pick<ComposerStyle, "statusAttachment" | "bottomBar" | "bottomBarGap">): void {
		this.#standalone = style.bottomBar === "none" ? false : style.bottomBar === "left" ? "left-only" : "full";
		this.#topAttachment = style.statusAttachment;
		this.#standaloneGap = style.bottomBarGap;
		this.#syncPricingTimer();
	}

	/** While true, the standalone bar yields its row to the editor's autocomplete menu. */
	setAutocompleteActiveProbe(probe: (() => boolean) | undefined): void {
		this.#autocompleteActiveProbe = probe;
	}

	/** Plain right-group content for the claude composer's top rule. */
	getStandaloneTopBorder(width: number, previewTitle?: string): { content: string; width: number; revision: number } {
		const statusLine = this.#buildStatusLine(width, "plain-right", previewTitle);
		return {
			content: statusLine.dimmedContent,
			width: statusLine.width,
			revision: this.#renderRevision,
		};
	}

	/**
	 * The plain standalone bottom bar through the real segment/gauge pipeline —
	 * `groups` picks which segment groups it carries. Used by the live render
	 * loop and by composer previews (which inject a candidate layout instead of
	 * the active one).
	 */
	renderBottomBar(width: number, groups: "left" | "full", previewTitle?: string): string {
		return this.#buildStatusLine(width, groups === "left" ? "plain-left" : "plain-full", previewTitle).dimmedContent;
	}
	/**
	 * Status bar lines for a composer layout, rendered through the real
	 * pipeline — the single source for the /settings appearance preview.
	 * `style` overrides the layout (candidate composer shape); omitted, the
	 * active layout is used. Ignores the autocomplete probe: previews always
	 * render.
	 */
	getPreviewLines(width: number, style?: Pick<ComposerStyle, "statusAttachment" | "bottomBar">): string[] {
		const attachment = style?.statusAttachment ?? this.#topAttachment;
		const bottomBar =
			style?.bottomBar ?? (this.#standalone === false ? "none" : this.#standalone === "left-only" ? "left" : "full");
		const lines: string[] = [];
		if (attachment === "top-border") {
			const border = this.getTopBorder(width);
			if (border.content) lines.push(border.content);
		} else if (attachment === "top-band") {
			const band = this.getBandTopBorder(width);
			if (band.content) lines.push(band.content);
		} else if (attachment === "top-rule-chip") {
			// Render the chip on its rule exactly as the claude composer does.
			const rule = claudeComposerStyle.renderTop({
				width,
				paddingX: 0,
				borderColor: str => theme.fg("border", str),
				accentColor: str => theme.fg("accent", str),
				surfaceColor: str => theme.bgFill("userMessageBg", theme.fgOnBg("userMessageText", "userMessageBg", str)),
				box: theme.boxRound,
				topBorder: this.getStandaloneTopBorder(width),
			});
			if (rule !== undefined) lines.push(rule);
		}
		if (bottomBar !== "none") {
			const main = this.renderBottomBar(width, bottomBar);
			if (main) lines.push(main);
		}
		return lines;
	}

	/**
	 * The composer's facts on a TSP terminal, which draws no status strip: the
	 * context hairline, the model chip label, the usage text, and every other
	 * configured segment as a `seg` in configured order with its drop priority.
	 * Returns the same object while nothing changed.
	 */
	describeComposerFacts(): ComposerFacts {
		const effectiveSettings = this.#resolveSettings();
		const probe = this.#nativeInputsProbe;
		this.#readStatusLineExternalInputs(probe);
		const nowMs = Date.now();
		this.#expireStaleVcsRender(nowMs);
		const clockTick = this.#nativeClock(nowMs, effectiveSettings);
		const memo = this.#nativeMemo;
		if (
			memo &&
			memo.renderRevision === this.#renderRevision &&
			memo.inputRevision === this.#statusLineInputRevision &&
			memo.clockTick === clockTick &&
			this.#sameStatusLineExternalInputs(memo.externalInputs, probe)
		) {
			return memo.facts;
		}
		this.#nativeInputsProbe = new StatusLineExternalInputs();
		const built = this.#buildComposerFacts(effectiveSettings, nowMs);
		const fingerprint = JSON.stringify(built, withoutAges);
		this.#nativeMemo = {
			facts: memo?.fingerprint === fingerprint ? memo.facts : built,
			fingerprint,
			renderRevision: this.#renderRevision,
			inputRevision: this.#statusLineInputRevision,
			clockTick,
			externalInputs: probe,
		};
		return this.#nativeMemo.facts;
	}

	/**
	 * Native status bar for the /settings appearance preview: a `status` of
	 * `seg`s in configured order, each with its side and a drop priority from
	 * that order, plus hook-status rows.
	 */
	describePreview(): NativeNode {
		return this.#describeStatusLine(this.#resolveSettings(), Date.now());
	}

	/**
	 * Called with the branch's pull request (undefined when there is none) each
	 * time it changes while the composer facts are described; the native tab
	 * title carries it. Looked up only when the `pr` segment is configured.
	 */
	onNativePullRequest: ((pr: StatusLinePullRequest | undefined) => void) | undefined;

	/** The host's handler for clicks on native segments ({@link NATIVE_SEGMENT_ACTIONS}). */
	onNativeAction: ((action: StatusLineNativeAction) => void) | undefined;

	handleNativeEvent(event: NativeUiEvent): void {
		if (event.type !== "action") return;
		for (const key in NATIVE_SEGMENT_ACTIONS) {
			const action = NATIVE_SEGMENT_ACTIONS[key];
			if (action !== event.act) continue;
			this.onNativeAction?.(action);
			return;
		}
	}

	#buildComposerFacts(effectiveSettings: EffectiveStatusLineSettings, nowMs: number): ComposerFacts {
		const { leftSegments, rightSegments } = effectiveSettings;
		const segments = [...leftSegments, ...rightSegments];
		// Tern's pane header shows the path from the pane's cwd; the branch sits by the model chip.
		const gitEnabled = this.#gitEnabled();
		const ctx = this.#buildSegmentContext(
			0,
			effectiveSettings.segmentOptions,
			false,
			gitEnabled && hasGitSegment(segments),
			gitEnabled && hasPrSegment(segments),
			nowMs,
		);
		const pr = ctx.git.pr ?? undefined;
		if (pr?.url !== this.#nativePullRequest?.url || pr?.number !== this.#nativePullRequest?.number) {
			this.#nativePullRequest = pr && { number: pr.number, url: pr.url };
			this.onNativePullRequest?.(this.#nativePullRequest);
		}

		const dim = this.#focusedAgentId !== undefined;
		const facts: NativeNode[] = [];
		const collect = (side: "left" | "right", ids: readonly StatusLineSegmentId[]): void => {
			ids.forEach((id, index) => {
				if (COMPOSER_HOMED_SEGMENTS[id]) return;
				const view = describeSegment(id, ctx);
				if (!view) return;
				const props: TspProps<"seg"> = {
					role: "omp.composer.fact",
					priority:
						(PINNED_NATIVE_SEGMENTS[id] === true ? PINNED_NATIVE_PRIORITY : 0) +
						statusSegmentPriority(side, index, ids.length),
				};
				const action = NATIVE_SEGMENT_ACTIONS[id];
				if (action) props.actions = { click: action };
				if (id === "cache" && ctx.promptCache) Object.assign(props, promptCacheFactProps(ctx.promptCache, nowMs));
				facts.push(describeSeg(id, props, view, dim));
			});
		};
		collect("left", leftSegments);
		collect("right", rightSegments);
		// Hook statuses the `status` segment doesn't already carry trail the configured facts.
		if ((this.#settings.showHookStatus ?? true) && !segments.includes("status")) {
			this.#sortedHookStatuses.forEach((status, index) => {
				const text = sanitizeStatusText(status);
				if (!text) return;
				const props: TspProps<"seg"> = { role: "omp.composer.fact", priority: 0 };
				facts.push(describeSeg(`hook-${index}`, props, { spans: [span(text)] }, dim));
			});
		}

		const pct = ctx.contextPercent;
		const window = ctx.contextWindow;
		const boundaries = ctx.autoCompactEnabled ? this.#compactionBoundaries(window) : null;
		const lines = [
			pct === null ? "Context usage unknown" : `Context ${Math.round(pct)}% used`,
			window > 0 ? `${formatNumber(ctx.contextTokens)} of ${formatNumber(window)} tokens` : "No context window",
		];
		if (boundaries) lines.push(`Auto-compact at ${Math.round(boundaries.thresholdPercent)}%`);
		const speculation = ctx.compactionSpeculation;
		if (speculation === "running") lines.push("Compaction summary in progress");
		else if (speculation === "armed") lines.push("Compaction summary ready");
		// The line spans the whole window: omp's boundary symbols sit where speculation
		// starts and compaction fires, and the share past the speculation point is accent.
		const used = pct === null ? null : Math.min(1, pct / 100);
		const speculationAt =
			boundaries?.speculationPercent == null ? null : Math.min(1, boundaries.speculationPercent / 100);
		const marks: TspMeterMark[] = [];
		if (boundaries) {
			if (speculationAt !== null) {
				const start: TspMeterMark = {
					at: speculationAt,
					icon: "context.speculation",
					title: `Compaction summary starts at ${Math.round(speculationAt * 100)}%`,
				};
				// Lit while a background summary runs or waits armed.
				if (speculation !== "idle") start.tone = "accent";
				marks.push(start);
			}
			marks.push({
				at: Math.min(1, boundaries.thresholdPercent / 100),
				icon: "context.compaction",
				title: `Auto-compact at ${Math.round(boundaries.thresholdPercent)}%`,
			});
		}
		const context = node(
			"meter",
			{
				role: "omp.composer.context",
				value: used,
				style: "bar",
				thresholds: getContextMeterThresholds(window),
				...(used !== null && speculationAt !== null && used > speculationAt
					? { parts: [{ value: speculationAt }, { value: used - speculationAt, token: "accent" }] }
					: {}),
				...(marks.length > 0 ? { marks } : {}),
				...(pct === null ? {} : { label: `${Math.round(pct)}%` }),
				...(window > 0 ? { total: formatNumber(window) } : {}),
				title: lines.join("\n"),
				actions: { click: "status.context" },
			},
			undefined,
			"context",
		);

		// The meter reads the context; the bar's usage is the session's cost.
		const cost =
			describeSegment("cost", ctx)
				?.spans.map(part => part.t)
				.join("") ?? "";
		const usage = node(
			"text",
			{
				role: "omp.composer.usage",
				text: cost,
				wrap: "none",
				...(cost ? { title: `Session cost ${cost}` } : {}),
				actions: { click: "status.cost" },
			},
			undefined,
			"usage",
		);

		// The effort chip carries the thinking level.
		const modelCtx: SegmentContext = {
			...ctx,
			options: { ...ctx.options, model: { ...ctx.options.model, showThinkingLevel: false } },
		};
		return {
			context,
			model: describeSegment("model", modelCtx) ?? { spans: [] },
			extras: node("status", { role: "omp.composer.extras", transparent: true, grow: 1 }, facts, "extras"),
			usage,
		};
	}

	/**
	 * Wall-clock granularity of the native bar. Spinners, turn timers and the
	 * brand fade are terminal-clocked, so only wall-clock text (time, loop
	 * countdowns) advances it; VCS refreshes are deadline-driven
	 * ({@link #expireStaleVcsRender}).
	 */
	#nativeClock(nowMs: number, effectiveSettings: EffectiveStatusLineSettings): number {
		const segments = [...effectiveSettings.leftSegments, ...effectiveSettings.rightSegments];
		const includesTime = segments.includes("time");
		if (
			(this.#loopModeStatus?.limit?.kind === "duration" && segments.includes("mode")) ||
			(includesTime && effectiveSettings.segmentOptions?.time?.showSeconds === true)
		) {
			return Math.floor(nowMs / 1_000);
		}
		if (includesTime) return Math.floor(nowMs / 60_000);
		return 0;
	}

	#describeStatusLine(effectiveSettings: EffectiveStatusLineSettings, nowMs: number): NativeNode {
		const { leftSegments, rightSegments } = effectiveSettings;
		const segments = [...leftSegments, ...rightSegments];
		const gitEnabled = this.#gitEnabled();
		const ctx = this.#buildSegmentContext(
			0,
			effectiveSettings.segmentOptions,
			hasPathSegment(segments),
			gitEnabled && hasGitSegment(segments),
			gitEnabled && hasPrSegment(segments),
			nowMs,
		);
		const dim = this.#focusedAgentId !== undefined;
		const segs: NativeNode[] = [];
		const push = (key: string, side: "left" | "right", priority: number, view: SegmentView): void => {
			const pinned = PINNED_NATIVE_SEGMENTS[key] === true;
			const props: TspProps<"seg"> = {
				role: `omp.status.${key}`,
				side,
				priority: pinned ? PINNED_NATIVE_PRIORITY + priority : priority,
			};
			// The path truncates before anything drops.
			if (key === "path") props.min = { w: "12ch" };
			const action = NATIVE_SEGMENT_ACTIONS[key];
			if (action) props.actions = { click: action };
			segs.push(describeSeg(key, props, view, dim));
		};
		const subagentBadge = this.#subagentCount > 0;
		leftSegments.forEach((id, index) => {
			if (subagentBadge && id === "subagents") return;
			const view = describeSegment(id, ctx);
			if (view) push(id, "left", statusSegmentPriority("left", index, leftSegments.length), view);
		});
		// Live-work badges lead the right group, as in the ANSI bar; they sit on
		// the inner edge, so they drop before any configured segment.
		if (subagentBadge) {
			push("subagent-badge", "right", 0, {
				spans: [{ t: `${this.#subagentCount}`, s: "statusLineSubagents" }],
				icon: "agents",
			});
		}
		const runningBackgroundJobs = this.runningBackgroundJobCount();
		if (runningBackgroundJobs > 0) {
			push("jobs", "right", 0, {
				spans: [{ t: `${runningBackgroundJobs}`, s: "statusLineSubagents" }],
				icon: "job",
			});
		}
		rightSegments.forEach((id, index) => {
			if (subagentBadge && id === "subagents") return;
			const view = describeSegment(id, ctx);
			if (view) push(id, "right", statusSegmentPriority("right", index, rightSegments.length), view);
		});
		const bar = node(
			"status",
			{ role: "omp.status", transparent: effectiveSettings.transparent === true },
			segs,
			"bar",
		);
		const showHooks = this.#settings.showHookStatus ?? true;
		if (!showHooks || this.#sortedHookStatuses.length === 0) return bar;
		return col(
			[
				bar,
				...this.#sortedHookStatuses.map((status, index) =>
					node(
						"text",
						{ text: sanitizeStatusText(status), wrap: "none", role: "omp.status.hook" },
						undefined,
						`hook-${index}`,
					),
				),
			],
			{ role: "omp.status.panel" },
		);
	}

	render(width: number): readonly string[] {
		const lines: string[] = [];
		if (this.#standalone && !this.#autocompleteActiveProbe?.()) {
			const content = this.renderBottomBar(width, this.#standalone === "left-only" ? "left" : "full");
			if (content) {
				if (this.#standaloneGap) lines.push("");
				lines.push(content);
			}
		}
		const showHooks = this.#settings.showHookStatus ?? true;
		if (showHooks && this.#sortedHookStatuses.length > 0) {
			lines.push(...this.#sortedHookStatuses.map(text => truncateToWidth(sanitizeHookStatusText(text), width)));
		}
		return lines;
	}
}
