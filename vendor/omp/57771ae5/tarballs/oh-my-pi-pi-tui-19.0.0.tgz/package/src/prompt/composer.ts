import { getComposerStyle } from "../components/composer/registry";
import { Spacer } from "../components/spacer";
import type { StatusLineComponent } from "../status-line/component";
import { extensionLinkLabels } from "../render/extension-links";
import { LinkHints, type ViewportLink, viewportLinkTargets } from "../render/link-hints";
import type { StatusLineSession } from "../status-line/host";
import { createStartupStatusLine, type StatusLineStartupData, startupComposerState } from "../status-line/startup";
import { isInsideTerminalMultiplexer } from "../terminal-multiplexer";
import { ProcessTerminal, type Terminal } from "../terminal";
import {
	type Component,
	Container,
	type RenderTimer,
	type ResizeScrollbackMode,
	type TerminalFramePlan,
	type TerminalFrameProvider,
	TUI,
	type TUIOptions,
	type ViewportSize,
} from "../tui";
import { wrapLiteralLine } from "../utils";
import type { DescribeContext, NativeChild, NativeSurface, NativeSurfaceProvider } from "../native/node";
import { sameItems } from "../native/memo";
import { postmortem } from "@oh-my-pi/pi-utils";
import { CustomEditor } from "./custom-editor";
import type { WordCompletionMethod } from "./word-completion";
import { type AnimationFrame, TranscriptContainer } from "../chrome/transcript-container";
import { type VersionUpdate, WelcomeComponent } from "./welcome";
import { ensureThemeSync, getEditorTheme, theme } from "../theme/theme";

const DOUBLE_INTERRUPT_MS = 500;
// How long idle chrome must hold its height after a turn before it is treated as permanent.
const IDLE_CHROME_SETTLE_MS = 250;

/** Live settings that affect the composer before and after session adoption. */
export interface ComposerPreferences {
	readonly quiet: boolean;
	readonly composerShape: string;
	readonly showHardwareCursor: boolean;
	readonly maxInlineImages: number;
	readonly resizeScrollback: ResizeScrollbackMode;
	/** Send rows a growing HUD or dialog pushes off screen straight to scrollback instead of holding them back until it shrinks. */
	readonly completeScrollback: boolean;
	readonly imeSafeCursor: boolean;
	readonly autocompleteMaxVisible: number;
	readonly spellingTypoDetection: boolean;
	readonly spellingAutocomplete: WordCompletionMethod;
	readonly spellingAutocorrect: boolean;
}

/** Settings-schema-compatible defaults used when constructing a dependency-free composer. */
export const COMPOSER_DEFAULTS: ComposerPreferences = {
	quiet: false,
	composerShape: "band",
	showHardwareCursor: true,
	maxInlineImages: 8,
	resizeScrollback: "rebuild",
	completeScrollback: false,
	imeSafeCursor: false,
	autocompleteMaxVisible: 10,
	spellingTypoDetection: true,
	spellingAutocomplete: "auto",
	spellingAutocorrect: false,
};

/** Welcome data that can be supplied initially or patched as startup resolves it. */
export interface ComposerWelcomeUpdate {
	readonly version?: string;
	/** Background self-update activity after the version label; `null` clears it. */
	readonly versionUpdate?: VersionUpdate | null;
}

/**
 * Status-bar inputs persisted by the last session. The first frame renders
 * them through a startup {@link StatusLineComponent} at the live width until
 * the session-aware status line attaches.
 */
export interface ComposerStatusCache {
	/** ANSI wrapper of the editor border when persisted (session accent or thinking color). */
	readonly borderColor?: {
		readonly prefix: string;
		readonly suffix: string;
	};
	readonly statusLine: StatusLineStartupData;
}

/** Optional dependencies and initial state for a standalone composer. */
export interface ComposerOptions {
	readonly terminal?: Terminal;
	/** Extra TUI construction options (render scheduler injection for tests and `omp render`). */
	readonly tuiOptions?: TUIOptions;
	readonly preferences?: Partial<ComposerPreferences>;
	readonly welcome?: ComposerWelcomeUpdate;
	readonly status?: ComposerStatusCache;
	readonly exit?: (code: number) => void;
	readonly now?: () => number;
}

/** A native dock root described only on terminals whose `hello` advertises `feature`. */
export interface FeatureDockEntry {
	readonly component: Component;
	readonly feature: string;
}

/** How {@link Composer.setRuntimeChildren} lays out the roots below the transcript. */
export interface RuntimeChildrenOptions {
	/**
	 * Dock order on a TSP terminal (no status strip; the composer carries its
	 * facts): the native dock stacks HUD pills, the working row and queued messages over
	 * the composer in its own order, and may add describe-only roots, also
	 * ones only a terminal with a given feature gets. Defaults to the roots
	 * below the transcript in render order.
	 */
	readonly nativeDock?: readonly (Component | FeatureDockEntry)[];
	/**
	 * Below-transcript containers whose children continue `main` on a TSP
	 * terminal, one block each after the transcript's, instead of riding in the
	 * dock: output on its way into the transcript (shell runs deferred until the
	 * next prompt) reads as its tail, and keeps its block when it moves in.
	 */
	readonly nativeTail?: readonly Container[];
	/**
	 * Below-transcript roots the user opens and closes (the editor surface that
	 * drafts and dialogs swap into, docked reports). Their rows never become
	 * part of the post-run chrome floor, so collapsing them refills the screen.
	 */
	readonly transientChrome?: readonly Component[];
	/**
	 * Transient roots that clear themselves (todo and subagent HUDs, progress).
	 * Their first paint can be their tallest, e.g. a restored todo list on a
	 * resumed session, so unlike {@link transientChrome} it is never treated as
	 * their resting height: their rows start outside the floor, and the rows they
	 * displace are held back for them to clear. One still up once the idle settle
	 * window has passed is billed like any other idle chrome, so the rows it
	 * displaces retire to scrollback instead of staying hidden. Roots listed here
	 * are transient and need not also appear in `transientChrome`.
	 */
	readonly selfClearingChrome?: readonly Component[];
	/**
	 * Roots whose rows are billed at their current height on every frame and
	 * never folded into the floor: the working row, whose height changes with
	 * each run. Their rows always count toward retirement, so finished transcript
	 * rows reach native history as soon as they leave the screen instead of being
	 * clipped above it while the root is taller than the floor. When a root
	 * shrinks, the editor moves up into the rows it gave up. A root listed here
	 * is billed even if it also appears in `transientChrome` or
	 * `selfClearingChrome`.
	 */
	readonly billedChrome?: readonly Component[];
}

/** Controls the first terminal paint for a composer that does not already own the terminal. */
export interface ComposerStartOptions {
	readonly clearScrollback?: boolean;
	readonly playWelcomeIntro?: boolean;
	/**
	 * Paint without owning stdin: the tty keeps cooked-mode echo/editing so
	 * typing stays visible while startup module loading blocks the event loop.
	 * {@link Composer.enableInput} later switches to raw input and replays the
	 * kernel-buffered keystrokes into the editor.
	 */
	readonly deferInput?: boolean;
}

/**
 * Mount slot below the editor: the startup status line, then the session-aware
 * one. ANSI only: a TSP terminal has no status strip, the composer carries the
 * status line's facts ({@link StatusLineComponent.describeComposerFacts}).
 */
class StatusHost implements Component {
	#component: Component | undefined;

	setComponent(component: Component): void {
		this.#component = component;
	}

	render(width: number): readonly string[] {
		return this.#component?.render(width) ?? [];
	}
}

/** One click target's row span within the mutable viewport (half-open `[start, end)`). */
export interface ViewportClickSpan {
	start: number;
	end: number;
	/** Candidate subagent ids for a span-local row. */
	candidates: (local: number) => string[];
}

/**
 * Row-level click target: maps rendered rows to subagent ids. Implemented by
 * the subagent HUD, whose rows are fixed 1:1 with visible sessions.
 */
export interface ViewportClickRowTarget {
	getClickAgentAtRow(row: number): string | undefined;
}

/**
 * Candidates under a mutable-viewport line: the first span containing it.
 * Pure seam for tests; the caller intersects with the live registry, which
 * decides focusability and recency.
 */
export function routeViewportClick(spans: readonly ViewportClickSpan[], index: number): string[] {
	if (!Number.isInteger(index) || index < 0) return [];
	for (const span of spans) {
		if (index < span.start || index >= span.end) continue;
		return span.candidates(index - span.start);
	}
	return [];
}

/**
 * Called once when link-hint mode ends; `reason` is `"crowded"` when a row held more links than
 * their tags could fit side by side, so no tags were drawn.
 */
export type LinkHintsEnd = (reason?: "crowded") => void;

/**
 * Nested background opens inside a hovered row. The band wraps the line, so a
 * surviving nested open would paint over it for every cell it covers; the
 * matching closes stay and become band resumes via bgFill.
 */
const NESTED_BG_OPEN_PATTERN = new RegExp(`${String.fromCharCode(27)}\\[(?:4[0-7]|10[0-7]|48;[0-9;]*)m`, "g");

/**
 * Candidate resolver for a row-level click target, if the component is one.
 * Shared by root and nested-child hit-testing so both stay in lockstep.
 */
function rowTargetCandidates(target: Component): ((local: number) => string[]) | undefined {
	const rowTarget = target as Partial<ViewportClickRowTarget>;
	if (typeof rowTarget.getClickAgentAtRow !== "function") return undefined;
	return (local: number) => {
		const id = rowTarget.getClickAgentAtRow?.(local);
		return id === undefined ? [] : [id];
	};
}

/**
 * Canonical interactive composer, usable before session/settings exist and updatable in place.
 * It owns the terminal, welcome header, and editor; InteractiveMode later supplies authoritative
 * data and mounts the session-aware runtime children without replacing the visible header.
 */
export class Composer implements TerminalFrameProvider, NativeSurfaceProvider {
	readonly ui: TUI;
	#editor: CustomEditor;
	readonly #header = new Container();
	readonly #bootstrapInputGap = new Spacer(1);
	readonly #statusHost = new StatusHost();
	readonly #exit: (code: number) => void;
	readonly #now: () => number;
	#preferences: ComposerPreferences;
	#welcome: WelcomeComponent | undefined;
	#version = "";
	#versionUpdate: VersionUpdate | null = null;
	#headerBefore: readonly Component[] = [];
	#headerAfter: readonly Component[] = [];
	#runtimeChildren: readonly Component[] = [];
	#nativeDock: readonly (Component | FeatureDockEntry)[] | undefined;
	#nativeTail: readonly Container[] = [];
	/** Cache-driven status line shown until {@link setStatusComponent} mounts the session's. */
	#startupStatus: StatusLineComponent | undefined;
	#runtimeMounted = false;
	// Composer-owned history id space. Transcript batch ids restart across
	// container clears/swaps; the composer translates them into one monotonic
	// sequence the terminal's accepted-id watermark can trust.
	#nextHistoryId = 1;
	#offeredHistory:
		| {
				id: number;
				rows: readonly string[];
				kind: "append" | "replay";
				source:
					| "header"
					| {
							transcript: TranscriptContainer;
							transcriptId?: number;
							header: "none" | "replay";
							/** Recomposed header rows to accept as the new retired-header bytes. */
							headerRows?: readonly string[];
					  };
		  }
		| undefined;
	#historyReplayRequested = false;
	#headerReplayPending = false;
	#historyFlush = false;
	// The welcome header retires to terminal history exactly once, after the
	// intro settles; until then it renders as mutable viewport chrome.
	#headerRetired = false;
	// Exact hard rows accepted into native history. Transient resize-alt
	// paints reflow these rows to match the terminal's own rewrap of history
	// it still holds; a settled replay owns every byte it emits, so it
	// recomposes the header at the replay width and refreshes these rows.
	#retiredHeaderRows: readonly string[] | undefined;
	/** Click spans of the last `renderFrame` viewport, in viewport coordinates. */
	#lastClickSpans: ViewportClickSpan[] = [];
	/** Rows of the last `renderFrame` viewport, before the hover band; read to hit-test extension links. */
	#lastViewportRows: readonly string[] = [];
	/** Click-candidate id under the pointer, painted with the hover band. Id-anchored so it follows streaming rows. */
	#hoveredClickId: string | undefined;
	/** Keyboard link-hint mode: its tags (assigned by the first frame after `startLinkHints`) and what to run when it ends. */
	#linkHints: { hints: LinkHints; onEnd: LinkHintsEnd } | undefined;
	/** Width of the last painted viewport, which `#lastViewportRows` was laid out for. */
	#lastViewportWidth = 0;
	// Hard-row prefix currently above the native viewport. The first resize
	// frame may pull part of it down before the normal buffer is borrowed.
	#retiredHeaderStart = 0;
	#resizeRetiredHeaderStart: number | undefined;
	#lastNormalRows = 0;
	// Retirement bills below-transcript chrome at this floor, not its current
	// height. It follows contractions immediately and promotes stable eligible
	// growth only while idle. Transient roots count at their minimum painted
	// height: a growing dialog or draft clips the live tail without committing
	// displaced rows, so those rows refill the screen when it shrinks (#11007).
	// Displaced rows reach history when newer output pushes them past the floor
	// or persistent idle chrome settles and raises it.
	// With `completeScrollback`, rows the chrome pushes off screen go straight
	// to scrollback, and when it shrinks the freed rows stay blank.
	// The floor is terminal-height independent — chrome heights do not scale
	// with rows — so it is retained across resizes rather than rediscovered
	// from whatever chrome is expanded when the height changes.
	#chromeFloor: number | undefined;
	// Settled idle chrome has retired rows; contraction must preserve native history.
	#chromeFloorPromoted = false;
	#runActive = false;
	// Billed-chrome rows the last composition counted toward retirement; see renderFrame.
	#billedChromeRows = 0;
	// Billed chrome shrank and no emitted paint has moved the editor up yet.
	#billedChromeContracted = false;
	#billedChrome: ReadonlySet<Component> = new Set();
	#transientChrome: ReadonlySet<Component> = new Set();
	#selfClearingChrome: ReadonlySet<Component> = new Set();
	// Fewest rows the user-driven transient roots have painted since mount; only rows above it are excluded from the floor.
	#transientFloor: number | undefined;
	// Editor and shape the transient floor was measured under, plus the last frame's transient rows.
	// A shape swap (band → pi) changes the editor's resting height; a minimum carried over from the
	// shorter shape would exclude the taller shape's fixed rows forever and clip that many transcript rows.
	#transientEditor: Component | undefined;
	#transientEditorStyle: string | undefined;
	#lastTransientRows = 0;
	// Fewest rows the bare editor painted before the runtime mounted, and the shape it was painted in.
	// A draft replayed from the startup keystroke buffer can already be present on the first runtime
	// frame, so that frame is not the editor's resting height; this is, because the bootstrap frame
	// paints before replay. Only valid while the shape is unchanged.
	#bootstrapEditorRows: number | undefined;
	#bootstrapEditorStyle: string | undefined;
	// Idle chrome height awaiting the settle window, and whether it has elapsed.
	// Turn-scoped HUDs can close a few frames after the last block finalizes;
	// billing them first would commit rows they cover and strand a band.
	#idleChrome: number | undefined;
	#idleChromeSettled = false;
	#idleChromeTimer: RenderTimer | undefined;
	/** Rows the chrome below each below-transcript root took in the last frame (see {@link rowsBelow}). */
	#rowsBelow = new Map<Component, number>();
	#lastInterruptAt = 0;
	/** Last described surface; its arrays are reused while their children are unchanged. */
	#nativeSurface: NativeSurface = { main: [], dock: [] };
	#started = false;
	#stopped = false;
	#transferred = false;

	constructor(options: ComposerOptions = {}) {
		ensureThemeSync();
		// Host-owned hard exit: route through postmortem so a double-Ctrl-C during
		// an open extension-load guard window exits cleanly instead of throwing
		// ExtensionExitError through the guarded process.exit (#11789).
		this.#exit = options.exit ?? (code => postmortem.exitProcess(code));
		this.#now = options.now ?? Date.now;
		this.#preferences = { ...COMPOSER_DEFAULTS, ...options.preferences };
		this.#applyWelcomeUpdate(options.welcome ?? {});

		this.ui = new TUI(
			options.terminal ?? new ProcessTerminal(),
			this.#preferences.showHardwareCursor,
			options.tuiOptions,
		);
		this.ui.setFrameProvider(this);
		this.ui.setMaxInlineImages(this.#preferences.maxInlineImages);
		this.ui.setResizeScrollback(this.#preferences.resizeScrollback);

		this.#editor = new CustomEditor(getEditorTheme());
		this.editor.disableSubmit = true;
		this.editor.setUseTerminalCursor(this.ui.getShowHardwareCursor());
		this.editor.setImeSafeCursorLayout(this.#preferences.imeSafeCursor);
		this.editor.setAutocompleteMaxVisible(this.#preferences.autocompleteMaxVisible);
		this.editor.setSpellingFeatures({
			typoDetection: this.#preferences.spellingTypoDetection,
			autocomplete: this.#preferences.spellingAutocomplete,
			autocorrect: this.#preferences.spellingAutocorrect,
		});
		try {
			this.editor.setBorderStyle(this.#preferences.composerShape);
		} catch {
			// Extension-defined styles arrive with the session; InteractiveMode reapplies them.
		}
		if (options.status) {
			const { borderColor, statusLine } = options.status;
			if (borderColor) this.editor.borderColor = text => `${borderColor.prefix}${text}${borderColor.suffix}`;
			this.#startupStatus = createStartupStatusLine(statusLine);
			this.#statusHost.setComponent(this.#startupStatus);
			this.#startupStatus.attachToEditor(this.editor, getComposerStyle(this.#preferences.composerShape));
			const state = startupComposerState(statusLine);
			this.editor.composerState = () => state;
		}
		// Emergency controls stay active until InteractiveMode installs configured bindings.
		// They deliberately mirror the interactive editor's contract so a stalled startup
		// never behaves differently from a healthy one: Ctrl+C clears the draft and a second
		// press exits 130 — the unconditional abort, draft or not; Ctrl+D exits 0 on an
		// empty draft and otherwise forward-deletes (see CustomEditor's app.exit handling),
		// so typing while the session loads cannot be lost to a mistyped delete.
		this.editor.setActionKeys("app.clear", ["ctrl+c"]);
		this.editor.setActionKeys("app.exit", ["ctrl+d"]);
		this.editor.onClear = () => this.#handleInterrupt();
		this.editor.onExit = () => this.#requestExit(0);
		this.editor.setShimmerRepaintHandler(() => this.ui.requestComponentRender(this.editor));

		if (!this.#preferences.quiet) this.#ensureWelcome();
		this.#rebuildHeader();
		this.ui.addChild(this.#header);
		this.ui.addChild(this.#bootstrapInputGap);
		this.ui.addChild(this.editor);
		this.ui.addChild(this.#statusHost);
		this.ui.setFocus(this.editor);
		// A settle timer that fires while the TUI is stopped (external editor, suspend) is dropped;
		// forget it on restart so the next frame re-arms instead of waiting on it forever.
		this.ui.addStartListener(() => this.#resetIdleChrome());
	}
	/**
	 * Rows the below-transcript chrome under `root` (editor, status line, …)
	 * took in the last frame, so a root that grows upward can cap itself to
	 * the screen rows left above them; `undefined` before `root` was laid out.
	 */
	rowsBelow(root: Component): number | undefined {
		return this.#rowsBelow.get(root);
	}

	/** Compose the bounded mutable viewport and the next ordered history append. */
	renderFrame(viewport: ViewportSize): TerminalFramePlan {
		if (!this.#started || this.#stopped) return { viewport: [] };
		const width = Math.max(1, viewport.columns);
		const rows = Math.max(0, viewport.rows);
		if (this.#resizeRetiredHeaderStart !== undefined) {
			this.#retiredHeaderStart = this.#resizeRetiredHeaderStart;
			this.#resizeRetiredHeaderStart = undefined;
		}
		this.#lastNormalRows = rows;
		const roots = this.#runtimeMounted
			? [...this.#runtimeChildren, this.#statusHost]
			: [this.#header, this.#bootstrapInputGap, this.editor, this.#statusHost];
		const transcriptIndex = roots.findIndex(root => root instanceof TranscriptContainer);
		if (transcriptIndex < 0) {
			this.#lastClickSpans = [];
			this.#lastViewportRows = [];
			this.#syncLinkHints([], 0);
			const viewport: string[] = [];
			for (const root of roots) {
				const rendered = root.render(width);
				if (!this.#runtimeMounted && root === this.editor) this.#recordBootstrapEditorRows(rendered.length);
				viewport.push(...rendered);
			}
			return { viewport: viewport.slice(-rows) };
		}
		const transcript = roots[transcriptIndex] as TranscriptContainer;
		const preRoots = this.#renderRoots(roots.slice(0, transcriptIndex), width);
		const afterRoots = roots.slice(transcriptIndex + 1);
		const after: string[] = [];
		const afterSpans: ViewportClickSpan[] = [];
		const ends: { root: Component; end: number }[] = [];
		let transientRows = 0;
		let selfClearingRows = 0;
		let billedRows = 0;
		for (const root of afterRoots) {
			const start = after.length;
			this.#renderBelowRoot(root, width, after, afterSpans);
			if (this.#billedChrome.has(root)) billedRows += after.length - start;
			else if (this.#selfClearingChrome.has(root)) selfClearingRows += after.length - start;
			else if (this.#transientChrome.has(root)) transientRows += after.length - start;
			ends.push({ root, end: after.length });
		}
		this.#rowsBelow = new Map(ends.map(({ root, end }) => [root, after.length - end]));
		const transientFloor = this.#syncTransientFloor(transientRows);
		// Billable chrome excludes user-driven transient rows above their resting height and every
		// billed row (those count at their current height below). Eligible chrome also excludes
		// every self-clearing row: those start outside the floor, so the rows a HUD displaces are
		// held back for it to clear. A HUD that is still up once the idle settle window has passed
		// is billed like any other idle chrome (see #rebaselineChromeFloor): held back rows are on
		// no screen and in no scrollback, and a restored todo list or a subagent panel can stay up
		// for the rest of the session.
		const billableChrome = after.length - (transientRows - transientFloor) - billedRows;
		const eligibleChrome = billableChrome - selfClearingRows;
		const promotedChromeContracted = this.#chromeFloorPromoted && billableChrome < (this.#chromeFloor ?? 0);
		// Contraction follows immediately: the floor never exceeds what is billable now, and before a
		// promotion it never exceeds the eligible chrome either.
		const floorCap = this.#chromeFloorPromoted ? billableChrome : eligibleChrome;
		this.#chromeFloor = Math.min(this.#chromeFloor ?? eligibleChrome, floorCap);
		this.#rebaselineChromeFloor(this.#runActive || transcript.hasActiveBlock(), billableChrome);
		// The working row grows and shrinks with every run, so a floor (its
		// smallest height) undercounts it whenever it is taller: retirement would
		// clip that many finished rows off the top of the viewport before they
		// reach native history, a scrolled-back terminal would watch that seam
		// shift on every commit, and the rows would reappear, moving the whole
		// screen, when it shrank. Bill its current rows on every frame instead;
		// when it shrinks, the editor moves up into the rows it gave up, because
		// committed rows cannot come back down. With `completeScrollback` all
		// chrome counts at its current height, the working row included, and a
		// shrink leaves its documented blank rows above the editor instead.
		const completeScrollback = this.#preferences.completeScrollback;
		if (!completeScrollback && billedRows < this.#billedChromeRows) this.#billedChromeContracted = true;
		this.#billedChromeRows = billedRows;
		const belowFloor = completeScrollback ? after.length : this.#chromeFloor + billedRows;
		// Offer history under capacity pressure only: blocks stay live (and keep
		// reflowing to the current width) while the screen has room. A batch
		// leaves the mutable viewport in the same frame it is appended, so its
		// rows are never painted twice.
		const now = performance.now();
		const frame: AnimationFrame = { now, tick: Math.floor(now / 80) };
		// Retirement measures the same live blocks the viewport lays out below;
		// one open frame renders each of them once for both.
		transcript.beginFrame(frame);
		transcript.completeScrollback = this.#preferences.completeScrollback;
		const history = this.#offerHistory(transcript, width, rows, preRoots.length + belowFloor);
		const headerVisible = !this.#headerRetired && this.#offeredHistory?.source !== "header";
		const headerRows = headerVisible ? this.#header.render(width) : [];
		const before = [...headerRows, ...preRoots];
		// The live tail is laid out against the same baseline retirement is
		// billed against, so its compaction allocator (one row per block, no
		// inter-block blanks) engages only when a block genuinely cannot retire.
		// Rows the chrome above its floor displaces are clipped from the top by
		// the `drop` slice below; they stay live until the chrome shrinks. With
		// `completeScrollback` none are held back.
		const active = transcript.renderViewport(width, Math.max(0, rows - before.length - belowFloor), frame);
		const activeSpans: ViewportClickSpan[] = [];
		for (const span of transcript.getLastViewportSpans()) {
			const ids = (span.component as Partial<{ getClickFocusAgentIds(): string[] }>).getClickFocusAgentIds?.();
			if (!ids || ids.length === 0) continue;
			activeSpans.push({ start: span.start, end: span.end, candidates: () => ids });
		}
		const drop = Math.max(0, before.length + active.length + after.length - rows);
		const mutable = [...before, ...active, ...after].slice(drop);
		// Once a paint reaches the bottom row over committed history, rows above
		// it may already be in native scrollback, which no later frame can pull
		// back down. Keep the input on the bottom row whenever the frame shrinks
		// — a closing dialog, report or HUD, or a live block collapsing. The
		// slack that leaves has to sit somewhere: rows above the live area hold
		// committed history still on screen, so the live rows cannot move up into
		// them, and replaying those rows would duplicate them while clearing
		// history would lose them. Replays position themselves. Without native
		// history the live viewport is the whole document and shrinks in place.
		const filledHistoryRows =
			history?.kind === "replay" || !(history !== undefined || this.ui.hasProviderHistory())
				? undefined
				: this.ui.getFilledHistoryRows();
		// Once settled chrome has retired rows, shrinking it cannot pull those
		// rows back out of native scrollback. Let the editor move up instead of
		// inserting a seam band; subsequent frames retain that natural anchor
		// until new output fills the screen again. Shell history stays untouched.
		const fillSlack =
			filledHistoryRows === undefined
				? 0
				: Math.max(0, rows - Math.min(rows, filledHistoryRows + (history?.rows.length ?? 0)) - mutable.length);
		// The TUI can discard a composition (an image-budget retry, a deferred
		// first image paint), so a billed contraction holds until a paint lands
		// where the screen has no slack to fill: the editor moved up, or output
		// filled the rows back in.
		if (fillSlack === 0) this.#billedChromeContracted = false;
		const slack = promotedChromeContracted || this.#billedChromeContracted ? 0 : fillSlack;
		// Park the slack below the live rows rather than above them. Above, it
		// splits the on-screen history from the live tail and reads as a hole
		// punched into whatever was streaming — a table's rows included — and
		// each slack row is written with no cells, so no repaint, mark or
		// selection can cover it until something scrolls it away. Below, the
		// transcript stays contiguous with the history, the slack reads as the
		// empty tail of a short document, and growth consumes it before any row
		// can scroll.
		if (slack > 0) {
			const at = Math.max(0, Math.min(mutable.length, before.length + active.length - drop));
			mutable.splice(at, 0, ...Array<string>(slack).fill(""));
		}
		const viewportLength = mutable.length;
		const spans: ViewportClickSpan[] = [];
		const shift = (span: ViewportClickSpan, base: number): void => {
			const start = span.start + base;
			const end = Math.min(span.end + base, viewportLength);
			const clamped = Math.max(0, start);
			if (end > clamped) {
				// A clipped head must offset the callback: without the skew the
				// first visible row would hit-test as span-local row 0.
				const skew = clamped - start;
				spans.push({ start: clamped, end, candidates: (local: number) => span.candidates(local + skew) });
			}
		};
		for (const span of activeSpans) shift(span, before.length - drop);
		for (const span of afterSpans) shift(span, slack + before.length + active.length - drop);
		this.#lastClickSpans = spans;
		this.#lastViewportRows = mutable;
		this.#lastViewportWidth = width;
		this.#syncLinkHints(mutable, width);
		if (history !== undefined && this.#offeredHistory?.source === "header") {
			const visibleHeaderRows = Math.max(0, rows - (mutable.length + drop));
			this.#retiredHeaderStart = Math.max(0, history.rows.length - visibleHeaderRows);
		}
		const painted = this.#paintHoverBand(mutable, spans);
		return { history, viewport: this.#linkHints?.hints.paint(painted, width) ?? painted };
	}

	/**
	 * Keep link-hint tags on what `rows` show. The first frame after `startLinkHints` tags its
	 * labels; later frames keep the tags while the tagged labels are still drawn first, in the same
	 * order and columns (rows may scroll, links may be added below), and otherwise end the mode, so a
	 * tag never picks a label no longer drawn under it. Every frame ends the mode as `"crowded"` when
	 * some row has more tag cells than `width` (a resize can narrow it), since tags drawn side by
	 * side could not all be read.
	 */
	#syncLinkHints(rows: readonly string[], width: number): void {
		const state = this.#linkHints;
		if (state === undefined) return;
		const kept = state.hints.tagged ? state.hints.follow(rows) : state.hints.assign(rows) > 0;
		if (!kept) this.#endLinkHints();
		else if (state.hints.crowded(width)) this.#endLinkHints("crowded");
	}

	#endLinkHints(reason?: "crowded"): void {
		const state = this.#linkHints;
		if (state === undefined) return;
		this.#linkHints = undefined;
		state.onEnd(reason);
	}

	/**
	 * Describe the whole surface for a TSP terminal. `main` is the flowing
	 * document: the header (welcome, extras) and every transcript block as its
	 * own component child, then the children of the
	 * {@link RuntimeChildrenOptions.nativeTail} roots. `dock` is the live chrome
	 * below the transcript in render order: pending messages, HUDs, the working
	 * row, the editor and the status line. There is no history/viewport split:
	 * retirement, resize replay and hover bands are ANSI concerns.
	 */
	describeSurface(cx: DescribeContext): NativeSurface {
		if (!this.#started || this.#stopped) return this.#nativeSurface;
		const main: NativeChild[] = [...this.#header.children];
		const dock: NativeChild[] = [];
		if (!this.#runtimeMounted) {
			// The bootstrap gap is row spacing; the terminal owns the dock layout.
			dock.push(this.editor);
		} else {
			const roots = this.#runtimeChildren;
			const transcriptIndex = roots.findIndex(root => root instanceof TranscriptContainer);
			if (transcriptIndex < 0) {
				dock.push(...roots);
			} else {
				const transcript = roots[transcriptIndex] as TranscriptContainer;
				main.push(...roots.slice(0, transcriptIndex), ...transcript.nativeBlocks(cx));
				for (const root of this.#nativeTail) main.push(...root.children);
				const tail: readonly Component[] = this.#nativeTail;
				if (this.#nativeDock) {
					for (const entry of this.#nativeDock) {
						if (!("feature" in entry)) dock.push(entry);
						else if (cx.feature(entry.feature)) dock.push(entry.component);
					}
				} else {
					dock.push(...roots.slice(transcriptIndex + 1).filter(root => !tail.includes(root)));
				}
			}
		}
		const previous = this.#nativeSurface;
		const nextMain = sameItems(previous.main, main) ? previous.main : main;
		const nextDock = sameItems(previous.dock, dock) ? previous.dock : dock;
		if (nextMain !== previous.main || nextDock !== previous.dock) {
			this.#nativeSurface = { main: nextMain, dock: nextDock };
		}
		return this.#nativeSurface;
	}

	/**
	 * Append one below-transcript root's rows to `after`, recording click spans
	 * for its row targets in `after` coordinates.
	 *
	 * Row targets usually nest one level down: chrome roots are plain
	 * containers (the HUD lives inside `subagentContainer`), and
	 * `Container.render` is a pure concatenation, so child spans tile the root
	 * span exactly. Render those children once and share the rows for
	 * composition and measurement — a second render per frame would duplicate
	 * render-time side effects (image placement registration). Roots with a
	 * custom render keep the composed output as the source of truth and measure
	 * up to the last target.
	 */
	#renderBelowRoot(root: Component, width: number, after: string[], spans: ViewportClickSpan[]): void {
		const start = after.length;
		const plainContainer = root instanceof Container && root.render === Container.prototype.render;
		const targets = root instanceof Container ? root.children : [root];
		const resolves = targets.map(rowTargetCandidates);
		const lastTarget = resolves.findLastIndex(resolve => resolve !== undefined);
		if (plainContainer) {
			let offset = start;
			for (let index = 0; index < targets.length; index++) {
				const childLines = targets[index]!.render(width);
				after.push(...childLines);
				if (index > lastTarget) continue;
				const resolve = resolves[index];
				if (resolve !== undefined && childLines.length > 0) {
					spans.push({ start: offset, end: offset + childLines.length, candidates: resolve });
				}
				offset += childLines.length;
			}
			return;
		}
		after.push(...root.render(width));
		if (lastTarget === -1) return;
		let offset = start;
		for (let index = 0; index <= lastTarget; index++) {
			const childLines = targets[index] === root ? after.length - start : targets[index]!.render(width).length;
			const resolve = resolves[index];
			if (resolve !== undefined && childLines > 0) {
				spans.push({ start: offset, end: offset + childLines, candidates: resolve });
			}
			offset += childLines;
		}
	}

	/**
	 * Band the hovered click target's current rows. Id-anchored (not
	 * line-anchored) so the band follows an agent whose rows shift while it
	 * streams; a retired id matches no span and simply paints nothing. Only
	 * the viewport copy is banded — retirement reads unbanded component rows.
	 */
	#paintHoverBand(viewport: string[], spans: readonly ViewportClickSpan[]): string[] {
		const hovered = this.#hoveredClickId;
		if (hovered === undefined) return viewport;
		let banded = false;
		const painted = viewport.map((line, index) => {
			for (const span of spans) {
				if (index < span.start || index >= span.end) continue;
				if (!span.candidates(index - span.start).includes(hovered)) continue;
				banded = true;
				// A wrapping band loses to background opens nested inside the row
				// (live card rows carry the pending-tint bg, which would paint over
				// the band for every cell it covers), so drop nested bg opens
				// first; their closes stay and become band resumes via bgFill.
				return theme.bgFill("selectedBg", line.replace(NESTED_BG_OPEN_PATTERN, ""));
			}
			return line;
		});
		return banded ? painted : viewport;
	}

	/**
	 * Candidate subagent ids under a mutable-viewport line, for click-to-focus.
	 * Empty when the line has no click target (chrome, separators, retired rows
	 * are never in the viewport). Callers intersect with the live registry.
	 */
	viewportClickCandidates(index: number): string[] {
		return routeViewportClick(this.#lastClickSpans, index);
	}

	/**
	 * The extension-owned link label drawn at cell `col` of a mutable-viewport line, or `undefined`.
	 * Only links whose scheme an extension registered match; see `extensionLinkLabels`.
	 */
	viewportLinkAt(index: number, col: number): ViewportLink | undefined {
		const line = this.#lastViewportRows[index];
		if (line === undefined || col < 0) return undefined;
		const label = extensionLinkLabels(line).find(label => col >= label.start && col < label.end);
		return label && { url: label.url, row: index, start: label.start };
	}

	/**
	 * Point the hover band at a click-candidate id (or clear it). Takes effect
	 * on the next frame; callers repaint only when the target actually changes.
	 */
	setHoveredClickId(id: string | undefined): void {
		this.#hoveredClickId = id;
	}

	/** How many extension link labels the last frame drew; a label wrapped across rows counts once. */
	viewportLinkCount(): number {
		return viewportLinkTargets(this.#lastViewportRows).length;
	}

	/**
	 * Enter keyboard link-hint mode: the next frame draws a tag over each extension link label it
	 * shows. `onEnd` runs once when the mode ends: a pick, a cancel, a key no tag starts with, a
	 * repaint that no longer draws the tagged labels where they were, or (`"crowded"`) a row with
	 * too many links for their tags to fit side by side.
	 */
	startLinkHints(onEnd: LinkHintsEnd): void {
		this.#endLinkHints();
		this.#linkHints = { hints: new LinkHints(), onEnd };
	}

	/** Whether link-hint mode is on. */
	get linkHintsActive(): boolean {
		return this.#linkHints !== undefined;
	}

	/**
	 * Type one letter of a tag. Returns the link whose whole tag is now typed, `true` while the
	 * letters still lead to several tags, and `false` when none starts with them. The mode ends on
	 * a pick or a miss.
	 */
	typeLinkHint(letter: string): ViewportLink | boolean {
		const state = this.#linkHints;
		if (state === undefined) return false;
		// A key typed before the tags were first painted picks among the labels last drawn.
		if (!state.hints.tagged) this.#syncLinkHints(this.#lastViewportRows, this.#lastViewportWidth);
		if (this.#linkHints !== state) return false;
		const result = state.hints.type(letter);
		if (result !== true) this.#endLinkHints();
		return result;
	}

	/** Leave link-hint mode without picking a link. */
	cancelLinkHints(): void {
		this.#endLinkHints();
	}

	/** Acknowledges one accepted header, replay, or transcript batch. */
	acknowledgeHistory(id: number): void {
		const offered = this.#offeredHistory;
		if (offered === undefined || offered.id !== id) return;
		if (offered.source === "header") {
			this.#headerRetired = true;
			this.#retiredHeaderRows = offered.rows;
		} else {
			if (offered.source.transcriptId !== undefined) {
				offered.source.transcript.acknowledgeFinalizedBatch(offered.source.transcriptId);
			}
			if (offered.source.header === "replay") {
				this.#headerReplayPending = false;
				if (offered.source.headerRows !== undefined) this.#retiredHeaderRows = offered.source.headerRows;
			}
		}
		this.#offeredHistory = undefined;
		if (this.#historyReplayRequested) this.#startHistoryReplay();
		if (offered.kind === "replay") {
			this.ui.requestRender();
		}
	}

	/** Render the semantic transcript tail while the terminal borrows its resize buffer. */
	renderResizeFrame(viewport: ViewportSize): readonly string[] {
		if (!this.#started || this.#stopped) return [];
		const width = Math.max(1, viewport.columns);
		const rows = Math.max(0, viewport.rows);
		const tail = this.#runtimeMounted
			? this.#renderResizeTail(width, rows)
			: this.#renderRoots([this.#bootstrapInputGap, this.editor, this.#statusHost], width);
		let header: readonly string[];
		if (this.#headerRetired) {
			this.#resizeRetiredHeaderStart ??= Math.max(
				0,
				this.#retiredHeaderStart - Math.max(0, rows - this.#lastNormalRows),
			);
			header = this.#reflowRetiredHeader(width, this.#resizeRetiredHeaderStart);
		} else {
			header = this.#header.render(width);
		}
		const rendered = [...header, ...tail];
		return rendered.length <= rows ? rendered : rendered.slice(rendered.length - rows);
	}

	/** Replays committed presentation without changing logical retirement state. */
	beginHistoryReplay(): void {
		if (this.#offeredHistory !== undefined) {
			this.#historyReplayRequested = true;
			return;
		}
		this.#startHistoryReplay();
	}

	/** Forces every currently eligible finalized prefix to retire before stop. */
	beginHistoryFlush(): void {
		this.#historyFlush = true;
		// A pending replay would re-render and re-stream the entire committed
		// ledger during shutdown; the terminal already holds that history, so
		// flush emits only genuinely un-retired rows. An already offered batch
		// stays valid and is accepted by the flush loop.
		this.#historyReplayRequested = false;
		this.#headerReplayPending = false;
		for (const child of this.#runtimeChildren) {
			if (child instanceof TranscriptContainer) child.cancelReplay();
		}
	}

	#startHistoryReplay(): void {
		this.#headerReplayPending = this.#headerRetired && (this.#retiredHeaderRows?.length ?? 0) > 0;
		this.#historyReplayRequested = false;
		for (const child of this.#runtimeChildren) {
			if (child instanceof TranscriptContainer) child.beginReplay();
		}
	}

	/** Raise the floor to eligible idle chrome that survives the settle window, even if it appeared after the run. */
	#rebaselineChromeFloor(busy: boolean, chrome: number): void {
		if (busy || chrome <= (this.#chromeFloor ?? chrome)) {
			this.#resetIdleChrome();
			return;
		}
		if (this.#idleChromeSettled && this.#idleChrome === chrome) {
			this.#chromeFloorPromoted = true;
			this.#chromeFloor = chrome;
			this.#resetIdleChrome();
			return;
		}
		if (this.#idleChrome === chrome && this.#idleChromeTimer !== undefined) return;
		this.#resetIdleChrome();
		this.#idleChrome = chrome;
		this.#idleChromeTimer = this.ui.scheduleAfter(IDLE_CHROME_SETTLE_MS, () => {
			this.#idleChromeTimer = undefined;
			this.#idleChromeSettled = true;
			this.ui.requestRender();
		});
	}

	#resetIdleChrome(): void {
		this.#idleChromeTimer?.cancel();
		this.#idleChromeTimer = undefined;
		this.#idleChrome = undefined;
		this.#idleChromeSettled = false;
	}

	/** Track the empty editor's pre-mount height per shape; a shape change restarts the measurement. */
	#recordBootstrapEditorRows(rows: number): void {
		const style = this.editor.getBorderStyle();
		this.#bootstrapEditorRows =
			style === this.#bootstrapEditorStyle ? Math.min(this.#bootstrapEditorRows ?? rows, rows) : rows;
		this.#bootstrapEditorStyle = style;
	}

	/**
	 * Follow the transient roots' resting height. Normally a running minimum; when the editor or its
	 * shape changes, the floor shifts by that frame's height change instead, so draft growth stays
	 * excluded while the new shape's fixed rows are billed.
	 */
	#syncTransientFloor(transientRows: number): number {
		const editor = this.editor;
		const style = editor.getBorderStyle();
		let floor: number;
		if (this.#transientFloor === undefined) {
			// The first runtime frame may already carry a replayed startup draft; seed from the empty
			// editor's pre-mount height when it was painted in the same shape.
			const bootstrap = this.#bootstrapEditorStyle === style ? this.#bootstrapEditorRows : undefined;
			floor = bootstrap === undefined ? transientRows : Math.min(transientRows, bootstrap);
		} else if (editor !== this.#transientEditor || style !== this.#transientEditorStyle) {
			floor = Math.max(0, Math.min(transientRows, this.#transientFloor + transientRows - this.#lastTransientRows));
		} else {
			floor = Math.min(this.#transientFloor, transientRows);
		}
		this.#transientFloor = floor;
		this.#bootstrapEditorRows = undefined;
		this.#bootstrapEditorStyle = undefined;
		this.#transientEditor = editor;
		this.#transientEditorStyle = style;
		this.#lastTransientRows = transientRows;
		return floor;
	}

	/** Header retires first; replay coalesces it with the complete transcript ledger. */
	#offerHistory(
		transcript: TranscriptContainer,
		width: number,
		rows: number,
		chromeRows: number,
	): { id: number; rows: readonly string[]; kind: "append" | "replay" } | undefined {
		if (this.#offeredHistory !== undefined) {
			this.#rerenderOfferedHistory(width);
			return {
				id: this.#offeredHistory.id,
				rows: this.#offeredHistory.rows,
				kind: this.#offeredHistory.kind,
			};
		}
		if (this.#headerReplayPending) {
			const transcriptReplay = transcript.peekReplayBatch(width);
			// A replay follows a scrollback clear, so the header recomposes at
			// the new width exactly like transcript entries do. An empty
			// recompose (welcome unmounted after retirement) falls back to the
			// committed rows, hard-wrapped the way the terminal would.
			const recomposed = this.#header.render(width);
			const headerRows = recomposed.length > 0 ? [...recomposed, ""] : this.#reflowRetiredHeader(width, 0);
			this.#offeredHistory = {
				id: this.#nextHistoryId++,
				rows: [...headerRows, ...(transcriptReplay?.rows ?? [])],
				kind: "replay",
				source: {
					transcript,
					transcriptId: transcriptReplay?.id,
					header: "replay",
					headerRows,
				},
			};
			return {
				id: this.#offeredHistory.id,
				rows: this.#offeredHistory.rows,
				kind: this.#offeredHistory.kind,
			};
		}
		if (!this.#headerRetired) {
			const welcome = this.#welcome;
			if (welcome !== undefined && !welcome.isTranscriptBlockFinalized()) return undefined;
			// The header stays live viewport chrome until the screen fills; then it
			// retires first so transcript prefixes can follow in order.
			const renderedHeader = this.#header.render(width);
			if (renderedHeader.length > 0) {
				// Only the comparison below reads the height, so the walk stops at
				// the budget instead of rendering every replayed block (#12933).
				const liveRows = transcript.liveRowCount(width, Math.max(0, rows - renderedHeader.length - chromeRows));
				if (!this.#historyFlush && renderedHeader.length + chromeRows + liveRows <= rows) return undefined;
				this.#offeredHistory = {
					id: this.#nextHistoryId++,
					rows: [...renderedHeader, ""],
					kind: "append",
					source: "header",
				};
				return {
					id: this.#offeredHistory.id,
					rows: this.#offeredHistory.rows,
					kind: this.#offeredHistory.kind,
				};
			}
			this.#headerRetired = true;
			this.#retiredHeaderRows = [];
		}
		const batch = this.#historyFlush
			? transcript.peekFlushBatch(width)
			: transcript.peekFinalizedBatch(width, Math.max(0, rows - chromeRows));
		if (batch === undefined) return undefined;
		this.#offeredHistory = {
			id: this.#nextHistoryId++,
			rows: batch.rows,
			kind: batch.kind ?? "append",
			source: { transcript, transcriptId: batch.id, header: "none" },
		};
		return {
			id: this.#offeredHistory.id,
			rows: this.#offeredHistory.rows,
			kind: this.#offeredHistory.kind,
		};
	}

	#rerenderOfferedHistory(width: number): void {
		const offered = this.#offeredHistory;
		if (offered === undefined) return;
		if (offered.source === "header") {
			const rows = this.#header.render(width);
			offered.rows = rows.length > 0 ? [...rows, ""] : [];
			return;
		}
		const transcript = offered.source.transcript.rerenderOfferedBatch(width);
		if (offered.source.header === "none") {
			if (transcript !== undefined) offered.rows = transcript.rows;
			return;
		}
		const recomposed = this.#header.render(width);
		const headerRows = recomposed.length > 0 ? [...recomposed, ""] : this.#reflowRetiredHeader(width, 0);
		offered.source.headerRows = headerRows;
		offered.rows = [...headerRows, ...(transcript?.rows ?? [])];
	}

	#renderRoots(roots: readonly Component[], width: number): string[] {
		const rows: string[] = [];
		for (const root of roots) rows.push(...root.render(width));
		return rows;
	}
	/**
	 * Mounted-runtime rows for the transient resize buffer. Only the trailing
	 * viewport can survive the caller's bottom slice, so the transcript renders
	 * a bounded tail instead of the full committed ledger, and the chrome above
	 * it renders only when that tail underfills the screen.
	 */
	#renderResizeTail(width: number, rows: number): string[] {
		const roots = [...this.#runtimeChildren, this.#statusHost];
		const transcriptIndex = roots.findIndex(root => root instanceof TranscriptContainer);
		if (transcriptIndex < 0) return this.#renderRoots(roots, width);
		const transcript = roots[transcriptIndex] as TranscriptContainer;
		const after = this.#renderRoots(roots.slice(transcriptIndex + 1), width);
		const transcriptRows = transcript.renderTail(width, Math.max(0, rows - after.length));
		const pre =
			transcriptRows.length + after.length >= rows ? [] : this.#renderRoots(roots.slice(0, transcriptIndex), width);
		return [...pre, ...transcriptRows, ...after];
	}

	/** Reflow accepted hard rows exactly as the restored terminal buffer will. */
	#reflowRetiredHeader(width: number, start: number): string[] {
		const lines = this.#retiredHeaderRows;
		if (!lines) return [];
		if (isInsideTerminalMultiplexer()) return lines.slice(start);
		const reflowed: string[] = [];
		for (let index = start; index < lines.length; index++) {
			reflowed.push(...wrapLiteralLine(lines[index]!, width));
		}
		return reflowed;
	}

	/** Live editor whose draft survives startup and session adoption. */
	get editor(): CustomEditor {
		return this.#editor;
	}

	/** The welcome component currently mounted in the header, if quiet mode is off. */
	get welcome(): WelcomeComponent | undefined {
		return this.#welcome;
	}

	/** Whether this composer already owns the terminal render/input loop. */
	get started(): boolean {
		return this.#started && !this.#stopped;
	}

	/** Start terminal ownership and optionally begin the welcome intro. */
	start(options: ComposerStartOptions = {}): void {
		if (this.#started || this.#stopped) return;
		this.#started = true;
		// A TSP terminal keeps (and draws) what is typed until startup releases
		// the held input, standing in for the kernel echo other terminals give.
		this.#editor.nativeTypeahead = options.deferInput === true;
		this.ui.start({ clearScrollback: options.clearScrollback === true, deferInput: options.deferInput === true });
		if (options.playWelcomeIntro !== false) this.playWelcomeIntro();
		// Deferred input identifies the CLI prepaint handoff. Flush the queued
		// forced frame before returning so subsequent dynamic-import evaluation
		// cannot monopolize the event loop ahead of the speculative status chrome.
		if (options.deferInput === true) this.ui.renderNow({ clearScrollback: options.clearScrollback === true });
	}
	/** Take raw-input ownership after a deferred-input start. Idempotent. */
	enableInput(): void {
		if (this.#stopped) return;
		this.ui.enableInput();
	}

	/** Apply settings changes without replacing the editor or welcome component. */
	setPreferences(update: Partial<ComposerPreferences>): void {
		if (this.#stopped) return;
		const wasQuiet = this.#preferences.quiet;
		this.#preferences = { ...this.#preferences, ...update };
		this.editor.setTheme(getEditorTheme());
		try {
			this.editor.setBorderStyle(this.#preferences.composerShape);
		} catch {
			// Extension-defined styles arrive with the session; InteractiveMode reapplies them.
		}
		this.ui.setShowHardwareCursor(this.#preferences.showHardwareCursor);
		this.editor.setUseTerminalCursor(this.ui.getShowHardwareCursor());
		this.ui.setMaxInlineImages(this.#preferences.maxInlineImages);
		if (update.resizeScrollback !== undefined) this.ui.setResizeScrollback(update.resizeScrollback);
		this.editor.setImeSafeCursorLayout(this.#preferences.imeSafeCursor);
		this.editor.setAutocompleteMaxVisible(this.#preferences.autocompleteMaxVisible);
		this.editor.setSpellingFeatures({
			typoDetection: this.#preferences.spellingTypoDetection,
			autocomplete: this.#preferences.spellingAutocomplete,
			autocorrect: this.#preferences.spellingAutocorrect,
		});
		this.#startupStatus?.attachToEditor(this.editor, getComposerStyle(this.#preferences.composerShape));
		if (this.#preferences.quiet) {
			this.#welcome?.stopIntro();
			this.#welcome = undefined;
		} else {
			this.#ensureWelcome();
			this.#welcome?.invalidate();
			if (wasQuiet && this.#started) this.playWelcomeIntro();
		}
		if (wasQuiet !== this.#preferences.quiet) this.#rebuildHeader();
		this.ui.requestRender();
	}

	/** Patch welcome data in place as version, session, and project discovery complete. */
	updateWelcome(update: ComposerWelcomeUpdate): void {
		if (this.#stopped) return;
		this.#applyWelcomeUpdate(update);
		if (this.#preferences.quiet) return;
		this.#ensureWelcome();
		const welcome = this.#welcome;
		if (!welcome) return;
		if (update.version !== undefined) welcome.setVersion(this.#version);
		if (update.versionUpdate !== undefined) welcome.setVersionUpdate(this.#versionUpdate);
		this.ui.requestRender();
	}

	/**
	 * Mark whether a host agent run is in flight. Mid-run gaps with no streaming
	 * block (tool arguments not yet parseable, between tool calls) then do not
	 * count as the run ending when the post-run chrome floor is decided.
	 */
	setRunActive(active: boolean): void {
		if (this.#runActive === active) return;
		this.#runActive = active;
		this.ui.requestRender();
	}

	/** Replace optional header content around the stable welcome scene. */
	setHeaderExtras(before: readonly Component[], after: readonly Component[]): void {
		if (this.#stopped) return;
		this.#headerBefore = before;
		this.#headerAfter = after;
		this.#rebuildHeader();
		this.ui.requestRender();
	}

	/** Update the canonical editor reference after InteractiveMode remounts a custom editor. */
	setEditor(editor: CustomEditor): void {
		this.ui.replaceHeldFocus(this.#editor, editor);
		editor.nativeTypeahead = this.#editor.nativeTypeahead;
		this.#editor = editor;
	}

	/**
	 * End the startup input hold once the app's handlers are wired: the TSP
	 * terminal sends the typing it kept, and the keys the TUI held replay
	 * ({@link TUI.releaseHeldInput}). Idempotent.
	 */
	releaseHeldInput(): void {
		if (this.#editor.nativeTypeahead) {
			this.#editor.nativeTypeahead = false;
			this.ui.requestRender();
		}
		this.ui.releaseHeldInput();
	}

	/**
	 * Mount the session-aware status component into the slot below the editor,
	 * retiring the startup status line; the caller installs the real top-border
	 * provider through its composer-shape sync.
	 */
	setStatusComponent<TSession extends StatusLineSession>(component: StatusLineComponent<TSession>): void {
		if (this.#startupStatus) component.adoptGitStatus(this.#startupStatus);
		this.#disposeStartupStatus();
		this.#statusHost.setComponent(component);
		this.editor.setTopBorderProvider(undefined);
		this.editor.composerFacts = component;
	}

	#disposeStartupStatus(): void {
		this.#startupStatus?.dispose();
		this.#startupStatus = undefined;
	}

	/** Mount or replace session-aware root children while preserving the header and status hosts. */
	setRuntimeChildren(children: readonly Component[], options: RuntimeChildrenOptions = {}): void {
		if (this.#stopped) return;
		this.#chromeFloor = undefined;
		this.#chromeFloorPromoted = false;
		this.#resetIdleChrome();
		this.#nativeDock = options.nativeDock;
		this.#nativeTail = options.nativeTail ?? [];
		this.#transientChrome = new Set(options.transientChrome);
		this.#selfClearingChrome = new Set(options.selfClearingChrome);
		this.#billedChrome = new Set(options.billedChrome);
		this.#billedChromeRows = 0;
		this.#billedChromeContracted = false;
		this.#transientFloor = undefined;
		this.ui.removeChild(this.#statusHost);
		if (this.#runtimeMounted) {
			for (const child of this.#runtimeChildren) this.ui.removeChild(child);
		} else {
			this.ui.removeChild(this.#bootstrapInputGap);
			this.ui.removeChild(this.editor);
			this.#runtimeMounted = true;
		}
		this.#runtimeChildren = children;
		for (const child of children) this.ui.addChild(child);
		this.ui.addChild(this.#statusHost);
		this.ui.requestRender();
	}

	/** Play or replay the welcome intro against the stable header render target. */
	playWelcomeIntro(): void {
		this.#welcome?.playIntro(() => this.ui.requestComponentRender(this.#header));
	}

	/** Transfer terminal ownership to InteractiveMode without stopping the composer. */
	transfer(): void {
		if (!this.#started || this.#stopped || this.#transferred) {
			throw new Error("Composer is not available for transfer");
		}
		this.#transferred = true;
	}

	/** Stop a composer that has not transferred terminal ownership. */
	stop(): void {
		if (!this.#started || this.#stopped || this.#transferred) return;
		this.#welcome?.stopIntro();
		this.#disposeStartupStatus();
		this.ui.stop();
		this.#stopped = true;
	}

	#applyWelcomeUpdate(update: ComposerWelcomeUpdate): void {
		if (update.version !== undefined) this.#version = update.version;
		if (update.versionUpdate !== undefined) this.#versionUpdate = update.versionUpdate;
	}

	#ensureWelcome(): void {
		if (this.#welcome) return;
		this.#welcome = new WelcomeComponent(this.#version);
		this.#welcome.setVersionUpdate(this.#versionUpdate);
	}

	#rebuildHeader(): void {
		this.#header.clear();
		for (const component of this.#headerBefore) this.#header.addChild(component);
		if (this.#welcome) {
			this.#header.addChild(new Spacer(1));
			this.#header.addChild(this.#welcome);
			this.#header.addChild(new Spacer(1));
		}
		for (const component of this.#headerAfter) this.#header.addChild(component);
	}

	#handleInterrupt(): void {
		const now = this.#now();
		if (now - this.#lastInterruptAt < DOUBLE_INTERRUPT_MS) {
			this.#requestExit(130);
			return;
		}
		this.editor.setText("");
		this.#lastInterruptAt = now;
	}

	#requestExit(code: number): void {
		// Remains live after transfer until InteractiveMode installs its configured handlers.
		if (this.#stopped) return;
		this.#welcome?.stopIntro();
		if (this.#started) this.ui.stop();
		this.#stopped = true;
		this.#exit(code);
	}
}
