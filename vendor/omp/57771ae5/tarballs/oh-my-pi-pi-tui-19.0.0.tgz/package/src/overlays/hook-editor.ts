/**
 * Multi-line editor component for hooks and ask custom input.
 * Supports Ctrl+G for external editor.
 *
 * Two modes:
 * - Default (hook): Enter inserts newline, the `app.message.followUp` chord
 *   (Ctrl+Q / Ctrl+Enter) submits, bordered popup
 * - Prompt-style (ask): Enter submits, Shift+Enter inserts newline, legacy ask chrome
 */
import type { ImageContent } from "@oh-my-pi/pi-ai";
import { compactImageAttachments, formatVisionMarker, PLACEHOLDER_REGEX } from "../prompt/composer-attachments";
import { classifyImagePaste } from "../prompt/custom-editor";
import { OrderedPastes } from "../prompt/ordered-pastes";
import {
	Editor,
	Ellipsis,
	type Focusable,
	matchesKey,
	replaceTabs,
	Spacer,
	Text,
	type TUI,
	truncateToWidth,
	wrapTextWithAnsi,
} from "../index";
import { BracketedPasteHandler } from "../bracketed-paste";
import { getEditorTheme, theme } from "../theme/theme";
import { matchesAppExternalEditor, matchesAppFollowUp, matchesAppInterrupt } from "../keybinding-matchers";
import { formTheme } from "../chrome/form-theme";
import { OverlayPanel } from "../chrome/overlay-box";
import { FormField } from "../components/form";
import { formatKeyHint, formatKeyHints } from "../app-keybindings";
import { boundKeys, editorKey, interruptKey } from "../chrome/keybinding-hints";
import { formatTooltipKey, type KeyName } from "../key-hint-format";
import { col, node, span } from "../native/describe";
import type { DescribeContext, NativeChild, NativeNode, NativeUiEvent } from "../native/node";
import { actionBar, actionButton } from "../native/overlay";
import { plainText } from "../native/spans";
import { sanitizeCarriageReturns } from "../render/render-utils";

/** Root role of the native sheet. */
const ROLE = "omp.overlay.hook-editor";
/**
 * Role prefix of its parts (`.head`, `.title`, `.detail`, `.eyebrow`, `.field`/`.line`); outside
 * `omp.overlay.*`, which Tern draws as a sheet of its own.
 */
const PART = "omp.hook-editor";

/** Most title rows the terminal prompt shows, so a long question cannot push the input row off-screen. */
const MAX_PROMPT_TITLE_ROWS = 3;
/** Border (2) + padX (2) columns consumed by the panel chrome. */
const PROMPT_TITLE_CHROME_COLUMNS = 4;

/**
 * `prefix` and `question` flattened onto one line, wrapped to the terminal's width and cut to
 * {@link MAX_PROMPT_TITLE_ROWS} rows (the last ends in `…` when cut). For terminal rendering only:
 * native hosts get the question whole ({@link HookEditorOptions.question}).
 */
export function boundPromptTitle(prefix: string, question: string): string {
	const width = Math.max(1, (process.stdout.columns ?? 80) - PROMPT_TITLE_CHROME_COLUMNS);
	const flat = replaceTabs(`${prefix}${question}`).replace(/\s+/g, " ").trim();
	const wrapped = wrapTextWithAnsi(flat, width);
	if (wrapped.length <= MAX_PROMPT_TITLE_ROWS) return wrapped.join("\n");
	const kept = wrapped.slice(0, MAX_PROMPT_TITLE_ROWS - 1);
	const last = truncateToWidth(wrapped.slice(MAX_PROMPT_TITLE_ROWS - 1).join(" "), width, Ellipsis.Unicode);
	return [...kept, last].join("\n");
}

export interface HookEditorOptions {
	/** Edit text with the host's configured external editor. */
	externalEditor?: (text: string) => Promise<string | null>;
	/** When true, use prompt-style keybindings with the legacy ask prompt chrome. */
	promptStyle?: boolean;
	/**
	 * The question the text answers (the ask tool's custom answers and notes). The terminal
	 * shows it after `<title>: `, wrapped and cut to three rows; native hosts put it whole,
	 * as markdown, under the title.
	 */
	question?: string;
	/** Allow clipboard images to be attached to this prompt. */
	acceptImages?: boolean;
	/** Images already represented by markers in the prefilled text. */
	images?: readonly ImageContent[];
	/**
	 * With `acceptImages`, called for an empty bracketed paste, which is how terminals that own
	 * the paste key send an image-only clipboard (#3601). Same signature as
	 * `CustomEditor.onPasteImage`; the host calls `beginPaste` before its first await.
	 */
	onPasteImage?: () => Promise<boolean>;
	/**
	 * With `acceptImages`, called for each path of a bracketed paste made only of image paths.
	 * Same signature as `CustomEditor.onPasteImagePath`; calls are not awaited in turn, so images
	 * attach as they finish loading and are renumbered in text order on submit.
	 */
	onPasteImagePath?: (path: string) => void | Promise<void>;
	/**
	 * Max rows the inner Editor may occupy. When omitted, the editor is
	 * bounded to the current terminal height minus the component's chrome
	 * (≈10 rows) so long content scrolls instead of pushing the submit
	 * hint out of view.
	 */
	maxHeight?: number;
}

/** Interactive multiline dialog used by hooks and the ask tool's Other response. */
export class HookEditorComponent extends OverlayPanel implements Focusable {
	#editor: Editor;
	#field: FormField;
	#onSubmitCallback: (value: string, images?: ImageContent[]) => void;
	#onCancelCallback: (draft: string, images?: ImageContent[]) => void;
	#tui: TUI;
	#promptStyle: boolean;
	#acceptImages: boolean;
	#images: ImageContent[];
	#externalEditor: HookEditorOptions["externalEditor"];
	#onPasteImage: HookEditorOptions["onPasteImage"];
	#onPasteImagePath: HookEditorOptions["onPasteImagePath"];
	#pasteHandler = new BracketedPasteHandler();
	#pastes = new OrderedPastes({
		deliver: text => this.#editor.pasteText(text),
		run: () => this.#submitCurrentText(true),
		live: () => !this.#disposed,
	});
	#disposed = false;
	/** Head, field and action bar; every part but the editor (which describes itself) is fixed, so it is built once. */
	#nativeRoot: NativeNode;
	/** Focus state mirrored to the nested editor during rendering. */
	focused = false;

	constructor(
		tui: TUI,
		title: string,
		prefill: string | undefined,
		onSubmit: (value: string, images?: ImageContent[]) => void,
		/** Receives the text and images left in the editor, so a host can offer them again. */
		onCancel: (draft: string, images?: ImageContent[]) => void,
		options?: HookEditorOptions,
	) {
		// First title line insets into the panel border; remaining lines (e.g. the
		// bounded ask question) stay as body rows so they are never truncated into
		// the one-row border.
		const question = options?.question;
		const terminalTitle = question === undefined ? title : boundPromptTitle(`${title}: `, question);
		const [titleLine = "", ...detailLines] = terminalTitle.split("\n");
		super(titleLine, ROLE);

		this.#tui = tui;
		this.#onSubmitCallback = onSubmit;
		this.#onCancelCallback = onCancel;
		this.#promptStyle = options?.promptStyle ?? false;
		this.#acceptImages = options?.acceptImages ?? false;
		this.#images = this.#acceptImages ? [...(options?.images ?? [])] : [];
		this.#externalEditor = options?.externalEditor;
		this.#onPasteImage = options?.onPasteImage;
		this.#onPasteImagePath = options?.onPasteImagePath;

		// Editor
		this.#editor = new Editor(getEditorTheme());
		if (this.#promptStyle) {
			this.#editor.setBorderVisible(false);
			this.#editor.setPromptGutter("> ");
			this.#editor.disableSubmit = true;
		}
		// Image markers delete as a unit, like the main editor's attachment tokens.
		if (options?.acceptImages) this.#editor.atomicTokenPattern = PLACEHOLDER_REGEX;
		// Bound the editor so long content scrolls instead of pushing the
		// submit hint off-screen. Caller may override via options.maxHeight.
		const termRows = this.#tui.terminal?.rows ?? process.stdout.rows ?? 40;
		this.#editor.setMaxHeight(options?.maxHeight ?? Math.max(3, termRows - 12));
		this.#editor.setScrollbarVisible(true);
		if (prefill) {
			this.#editor.setText(prefill);
		}
		// Hint
		const followUpKeys = boundKeys("app.message.followUp", ["ctrl+q", "ctrl+enter"]);
		const [primaryFollowUpKey = "ctrl+q"] = followUpKeys;
		const externalEditorKey = editorKey("app.editor.external") || formatKeyHint("ctrl+g");
		const hint = this.#promptStyle
			? `${formatKeyHint("enter")} or ${formatKeyHint(primaryFollowUpKey)} submit  ${formatKeyHint("escape")} cancel  ${externalEditorKey} external editor`
			: `${formatKeyHints(followUpKeys)} submit  ${interruptKey()} cancel  ${externalEditorKey} external editor`;
		this.#field = new FormField(this.#editor, {
			theme: formTheme,
			details:
				detailLines.length > 0
					? [new Spacer(1), ...detailLines.map(line => new Text(theme.fg("accent", line), 0, 0))]
					: undefined,
			hint,
		});
		this.addChild(this.#field);
		this.addChild(new Spacer(1));

		// Native: the field drops its terminal frame for the sheet's, and says what to type while empty.
		const fieldRole = this.#promptStyle ? `${PART}.line` : `${PART}.field`;
		this.#editor.describeLayout = input => ({ role: fieldRole, children: [input], caret: "input" });
		const placeholder = [span(this.#promptStyle ? "Type your answer" : "Type here")];
		this.#editor.describePlaceholder = () => placeholder;

		const head: NativeChild[] = [];
		if (question !== undefined) {
			// The question is the heading, as on the ask sheet; the prompt's own title names the answer above it.
			head.push(
				node(
					"text",
					{ spans: [span(plainText(title))], role: `${PART}.eyebrow`, wrap: "none", truncate: "end" },
					undefined,
					"eyebrow",
				),
			);
			head.push(
				node(
					"md",
					{ text: replaceTabs(sanitizeCarriageReturns(question)), role: "omp.ask.question" },
					undefined,
					"question",
				),
			);
		} else {
			head.push(
				node(
					"text",
					{ spans: [span(plainText(titleLine))], role: `${PART}.title`, wrap: "word" },
					undefined,
					"title",
				),
			);
			if (detailLines.length > 0) {
				head.push(
					node(
						"text",
						{ spans: [span(plainText(detailLines.join("\n")))], wrap: "word", role: `${PART}.detail` },
						undefined,
						"detail",
					),
				);
			}
		}

		// Buttons say what they do; their keys live in the tooltips.
		const tip = (clauses: readonly (readonly [string, KeyName | undefined])[]): string =>
			clauses.map(([label, key]) => (key ? `${label}  ${formatTooltipKey(key)}` : label)).join(" · ");
		const submitKey: KeyName = this.#promptStyle ? "enter" : primaryFollowUpKey;
		const newlineKey: KeyName = this.#promptStyle ? "shift+enter" : "enter";
		const cancelKey = this.#promptStyle ? "escape" : (boundKeys("app.interrupt", ["escape"])[0] ?? "escape");
		const buttons: (NativeNode | null)[] = [];
		if (this.#externalEditor) {
			const [externalKey] = boundKeys("app.editor.external", ["ctrl+g"]);
			buttons.push(
				actionButton("Open in editor", "external", {
					...(externalKey ? { keys: externalKey } : {}),
					title: tip([["Edit in your external editor", externalKey]]),
				}),
			);
		}
		buttons.push(
			null,
			actionButton("Cancel", "cancel", { keys: cancelKey, title: tip([["Cancel", cancelKey]]) }),
			actionButton("Submit", "submit", {
				keys: submitKey,
				tone: "accent",
				title: tip([
					["Submit", submitKey],
					["New line", newlineKey],
				]),
			}),
		);

		this.#nativeRoot = col(
			[node("col", { role: `${PART}.head`, gap: "xs" }, head, "head"), this.#editor, actionBar(buttons)],
			{ role: ROLE },
		);
	}

	/**
	 * A sheet in the composer's place: the title (or, answering a question, the question under the
	 * prompt's name) over a hairline, the editor, and Open in editor · Cancel · Submit.
	 */
	override describe(_cx: DescribeContext): NativeNode {
		this.#field.focused = this.focused;
		return this.#nativeRoot;
	}

	/** The action bar's buttons run what their keys run. */
	handleNativeEvent(event: NativeUiEvent): void {
		if (this.#disposed || event.type !== "action") return;
		if (event.act === "submit") this.#submitCurrentText();
		else if (event.act === "cancel") this.#cancel();
		else if (event.act === "external") void this.#openExternalEditor();
	}

	/** Keep the nested editor's software/hardware cursor mode aligned with the dialog focus target. */
	setUseTerminalCursor(useTerminalCursor: boolean): void {
		this.#field.setUseTerminalCursor(useTerminalCursor);
	}

	/** Render the dialog after forwarding its focus state to the nested editor. */
	override render(width: number): readonly string[] {
		this.#field.focused = this.focused;
		return super.render(width);
	}

	handleInput(keyData: string): void {
		if (this.#disposed) return;
		const paste = this.#pasteHandler.process(keyData);
		if (paste.handled) {
			if (paste.pasteContent === undefined) return;
			// Hosts reserve ordered delivery synchronously inside these callbacks, so input
			// that followed the paste in this chunk (e.g. Enter) still waits for the image.
			const content = paste.pasteContent;
			const image = this.acceptsImages ? classifyImagePaste(content) : undefined;
			if (image?.kind === "clipboard" && this.#onPasteImage) {
				void this.#onPasteImage();
			} else if (image?.kind === "paths" && this.#onPasteImagePath) {
				for (const path of image.paths) void this.#onPasteImagePath(path);
			} else {
				this.pasteText(content);
			}
			if (paste.remaining.length > 0) this.handleInput(paste.remaining);
			return;
		}
		if (this.#promptStyle) {
			this.#handlePromptStyleInput(keyData);
		} else {
			this.#handleHookStyleInput(keyData);
		}
	}

	#submitCurrentText(requireText = false): void {
		if (this.#disposed) return;
		if (this.#pastes.holdAction()) return;
		const { text, images } = this.#currentValue();
		if (requireText && text.trim().length === 0) return;
		this.dispose();
		if (images?.length) this.#onSubmitCallback(text, images);
		else this.#onSubmitCallback(text);
	}

	/** Expanded editor text, with attached images renumbered in text order (path pastes attach as they load). */
	#currentValue(): { text: string; images: ImageContent[] | undefined } {
		const text = this.#editor.getExpandedText();
		if (this.#images.length === 0) return { text, images: undefined };
		return compactImageAttachments(text, this.#images);
	}

	/** Whether this prompt opted into clipboard image attachments. */
	get acceptsImages(): boolean {
		return this.#acceptImages && !this.#disposed;
	}

	/** Attach an image; returns its `[Image #N, WxH]` marker for the caller to deliver. */
	attachImage(image: ImageContent, dims?: { width: number; height: number }): string | undefined {
		if (!this.acceptsImages) return undefined;
		this.#images.push(image);
		return formatVisionMarker("image", this.#images.length, dims);
	}

	/** Reserve ordered clipboard delivery. Completion accepts nonempty text once, or releases on undefined. */
	beginPaste(): (text: string | undefined) => boolean {
		if (this.#disposed) return () => false;
		return this.#pastes.begin();
	}

	override dispose(): void {
		if (this.#disposed) return;
		this.#disposed = true;
		this.#pastes.clear();
		super.dispose();
	}

	#cancel(): void {
		const { text, images } = this.#currentValue();
		this.dispose();
		if (images?.length) this.#onCancelCallback(text, images);
		else this.#onCancelCallback(text);
	}

	/** Route non-bracketed paste transports (e.g. kitty's OSC 5522 enhanced clipboard)
	 *  into the inner editor, mirroring bracketed-paste semantics. Without this hook,
	 *  enhanced-paste routing falls back to the main prompt editor hidden behind the
	 *  dialog (#2127 routing contract). */
	pasteText(text: string): void {
		if (this.#disposed) return;
		this.#pastes.paste(text);
	}

	/** Replace the draft, as Ctrl+R history search does for the main composer. */
	setText(text: string): void {
		if (this.#disposed) return;
		this.#editor.setText(text);
	}

	/**
	 * Prompt-style: raw Enter submits; Editor owns newline-producing sequences.
	 * The follow-up chord (`app.message.followUp` → Ctrl+Q / Ctrl+Enter) also
	 * submits, so muscle memory from the main editor / hook-style surface works
	 * here and Windows Terminal — which can't deliver a distinct Ctrl+Enter
	 * event (#1903) — still has a working chord via Ctrl+Q (#3353).
	 */
	#handlePromptStyleInput(keyData: string): void {
		// Submit on the follow-up chord first so it wins over Editor's own
		// Ctrl+Enter newline handling. Mirrors #handleHookStyleInput.
		if (matchesAppFollowUp(keyData)) {
			this.#submitCurrentText();
			return;
		}

		// Prompt-style keeps Escape as an explicit cancel key and also honors app.interrupt remaps.
		if (matchesKey(keyData, "escape") || matchesKey(keyData, "esc") || matchesAppInterrupt(keyData)) {
			this.#cancel();
			return;
		}

		// Ctrl+G for external editor
		if (matchesAppExternalEditor(keyData)) {
			void this.#openExternalEditor();
			return;
		}

		// Submit on any plain Enter encoding, including terminals that report unmodified Enter as LF.
		if (matchesKey(keyData, "enter") || matchesKey(keyData, "return")) {
			this.#submitCurrentText();
			return;
		}

		// Let Editor handle modified newline-producing variants (Shift+Enter, Ctrl+Enter, Alt+Enter, etc.)
		this.#editor.handleInput(keyData);
	}

	/** Hook-style: Enter=newline, app.message.followUp chord (Ctrl+Q/Ctrl+Enter) submits. */
	#handleHookStyleInput(keyData: string): void {
		// Submit on the follow-up chord. Uses the shared keybinding so Ctrl+Q works
		// on Windows Terminal (#1903) and any user remap of `app.message.followUp`
		// applies here too.
		if (matchesAppFollowUp(keyData)) {
			this.#submitCurrentText();
			return;
		}

		// Plain Enter inserts a new line in hook editor
		if (matchesKey(keyData, "enter") || matchesKey(keyData, "return") || keyData === "\n") {
			this.#editor.handleInput("\n");
			return;
		}

		// Escape to cancel
		if (matchesAppInterrupt(keyData)) {
			this.#cancel();
			return;
		}

		// Ctrl+G for external editor
		if (matchesAppExternalEditor(keyData)) {
			void this.#openExternalEditor();
			return;
		}

		// Forward to editor
		this.#editor.handleInput(keyData);
	}

	async #openExternalEditor(): Promise<void> {
		const externalEditor = this.#externalEditor;
		if (!externalEditor) return;

		const currentText = this.#editor.getExpandedText();
		try {
			this.#tui.stop();
			const result = await externalEditor(currentText);
			if (!this.#disposed && result !== null) {
				this.#editor.setText(result);
			}
		} finally {
			this.#tui.start();
			this.#tui.requestRender(true);
		}
	}
}
