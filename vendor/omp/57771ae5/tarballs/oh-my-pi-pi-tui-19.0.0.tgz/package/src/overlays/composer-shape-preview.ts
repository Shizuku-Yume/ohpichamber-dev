/**
 * Live preview for the `composer.shape` setting and the setup-wizard composer
 * scene. Chrome is rendered through the same {@link ComposerStyle} objects the
 * real editor uses, and status rows come from the live
 * {@link ComposerPreviewStatusSource} (the session's StatusLineComponent) —
 * nothing about the preview is a re-implementation. Prompt text is a preview
 * stand-in, and the `session_name` segment falls back to a stand-in title
 * (passed via `previewTitle`) when the session is unnamed.
 */
import {
	type Component,
	type ComposerChromeContext,
	type EditorTopBorder,
	getComposerStyle,
	isFilledComposerStyle,
	padding,
	truncateToWidth,
	visibleWidth,
} from "../index";
import { type ComposerShape, getComposerShapeOptions } from "./composer-shape-registry";
import { theme } from "../theme/theme";
import type { NativeNode } from "../native/node";
import { col, node, span, text } from "../native/describe";

/**
 * Real status renderer the preview borrows rows from — structurally satisfied
 * by {@link StatusLineComponent}. Layout is parameterized so a preview can
 * render a candidate shape's placement instead of the active one.
 */
export interface ComposerPreviewStatusSource {
	/** Powerline bar with the context gauge (box top border content). */
	getTopBorder(width: number, previewTitle?: string): { content: string; width: number };
	/** Flush soft-capped powerline band (band composer top row). */
	getBandTopBorder(width: number, previewTitle?: string): { content: string; width: number };
	/** Plain right-group chip (claude top rule content). */
	getStandaloneTopBorder(width: number, previewTitle?: string): { content: string; width: number };
	/** Plain standalone bottom bar carrying the given segment groups. */
	renderBottomBar(width: number, groups: "left" | "full", previewTitle?: string): string;
}

export interface ComposerShapePreviewOptions {
	requestRender?: () => void;
	/** Live status renderer; omitted (tests), the chrome renders without status rows. */
	status?: ComposerPreviewStatusSource;
}
/** Stand-in session title shown while the previewed session is unnamed. */
const PREVIEW_TITLE = "omp";

export function renderComposerShapePreview(
	shape: ComposerShape,
	width: number,
	status?: ComposerPreviewStatusSource,
): readonly string[] {
	// No upper cap: the hosting overlay already bounds width by the terminal,
	// and capping clips the status band the preview exists to show (#12500).
	const previewWidth = Math.max(24, width);
	const style = getComposerStyle(shape);
	const paddingX = style.defaultPaddingX(undefined);
	const chromeWidth = style.sideChromeWidth(paddingX);

	let topBorder: EditorTopBorder | undefined;
	if (status) {
		if (style.statusAttachment === "top-border") {
			topBorder = status.getTopBorder(Math.max(1, previewWidth - chromeWidth * 2), PREVIEW_TITLE);
		} else if (style.statusAttachment === "top-band") {
			topBorder = status.getBandTopBorder(previewWidth, PREVIEW_TITLE);
		} else if (style.statusAttachment === "top-rule-chip") {
			topBorder = status.getStandaloneTopBorder(previewWidth, PREVIEW_TITLE);
		}
	}

	const ctx: ComposerChromeContext = {
		width: previewWidth,
		paddingX,
		borderColor: (str: string) => theme.fg("borderAccent", str),
		accentColor: (str: string) => theme.fg("accent", str),
		surfaceColor: (str: string) =>
			theme.bgFill("userMessageBg", theme.fgOnBg("userMessageText", "userMessageBg", str)),
		box: theme.boxRound,
		topBorder,
	};

	const gutter = style.defaultPromptGutter ?? "";
	const contentWidth = Math.max(1, previewWidth - chromeWidth * 2 - visibleWidth(gutter));
	const promptText = truncateToWidth("Ask anything, edit files, run tools", Math.max(1, contentWidth - 1));
	// Mirror the live editor: filled shapes let `surfaceColor` paint their own
	// foreground, while transparent shapes resolve `text` to a contrast-safe
	// color so an empty token never falls back to the terminal default.
	const promptRow = `${promptText}${theme.inverse(" ")}`;
	const text = isFilledComposerStyle(style) ? promptRow : theme.fgResolved("text", promptRow);
	const pad = padding(Math.max(0, contentWidth - visibleWidth(promptText) - 1));
	const styledGutter = gutter ? theme.fg("accent", gutter) : "";

	const lines: string[] = [];
	const top = style.renderTop(ctx);
	if (top !== undefined) lines.push(top);
	lines.push(
		...style.renderRow({
			...ctx,
			text,
			pad,
			gutter: styledGutter,
			isLastRow: true,
			cursorOverflow: 0,
			imeSafeCursorTail: false,
			scrollbarThumb: false,
		}),
	);
	const bottom = style.renderBottom(ctx);
	if (bottom !== undefined) lines.push(bottom);

	if (style.bottomBar !== "none" && status) {
		const bar = status.renderBottomBar(previewWidth, style.bottomBar, PREVIEW_TITLE);
		if (bar) {
			if (style.bottomBarGap) lines.push("");
			lines.push(bar);
		}
	}
	return lines;
}

export class ComposerShapePreview implements Component {
	#shape: ComposerShape;
	#options: ComposerShapePreviewOptions;
	#native: { shape: ComposerShape; node: NativeNode } | undefined;

	constructor(initialValue: ComposerShape = "band", options: ComposerShapePreviewOptions = {}) {
		this.#shape = initialValue;
		this.#options = options;
	}

	setValue(shape: ComposerShape): void {
		if (this.#shape === shape) return;
		this.#shape = shape;
		this.#options.requestRender?.();
	}

	/**
	 * A TSP terminal draws the composer itself, so the shape's glyph chrome has
	 * no native twin: the preview names the shape over a read-only prompt.
	 */
	describe(): NativeNode {
		const memo = this.#native;
		if (memo?.shape === this.#shape) return memo.node;
		const option = getComposerShapeOptions().find(candidate => candidate.value === this.#shape);
		const caption = [span(option?.label ?? this.#shape, "strong")];
		if (option?.description) caption.push(span(` · ${option.description}`, "muted"));
		const described = col(
			[
				text([span("Preview:", "muted")]),
				node("editor", { placeholder: "Ask anything, edit files, run tools", readonly: true, maxLines: 1 }),
				text(caption, { wrap: "word" }),
			],
			{ role: "omp.preview.composer-shape", gap: "xs" },
		);
		this.#native = { shape: this.#shape, node: described };
		return described;
	}

	render(width: number): readonly string[] {
		const lines = renderComposerShapePreview(this.#shape, width, this.#options.status);
		return ["", theme.fg("muted", "Preview:"), ...lines];
	}
}
