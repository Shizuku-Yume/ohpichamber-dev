import type { ImageContent } from "@oh-my-pi/pi-ai";
import {
	type Component,
	Ellipsis,
	Markdown,
	type MarkdownTheme,
	matchesKey,
	padding,
	renderInlineMarkdown,
	replaceTabs,
	ScrollView,
	Text,
	type TUI,
	truncateToWidth,
	visibleWidth,
	wrapTextWithAnsi,
} from "../index";
/** One selectable answer in an ask dialog. */
export interface ExtensionAskDialogOption {
	label: string;
	description?: string;
	preview?: string;
}

/** Question and answer choices displayed by the ask dialog. */
export interface ExtensionAskDialogQuestion {
	id: string;
	question: string;
	header?: string;
	options: ExtensionAskDialogOption[];
	multi?: boolean;
	recommended?: number;
}

/** Prompt text and the images pasted into it (custom answers and notes). */
export interface AskDialogPromptValue {
	text: string;
	images?: ImageContent[];
}

/** A prompt left without submitting: what it still held, offered again when the custom answer reopens. */
export interface AskDialogPromptDraft {
	draft: AskDialogPromptValue;
}

/** Submitted answer to one dialog question. */
export interface ExtensionAskDialogResultItem {
	id: string;
	question: string;
	options: string[];
	multi: boolean;
	selectedOptions: string[];
	customInput?: string;
	customInputImages?: ImageContent[];
	note?: string;
	noteImages?: ImageContent[];
	/** Label of the option the note is on; unset when it is on the custom answer. */
	noteOption?: string;
	timedOut?: boolean;
}

/** Answers submitted from the dialog. */
export interface ExtensionAskDialogSubmitResult {
	kind: "submit";
	results: ExtensionAskDialogResultItem[];
}

/** Request to discuss the question instead of answering it. */
export interface ExtensionAskDialogChatResult {
	kind: "chat";
}

/** Completed dialog action, distinct from cancellation. */
export type ExtensionAskDialogResult = ExtensionAskDialogSubmitResult | ExtensionAskDialogChatResult;
import { disambiguateDisplayLabels, expandKeyHint, sanitizeCarriageReturns } from "../render/render-utils";
import { ASK_RESERVED_ROWS, renderFoldedQuestion } from "../chrome/ask-fold";
import { getMarkdownTheme, highlightCode, theme } from "../theme/theme";
import {
	matchesAppToolsExpand,
	matchesSelectCancel,
	matchesSelectDown,
	matchesSelectPageDown,
	matchesSelectPageUp,
	matchesSelectUp,
} from "../keybinding-matchers";
import { optionMarker } from "../tools/ask";
import { CountdownTimer } from "../chrome/countdown-timer";
import { editorKey, editorKeys } from "../chrome/keybinding-hints";
import { formatKeyHint, formatKeyHints } from "../app-keybindings";
import { OverlayPanel, PanelRows } from "../chrome/overlay-box";
import { handleTabSwitchKey } from "../chrome/selector-helpers";
import { askCard, type AskPill, type FoldSummary, foldQuestion, openQuestion } from "../native/ask-card";
import { node, span, text } from "../native/describe";
import {
	type DescribeContext,
	leafKey,
	type NativeChild,
	type NativeNode,
	type NativeUiEvent,
	type TspSpan,
} from "../native/node";
import { actionBar, actionButton } from "../native/overlay";
import { getKeybindings } from "../keybindings";
import { isNativeRendering } from "../native/state";

const OTHER_OPTION = "Other (type your own)";
const RECOMMENDED_SUFFIX = " (Recommended)";
/** Native label of the free-text row. */
const OTHER_LABEL = "Other…";
/** Widest a folded question's text grows natively, in cells, before it is cut. */
const MAX_FOLD_QUESTION_WIDTH = 200;

// Action rows appended by the guest race participant. An option sanitizing
// to one of these must disambiguate identically on both sides, or the same
// question renders different rows depending on who answers.
const GUEST_ACTION_LABELS = ["Chat about this", "Next →"];

/** Fraction of the terminal the dialog may occupy. The box height is fixed
 *  at spawn from the tallest column (whichever question open; re-measured
 *  only on viewport resize) and clamped to this ratio and to the terminal
 *  less {@link ASK_RESERVED_ROWS}; it rises from the bottom as a stable panel
 *  that never resizes as questions open or the cursor moves. */
const DIALOG_HEIGHT_RATIO = 0.7;
const MIN_DIALOG_ROWS = 10;
/** The panel's rows around its body: the top and bottom borders. */
const PANEL_CHROME_ROWS = 2;
const MIN_BODY_ROWS = 5;
/** Cells the open question's text sits in from its mark, as a folded question's does (`renderFoldedQuestion`). */
const OPEN_INDENT = "  ";
/** Maximum number of wrapped lines for an in-body question header, so a long
 *  or multi-line question cannot push the option list off-screen. Mirrors the
 *  row-cap pattern of the prompt editor's title (`boundPromptTitle`). */
const MAX_HEADER_ROWS = 4;
/** Maximum number of wrapped lines shown for an option description before
 *  Ctrl+O expansion. Mirrors the header row-cap above so long descriptions
 *  cannot push later options off-screen. */
const MAX_DESC_ROWS = 2;

/** What a custom-answer or note prompt asks: the host shows `title` over `question` (`HookEditorOptions.question`). */
export interface AskDialogPrompt {
	/** `Custom answer`, `Note for <option>`. */
	title: string;
	/** The question being answered, verbatim. */
	question: string;
}

interface AskDialogCallbacks {
	onSubmit(result: ExtensionAskDialogSubmitResult): void;
	onCancel(): void;
	/** Resolves the submitted text; on cancel, the editor's draft, or `undefined` when none is kept. */
	onPrompt(prompt: AskDialogPrompt, prefill?: string): Promise<string | AskDialogPromptDraft | undefined>;
	/** Prompt that accepts pasted images; without it, prompts use `onPrompt`. Resolves like `onPrompt`. */
	onImagePrompt?(
		prompt: AskDialogPrompt,
		prefill: AskDialogPromptValue | undefined,
	): Promise<AskDialogPromptValue | AskDialogPromptDraft | undefined>;
}

interface AskDialogOptions {
	timeout?: number;
	onTimeout?: () => void;
	tui?: TUI;
	/** While it returns text, the native card dims its questions and warns with it: sending the composer draft skips the ask. */
	skipNotice?(): string | undefined;
	/** Natively, a pointer action on the card: the host gives it the keyboard, which the composer may hold. */
	claimKeys?(): void;
	/** Esc (and natively Tab past the last question): the host hands the keyboard to the composer under the ask. */
	releaseKeys?(): void;
}

interface QuestionState {
	selectedOptions: Set<string>;
	customInput: string | undefined;
	customInputImages: ImageContent[] | undefined;
	/** Unsubmitted custom answer left by a cancelled prompt; prefills the next one over `customInput`. */
	customDraft: AskDialogPromptValue | undefined;
	note: string | undefined;
	noteImages: ImageContent[] | undefined;
	noteRowKey: string | undefined;
	cursorIndex: number;
	timedOut: boolean;
}

type QuestionRowKind = "option" | "other";

interface QuestionRow {
	kind: QuestionRowKind;
	key: string;
	label: string;
	optionIndex: number | undefined;
}

/** The open question's rows: its head, then its answer rows, which start at `rowStarts` (and the block ends at its last entry). */
interface OpenQuestionLines {
	lines: string[];
	rowStarts: number[];
}

/** The stacked column: every question, folded but the open one, which starts at `openStart`; `rowStarts` index the whole column. */
interface ColumnLines extends OpenQuestionLines {
	openStart: number;
}

interface PreviewSegment {
	kind: "markdown" | "code";
	text: string;
	language: string | undefined;
}

type PreviewRenderCache = Map<string, Map<number, readonly string[]>>;

function clamp(value: number, min: number, max: number): number {
	return Math.max(min, Math.min(value, max));
}

function wrapQuestionTitle(question: ExtensionAskDialogQuestion, width: number): string[] {
	return renderPreviewContent(sanitizeCarriageReturns(question.question), Math.max(1, width), "text");
}

function renderQuestionTitle(question: ExtensionAskDialogQuestion, width: number, maxRows = MAX_HEADER_ROWS): string[] {
	const wrapped = wrapQuestionTitle(question, width);
	if (wrapped.length <= maxRows) return wrapped;
	return [
		...wrapped.slice(0, maxRows - 1),
		truncateToWidth(wrapped.slice(maxRows - 1).join(" "), Math.max(1, width), Ellipsis.Unicode),
	];
}
/** Wrap an option description exactly as the option list renders it, so
 *  overflow detection and expanded rendering stay in sync with the row. */
function wrapOptionDescription(description: string, contentWidth: number): string[] {
	const mdTheme = getMarkdownTheme();
	const rendered = renderInlineMarkdown(description.trim(), mdTheme, t => theme.fg("muted", t));
	return wrapTextWithAnsi(rendered, Math.max(1, contentWidth - 6));
}

/** True when any option description of the question wraps past the collapsed
 *  row-cap at the given content width. */
function questionDescriptionsOverflow(question: ExtensionAskDialogQuestion, contentWidth: number): boolean {
	return question.options.some(option => {
		if (!option?.description?.trim()) return false;
		return wrapOptionDescription(option.description, contentWidth).length > MAX_DESC_ROWS;
	});
}

function splitPreviewSegments(preview: string): PreviewSegment[] {
	const segments: PreviewSegment[] = [];
	const markdownBuffer: string[] = [];
	let fenceChar: string | undefined;
	let fenceLength = 0;
	let fenceLanguage: string | undefined;
	let codeBuffer: string[] = [];

	const flushMarkdown = (): void => {
		if (markdownBuffer.length === 0) return;
		segments.push({ kind: "markdown", text: markdownBuffer.join("\n"), language: undefined });
		markdownBuffer.length = 0;
	};
	const flushCode = (): void => {
		segments.push({ kind: "code", text: codeBuffer.join("\n"), language: fenceLanguage });
		codeBuffer = [];
		fenceChar = undefined;
		fenceLength = 0;
		fenceLanguage = undefined;
	};

	for (const line of replaceTabs(preview).split("\n")) {
		const fenceMatch = /^(\s{0,3})(`{3,}|~{3,})(.*)$/.exec(line);
		if (fenceChar !== undefined) {
			if (fenceMatch) {
				const marker = fenceMatch[2] ?? "";
				const info = fenceMatch[3]?.trim() ?? "";
				if (marker.startsWith(fenceChar) && marker.length >= fenceLength && info === "") {
					flushCode();
					continue;
				}
			}
			codeBuffer.push(line);
			continue;
		}
		if (fenceMatch) {
			flushMarkdown();
			const marker = fenceMatch[2] ?? "";
			fenceChar = marker[0];
			fenceLength = marker.length;
			fenceLanguage = fenceMatch[3]?.trim().split(/\s+/, 1)[0] || undefined;
			codeBuffer = [];
			continue;
		}
		markdownBuffer.push(line);
	}

	if (fenceChar !== undefined) {
		segments.push({ kind: "code", text: codeBuffer.join("\n"), language: fenceLanguage });
	} else {
		flushMarkdown();
	}
	return segments;
}

function renderPreviewContent(preview: string, width: number, textColor: "muted" | "text" = "muted"): string[] {
	const out: string[] = [];
	const mdTheme = getMarkdownTheme();
	const accentStyle = { color: (text: string) => theme.fg(textColor, text) };
	for (const segment of splitPreviewSegments(preview)) {
		if (segment.kind === "code") {
			const highlighted = highlightCode(segment.text, segment.language);
			const text = new Text(highlighted.join("\n"), 0, 0);
			out.push(...text.render(Math.max(1, width)));
			continue;
		}
		const markdown = new Markdown(segment.text, 0, 0, mdTheme, accentStyle);
		out.push(...markdown.render(Math.max(1, width)));
	}
	return out;
}

function renderCachedPreview(cache: PreviewRenderCache, preview: string, width: number): readonly string[] {
	let byWidth = cache.get(preview);
	if (!byWidth) {
		byWidth = new Map();
		cache.set(preview, byWidth);
	}
	let rendered = byWidth.get(width);
	if (!rendered) {
		rendered = renderPreviewContent(preview, width).map(line => `      ${theme.fg("border", "│")} ${line}`);
		byWidth.set(width, rendered);
	}
	return rendered;
}

function normalizedInlineInput(input: string): string {
	return replaceTabs(input).replace(/\s+/g, " ").trim();
}

/**
 * Final display labels for a question's options: sanitized, badged, unique,
 * and sentinel-safe. The recommendation badge goes on BEFORE collision
 * disambiguation — badging itself can collide two rows (`Retry\rnow`
 * recommended vs a literal `Retry now (Recommended)`). Mirrors the guest
 * selector (`#runGuestAskQuestion`): same inputs, same rows, whichever
 * participant answers. State and results keep originals.
 */
function displayOptionLabels(question: ExtensionAskDialogQuestion): string[] {
	const badged = question.options.map((option, index) => {
		const base = sanitizeCarriageReturns(option.label);
		return question.recommended === index && !base.endsWith(RECOMMENDED_SUFFIX)
			? `${base}${RECOMMENDED_SUFFIX}`
			: base;
	});
	return disambiguateDisplayLabels(badged, [OTHER_OPTION, ...GUEST_ACTION_LABELS]);
}

/** Inline markdown code (`` `x` ``) as mono `code` spans, the rest plain, as the ANSI rows render it. */
function inlineCodeSpans(value: string): TspSpan[] {
	return value
		.split(/(`[^`]+`)/)
		.flatMap(piece =>
			piece === ""
				? []
				: piece.length > 2 && piece.startsWith("`") && piece.endsWith("`")
					? [span(piece.slice(1, -1), "code")]
					: [span(piece)],
		);
}

/** An option's native label: the `(Recommended)` suffix goes (the row's badge says it), inline code runs mono. */
function optionLabelSpans(question: ExtensionAskDialogQuestion, optionIndex: number, label: string): TspSpan[] {
	const recommended = question.recommended === optionIndex && label.endsWith(RECOMMENDED_SUFFIX);
	return inlineCodeSpans(recommended ? label.slice(0, -RECOMMENDED_SUFFIX.length) : label);
}

function isAnswered(state: QuestionState): boolean {
	return state.selectedOptions.size > 0 || state.customInput !== undefined;
}

/**
 * A folded question's summary: its options as pills (labels without the `(Recommended)` suffix or
 * code ticks; a click picks or flips one), a multi-select's custom answer as one more chosen pill
 * that opens the question, and a single-select's custom answer as its own line.
 */
function foldSummary(question: ExtensionAskDialogQuestion, state: QuestionState, index: number): FoldSummary {
	const labels = displayOptionLabels(question);
	const note = noteForSubmittedAnswer(question, state)?.text.trim();
	const noteText = note ? normalizedInlineInput(note) : undefined;
	const custom = state.customInput === undefined ? undefined : `Other: “${normalizedInlineInput(state.customInput)}”`;
	if (custom !== undefined && !question.multi) {
		return { kind: "answer", text: custom, note: noteText };
	}
	const pills: AskPill[] = question.options.map((option, optionIndex) => ({
		label: optionLabelSpans(question, optionIndex, labels[optionIndex] ?? option.label)
			.map(part => part.t)
			.join(""),
		chosen: state.selectedOptions.has(option.label),
		act: `pick:${index}:${optionIndex}`,
	}));
	if (custom !== undefined) pills.push({ label: custom, chosen: true, act: `open:${index}` });
	return { kind: "pills", pills, more: `open:${index}`, ...(noteText ? { note: noteText } : {}) };
}

/** A folded question's text: on one line, inline code mono, cut to {@link MAX_FOLD_QUESTION_WIDTH}. */
function foldQuestionSpans(question: ExtensionAskDialogQuestion): TspSpan[] {
	const inline = normalizedInlineInput(sanitizeCarriageReturns(question.question));
	return inlineCodeSpans(truncateToWidth(inline, MAX_FOLD_QUESTION_WIDTH, Ellipsis.Unicode));
}

/** Pick an option: the only answer of a single-select (dropping a custom answer), flipped in a multi-select. */
function pickOption(question: ExtensionAskDialogQuestion, state: QuestionState, optionIndex: number): void {
	const option = question.options[optionIndex];
	if (!option) return;
	const rowKey = `option:${optionIndex}`;
	if (question.multi) {
		if (state.selectedOptions.has(option.label)) {
			state.selectedOptions.delete(option.label);
			clearNoteIfRow(state, rowKey);
		} else {
			state.selectedOptions.add(option.label);
		}
		return;
	}
	state.selectedOptions = new Set([option.label]);
	state.customInput = undefined;
	state.customInputImages = undefined;
	clearNoteUnlessRow(state, rowKey);
}

/** Native `item.detail` of an option row: its description or the typed custom answer, then its note (`em`). */
function describeRowDetail(
	rowItem: QuestionRow,
	question: ExtensionAskDialogQuestion,
	state: QuestionState,
): readonly TspSpan[] | undefined {
	const spans: TspSpan[] = [];
	if (rowItem.kind === "option") {
		const description = question.options[rowItem.optionIndex ?? -1]?.description?.trim();
		if (description) spans.push(...inlineCodeSpans(normalizedInlineInput(description)));
	} else if (state.customInput !== undefined) {
		spans.push(span(`“${normalizedInlineInput(state.customInput)}”`));
	}
	if (state.note && state.noteRowKey === rowItem.key) {
		spans.push(span(`${spans.length > 0 ? "  " : ""}✎ `, "dim"), span(normalizedInlineInput(state.note), "em"));
	}
	return spans.length > 0 ? spans : undefined;
}

/** A prompt's outcome: the submitted value, or after a cancel the draft the host kept, if any. */
type PromptOutcome =
	| { submitted: true; text: string; images: ImageContent[] | undefined }
	| { submitted: false; draft: AskDialogPromptValue | undefined };

/** Normalize the result of either prompt callback. */
function promptOutcome(result: string | AskDialogPromptValue | AskDialogPromptDraft | undefined): PromptOutcome {
	if (result === undefined) return { submitted: false, draft: undefined };
	if (typeof result === "string") return { submitted: true, text: result, images: undefined };
	if ("draft" in result) return { submitted: false, draft: result.draft };
	return { submitted: true, text: result.text, images: result.images?.length ? result.images : undefined };
}

function clearNote(state: QuestionState): void {
	state.note = undefined;
	state.noteImages = undefined;
	state.noteRowKey = undefined;
}

function clearNoteIfRow(state: QuestionState, rowKey: string): void {
	if (state.noteRowKey === rowKey) clearNote(state);
}

function clearNoteUnlessRow(state: QuestionState, rowKey: string): void {
	if (state.noteRowKey !== undefined && state.noteRowKey !== rowKey) clearNote(state);
}

/** The note that goes out with the answer (its row is part of it), and the option it is on (unset for Other). */
function noteForSubmittedAnswer(
	question: ExtensionAskDialogQuestion,
	state: QuestionState,
): { text: string; option?: string } | undefined {
	if (state.note === undefined || state.noteRowKey === undefined) return undefined;
	if (state.noteRowKey === "other") return state.customInput !== undefined ? { text: state.note } : undefined;
	const match = /^option:(\d+)$/.exec(state.noteRowKey);
	const optionIndex = match?.[1] === undefined ? Number.NaN : Number.parseInt(match[1], 10);
	const option = Number.isInteger(optionIndex) ? question.options[optionIndex] : undefined;
	return option && state.selectedOptions.has(option.label) ? { text: state.note, option: option.label } : undefined;
}

function renderRowLabel(
	rowItem: QuestionRow,
	question: ExtensionAskDialogQuestion,
	state: QuestionState,
	selected: boolean,
	mdTheme: MarkdownTheme,
	previewCache: PreviewRenderCache,
	width: number,
	expanded = false,
): string[] {
	const isOption = rowItem.kind === "option";
	const isOther = rowItem.kind === "other";
	const option = isOption ? question.options[rowItem.optionIndex ?? -1] : undefined;
	const checked =
		option !== undefined ? state.selectedOptions.has(option.label) : isOther && state.customInput !== undefined;
	const color = selected ? "accent" : checked ? "toolOutput" : "text";
	const marker = `${theme.fg(checked ? "success" : "dim", optionMarker(theme, question.multi, checked))} `;
	const cursor = selected ? theme.fg("accent", `${theme.nav.cursor} `) : "  ";
	const label = renderInlineMarkdown(rowItem.label, mdTheme, t => theme.fg(color, t));
	const noteMarker = state.note && state.noteRowKey === rowItem.key ? theme.fg("success", "  ✎ note") : "";
	// `width` is already the inner content width supplied by OverlayPanel; when
	// a scrollbar is needed, renderRows() calls this again with one less column.
	// Keep the cursor, option marker, first wrapped label line, and optional
	// note marker within that budget so the outer fit() never truncates them.
	const noteWidth = noteMarker ? visibleWidth(noteMarker) : 0;
	const labelWidth = Math.max(1, width - visibleWidth(cursor) - visibleWidth(marker) - noteWidth);
	const wrappedLabel = wrapTextWithAnsi(label, labelWidth);
	const indent = padding(visibleWidth(cursor) + visibleWidth(marker));
	const lines = [`${cursor}${marker}${wrappedLabel[0] ?? ""}${noteMarker}`];
	for (let i = 1; i < wrappedLabel.length; i++) {
		lines.push(`${indent}${wrappedLabel[i] ?? ""}`);
	}
	if (rowItem.kind === "option") {
		const option = question.options[rowItem.optionIndex ?? -1];
		if (option?.description?.trim()) {
			const wrapped = wrapOptionDescription(option.description, width);
			const shown = expanded ? wrapped : wrapped.slice(0, MAX_DESC_ROWS);
			for (const line of shown) {
				lines.push(`      ${truncateToWidth(line, Math.max(1, width - 6), Ellipsis.Unicode)}`);
			}
		}
		if (option?.preview?.trim()) {
			const previewWidth = Math.max(1, width - 8);
			lines.push(...renderCachedPreview(previewCache, option.preview, previewWidth));
		}
	}
	if (isOther && state.customInput !== undefined) {
		const preview = replaceTabs(state.customInput).replace(/\s+/g, " ").trim();
		lines.push(theme.fg("muted", `      ${truncateToWidth(preview, Math.max(1, width - 6), Ellipsis.Unicode)}`));
	}
	return lines;
}

/**
 * Coerce untrusted dialog questions into a render-safe shape. The live ask
 * dialog is reached from the public `askDialog` extension surface and from
 * streamed tool args, where a question entry can arrive with a missing or
 * non-string `question` field. The render helpers (`replaceTabs`,
 * `renderQuestionTitle`, `foldQuestionSpans`) assume strings, so a malformed
 * entry throws and takes down the whole TUI render loop. Mirrors
 * `normalizeRenderQuestions` on the transcript path.
 */
export function normalizeDialogQuestions(questions: ExtensionAskDialogQuestion[]): ExtensionAskDialogQuestion[] {
	if (!Array.isArray(questions)) return [];
	const out: ExtensionAskDialogQuestion[] = [];
	for (const entry of questions) {
		if (!entry || typeof entry !== "object") continue;
		const q = entry as Partial<ExtensionAskDialogQuestion>;
		const options: ExtensionAskDialogOption[] = [];
		if (Array.isArray(q.options)) {
			for (const opt of q.options) {
				if (!opt || typeof opt !== "object") continue;
				const o = opt as Partial<ExtensionAskDialogOption>;
				options.push({
					// The label is a caller-supplied correlation key echoed verbatim
					// in results (matching the guest path) — sanitize only the
					// display copy (`displayOptionLabels`).
					label: typeof o.label === "string" ? o.label : "",
					...(typeof o.description === "string" ? { description: sanitizeCarriageReturns(o.description) } : {}),
					...(typeof o.preview === "string" ? { preview: sanitizeCarriageReturns(o.preview) } : {}),
				});
			}
		}
		out.push({
			// The id is a caller-supplied correlation key echoed verbatim in
			// results; the dialog never shows it.
			id: typeof q.id === "string" ? q.id : "?",
			// The question is echoed verbatim in results (matching the guest
			// path) — sanitize only the display copy (`wrapQuestionTitle`).
			question: typeof q.question === "string" ? q.question : "",
			...(typeof q.header === "string" ? { header: sanitizeCarriageReturns(q.header) } : {}),
			options,
			...(typeof q.multi === "boolean" ? { multi: q.multi } : {}),
			...(Number.isInteger(q.recommended) ? { recommended: q.recommended } : {}),
		});
	}
	return out;
}

export class AskDialogComponent implements Component {
	#states: QuestionState[];
	/** The question shown open; the rest are folded. */
	#openIndex = 0;
	/** First body row shown in rows; follows the cursor unless {@link #manualScroll}. */
	#scrollOffset = 0;
	/** PgUp/PgDn paged the body: a focused row taller than the panel keeps that offset. */
	#manualScroll = false;
	#bodyRows = MIN_BODY_ROWS;
	#questionCanPage = false;
	#remainingSeconds: number | undefined;
	#countdown: CountdownTimer | undefined;
	#promptActive = false;
	#timeoutExpired = false;
	#closed = false;
	#stableHeight: { key: string; total: number } | undefined;
	#previewCache: PreviewRenderCache = new Map();
	/** Body layouts (`width:rows:open`) known to overflow, drawn one column narrower for the scrollbar. */
	#overflowLayouts = new Set<string>();
	#expanded = false;
	#contentWidth = 76;
	#headerExpandable = false;
	#descExpandable = false;
	/** Collapsed to one line (`app.ask.hide` / the Hide button) while the question stays pending. */
	#hidden = false;
	/** Memoized native description; dropped whenever dialog state may have changed. */
	#native: NativeNode | undefined;
	/** Skip notice {@link #native} was described with (it changes outside this dialog). */
	#nativeSkip: string | undefined;
	/** Bumped whenever another question opens natively, so Tern scrolls it into view. */
	#reveal = 0;
	/** When the countdown runs out (epoch ms), for the native ring. */
	#countdownDeadline = 0;
	/** Once-a-second re-describe while the native countdown ring is shown. */
	#ringTick: NodeJS.Timeout | undefined;
	readonly #panel: OverlayPanel;
	readonly #bodyRegion: PanelRows;
	/** The skip notice's row while it shows, under the body. */
	readonly #skipRegion: PanelRows;
	readonly #questions: ExtensionAskDialogQuestion[];

	constructor(
		questions: ExtensionAskDialogQuestion[],
		private readonly callbacks: AskDialogCallbacks,
		private readonly options: AskDialogOptions = {},
	) {
		this.#questions = normalizeDialogQuestions(questions);
		this.#states = this.#questions.map(question => {
			const recommended = Number.isInteger(question.recommended) ? question.recommended : 0;
			const maxIndex = Math.max(0, question.options.length - 1);
			return {
				selectedOptions: new Set<string>(),
				customInput: undefined,
				customInputImages: undefined,
				customDraft: undefined,
				note: undefined,
				noteImages: undefined,
				noteRowKey: undefined,
				cursorIndex: clamp(recommended ?? 0, 0, maxIndex),
				timedOut: false,
			};
		});
		if (options.timeout && options.timeout > 0) {
			this.#countdown = new CountdownTimer(
				options.timeout,
				options.tui,
				seconds => {
					this.#remainingSeconds = seconds;
					// Fires on every (re)start: the native ring's deadline.
					this.#countdownDeadline = Date.now() + seconds * 1000;
				},
				() => this.#handleTimeout(),
			);
		}
		this.#panel = new OverlayPanel("Ask");
		this.#bodyRegion = new PanelRows();
		this.#skipRegion = new PanelRows();
		this.#panel.addChild(this.#bodyRegion);
		this.#panel.addChild(this.#skipRegion);
	}

	invalidate(): void {
		this.#native = undefined;
		this.#stableHeight = undefined;
		this.#previewCache.clear();
		this.#overflowLayouts.clear();
		this.#panel.invalidate();
	}

	dispose(): void {
		this.#closed = true;
		this.#countdown?.dispose();
		this.#stopRingTick();
		this.#panel.dispose();
	}
	/**
	 * Toggle truncated question headers and option descriptions. Returns false
	 * when there is nothing to expand so the global Ctrl+O listener can still
	 * expand transcript tools.
	 */
	toggleQuestionExpansion(): boolean {
		if (!this.#canToggleExpansion()) return false;
		this.#expanded = !this.#expanded;
		this.invalidate();
		this.#requestRender();
		return true;
	}

	#canToggleExpansion(): boolean {
		if (this.#closed || this.#hidden) return false;
		const question = this.#questions[this.#currentQuestionIndex()];
		if (!question) return false;
		if (this.#expanded) return true;
		return (
			wrapQuestionTitle(question, this.#contentWidth - OPEN_INDENT.length).length > MAX_HEADER_ROWS ||
			questionDescriptionsOverflow(question, this.#contentWidth)
		);
	}

	handleInput(keyData: string): void {
		if (this.#closed || this.#promptActive) return;
		// Reset the inactivity countdown on any key that reaches past the
		// closed/prompt guards, matching HookSelector/HookInput semantics.
		this.#countdown?.reset();
		this.#native = undefined;
		// Esc hands the keys to the composer; cancelling is the Cancel button natively, and in rows
		// the composer's Esc (interrupting the turn cancels the ask).
		if (matchesSelectCancel(keyData)) {
			this.options.releaseKeys?.();
			return;
		}
		// The native card sits in the transcript, out of the composer's way: nothing to hide.
		const native = isNativeRendering();
		if (getKeybindings().matches(keyData, "app.ask.hide")) {
			if (!native) this.#setHidden(!this.#hidden);
			return;
		}
		if (matchesAppToolsExpand(keyData)) {
			this.toggleQuestionExpansion();
			return;
		}
		// Only rows hide (above), so natively this never holds.
		if (this.#hidden) {
			if (matchesKey(keyData, "enter") || matchesKey(keyData, "return") || keyData === "\n") {
				this.#setHidden(false);
			}
			return;
		}
		this.#handleQuestionInput(keyData);
	}

	render(width: number): readonly string[] {
		if (this.#hidden) return this.#renderHidden(width);
		const innerWidth = Math.max(1, width - 4);
		this.#contentWidth = innerWidth;
		// Fixed panel height: measured from the tallest column at spawn and
		// re-measured only when the viewport changes. Opening another question,
		// cursor moves, and later answers never resize the box; content that
		// outgrows it scrolls.
		const totalRows = this.#dialogHeight(innerWidth, process.stdout.rows || 40);
		const skip = this.options.skipNotice?.();
		// The borders, and the skip notice under the body while it shows.
		const bodyRows = Math.max(MIN_BODY_ROWS, totalRows - PANEL_CHROME_ROWS - (skip ? 1 : 0));
		this.#bodyRows = bodyRows;
		this.#panel.title = this.#panelTitle();
		this.#bodyRegion.setLines(this.#renderBody(innerWidth, bodyRows));
		this.#bodyRegion.setHeight(bodyRows);
		this.#skipRegion.setLines(
			skip ? [theme.fg("warning", truncateToWidth(`⚠ ${skip}`, innerWidth, Ellipsis.Unicode))] : [],
		);
		this.#skipRegion.setHeight(skip ? 1 : 0);
		return this.#panel.render(width);
	}

	/** The keys for the open question, themed on one line: the rows panel has no footer, so the host shows them in the folded composer. */
	keyHints(): string {
		const composer = `${editorKey("tui.select.cancel")} composer`;
		const hideKey = editorKey("app.ask.hide");
		const enter = formatKeyHint("enter");
		const upDown = editorKeys("tui.select.up", "tui.select.down");
		const index = this.#currentQuestionIndex();
		const question = this.#questions[index];
		// Enter moves on to the next question; on the last it submits (or opens the first unanswered one).
		const enterAction = index + 1 < this.#questions.length ? "next" : "submit";
		const hints = [
			question?.multi
				? `${formatKeyHint("space")} toggle · ${enter} ${enterAction}`
				: `${enter} select · ${formatKeyHint("n")} note`,
			`${upDown} move`,
		];
		if (this.#questions.length > 1) hints.push(`${formatKeyHints(["tab", "left", "right"])} question`);
		if (this.#questionCanPage) hints.push(`${editorKeys("tui.select.pageUp", "tui.select.pageDown")} page`);
		if (this.#headerExpandable || this.#descExpandable) {
			hints.push(`${expandKeyHint()} ${this.#expanded ? "collapse" : "expand"}`);
		}
		hints.push(composer);
		if (hideKey) hints.push(`${hideKey} hide`);
		return theme.fg("dim", hints.join(" · "));
	}

	/**
	 * Inline in the transcript, as an ask card (`omp.ask.card`): every question stacked in one
	 * column, the focused one open (its header, the question, its answers as radio/check rows and the
	 * highlighted option's preview), the rest folded to their question over their answer or option
	 * pills, then the action bar (the countdown, Note, Cancel and the primary Submit).
	 */
	describe(cx: DescribeContext): NativeNode {
		const ring = this.#countdown !== undefined && cx.supports("meter");
		if (ring) this.#startRingTick();
		const skip = this.options.skipNotice?.();
		if (this.#native && this.#nativeSkip === skip) return this.#native;
		const open = this.#currentQuestionIndex();
		const body: NativeChild[] = [];
		let answered = 0;
		for (let index = 0; index < this.#questions.length; index++) {
			const question = this.#questions[index];
			const state = this.#states[index];
			if (!question || !state) continue;
			if (isAnswered(state)) answered += 1;
			body.push(
				index === open
					? this.#describeOpenQuestion(index, question, state)
					: foldQuestion({
							key: `q${index}`,
							question: foldQuestionSpans(question),
							answered: isAnswered(state),
							summary: foldSummary(question, state, index),
							open: `open:${index}`,
						}),
			);
		}
		const total = this.#questions.length;
		this.#native = askCard({
			...(total > 1 ? { progress: `${answered} of ${total} answered` } : {}),
			body,
			...(skip ? { skip } : {}),
			actions: this.#describeActions(ring),
		});
		this.#nativeSkip = skip;
		return this.#native;
	}

	/** The countdown: a ring when the terminal draws meters, else a clocked `elapsed`. */
	#describeTimer(countdown: CountdownTimer, ring: boolean): NativeNode {
		if (!ring) return countdown.describe();
		const total = Math.max(1, this.options.timeout ?? 1);
		const left = Math.max(0, this.#countdownDeadline - Date.now());
		return node(
			"meter",
			{
				value: Math.round((left / total) * 1000) / 1000,
				style: "ring",
				size: "sm",
				label: `${Math.ceil(left / 1000)}s`,
				title: "Answers the recommended option when the time runs out",
			},
			undefined,
			"timer",
		);
	}

	/** The open question: its header, the question as markdown, its answers as radio/check rows, the highlighted preview. */
	#describeOpenQuestion(index: number, question: ExtensionAskDialogQuestion, state: QuestionState): NativeNode {
		const rows = this.#questionRows(question);
		state.cursorIndex = clamp(state.cursorIndex, 0, Math.max(0, rows.length - 1));
		const children: NativeChild[] = [];
		const header = question.header?.trim();
		if (header) children.push(text([span(replaceTabs(header), "muted")], { role: "omp.ask.header" }));
		children.push(
			node(
				"md",
				{ text: replaceTabs(sanitizeCarriageReturns(question.question)), role: "omp.ask.question" },
				undefined,
				"question",
			),
		);
		// Radios (`omp.ask.option`, `omp.ask.other`) or checks (`omp.ask.check`, `omp.ask.other.check`); a chosen
		// row is `accent`-toned (a check also carries the check glyph), apart from the highlighted row (`selected`).
		const items = rows.map(rowItem => {
			const option = rowItem.kind === "option" ? question.options[rowItem.optionIndex ?? -1] : undefined;
			const checked =
				rowItem.kind === "other"
					? state.customInput !== undefined
					: option !== undefined && state.selectedOptions.has(option.label);
			const recommended = rowItem.kind === "option" && question.recommended === rowItem.optionIndex;
			const detail =
				describeRowDetail(rowItem, question, state) ??
				(rowItem.kind === "other" ? [span("Type your own answer")] : undefined);
			const role =
				rowItem.kind === "other"
					? question.multi
						? "omp.ask.other.check"
						: "omp.ask.other"
					: question.multi
						? "omp.ask.check"
						: "omp.ask.option";
			return node(
				"item",
				{
					// The badge replaces the ANSI `(Recommended)` suffix.
					label:
						rowItem.kind === "other"
							? [span(OTHER_LABEL)]
							: optionLabelSpans(question, rowItem.optionIndex ?? -1, rowItem.label),
					role,
					...(detail ? { detail } : {}),
					...(recommended ? { value: [span("Recommended")] } : {}),
					...(checked ? { tone: "accent" as const, ...(question.multi ? { icon: "check" } : {}) } : {}),
					// Notes this row without picking it, wherever the cursor is.
					actions: { menu: ["note"] },
				},
				undefined,
				rowItem.key,
			);
		});
		// Keyed per question: a click aimed at one question's list never lands on the next after it advances.
		children.push(
			node("list", { selected: rows[state.cursorIndex]?.key ?? null, role: "omp.ask.options" }, items, `q${index}`),
		);
		const highlighted = rows[state.cursorIndex];
		const option = highlighted?.kind === "option" ? question.options[highlighted.optionIndex ?? -1] : undefined;
		if (option?.preview?.trim()) {
			children.push(
				node("md", { text: replaceTabs(option.preview), role: "omp.ask.preview" }, undefined, "preview"),
			);
		}
		return openQuestion(`q${index}`, children, this.#reveal);
	}

	/**
	 * The action bar under the questions: the countdown, then Note, Cancel and the primary Submit
	 * (every answer, or the first unanswered question while one is left). Buttons say what they do;
	 * their keys live in their tooltips.
	 */
	#describeActions(ring: boolean): NativeNode {
		const cancel = actionButton("Cancel", "cancel", { title: "Cancel without answering" });
		const lead: NativeNode[] = this.#countdown ? [this.#describeTimer(this.#countdown, ring)] : [];
		const note = actionButton("Note", "note", {
			keys: "n",
			title: "Add a note to the highlighted answer  n",
		});
		const submit = actionButton("Submit", "submit", { tone: "accent", title: "Submit the answers" });
		return actionBar([...lead, null, note, cancel, submit]);
	}

	/**
	 * Pointer actions: a fold's `open:<q>` opens question q; a pill's `pick:<q>:<o>` picks option o of
	 * q (flips it in a multi-select) without moving focus; a click on an open answer row is Enter on
	 * it (Space for a multi-select option, so it flips; its double-click `activate` is Enter); Submit
	 * sends the answers or opens the first unanswered question, Note runs what `n` runs on the
	 * highlighted row, Cancel cancels the ask, and a row's menu Note highlights that row and notes it.
	 */
	handleNativeEvent(event: NativeUiEvent): void {
		if (this.#closed || this.#promptActive) return;
		this.options.claimKeys?.();
		if (event.type === "action") {
			if (event.act === "cancel") {
				this.#finishCancel();
				return;
			}
			if (event.act === "submit") {
				this.#countdown?.reset();
				this.#submitOrOpenUnanswered();
			} else if (event.act === "note") this.#noteFromPointer(event.key);
			else this.#openOrPick(event.act);
			return;
		}
		if (event.type !== "select" && event.type !== "activate") return;
		if (leafKey(event.key) !== `q${this.#currentQuestionIndex()}`) return;
		const active = this.#activeQuestionState();
		if (!active) return;
		const { question, state } = active;
		const rows = this.#questionRows(question);
		const index = rows.findIndex(rowItem => rowItem.key === event.item);
		const rowItem = rows[index];
		if (!rowItem) return;
		this.#countdown?.reset();
		state.cursorIndex = index;
		this.#manualScroll = false;
		const toggles = event.type === "select" && question.multi === true && rowItem.kind === "option";
		this.#commitRow(question, state, rowItem, !toggles);
		this.#requestRender();
	}

	/** A fold's `open:<q>`, or a pill's `pick:<q>:<o>`; anything else does nothing. */
	#openOrPick(act: string): void {
		const open = /^open:(\d+)$/.exec(act);
		if (open) {
			const index = Number(open[1]);
			if (index >= this.#questions.length) return;
			this.#countdown?.reset();
			this.#openQuestionAt(index);
			this.#requestRender();
			return;
		}
		const pick = /^pick:(\d+):(\d+)$/.exec(act);
		if (!pick) return;
		const question = this.#questions[Number(pick[1])];
		const state = this.#states[Number(pick[1])];
		if (!question || !state || !question.options[Number(pick[2])]) return;
		this.#countdown?.reset();
		pickOption(question, state, Number(pick[2]));
		this.#requestRender();
	}

	/** Open question `index`; `row` puts its cursor on its first or last row, else it keeps its own. */
	#openQuestionAt(index: number, row?: "first" | "last"): void {
		const question = this.#questions[index];
		const state = this.#states[index];
		if (!question || !state) return;
		if (row) state.cursorIndex = row === "first" ? 0 : this.#questionRows(question).length - 1;
		this.#manualScroll = false;
		if (this.#openIndex === index) return;
		this.#openIndex = index;
		this.#reveal += 1;
	}

	/**
	 * Submit (natively the button; Enter past the last question everywhere): send the answers once
	 * every question has one, else open the first unanswered question. When that question is
	 * already open there is nowhere left to send the user, so it submits anyway (the rest go unanswered).
	 */
	#submitOrOpenUnanswered(): void {
		const unanswered = this.#states.findIndex(state => !isAnswered(state));
		if (unanswered < 0 || unanswered === this.#currentQuestionIndex()) {
			this.#finishSubmit();
			return;
		}
		this.#openQuestionAt(unanswered);
		this.#requestRender();
	}

	/**
	 * Keys over the stacked questions: ↑/↓ walk the open question's rows and cross into the previous
	 * question's last row or the next one's first; ←/→ (Tab/Shift+Tab) open the previous/next
	 * question; Enter picks (single-select) and moves on, Space flips a multi-select option, `n` notes.
	 * PgUp/PgDn page the rows body through a focused row taller than the panel (a long preview).
	 */
	#handleQuestionInput(keyData: string): void {
		const index = this.#currentQuestionIndex();
		const active = this.#activeQuestionState();
		if (!active) return;
		const { question, state } = active;
		const rows = this.#questionRows(question);
		const lastRow = Math.max(0, rows.length - 1);
		state.cursorIndex = clamp(state.cursorIndex, 0, lastRow);
		const pageDown = matchesSelectPageDown(keyData);
		if (pageDown || matchesSelectPageUp(keyData)) {
			const page = Math.max(1, this.#bodyRows - 1);
			this.#scrollOffset = Math.max(0, this.#scrollOffset + (pageDown ? page : -page));
			this.#manualScroll = true;
			this.#requestRender();
			return;
		}
		if (matchesSelectUp(keyData)) {
			if (state.cursorIndex > 0) state.cursorIndex -= 1;
			else if (index > 0) this.#openQuestionAt(index - 1, "last");
			this.#manualScroll = false;
			this.#requestRender();
			return;
		}
		if (matchesSelectDown(keyData)) {
			if (state.cursorIndex < lastRow) state.cursorIndex += 1;
			else if (index + 1 < this.#questions.length) this.#openQuestionAt(index + 1, "first");
			this.#manualScroll = false;
			this.#requestRender();
			return;
		}
		if (matchesKey(keyData, "tab") && index + 1 >= this.#questions.length) {
			this.options.releaseKeys?.();
			return;
		}
		const switched = handleTabSwitchKey(keyData, direction => {
			const next = index + direction;
			if (next >= 0 && next < this.#questions.length) this.#openQuestionAt(next);
		});
		if (switched) {
			this.#requestRender();
			return;
		}
		const rowItem = rows[state.cursorIndex];
		if (!rowItem) return;
		if (keyData === "n" || keyData === "N") {
			this.#pressNote();
			return;
		}
		const isEnter = matchesKey(keyData, "enter") || matchesKey(keyData, "return") || keyData === "\n";
		const isSpace = matchesKey(keyData, "space") || keyData === " ";
		if (!isEnter && !(question.multi && isSpace)) return;
		this.#commitRow(question, state, rowItem, isEnter);
		this.#requestRender();
	}

	/** `n`: a note on the highlighted row of the open question. */
	#pressNote(): void {
		this.#countdown?.reset();
		const active = this.#activeQuestionState();
		const rowItem = active ? this.#questionRows(active.question)[active.state.cursorIndex] : undefined;
		if (active && rowItem) void this.#promptForNote(active.question, active.state, rowItem);
	}

	/**
	 * Note from the action bar (keypath `…/note`: the highlighted row) or from a row's menu (keypath
	 * `…/q<i>/<row>`: that row, highlighted first). A menu on a list the dialog has moved past does nothing.
	 */
	#noteFromPointer(keypath: string): void {
		const [listKey, rowKey] = keypath.split("/").slice(-2);
		if (listKey && /^q\d+$/.test(listKey)) {
			const active = this.#activeQuestionState();
			if (!active || listKey !== `q${this.#currentQuestionIndex()}`) return;
			const index = this.#questionRows(active.question).findIndex(row => row.key === rowKey);
			if (index < 0) return;
			active.state.cursorIndex = index;
			this.#manualScroll = false;
			this.#requestRender();
		}
		this.#pressNote();
	}

	/** Re-describe once a second while a countdown ring is shown (the ring's value is data, not a terminal clock). */
	#startRingTick(): void {
		if (this.#ringTick || this.#closed) return;
		this.#ringTick = setInterval(() => {
			if (this.#closed) {
				this.#stopRingTick();
				return;
			}
			this.#requestRender();
		}, 1000);
		this.#ringTick.unref?.();
	}

	#stopRingTick(): void {
		if (!this.#ringTick) return;
		clearInterval(this.#ringTick);
		this.#ringTick = undefined;
	}

	#dialogHeight(width: number, termRows: number): number {
		const key = `${width}:${termRows}:${this.#expanded ? 1 : 0}`;
		if (this.#stableHeight?.key === key) return this.#stableHeight.total;
		const total = this.#measureHeight(width, termRows);
		this.#stableHeight = { key, total };
		return total;
	}

	/** Measure the tallest column's natural height (whichever question is
	 *  open), clamped to DIALOG_HEIGHT_RATIO of the terminal and to the
	 *  terminal less ASK_RESERVED_ROWS, but never below MIN_BODY_ROWS of body.
	 *  Measured at spawn and on viewport changes only — never as the cursor
	 *  moves, a question opens, or answers change — so the box size is stable
	 *  for the dialog's lifetime at a given terminal size. */
	#measureHeight(width: number, termRows: number): number {
		const maxHeight = Math.max(
			PANEL_CHROME_ROWS + MIN_BODY_ROWS,
			Math.min(Math.floor(termRows * DIALOG_HEIGHT_RATIO), termRows - ASK_RESERVED_ROWS),
		);
		// Every question folded, a blank row between two, plus what opening the tallest one adds.
		let folded = 0;
		let opening = 0;
		let count = 0;
		for (let index = 0; index < this.#questions.length; index++) {
			const question = this.#questions[index];
			const state = this.#states[index];
			if (!question || !state) continue;
			const fold = this.#foldedLines(question, state, index, width).length;
			folded += fold;
			opening = Math.max(opening, this.#openQuestionLines(question, state, width).lines.length - fold);
			count += 1;
		}
		const body = folded + opening + Math.max(0, count - 1);
		return Math.min(Math.max(MIN_DIALOG_ROWS, PANEL_CHROME_ROWS + Math.max(MIN_BODY_ROWS, body)), maxHeight);
	}

	#titleText(): string {
		return this.#remainingSeconds === undefined ? "Ask" : `Ask (${this.#remainingSeconds}s)`;
	}

	/** The panel's title: {@link #titleText}, and with several questions how many have an answer (the native card's progress). */
	#panelTitle(): string {
		const total = this.#questions.length;
		if (total < 2) return this.#titleText();
		const answered = this.#states.filter(isAnswered).length;
		return `${this.#titleText()} · ${answered} of ${total} answered`;
	}

	#setHidden(hidden: boolean): void {
		if (this.#hidden === hidden) return;
		this.#hidden = hidden;
		this.#countdown?.reset();
		this.#requestRender();
	}

	/** Hidden: one line in the composer's place — title (with countdown), the question clipped to fit, and how to bring it back. */
	#renderHidden(width: number): readonly string[] {
		const hideKey = editorKey("app.ask.hide");
		const enter = formatKeyHint("enter");
		const show = hideKey ? `${hideKey}/${enter}` : enter;
		const hints = [`${show} show`, `${editorKey("tui.select.cancel")} composer`];
		const hint = theme.fg("dim", ` · ${hints.join(" · ")}`);
		const label = theme.fg("accent", `${this.#titleText()} hidden:`);
		const question = this.#questions[this.#currentQuestionIndex()];
		const more = this.#questions.length > 1 ? theme.fg("dim", ` (+${this.#questions.length - 1} more)`) : "";
		const summary = normalizedInlineInput(sanitizeCarriageReturns(question?.question ?? ""));
		const summaryWidth = Math.max(1, width - visibleWidth(label) - visibleWidth(more) - visibleWidth(hint) - 1);
		const clipped = truncateToWidth(summary, summaryWidth, Ellipsis.Unicode);
		return [truncateToWidth(`${label} ${theme.fg("muted", clipped)}${more}${hint}`, width, Ellipsis.Unicode)];
	}

	#currentQuestionIndex(): number {
		return clamp(this.#openIndex, 0, Math.max(0, this.#questions.length - 1));
	}

	#requestRender(): void {
		this.#native = undefined;
		this.options.tui?.requestRender();
	}

	#questionRows(question: ExtensionAskDialogQuestion): QuestionRow[] {
		const display = displayOptionLabels(question);
		const rows: QuestionRow[] = question.options.map((option, index) => ({
			kind: "option",
			key: `option:${index}`,
			label: display[index] ?? sanitizeCarriageReturns(option.label),
			optionIndex: index,
		}));
		rows.push({ kind: "other", key: "other", label: OTHER_OPTION, optionIndex: undefined });
		return rows;
	}

	#activeQuestionState(): { question: ExtensionAskDialogQuestion; state: QuestionState } | undefined {
		const question = this.#questions[this.#currentQuestionIndex()];
		const state = this.#states[this.#currentQuestionIndex()];
		if (!question || !state) return undefined;
		return { question, state };
	}

	/** Enter (`isEnter`) or multi-select Space on a row: toggle, select, or prompt for its answer. */
	#commitRow(
		question: ExtensionAskDialogQuestion,
		state: QuestionState,
		rowItem: QuestionRow,
		isEnter: boolean,
	): void {
		if (rowItem.kind === "other") {
			void this.#promptForCustomInput(question, state, rowItem);
			return;
		}
		const optionIndex = rowItem.optionIndex ?? -1;
		if (!question.options[optionIndex]) return;
		if (question.multi && isEnter) {
			// Enter confirms the current selection without toggling the
			// focused option; Space toggles. Moves on like single-select
			// Enter (#8252).
			this.#advanceAfterQuestion();
			return;
		}
		pickOption(question, state, optionIndex);
		if (question.multi) this.#requestRender();
		else this.#advanceAfterQuestion();
	}

	/** Move past the current question: the next one opens; past the last, the answers go or the first unanswered question opens. */
	#advanceAfterQuestion(): void {
		const current = this.#currentQuestionIndex();
		if (current + 1 < this.#questions.length) {
			this.#openQuestionAt(current + 1);
			this.#requestRender();
		} else {
			this.#submitOrOpenUnanswered();
		}
	}

	/**
	 * Open the host prompt, image-capable when available. Returns the callback's promise so each
	 * caller keeps one `await` before clearing `#promptActive`, which the host's restore relies on.
	 */
	#openPrompt(
		prompt: AskDialogPrompt,
		prefill: AskDialogPromptValue | undefined,
	): Promise<string | AskDialogPromptValue | AskDialogPromptDraft | undefined> {
		return this.callbacks.onImagePrompt
			? this.callbacks.onImagePrompt(prompt, prefill)
			: this.callbacks.onPrompt(prompt, prefill?.text);
	}

	async #promptForCustomInput(
		question: ExtensionAskDialogQuestion,
		state: QuestionState,
		rowItem: QuestionRow,
	): Promise<void> {
		this.#promptActive = true;
		try {
			// A cancelled edit's draft wins over the submitted answer it was revising.
			const prefill =
				state.customDraft ??
				(state.customInput === undefined
					? undefined
					: { text: state.customInput, images: state.customInputImages });
			const result = await this.#openPrompt({ title: "Custom answer", question: question.question }, prefill);
			if (this.#closed) return;
			const input = promptOutcome(result);
			if (!input.submitted) {
				const draft = input.draft;
				state.customDraft = draft && (draft.text.trim() !== "" || draft.images?.length) ? draft : undefined;
				return;
			}
			state.customDraft = undefined;
			if (input.text.trim() === "") {
				// Submitting an empty value unselects the custom answer.
				state.customInput = undefined;
				state.customInputImages = undefined;
				clearNoteIfRow(state, rowItem.key);
				return;
			}
			state.customInput = input.text;
			state.customInputImages = input.images;
			if (!question.multi) {
				state.selectedOptions.clear();
				clearNoteUnlessRow(state, rowItem.key);
			}
			// A lone multi-select stays open to confirm (Enter submits it).
			if (!question.multi || this.#questions.length > 1) this.#advanceAfterQuestion();
		} finally {
			this.#promptActive = false;
			this.#runDeferredTimeout();
			this.#requestRender();
		}
	}

	async #promptForNote(
		question: ExtensionAskDialogQuestion,
		state: QuestionState,
		rowItem: QuestionRow,
	): Promise<void> {
		this.#promptActive = true;
		try {
			const isReedit = state.noteRowKey === rowItem.key;
			const prefill =
				isReedit && state.note !== undefined ? { text: state.note, images: state.noteImages } : undefined;
			const result = await this.#openPrompt(
				{ title: `Note for ${rowItem.label}`, question: question.question },
				prefill,
			);
			if (this.#closed) return;
			const note = promptOutcome(result);
			if (!note.submitted) return;
			state.note = note.text;
			state.noteImages = note.images;
			state.noteRowKey = rowItem.key;
		} finally {
			this.#promptActive = false;
			this.#runDeferredTimeout();
			this.#requestRender();
		}
	}

	/**
	 * The rows body: the stacked column scrolled so the focused row shows, with the open question's
	 * head when both fit. A layout known to overflow draws one column narrower for the scrollbar.
	 */
	#renderBody(width: number, rows: number): string[] {
		const open = this.#currentQuestionIndex();
		const active = this.#activeQuestionState();
		if (active) {
			const { question, state } = active;
			state.cursorIndex = clamp(state.cursorIndex, 0, Math.max(0, this.#questionRows(question).length - 1));
			this.#headerExpandable = wrapQuestionTitle(question, width - OPEN_INDENT.length).length > MAX_HEADER_ROWS;
			this.#descExpandable = questionDescriptionsOverflow(question, width);
		} else {
			this.#headerExpandable = false;
			this.#descExpandable = false;
		}
		const layoutKey = `${width}:${rows}:${open}`;
		const knownOverflow = this.#overflowLayouts.has(layoutKey);
		let column = this.#renderColumn(knownOverflow && width > 1 ? width - 1 : width);
		if (!knownOverflow && width > 1 && column.lines.length > rows) {
			this.#overflowLayouts.add(layoutKey);
			column = this.#renderColumn(width - 1);
		}
		const { lines: allLines, rowStarts, openStart } = column;
		const cursor = active?.state.cursorIndex ?? 0;
		const cursorStart = rowStarts[cursor] ?? openStart;
		const cursorEnd = rowStarts[cursor + 1] ?? allLines.length;
		this.#questionCanPage = cursorEnd - cursorStart > rows;
		this.#scrollOffset = this.#scrollOffsetForCursor(openStart, cursorStart, cursorEnd, rows, allLines.length);
		const scrollView = new ScrollView(allLines, {
			height: rows,
			scrollbar: "auto",
			theme: { track: t => theme.fg("muted", t), thumb: t => theme.fg("accent", t) },
		});
		scrollView.setScrollOffset(this.#scrollOffset);
		const lines = [...scrollView.render(width)];
		while (lines.length < rows) lines.push("");
		return lines.slice(0, rows);
	}

	/** Every question in one column, a blank row between two: the open one whole, the rest folded. */
	#renderColumn(width: number): ColumnLines {
		const open = this.#currentQuestionIndex();
		const lines: string[] = [];
		let openStart = 0;
		let rowStarts: number[] = [];
		for (let index = 0; index < this.#questions.length; index++) {
			const question = this.#questions[index];
			const state = this.#states[index];
			if (!question || !state) continue;
			if (lines.length > 0) lines.push("");
			if (index !== open) {
				lines.push(...this.#foldedLines(question, state, index, width));
				continue;
			}
			openStart = lines.length;
			const block = this.#openQuestionLines(question, state, width);
			rowStarts = block.rowStarts.map(start => openStart + start);
			lines.push(...block.lines);
		}
		return { lines, rowStarts, openStart };
	}

	/** A folded question: its mark and question over the summary its native fold shows. */
	#foldedLines(question: ExtensionAskDialogQuestion, state: QuestionState, index: number, width: number): string[] {
		return renderFoldedQuestion(
			{
				question: foldQuestionSpans(question)
					.map(part => part.t)
					.join(""),
				answered: isAnswered(state),
				summary: foldSummary(question, state, index),
			},
			width,
		);
	}

	/**
	 * The open question: its header, its mark and question (capped at {@link MAX_HEADER_ROWS} until
	 * Ctrl+O), then its answer rows with their descriptions, previews and notes.
	 */
	#openQuestionLines(question: ExtensionAskDialogQuestion, state: QuestionState, width: number): OpenQuestionLines {
		const lines: string[] = [];
		const textWidth = Math.max(1, width - OPEN_INDENT.length);
		const header = question.header?.trim();
		if (header) {
			lines.push(
				`${OPEN_INDENT}${theme.fg("muted", truncateToWidth(replaceTabs(header), textWidth, Ellipsis.Unicode))}`,
			);
		}
		const mark = isAnswered(state) ? theme.fg("success", "✓") : theme.fg("accent", "○");
		const title = renderQuestionTitle(
			question,
			textWidth,
			this.#expanded ? Number.POSITIVE_INFINITY : MAX_HEADER_ROWS,
		);
		if (title.length === 0) title.push("");
		for (const [index, line] of title.entries()) lines.push(`${index === 0 ? `${mark} ` : OPEN_INDENT}${line}`);
		const mdTheme = getMarkdownTheme();
		const rowStarts: number[] = [];
		for (const [index, rowItem] of this.#questionRows(question).entries()) {
			rowStarts.push(lines.length);
			lines.push(
				...renderRowLabel(
					rowItem,
					question,
					state,
					index === state.cursorIndex,
					mdTheme,
					this.#previewCache,
					width,
					this.#expanded,
				),
			);
		}
		rowStarts.push(lines.length);
		return { lines, rowStarts };
	}

	/**
	 * The body offset that keeps the focused row (`cursorStart`..`cursorEnd`) in view, moving as
	 * little as it can: up to the open question's head when head and row fit together, else to the
	 * row. A row taller than the body shows its top, or after PgUp/PgDn the page chosen within it.
	 */
	#scrollOffsetForCursor(
		openStart: number,
		cursorStart: number,
		cursorEnd: number,
		rows: number,
		totalRows: number,
	): number {
		const maxOffset = Math.max(0, totalRows - rows);
		if (maxOffset === 0) return 0;
		let nextOffset = clamp(this.#scrollOffset, 0, maxOffset);
		const tall = cursorEnd - cursorStart > rows;
		if (this.#manualScroll && tall) {
			// A page must not expose another option while Enter still targets this one.
			nextOffset = clamp(nextOffset, cursorStart, cursorEnd - rows);
		} else {
			const top = cursorEnd - openStart <= rows ? openStart : cursorStart;
			if (top < nextOffset) nextOffset = top;
			else if (cursorEnd > nextOffset + rows) nextOffset = tall ? cursorStart : cursorEnd - rows;
		}
		return clamp(nextOffset, 0, maxOffset);
	}

	#handleTimeout(): void {
		if (this.#closed) return;
		if (this.#promptActive) {
			this.#timeoutExpired = true;
			return;
		}
		this.options.onTimeout?.();
		for (let index = 0; index < this.#questions.length; index++) {
			const question = this.#questions[index];
			const state = this.#states[index];
			if (!question || !state) continue;
			if (state.selectedOptions.size === 0 && state.customInput === undefined) {
				const noteMatch = /^option:(\d+)$/.exec(state.noteRowKey ?? "");
				const notedIndex = noteMatch ? Number.parseInt(noteMatch[1], 10) : Number.NaN;
				const fallbackIndex =
					Number.isInteger(notedIndex) && question.options[notedIndex]
						? notedIndex
						: clamp(question.recommended ?? 0, 0, Math.max(0, question.options.length - 1));
				const fallback = question.options[fallbackIndex];
				if (fallback) state.selectedOptions.add(fallback.label);
				state.timedOut = true;
			}
		}
		this.#finishSubmit();
	}

	#runDeferredTimeout(): void {
		if (!this.#timeoutExpired) return;
		this.#timeoutExpired = false;
		this.#handleTimeout();
	}

	#finishSubmit(): void {
		if (this.#closed) return;
		this.#closed = true;
		this.#countdown?.dispose();
		this.#stopRingTick();
		this.callbacks.onSubmit({ kind: "submit", results: this.#buildResults() });
	}

	#finishCancel(): void {
		if (this.#closed) return;
		this.#closed = true;
		this.#countdown?.dispose();
		this.#stopRingTick();
		this.callbacks.onCancel();
	}

	#buildResults(): ExtensionAskDialogResultItem[] {
		const results: ExtensionAskDialogResultItem[] = [];
		for (let index = 0; index < this.#questions.length; index++) {
			const question = this.#questions[index];
			const state = this.#states[index];
			if (!question || !state) continue;
			const selectedOptions = question.options
				.map(option => option.label)
				.filter(label => state.selectedOptions.has(label));
			const note = noteForSubmittedAnswer(question, state);
			results.push({
				id: question.id,
				question: question.question,
				options: question.options.map(option => option.label),
				multi: question.multi ?? false,
				selectedOptions,
				customInput: state.customInput,
				customInputImages: state.customInputImages,
				note: note?.text,
				noteImages: note === undefined ? undefined : state.noteImages,
				noteOption: note?.option,
				timedOut: state.timedOut || undefined,
			});
		}
		return results;
	}
}
