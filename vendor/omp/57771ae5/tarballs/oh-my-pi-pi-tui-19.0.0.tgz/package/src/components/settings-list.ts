import { formatKeyHint } from "../app-keybindings";
import { editorKey, editorKeys } from "../chrome/keybinding-hints";
import { fuzzyFilter } from "../fuzzy";
import { getKeybindings } from "../keybindings";
import { extractPrintableText } from "../keys";
import type { MouseRoutable, SgrMouseEvent } from "../mouse";
import { slugify } from "@oh-my-pi/pi-utils";
import type { TspPrefsControl, TspPrefsRow, TspPrefsSection, TspProps, TspSpan } from "@oh-my-pi/pi-wire";
import { col, node, span } from "../native/describe";
import { sameItems, sameProps } from "../native/memo";
import { plainLine, plainText } from "../native/spans";
import type { DescribeContext, NativeChild, NativeNode, NativeUiEvent } from "../native/node";
import type { Component } from "../tui";
import { Ellipsis, padding, replaceTabs, truncateToWidth, visibleWidth, wrapTextWithAnsi } from "../utils";
import { ScrollView } from "./scroll-view";
import { FormField, type FormFieldOptions, type FormFieldTheme, SelectFormField, TextFormField } from "./form";
import { MenuSelection } from "./menu-selection";

function sanitizeSingleLine(text: string): string {
	return replaceTabs(text)
		.replace(/[\r\n]+/g, " ")
		.replace(/\s+/g, " ")
		.trim();
}

/** Described `item` node cached on the setting, rebuilt when a visible field (e.g. `currentValue`) changes. */
const kNativeItem = Symbol("settingsList.nativeItem");

interface NativeDescribedSetting extends SettingItem {
	[kNativeItem]?: { signature: string; node: NativeNode };
}

function hasMouseRouter(component: Component): component is Component & MouseRoutable {
	return "routeMouse" in component && typeof component.routeMouse === "function";
}

/** Builds a row's editor from its current value; `done` closes it, with the value picked if one was. */
export type SettingEditor = (currentValue: string, done: (selectedValue?: string) => void) => Component;

export interface SettingItem {
	/** Unique identifier for this setting */
	id: string;
	/** Display label (left side) */
	label: string;
	/** Optional description shown when selected */
	description?: string;
	/** Optional risk note shown in warning styling above the description, with a glyph on the row. */
	warning?: string;
	/** Current value to display (right side) */
	currentValue: string;
	/** If provided, Enter/Space cycles through these values */
	values?: string[];
	/** If provided, Enter opens this submenu. Receives current value and done callback. */
	submenu?: SettingEditor;
	/**
	 * A `values` row's choices as a menu: a native settings page's popup button
	 * opens it ({@link SettingsList.openSubmenuFor}); Enter/Space still cycle.
	 */
	menu?: SettingEditor;
	/** True when the displayed setting differs from its default value. */
	changed?: boolean;
	/** The default, as a native settings page names it in the changed dot's title. */
	defaultLabel?: string;
	/** Render as a non-interactive section heading. Skipped by navigation and search. */
	heading?: boolean;
}

/** A row's open editor as a native settings page shows it (`TspPrefsProps.editing`). */
export interface PrefsEditing {
	row: string;
	draft?: string;
	cursor?: number;
	option?: string;
}

/** A submenu that reports the option it highlights (multiselect toggles) to a native settings page. */
export interface PrefsOptionSource {
	readonly prefsOption: string | undefined;
}

/** Where a setting row goes on a native settings page: its section and, for search results, its page. */
export interface PrefsSectionRef {
	id: string;
	title: string;
	page?: string;
}

/** The section id for a section title (`"Status Line"` → `"status-line"`). */
export function prefsSectionId(title: string): string {
	return slugify(title);
}

/** A setting as a native settings row, given its typed control; `undefined` for headings. */
export function settingPrefsRow(item: SettingItem, control: TspPrefsControl): TspPrefsRow | undefined {
	if (item.heading) return undefined;
	const row: TspPrefsRow = {
		id: item.id,
		label: plainLine(item.label),
		hint: item.description ? plainLine(item.description) : undefined,
		warning: item.warning ? plainLine(item.warning) : undefined,
		changed: item.changed === true ? true : undefined,
		defaultLabel: item.changed && item.defaultLabel ? plainLine(item.defaultLabel) : undefined,
		control,
	};
	return row;
}

function hasPrefsOption(component: Component): component is Component & PrefsOptionSource {
	return "prefsOption" in component;
}

export interface SettingsListTheme {
	label: (text: string, selected: boolean, changed: boolean) => string;
	value: (text: string, selected: boolean, changed: boolean) => string;
	description: (text: string) => string;
	/** Style for risk notes and the row warning glyph. Falls back to `description` when omitted. */
	warning?: (text: string) => string;
	/** Glyph marking rows that carry a `warning`. Omitted hides the row marker. */
	warningMark?: string;
	cursor: string;
	hint: (text: string) => string;
	/** Style for section heading rows (dimmed when outside the active section). Falls back to `hint` when omitted. */
	heading?: (text: string, dimmed: boolean) => string;
	/** Style for sidebar section names in the split layout. Falls back to label/hint. */
	section?: (text: string, active: boolean) => string;
	/** Hover band applied to the full row under the mouse pointer. */
	hovered?: (text: string) => string;
}

/** A contiguous run of items under one heading, derived from the item list. */
interface SettingSection {
	name: string;
	firstItemIndex: number;
	lastItemIndex: number;
}

/** Optional behavior overrides for {@link SettingsList}. */
export interface SettingsListOptions {
	/**
	 * "auto" (default) renders the section sidebar layout when headings exist
	 * and the width allows; "flat" always renders inline heading rows.
	 */
	layout?: "auto" | "flat";
	/**
	 * When false, printable input is ignored (no internal type-to-filter) and
	 * the search status line is never rendered. Use when a parent component
	 * owns the query. Default true.
	 */
	typeToSearch?: boolean;
	/** Text shown when the list has no items at all. */
	emptyText?: string;
	/**
	 * Footer hint line (hint-styled, replaces the default navigation hint).
	 * An empty string removes the hint row and its leading blank entirely —
	 * use when the host renders its own footer.
	 */
	hint?: string;
	/** Fixed split-sidebar width (columns incl. indent+gap); default derives from section names. */
	sidebarWidth?: number;
}

/** Searchable text for a setting item: label, id, value, description, warning, and cycle values. */
export function getSettingItemFilterText(item: SettingItem): string {
	let text = `${item.label} ${item.id} ${item.currentValue}`;
	if (item.description) {
		text += ` ${item.description}`;
	}
	if (item.warning) {
		text += ` ${item.warning}`;
	}
	if (item.values) {
		text += ` ${item.values.join(" ")}`;
	}
	return sanitizeSingleLine(text);
}

export class SettingsList implements Component {
	#items: readonly SettingItem[] = [];
	#filteredItems: readonly SettingItem[] = [];
	#selection: MenuSelection<SettingItem>;
	#theme: SettingsListTheme;
	#selectedIndex = 0;
	#maxVisible: number;
	#onChange: (id: string, newValue: string) => void;
	#onCancel: () => void;
	#options: SettingsListOptions;
	#filterQuery = "";
	#sectionFocus = false;
	#lastNotifiedSelectionId: string | undefined;

	/** Fired when the selected item changes (navigation, filtering, or setItems). */
	onSelectionChange?: (item: SettingItem | undefined) => void;

	// Submenu state
	#submenuComponent: Component | null = null;
	#submenuItemId: string | null = null;
	// Mouse support: hover highlight and per-render hit maps (content-line
	// index → item id), rebuilt by every main-list render.
	#hoveredItemId: string | null = null;
	#hitRows: (string | undefined)[] = [];
	#sidebarHitRows: (string | undefined)[] = [];
	#sidebarHitCol = 0;
	#nativeList?: { props: TspProps<"list">; items: readonly NativeNode[]; node: NativeNode };
	#nativeRoot?: { body: NativeChild; hint: string; node: NativeNode };
	constructor(
		items: SettingItem[],
		maxVisible: number,
		theme: SettingsListTheme,
		onChange: (id: string, newValue: string) => void,
		onCancel: () => void,
		options: SettingsListOptions = {},
	) {
		this.#selection = new MenuSelection(items, {
			getKey: item => item.id,
			getSearchText: getSettingItemFilterText,
			isDisabled: item => item.heading === true,
			filter: (candidates, query) =>
				fuzzyFilter(
					candidates.filter(item => !item.heading),
					query,
					getSettingItemFilterText,
				),
		});
		this.#syncSelectionState();
		this.#maxVisible = maxVisible;
		this.#theme = theme;
		this.#onChange = onChange;
		this.#onCancel = onCancel;
		this.#options = options;
		this.#lastNotifiedSelectionId = this.getSelectedItem()?.id;
	}
	/** Return item, selection, filter, and submenu state for debug inspection. */
	debugState(): Record<string, unknown> {
		const selected = this.getSelectedItem();
		return {
			itemCount: this.#items.length,
			filteredItemCount: this.#filteredItems.length,
			selectedIndex: this.#filteredItems.length > 0 ? this.#selectedIndex : -1,
			selectedItemId: selected?.id ?? null,
			selectedItemLabel: selected?.label ?? null,
			filterText: this.#filterQuery,
			sectionFocused: this.#sectionFocus,
			submenuOpen: this.#submenuComponent !== null,
		};
	}

	/** Expose the active submenu to the debug tree walker. */
	get debugChildren(): readonly Component[] {
		return this.#submenuComponent ? [this.#submenuComponent] : [];
	}

	/** The currently selected item, or undefined when empty or on a heading. */
	getSelectedItem(): SettingItem | undefined {
		const item = this.#filteredItems[this.#selectedIndex];
		return item && !item.heading ? item : undefined;
	}

	/** Move selection to the item with `id`. Returns false when it is not visible. */
	selectItem(id: string): boolean {
		const item = this.#filteredItems.find(candidate => !candidate.heading && candidate.id === id);
		if (!item) return false;
		this.#selection.setSelectedKey(id);
		this.#sectionFocus = false;
		this.#syncSelectionState();
		this.#notifySelection();
		return true;
	}

	/** True while keyboard focus is on the section headings instead of the setting rows. */
	get sectionFocused(): boolean {
		return this.#sectionFocus;
	}

	/** Whether section focus has anywhere to go: 2+ derived sections in the current view. */
	hasSectionFocusTargets(): boolean {
		return this.#sections().length >= 2;
	}

	/**
	 * Toggle keyboard focus between section headings and setting rows. While
	 * focused, Up/Down jump whole sections and Enter/Esc return to the rows.
	 * Engages only when {@link hasSectionFocusTargets}; returns the new state.
	 */
	toggleSectionFocus(): boolean {
		this.#sectionFocus = !this.#sectionFocus && this.hasSectionFocusTargets();
		return this.#sectionFocus;
	}

	/** True while an item submenu owns input. */
	hasOpenSubmenu(): boolean {
		return this.#submenuComponent !== null;
	}

	/** The open submenu and the row that opened it, if any. */
	get openSubmenu(): { id: string; component: Component } | undefined {
		const component = this.#submenuComponent;
		const id = this.#submenuItemId;
		return component && id !== null ? { id, component } : undefined;
	}

	/**
	 * The visible settings as native page sections: rows in list order, each
	 * in the section `sectionOf` (given the row and the heading above it) names,
	 * sections in order of their first row (ranked search results gather
	 * under their section). Rows `control` has no typed control for are left
	 * out.
	 */
	prefsSections(
		sectionOf: (item: SettingItem, heading: SettingItem | undefined) => PrefsSectionRef,
		control: (item: SettingItem) => TspPrefsControl | undefined,
	): TspPrefsSection[] {
		const sections: { ref: PrefsSectionRef; rows: TspPrefsRow[] }[] = [];
		let heading: SettingItem | undefined;
		for (const item of this.#filteredItems) {
			if (item.heading) {
				heading = item;
				continue;
			}
			const typed = control(item);
			const row = typed && settingPrefsRow(item, typed);
			if (!row) continue;
			const ref = sectionOf(item, heading);
			const section = sections.find(candidate => candidate.ref.id === ref.id);
			if (section) section.rows.push(row);
			else sections.push({ ref, rows: [row] });
		}
		return sections.map(({ ref, rows }) => ({ ...ref, rows }));
	}

	/** The row with keyboard focus, or while the section rail has focus the focused section's heading label. */
	prefsFocus(): { row?: string; section?: string } {
		if (this.#sectionFocus) {
			const sections = this.#sections();
			return { section: sections[this.#activeSectionIndex(sections)]?.name };
		}
		return { row: this.getSelectedItem()?.id };
	}

	/**
	 * The open editor as a native page draws it: a choice's highlighted option
	 * (when `inlineMenu(id)` says the row's choices fit its popup menu), a text
	 * field's draft and cursor (dots when masked), a multiselect's highlighted
	 * option; `null` when nothing is open or the editor has no native control
	 * (the host shows that one itself).
	 */
	prefsEditing(inlineMenu: (id: string) => boolean): PrefsEditing | null {
		const open = this.openSubmenu;
		if (!open) return null;
		const { id, component } = open;
		if (component instanceof SelectFormField) {
			if (!inlineMenu(id)) return null;
			return { row: id, option: component.selectList.getSelectedItem()?.value };
		}
		if (component instanceof TextFormField) {
			// Native inline text editing has no error slot; show the form until corrected.
			if (component.hasError) return null;
			const draft = component.getValue();
			return {
				row: id,
				draft: component.input.mask ? "•".repeat(draft.length) : draft,
				cursor: component.input.getCursor(),
			};
		}
		if (hasPrefsOption(component)) return { row: id, option: component.prefsOption };
		return null;
	}

	/** Applies `value` to a cycling (boolean/enum) row the way Enter does: the row shows it and `onChange` runs. */
	applyValue(id: string, value: string): void {
		const item = this.#items.find(candidate => !candidate.heading && candidate.id === id);
		if (!item || item.submenu || !item.values?.includes(value)) return;
		this.selectItem(id);
		item.currentValue = value;
		this.#onChange(item.id, value);
	}

	/**
	 * Opens row `id`'s submenu (a cycling row's `menu`) the way Enter opens a
	 * submenu, leaving one already open for it; returns it.
	 */
	openSubmenuFor(id: string): Component | undefined {
		const open = this.openSubmenu;
		if (open?.id === id) return open.component;
		if (open || !this.selectItem(id)) return undefined;
		const item = this.getSelectedItem();
		const editor = item?.submenu ?? item?.menu;
		if (!item || !editor) return undefined;
		this.#openSubmenu(item, editor);
		return this.#submenuComponent ?? undefined;
	}

	#notifySelection(): void {
		const item = this.getSelectedItem();
		if (item?.id === this.#lastNotifiedSelectionId) return;
		this.#lastNotifiedSelectionId = item?.id;
		this.onSelectionChange?.(item);
	}

	/** Resize the visible viewport (fullscreen hosts call this every render). */
	setMaxVisible(rows: number): void {
		const next = Math.max(3, Math.floor(rows));
		if (next === this.#maxVisible) return;
		this.#maxVisible = next;
		this.#clampSelectedIndex();
	}

	/** Move the selection one step for a wheel notch. */
	handleWheel(delta: -1 | 1): void {
		if (this.#submenuComponent) return;
		// Wheel is row-level interaction: it returns focus to the rows.
		this.#sectionFocus = false;
		this.#moveSelection(delta, false);
	}

	/** Move the selection one step for a wheel notch if the pointer is within the settings pane. */
	handleWheelAt(delta: -1 | 1, _line: number, col: number): boolean {
		if (this.#submenuComponent) return false;
		if (this.#sidebarHitCol > 0 && col < this.#sidebarHitCol) {
			return false;
		}
		this.handleWheel(delta);
		return true;
	}

	/** Highlight the item under the pointer (null clears). */
	setHoverItem(id: string | null): void {
		this.#hoveredItemId = id;
	}

	/**
	 * Resolve a pointer position against the last rendered frame. `line` is the
	 * 0-based content-line index within this component's render output, `col`
	 * the 0-based column. Sidebar rows resolve to the section's first item.
	 */
	hitTest(line: number, col: number): string | undefined {
		if (this.#submenuComponent) return undefined;
		if (this.#sidebarHitCol > 0 && col < this.#sidebarHitCol) {
			return this.#sidebarHitRows[line];
		}
		return this.#hitRows[line];
	}

	/**
	 * Like {@link hitTest}, but only rows the pointer is visually on: sidebar
	 * jump targets are excluded so hovering section names does not light up
	 * pane rows.
	 */
	hoverTest(line: number, col: number): string | undefined {
		if (this.#submenuComponent) return undefined;
		if (this.#sidebarHitCol > 0 && col < this.#sidebarHitCol) return undefined;
		return this.#hitRows[line];
	}

	/**
	 * Route a mouse event into an open submenu (coordinates are local to this
	 * list's rendered lines). Returns false when no submenu is open; submenus
	 * that do not implement {@link MouseRoutable} consume the event silently.
	 */
	routeSubmenuMouse(event: SgrMouseEvent, line: number, col: number): boolean {
		if (!this.#submenuComponent) return false;
		if (hasMouseRouter(this.#submenuComponent)) {
			this.#submenuComponent.routeMouse(event, line, col);
		}
		return true;
	}

	getSearchQuery(): string {
		return this.#filterQuery;
	}

	hasSearchQuery(): boolean {
		return this.#filterQuery.length > 0;
	}

	clearSearch(): void {
		if (this.#filterQuery.length === 0) return;
		this.#setFilter("");
	}

	/** Update an item's currentValue */
	updateValue(id: string, newValue: string): void {
		const item = this.#items.find(i => i.id === id);
		if (!item) return;

		item.currentValue = newValue;
		if (this.#filterQuery.trim()) {
			this.#selection.setItems(this.#items, this.#selection.selectedKey);
			this.#syncSelectionState();
		}
	}

	/**
	 * Replace the entire items array. Selection is preserved by item id when
	 * the previous selection still survives the active filter, otherwise
	 * clamped to the last filtered item (or 0 if there are no matches).
	 * An open submenu is left untouched — its lifetime is bounded by its own
	 * done callback, and `#closeSubmenu` re-resolves the restored item on exit.
	 */
	setItems(items: SettingItem[]): void {
		const selectedId = this.#selection.selectedKey;
		const previousIndex = this.#selection.selectedIndex;
		this.#selection.setItems(items, selectedId);
		if (selectedId !== undefined && !this.#selection.visibleItems.some(item => item.id === selectedId)) {
			this.#selection.setSelectedIndex(Math.min(previousIndex, this.#selection.visibleItems.length - 1));
		}
		this.#syncSelectionState();
		if (this.#sectionFocus && !this.hasSectionFocusTargets()) this.#sectionFocus = false;
		this.#notifySelection();
	}

	#setFilter(filter: string): void {
		if (filter.trim()) this.#sectionFocus = false;
		this.#selection.setQuery(filter, false);
		this.#syncSelectionState();
		this.#notifySelection();
	}

	/** Move selection by one selectable item, wrapping or clamping, and skipping headings. */
	#moveSelection(delta: -1 | 1, wrap = true): void {
		if (!this.#selection.move(delta, wrap)) return;
		this.#syncSelectionState();
		this.#notifySelection();
	}

	#syncSelectionState(): void {
		this.#items = this.#selection.items;
		this.#filteredItems = this.#selection.visibleItems;
		this.#filterQuery = this.#selection.query;
		this.#selectedIndex = Math.max(0, this.#selection.selectedIndex);
	}

	#setSelectedIndex(index: number): void {
		this.#selection.setSelectedIndex(index);
		this.#syncSelectionState();
	}

	/** Sections derived from heading rows in the filtered list. */
	#sections(): SettingSection[] {
		const sections: SettingSection[] = [];
		let current: SettingSection | null = null;
		for (let i = 0; i < this.#filteredItems.length; i++) {
			const item = this.#filteredItems[i];
			if (item.heading) {
				current = { name: item.label, firstItemIndex: -1, lastItemIndex: -1 };
				sections.push(current);
				continue;
			}
			if (!current) {
				current = { name: "", firstItemIndex: i, lastItemIndex: i };
				sections.push(current);
			}
			if (current.firstItemIndex < 0) current.firstItemIndex = i;
			current.lastItemIndex = i;
		}
		return sections.filter(section => section.firstItemIndex >= 0);
	}

	#activeSectionIndex(sections: SettingSection[]): number {
		for (let i = sections.length - 1; i >= 0; i--) {
			if (sections[i].firstItemIndex <= this.#selectedIndex) return i;
		}
		return 0;
	}

	/** Jump to the next/previous section; page through items when there are no sections. */
	#jumpSection(delta: -1 | 1): void {
		const sections = this.#sections();
		if (sections.length < 2) {
			const len = this.#filteredItems.length;
			if (len === 0) return;
			const index = Math.max(0, Math.min(this.#selectedIndex + delta * this.#maxVisible, len - 1));
			this.#setSelectedIndex(index);
		} else {
			const next = (this.#activeSectionIndex(sections) + delta + sections.length) % sections.length;
			this.#setSelectedIndex(sections[next].firstItemIndex);
		}
		this.#notifySelection();
	}

	#clampSelectedIndex(): void {
		this.#setSelectedIndex(this.#selectedIndex);
	}

	#renderSearchStatus(width: number): string {
		const query = sanitizeSingleLine(this.#filterQuery);
		const statusText = query ? `  Search: ${query}` : "  Type to search";
		return this.#theme.hint(truncateToWidth(statusText, width, Ellipsis.Omit));
	}

	#shouldRenderSearchStatus(): boolean {
		if (this.#options.typeToSearch === false) return false;
		return this.#items.length > this.#maxVisible || this.#filterQuery.length > 0;
	}

	#handleSearchInput(data: string): boolean {
		if (this.#options.typeToSearch === false) return false;
		if (this.#items.length === 0) return false;

		const kb = getKeybindings();
		if (kb.matches(data, "tui.editor.deleteCharBackward")) {
			if (this.#filterQuery.length === 0) return false;
			const chars = [...this.#filterQuery];
			chars.pop();
			this.#setFilter(chars.join(""));
			return true;
		}

		const printableText = extractPrintableText(data);
		if (printableText === undefined) return false;
		if (this.#filterQuery.length === 0 && printableText.trim().length === 0) return false;

		this.#setFilter(this.#filterQuery + printableText);
		return true;
	}

	invalidate(): void {
		this.#submenuComponent?.invalidate?.();
	}

	/**
	 * Every render path is padded to the same stable height so interacting with
	 * the list (navigating sections, opening submenus, filtering, condition-gated
	 * rows appearing) never resizes the panel. A live region that thrashes its
	 * height forces the terminal to re-anchor and can strand scrollback rows.
	 */
	#stableHeight(): number {
		// viewport + blank + 3 description rows, plus the optional search status
		// row and the optional blank+hint footer.
		let height = this.#maxVisible + 4;
		if (this.#options.typeToSearch !== false) height += 1;
		if (this.#options.hint !== "") height += 2;
		return height;
	}

	#padLines(lines: string[]): string[] {
		while (lines.length < this.#stableHeight()) lines.push("");
		return lines;
	}

	render(width: number): readonly string[] {
		// Hit maps describe exactly the frame being produced now.
		this.#hitRows = [];
		this.#sidebarHitRows = [];
		this.#sidebarHitCol = 0;
		// If submenu is active, render it instead (padded to the list's stable
		// height so opening/closing a submenu does not resize the panel).
		if (this.#submenuComponent) {
			return this.#padLines([...this.#submenuComponent.render(width)]);
		}

		return this.#padLines(this.#renderMainList(width));
	}

	/**
	 * A `list` of setting `item`s (label, current value on the right, risk note
	 * and description as detail; headings as disabled items) keyed by setting id,
	 * with the selection and search query, plus the footer hint. An open submenu
	 * replaces the list and describes itself.
	 */
	describe(_cx: DescribeContext): NativeNode {
		let body: NativeChild;
		let hint = "";
		if (this.#submenuComponent) {
			body = this.#submenuComponent;
		} else {
			body = this.#describeList();
			hint = this.#options.hint === "" ? "" : plainLine(this.#hintText());
		}
		const cached = this.#nativeRoot;
		if (cached && cached.body === body && cached.hint === hint) return cached.node;
		const children: NativeChild[] = [body];
		if (hint) children.push(node("text", { spans: [span(hint, "muted")] }, undefined, "hint"));
		const root = col(children, { role: "omp.settings", gap: "sm" });
		this.#nativeRoot = { body, hint, node: root };
		return root;
	}

	/**
	 * Pointer actions do what a click does in the settings hosts: `select` moves
	 * the selection to the row, or activates it (Enter) when it already is the
	 * selection; `activate` selects and activates.
	 */
	handleNativeEvent(event: NativeUiEvent): void {
		if (this.#submenuComponent || (event.type !== "select" && event.type !== "activate")) return;
		const wasSelected = this.getSelectedItem()?.id === event.item;
		if (!this.selectItem(event.item)) return;
		if (event.type === "activate" || wasSelected) this.#activateItem();
	}

	#describeList(): NativeNode {
		const items: NativeNode[] = [];
		for (const item of this.#filteredItems) items.push(this.#describeItem(item));
		const cachedMax = this.#nativeList?.props.max;
		const props: TspProps<"list"> = {
			selected: this.getSelectedItem()?.id ?? null,
			filter: this.#filterQuery.trim() || undefined,
			empty:
				this.#items.length === 0 ? (this.#options.emptyText ?? "No settings available") : "No matching settings",
			max:
				typeof cachedMax === "object" && cachedMax.lines === this.#maxVisible
					? cachedMax
					: { lines: this.#maxVisible },
		};
		const cached = this.#nativeList;
		if (cached && sameProps(cached.props, props) && sameItems(cached.items, items)) return cached.node;
		const list = node("list", props, items, "list");
		this.#nativeList = { props, items, node: list };
		return list;
	}

	#describeItem(item: NativeDescribedSetting): NativeNode {
		const value = plainLine(String(item.currentValue ?? ""));
		const changed = item.changed === true;
		const signature = `${item.heading === true}\0${item.label}\0${value}\0${changed}\0${item.warning ?? ""}\0${item.description ?? ""}`;
		const cached = item[kNativeItem];
		if (cached?.signature === signature) return cached.node;
		let described: NativeNode;
		if (item.heading) {
			described = node(
				"item",
				{ label: [span(plainLine(item.label), "strong")], disabled: true, role: "omp.settings.heading" },
				undefined,
				item.id,
			);
		} else {
			const label: TspSpan[] = [span(plainLine(item.label), changed ? "accent" : undefined)];
			if (item.warning && this.#theme.warningMark)
				label.push(span(` ${plainText(this.#theme.warningMark)}`, "warning"));
			const detail: TspSpan[] = [];
			if (item.warning) detail.push(span(plainLine(item.warning), "warning"));
			if (item.description) {
				if (detail.length > 0) detail.push(span(" "));
				detail.push(span(plainLine(item.description), "muted"));
			}
			described = node(
				"item",
				{
					label,
					value: [span(value, changed ? "accent" : "muted")],
					detail: detail.length > 0 ? detail : undefined,
				},
				undefined,
				item.id,
			);
		}
		item[kNativeItem] = { signature, node: described };
		return described;
	}

	#hintText(): string {
		const jumpHint =
			this.#sections().length >= 2
				? `${editorKeys("tui.select.pageUp", "tui.select.pageDown")} to jump sections · `
				: "";
		return (
			this.#options.hint ??
			`${editorKey("tui.select.confirm")}/${formatKeyHint("space")} to change · ${jumpHint}Type to search · ${editorKey("tui.select.cancel")} to cancel`
		);
	}

	/** Warning glyph suffix for a row that carries a risk note, or "" when none applies. */
	#warningMark(item: SettingItem): string {
		return item.warning && this.#theme.warningMark ? ` ${this.#theme.warningMark}` : "";
	}

	#renderItemRow(
		item: SettingItem,
		index: number,
		maxLabelWidth: number,
		rowWidth: number,
		dimmed = false,
		headingCursor = false,
	): string {
		if (item.heading) {
			const headingStyle = this.#theme.heading ?? ((text: string) => this.#theme.hint(text));
			const prefix = headingCursor ? this.#theme.cursor : "  ";
			return truncateToWidth(`${prefix}${headingStyle(item.label, dimmed)}`, Math.max(0, rowWidth));
		}
		// While section focus owns the keyboard, the row cursor hides so the
		// section cursor is the single focus indicator.
		const isSelected = index === this.#selectedIndex && !this.#sectionFocus;
		const prefix = isSelected ? this.#theme.cursor : "  ";
		const prefixWidth = visibleWidth(prefix);
		const mark = this.#warningMark(item);
		const labelPlain = item.label + mark;
		const labelPad = padding(Math.max(0, maxLabelWidth - visibleWidth(labelPlain)));
		const separator = "  ";
		const valueMaxWidth = rowWidth - prefixWidth - maxLabelWidth - visibleWidth(separator) - 2;
		const valuePlain = truncateToWidth(String(item.currentValue ?? ""), valueMaxWidth, Ellipsis.Omit);
		const hovered = !isSelected && this.#theme.hovered !== undefined && item.id === this.#hoveredItemId;
		// De-emphasized rows (outside the active section) render as plain text
		// under one dim wash so inner label/value colors don't fight it.
		if (dimmed && !isSelected) {
			const text = this.#theme.hint(
				truncateToWidth(`  ${labelPlain}${labelPad}${separator}${valuePlain}`, Math.max(0, rowWidth)),
			);
			return hovered && this.#theme.hovered ? this.#theme.hovered(text) : text;
		}
		const warningStyle = this.#theme.warning ?? this.#theme.description;
		const labelText =
			this.#theme.label(item.label, isSelected, item.changed === true) + (mark ? warningStyle(mark) : "") + labelPad;
		const valueText = this.#theme.value(valuePlain, isSelected, item.changed === true);
		const text = truncateToWidth(prefix + labelText + separator + valueText, Math.max(0, rowWidth));
		// Pointer hover paints a band behind the whole row, distinct from the
		// keyboard selection (cursor glyph + accent) which stays where it is.
		if (hovered && this.#theme.hovered) {
			return this.#theme.hovered(text);
		}
		return text;
	}

	#renderMainList(width: number): string[] {
		const lines: string[] = [];

		if (this.#items.length === 0) {
			lines.push(this.#theme.hint(`  ${this.#options.emptyText ?? "No settings available"}`));
			return lines;
		}

		if (this.#filteredItems.length === 0) {
			if (this.#shouldRenderSearchStatus()) {
				lines.push(this.#renderSearchStatus(width));
			}
			lines.push(this.#theme.hint("  No matching settings"));
			lines.push("");
			const editKey = editorKey("tui.editor.deleteCharBackward");
			const cancelKey = editorKey("tui.select.cancel");
			lines.push(truncateToWidth(this.#theme.hint(`  ${editKey} to edit search · ${cancelKey} to cancel`), width));
			return lines;
		}

		const sections = this.#sections();
		const splitLines =
			this.#options.layout !== "flat" && !this.#filterQuery.trim() && sections.length >= 2
				? this.#renderSplitList(width, sections)
				: null;
		if (splitLines) {
			lines.push(...splitLines);
		} else {
			const viewportHeight = Math.min(this.#maxVisible, this.#filteredItems.length);
			const startIndex = Math.max(
				0,
				Math.min(this.#selectedIndex - Math.floor(viewportHeight / 2), this.#filteredItems.length - viewportHeight),
			);
			const labelWidths = this.#filteredItems
				.filter(item => !item.heading)
				.map(item => visibleWidth(item.label + this.#warningMark(item)));
			const maxLabelWidth = Math.min(30, labelWidths.length > 0 ? Math.max(...labelWidths) : 0);
			const itemRowsOverflow = this.#filteredItems.length > viewportHeight;
			const itemRowWidth = Math.max(0, width - (itemRowsOverflow ? 1 : 0));
			const visibleItems = this.#filteredItems.slice(startIndex, startIndex + viewportHeight);
			// In the flat layout the active section's heading row carries the
			// section-focus cursor (the split layout shows it in the sidebar).
			const active = sections[this.#activeSectionIndex(sections)];
			const focusedHeadingIndex = this.#sectionFocus && active?.name ? active.firstItemIndex - 1 : -1;
			const itemRows = visibleItems.map((item, index) =>
				this.#renderItemRow(
					item,
					startIndex + index,
					maxLabelWidth,
					itemRowWidth,
					false,
					startIndex + index === focusedHeadingIndex,
				),
			);
			visibleItems.forEach((item, index) => {
				this.#hitRows[index] = item.heading ? undefined : item.id;
			});
			const scrollView = new ScrollView(itemRows, {
				height: viewportHeight,
				scrollbar: "auto",
				totalRows: this.#filteredItems.length,
				theme: {
					track: text => this.#theme.hint(text),
					thumb: text => this.#theme.label(text, true, false),
				},
			});
			scrollView.setScrollOffset(startIndex);
			lines.push(...scrollView.render(width));
			// Pad short lists to the full viewport so the panel height is constant.
			while (lines.length < this.#maxVisible) lines.push("");
		}

		// Description area: 1 blank + exactly 3 rows, clamped with an ellipsis,
		// so moving between items with/without descriptions never shifts rows.
		// The risk note leads so it survives the clamp when both are present.
		lines.push("");
		const selectedItem = this.#filteredItems[this.#selectedIndex];
		const descLines: string[] = [];
		if (selectedItem && !selectedItem.heading) {
			if (selectedItem.warning) {
				const warningStyle = this.#theme.warning ?? this.#theme.description;
				const mark = this.#theme.warningMark ? `${this.#theme.warningMark} ` : "";
				for (const line of wrapTextWithAnsi(`${mark}${selectedItem.warning}`, width - 4)) {
					descLines.push(warningStyle(`  ${line}`));
				}
			}
			if (selectedItem.description) {
				for (const line of wrapTextWithAnsi(selectedItem.description, width - 4)) {
					descLines.push(this.#theme.description(`  ${line}`));
				}
			}
			if (descLines.length > 3) {
				descLines.splice(3);
				descLines[2] = truncateToWidth(`${descLines[2]}…`, width);
			}
		}
		while (descLines.length < 3) descLines.push("");
		lines.push(...descLines);

		// External-search mode: the host renders the query; skip the status row.
		if (this.#options.typeToSearch !== false) {
			lines.push(this.#renderSearchStatus(width));
		}

		// Add hint (suppressed entirely when the host owns the footer)
		if (this.#options.hint !== "") {
			lines.push("");
			lines.push(truncateToWidth(this.#theme.hint(`  ${this.#hintText()}`), width));
		}

		return lines;
	}

	/**
	 * Split layout: section sidebar on the left, every item on the right with
	 * rows outside the active section dimmed so the section under the cursor
	 * pops. Up/Down navigation flows across section boundaries; the sidebar
	 * highlight follows the selection. Returns null when the width cannot fit
	 * both panes, falling back to the flat single-column layout.
	 */
	#renderSplitList(width: number, sections: SettingSection[]): string[] | null {
		const sectionNames = sections.map(section => section.name || "Other");
		let nameWidth = 0;
		for (const name of sectionNames) nameWidth = Math.max(nameWidth, visibleWidth(name));
		const sidebarWidth = this.#options.sidebarWidth ?? Math.min(22, nameWidth) + 4; // 2-space indent + 2-space gap
		const paneWidth = width - sidebarWidth - 2; // "│ " separator
		// Below this the value column starves (2 prefix + 30 label + 2 gap + ~25 value).
		if (paneWidth < 60) return null;

		const activeIndex = this.#activeSectionIndex(sections);
		const active = sections[activeIndex];

		const sectionStyle =
			this.#theme.section ??
			((text: string, isActive: boolean) =>
				isActive ? this.#theme.label(text, true, false) : this.#theme.hint(text));
		const sidebarRows = sectionNames.map((name, i) => {
			const label = truncateToWidth(name, sidebarWidth - 4, Ellipsis.Omit);
			// Section focus parks the cursor glyph on the active sidebar entry.
			const prefix = this.#sectionFocus && i === activeIndex ? this.#theme.cursor : "  ";
			return `${prefix}${sectionStyle(label, i === activeIndex)}${padding(sidebarWidth - visibleWidth(prefix) - visibleWidth(label))}`;
		});

		// Right pane: the whole list, continuously scrollable. The active
		// section's heading row belongs to its dim-exempt range.
		const activeStart = active.name ? active.firstItemIndex - 1 : active.firstItemIndex;
		const viewportHeight = Math.min(this.#maxVisible, this.#filteredItems.length);
		const startRow = Math.max(
			0,
			Math.min(this.#selectedIndex - Math.floor(viewportHeight / 2), this.#filteredItems.length - viewportHeight),
		);
		// Label column width spans all items so the layout stays stable across sections.
		const labelWidths = this.#filteredItems
			.filter(item => !item.heading)
			.map(item => visibleWidth(item.label + this.#warningMark(item)));
		const maxLabelWidth = Math.min(30, labelWidths.length > 0 ? Math.max(...labelWidths) : 0);
		const overflow = this.#filteredItems.length > viewportHeight;
		const rowWidth = Math.max(0, paneWidth - (overflow ? 1 : 0));
		const itemRows: string[] = [];
		for (let r = 0; r < viewportHeight; r++) {
			const index = startRow + r;
			const item = this.#filteredItems[index];
			if (!item) break;
			const dimmed = index < activeStart || index > active.lastItemIndex;
			itemRows.push(this.#renderItemRow(item, index, maxLabelWidth, rowWidth, dimmed));
		}
		const scrollView = new ScrollView(itemRows, {
			height: viewportHeight,
			scrollbar: "auto",
			totalRows: this.#filteredItems.length,
			theme: {
				track: text => this.#theme.hint(text),
				thumb: text => this.#theme.label(text, true, false),
			},
		});
		scrollView.setScrollOffset(startRow);
		const paneRows = scrollView.render(paneWidth);

		// Hit maps: sidebar rows resolve to each section's first item; pane rows
		// to the item they render.
		this.#sidebarHitCol = sidebarWidth;
		for (let i = 0; i < sectionNames.length; i++) {
			this.#sidebarHitRows[i] = this.#filteredItems[sections[i].firstItemIndex]?.id;
		}
		for (let r = 0; r < viewportHeight; r++) {
			const item = this.#filteredItems[startRow + r];
			if (item && !item.heading) this.#hitRows[r] = item.id;
		}

		const separator = this.#theme.hint("│ ");
		const lines: string[] = [];
		const height = Math.max(this.#maxVisible, sidebarRows.length);
		for (let i = 0; i < height; i++) {
			const left = sidebarRows[i] ?? padding(sidebarWidth);
			lines.push(truncateToWidth(left + separator + (paneRows[i] ?? ""), width));
		}
		return lines;
	}

	handleInput(data: string): void {
		// If submenu is active, delegate all input to it
		// The submenu's onCancel (triggered by escape) will call done() which closes it
		if (this.#submenuComponent) {
			this.#submenuComponent.handleInput?.(data);
			return;
		}

		// Main list input handling
		const kb = getKeybindings();
		if (kb.matches(data, "tui.select.cancel")) {
			if (this.#filterQuery.length > 0) {
				this.clearSearch();
				return;
			}
			if (this.#sectionFocus) {
				this.#sectionFocus = false;
				return;
			}
			this.#onCancel();
			return;
		}

		if (this.#handleSearchInput(data)) {
			return;
		}

		if (this.#filteredItems.length === 0) return;

		if (kb.matches(data, "tui.select.up")) {
			if (this.#sectionFocus) this.#jumpSection(-1);
			else this.#moveSelection(-1);
		} else if (kb.matches(data, "tui.select.down")) {
			if (this.#sectionFocus) this.#jumpSection(1);
			else this.#moveSelection(1);
		} else if (kb.matches(data, "tui.select.pageDown")) {
			this.#jumpSection(1);
		} else if (kb.matches(data, "tui.select.pageUp")) {
			this.#jumpSection(-1);
		} else if (kb.matches(data, "tui.select.confirm") || data === " " || data === "\n") {
			// Confirm on a focused heading drops into its first setting.
			if (this.#sectionFocus) this.#sectionFocus = false;
			else this.#activateItem();
		}
	}

	#activateItem(): void {
		const item = this.#filteredItems[this.#selectedIndex];
		if (!item || item.heading) return;

		if (item.submenu) {
			this.#openSubmenu(item, item.submenu);
		} else if (item.values && item.values.length > 0) {
			// Cycle through values
			const currentIndex = item.values.indexOf(item.currentValue);
			const nextIndex = (currentIndex + 1) % item.values.length;
			const newValue = item.values[nextIndex];
			item.currentValue = newValue;
			this.#onChange(item.id, newValue);
		}
	}

	/** Opens `editor` for `item` with its current value (so it pre-selects); a pick updates the row and runs `onChange`. */
	#openSubmenu(item: SettingItem, editor: SettingEditor): void {
		this.#submenuItemId = item.id;
		this.#submenuComponent = editor(item.currentValue, (selectedValue?: string) => {
			if (selectedValue !== undefined) {
				item.currentValue = selectedValue;
				this.#onChange(item.id, selectedValue);
			}
			this.#closeSubmenu();
		});
	}

	#closeSubmenu(): void {
		this.#submenuComponent = null;
		// Restore selection to the item that opened the submenu. Resolve by id:
		// onChange handlers may have called setItems while the submenu was open,
		// so a captured index could point at a different (or vanished) row.
		if (this.#submenuItemId !== null) {
			const index = this.#filteredItems.findIndex(item => !item.heading && item.id === this.#submenuItemId);
			this.#submenuItemId = null;
			if (index >= 0) {
				this.#setSelectedIndex(index);
			} else {
				this.#clampSelectedIndex();
			}
			this.#notifySelection();
		}
	}
}

/** Construction options for a SettingsList composed as a form field. */
export interface SettingsFormFieldOptions extends Omit<FormFieldOptions, "theme"> {
	items: SettingItem[];
	maxVisible: number;
	settingsTheme: SettingsListTheme;
	fieldTheme: FormFieldTheme;
	onChange(id: string, newValue: string): void;
	onCancel(): void;
	listOptions?: SettingsListOptions;
}

/**
 * SettingsList adapter for detail forms. It retains the canonical list
 * implementation while sharing FormField label, description, hint, focus, and
 * input dispatch with text and selection fields.
 */
export class SettingsFormField extends FormField {
	readonly settingsList: SettingsList;

	constructor(options: SettingsFormFieldOptions) {
		const settingsList = new SettingsList(
			options.items,
			options.maxVisible,
			options.settingsTheme,
			options.onChange,
			options.onCancel,
			options.listOptions,
		);
		super(settingsList, {
			theme: options.fieldTheme,
			label: options.label,
			description: options.description,
			details: options.details,
			previewLabel: options.previewLabel,
			preview: options.preview,
			hint: options.hint,
			summary: options.summary,
			footer: options.footer,
			leadingSpace: options.leadingSpace,
			spaceBeforeControl: options.spaceBeforeControl,
			spaceAfterControl: options.spaceAfterControl,
		});
		this.settingsList = settingsList;
	}
}
