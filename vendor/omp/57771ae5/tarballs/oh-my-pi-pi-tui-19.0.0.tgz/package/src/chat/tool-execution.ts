import { RunTrace } from "@oh-my-pi/pi-natives";
import { isShellTrace, type ShellTrace, type ShellVizPreferences, type ShellVizPresentation } from "@oh-my-pi/pi-wire";
import { defaultShellVizPreferences, readShellPresentation, shellVisualization } from "../tools/shell-viz";
import { changeShellVizPreferences, shellVizEventAction } from "../tools/shell-trace";
import { ShellVisualizer } from "../apps/shell-visualizer";
import { chatTranscriptDisplayPreferences } from "./display-preferences";
import type { ImageContent } from "@oh-my-pi/pi-ai";
import type { AgentTool } from "@oh-my-pi/pi-agent-core";
import { Box } from "../components/box";
import {
	onSpinnerIntervalChange,
	sharedSpinnerFrame,
	spinnerAnimated,
	spinnerInterval,
	spinnerTickDelay,
} from "../spinner-clock";
import { Image } from "../components/image";
import { Spacer } from "../components/spacer";
import { Text } from "../components/text";
import { getImageDimensions, ImageProtocol, imageFallback, TERMINAL } from "../terminal-capabilities";
import { type Component, Container, type TUI } from "../tui";
import { truncateToWidth } from "../utils";
import { getProjectDir, isRecord, logger, sanitizeText, sanitizeTextDeep } from "@oh-my-pi/pi-utils";
import type { Theme } from "../theme/theme";
import { ensureThemeSync, getThemeEpoch, theme } from "../theme/theme";
import {
	type FirstResultViewportRepaint,
	type NativeToolView,
	type RenderResultContextOptions,
	type ToolActivitySummary,
	type ToolRenderer,
	toolRenderers,
} from "../tools/index";
import { describeDefaultToolExecution, formatDefaultToolExecution } from "../tools/default-renderer";
import { INTENT_FIELD, type TspCardStatus, type TspPreview, type TspText, type TspTone } from "@oh-my-pi/pi-wire";
import { card, col, EMPTY_NODE, node, span, text, withHidden } from "../native/describe";
import {
	type DescribeContext,
	type NativeChild,
	type NativeNode,
	type NativeUiEvent,
	rootToggleExpanded,
} from "../native/node";
import { plainLine, plainText } from "../native/spans";
import { diagnosticsSection, displayPath, resultText, toolHead } from "../tools/native-view";
import type { FileDiagnosticsResult } from "../tools/lsp";
import { NativeImageCache, readMediaPath, shownMedia } from "../native/blobs";
import { imageLinksEnabled, linkedImageText } from "../prompt/image-references";
import { Memo } from "../native/memo";
import { type EditMode, type PerFileDiffPreview, renderStreamingFallback } from "../tools/edit";
import { taskCardAgentIds } from "../tools/task";
import { TODO_STRIKE_TOTAL_FRAMES, type TodoToolDetails } from "../tools/todo";
import { isNativeRendering } from "../native/state";
import { isWaitingPollDetails } from "../tools/wait";
import {
	DEFAULT_TERMINAL_PREVIEW_LINES,
	formatStatusIcon,
	replaceTabs,
	resolveImageOptions,
} from "../render/render-utils";
import type { XdevMountedState } from "../tools/xdev";
import { isFramedBlockComponent, markFramedBlockComponent, renderStatusLine, WidthAwareText } from "../render/index";
import { cachedPngConversion, convertImageToPngShared, imagePayloadKey } from "./image-loading";
import { FenceFigure } from "./fence-figure";
import { SpotlightNotices } from "./spotlight";
import { sanitizeWithOptionalSixelPassthrough } from "../render/sixel";
import { renderDiff } from "../chrome/diff";
import { type AnimationFrame, trimBlankEdges } from "../chrome/transcript-container";
import { LateDiagnosticsMessageComponent } from "./late-diagnostics-message";
import { compactRows, presentNative, TranscriptPresentationState } from "./transcript-presentation";

/** Resolves the canonical renderer key while retaining the provider's wire name in message history. */
export function toolRenderName(wireName: string, tool: AgentTool | undefined): string {
	return tool?.name ?? wireName;
}
type DisplaceableToolName = "wait" | "todo";

function isTodoToolDetails(details: unknown): details is TodoToolDetails {
	return (
		typeof details === "object" &&
		details !== null &&
		"phases" in details &&
		Array.isArray((details as { phases?: unknown }).phases)
	);
}

interface ToolImageBlock {
	data?: string;
	mimeType?: string;
}

function imageBlocksFromDetails(details: unknown): ToolImageBlock[] {
	if (!isRecord(details) || !Array.isArray(details.images)) return [];
	return details.images.filter(
		(image): image is ToolImageBlock =>
			isRecord(image) &&
			(image.data === undefined || typeof image.data === "string") &&
			(image.mimeType === undefined || typeof image.mimeType === "string"),
	);
}

function displaceableToolName(
	toolName: string,
	result: { details?: unknown; isError?: boolean },
	isPartial: boolean,
): DisplaceableToolName | undefined {
	if (result.isError === true) return undefined;
	if (toolName === "wait" && isWaitingPollDetails(result.details)) return "wait";
	if (toolName === "todo" && !isPartial && isTodoToolDetails(result.details)) return "todo";
	return undefined;
}

function isEditLikeToolName(toolName: string): boolean {
	return toolName === "edit" || toolName === "apply_patch";
}

/** Tools whose arguments stream a growing file body or diff into the card (edit, apply_patch, write). */
function streamsBody(toolName: string): boolean {
	return isEditLikeToolName(toolName) || toolName === "write";
}

function resolveEditModeForTool(toolName: string, tool: AgentTool | undefined): EditMode | undefined {
	if (toolName === "apply_patch") return "apply_patch";
	if (toolName !== "edit") return undefined;
	return (tool as { mode?: EditMode } | undefined)?.mode;
}

type ToolRendererStage = "call" | "result";

/**
 * A renderer's preview as the fallback card's clamp (`tail` becomes a head
 * clamp of the same size; `children` leaves the clamping to the body's own previews).
 */
function cardPreview(preview: NativeToolView["preview"]): TspPreview | undefined {
	if (preview === undefined) return { lines: DEFAULT_TERMINAL_PREVIEW_LINES };
	if (preview === "none" || preview === "children") return undefined;
	if (preview !== "auto" && "tail" in preview) return { lines: preview.tail };
	return preview;
}

/** The describe hooks of a registry renderer or of a custom tool object. */
type ToolDescriber = Pick<ToolRenderer, "describeCall" | "describeResult" | "mergeCallAndResult">;

/** Optional kinds of the host's vocabulary the describe hooks branch on. */
type NativeHostKinds = Required<Pick<RenderResultContextOptions, "media" | "json" | "shell" | "tray">>;

class SafeToolRendererComponent implements Component {
	#toolName: string;
	#stage: ToolRendererStage;
	#component: Component;
	#fallback: () => Component | undefined;
	#warned = false;
	readonly wantsKeyRelease: boolean | undefined;

	constructor(
		toolName: string,
		stage: ToolRendererStage,
		component: Component,
		fallback: () => Component | undefined,
	) {
		this.#toolName = toolName;
		this.#stage = stage;
		this.#component = component;
		this.#fallback = fallback;
		this.wantsKeyRelease = component.wantsKeyRelease;
		if (isFramedBlockComponent(component)) {
			markFramedBlockComponent(this);
		}
	}

	render(width: number): readonly string[] {
		try {
			return this.#component.render(width);
		} catch (err) {
			if (!this.#warned) {
				this.#warned = true;
				logger.warn("Tool renderer failed", { tool: this.#toolName, stage: this.#stage, error: String(err) });
			}
			return this.#fallback()?.render(width) ?? [];
		}
	}

	handleInput(data: string): void {
		const handleInput = this.#component.handleInput;
		if (handleInput === undefined) return;
		handleInput.call(this.#component, data);
	}

	invalidate(): void {
		const invalidate = this.#component.invalidate;
		if (invalidate === undefined) return;
		invalidate.call(this.#component);
	}

	releaseRenderCaches(): void {
		const release = this.#component.releaseRenderCaches;
		if (release === undefined) return;
		try {
			release.call(this.#component);
		} catch (err) {
			if (!this.#warned) {
				this.#warned = true;
				logger.warn("Tool renderer failed", {
					tool: this.#toolName,
					stage: this.#stage,
					phase: "releaseRenderCaches",
					error: String(err),
				});
			}
		}
	}

	setIgnoreTight(ignore: boolean): void {
		const setIgnoreTight = this.#component.setIgnoreTight;
		if (setIgnoreTight === undefined) return;
		setIgnoreTight.call(this.#component, ignore);
	}

	dispose(): void {
		const dispose = this.#component.dispose;
		if (dispose === undefined) return;
		dispose.call(this.#component);
	}
}

/** Minimal TUI surface ToolExecutionComponent uses to schedule repaints and share image budget. */
export interface ToolExecutionUi {
	requestRender(): void;
	requestComponentRender(component: Component): void;
	resetDisplay(): void;
	imageBudget?: TUI["imageBudget"];
	showOverlay?: TUI["showOverlay"];
	setFocus?: TUI["setFocus"];
	terminal?: { readonly rows: number };
}

export interface ToolExecutionOptions {
	showImages?: boolean; // default: true (only used if terminal supports images)
	/** Allow the name-keyed renderer registry only when the active tool is the built-in implementation. */
	useBuiltInRenderer?: boolean;
	/** Ask the extension transcript presenters; false for a replayed transcript (overlays). Default: true. */
	transcriptPresenters?: boolean;
}

/** A tool result or progress frame as a card shows it. */
export interface ToolResultFrame {
	content: Array<{ type: string; text?: string; data?: string; mimeType?: string }>;
	details?: unknown;
	isError?: boolean;
}

export interface ToolExecutionHandle extends Component {
	updateArgs(args: unknown, toolCallId?: string): void;
	updateStreamPreview?(update: unknown): void;
	updateResult(result: ToolResultFrame, isPartial?: boolean, toolCallId?: string): void;
	setArgsComplete(toolCallId?: string): void;
	setExecutionStarted(toolCallId?: string): void;
	setExpanded(expanded: boolean): void;
	/** Mark the call parked: it returned, but stays tracked for async job frames. */
	parkAsBackground(): void;
	/** Seal the block as final history and stop its animations. */
	seal(): void;
}

/** {@link ToolExecutionComponent.nativeTrailers} of a hidden call without late diagnostics. */
const EMPTY_TRAILERS: readonly Component[] = [];

/** Tools whose returned call hands its card to the background job it started (see {@link parksAsBackground}). */
const JOB_CARD_TOOLS: Record<string, "always" | "native"> = { task: "always", bash: "native", eval: "native" };

/**
 * Whether a call that returned with `details.async.state === "running"` stays
 * parked ({@link ToolExecutionHandle.parkAsBackground}) so its job's later
 * frames keep filling the card until a `completed`/`failed` frame settles it.
 * Detached `task` spawns always do; backgrounded `bash`/`eval` jobs only under
 * native rendering, where the terminal transcript keeps them frozen instead.
 * Shared by the live event controller and the transcript rebuild.
 */
export function parksAsBackground(toolName: string, details: unknown): boolean {
	const mode = JOB_CARD_TOOLS[toolName];
	if (mode === undefined || (mode === "native" && !isNativeRendering())) return false;
	return asyncJobState(details) === "running";
}

/** The background job state a tool result reports (`details.async.state`: running, completed, failed, cancelled). */
export function asyncJobState(details: unknown): string | undefined {
	if (!isRecord(details) || !isRecord(details.async)) return undefined;
	return typeof details.async.state === "string" ? details.async.state : undefined;
}

/** Whether a frame is a background job's last one: it completed, failed or was cancelled. */
export function isSettledJobFrame(details: unknown): boolean {
	const state = asyncJobState(details);
	return state === "completed" || state === "failed" || state === "cancelled";
}

/**
 * Settle a parked card ({@link parksAsBackground}) with its job's last frame
 * ({@link isSettledJobFrame}): a completed or failed job is the call's result;
 * a cancelled one keeps the output it got to and seals the card as cancelled.
 */
export function settleWithJobFrame(component: ToolExecutionHandle, frame: ToolResultFrame, toolCallId: string): void {
	const state = asyncJobState(frame.details);
	if (state === "cancelled") {
		component.updateResult(frame, true, toolCallId);
		component.seal();
		return;
	}
	component.updateResult({ ...frame, isError: state === "failed" }, false, toolCallId);
}

/** Card tone per status when the renderer doesn't choose one; settled cards stay neutral. */
const NATIVE_STATUS_TONE: Record<TspCardStatus, TspTone | undefined> = {
	pending: "pending",
	running: "pending",
	done: undefined,
	error: "error",
	cancelled: "info",
};

/** Live tool blocks currently driving a spinner. A single shared ticker (below)
 * advances and repaints every registered block per glyph step, so N concurrent
 * live/streaming blocks — e.g. parallel `task` subagents — cost one timer at the
 * shared spinner cadence and one coalesced render frame per tick instead of N
 * unsynchronized timers each independently waking the render scheduler
 * (issue #8731). The glyph index comes from `sharedSpinnerFrame`, so blocks
 * stay in phase with every other spinner on the clock. */
const liveSpinnerBlocks = new Set<ToolExecutionComponent>();
let sharedSpinnerTimer: NodeJS.Timeout | undefined;

/**
 * Arm the shared ticker if it is not already running and spinners animate. Ticks land on the shared
 * clock's boundaries, so this ticker and the working row repaint in the same frame. Each tick re-reads
 * the period; a tick under a static spinner paints frame 0 and leaves the ticker stopped.
 */
function ensureSharedSpinnerTicker(): void {
	if (sharedSpinnerTimer || isNativeRendering() || !spinnerAnimated()) return;
	sharedSpinnerTimer = setTimeout(() => {
		sharedSpinnerTimer = undefined;
		// A native surface opened while blocks were live: the terminal clocks their spinners, so the
		// repaint ticker has nothing left to do — drop the live blocks and stay stopped.
		if (isNativeRendering()) {
			stopSharedSpinnerTicker();
			return;
		}
		const frame = sharedSpinnerFrame(theme.spinnerFrames.length);
		// Removing the current block mid-iteration is safe on a Set.
		for (const block of liveSpinnerBlocks) block.tickSpinner(frame);
		if (liveSpinnerBlocks.size > 0) ensureSharedSpinnerTicker();
	}, spinnerTickDelay(spinnerInterval()));
}
// Static → animated: nothing is ticking, so restart.
onSpinnerIntervalChange(() => {
	if (liveSpinnerBlocks.size > 0) ensureSharedSpinnerTicker();
});

/** Register a live block with the shared ticker, starting it on first use. */
function registerSpinnerBlock(block: ToolExecutionComponent): void {
	liveSpinnerBlocks.add(block);
	ensureSharedSpinnerTicker();
}

/** Drop a block; stop the ticker once no live block remains. */
function unregisterSpinnerBlock(block: ToolExecutionComponent): void {
	if (!liveSpinnerBlocks.delete(block)) return;
	if (liveSpinnerBlocks.size === 0 && sharedSpinnerTimer) {
		clearTimeout(sharedSpinnerTimer);
		sharedSpinnerTimer = undefined;
	}
}

/** Stop the shared spinner ticker and drop every registered live block.
 *  Called on interactive-mode teardown so a stray live block cannot keep the
 *  process-wide spinner timer alive past shutdown (lingering event-loop
 *  handles pin the process; cf. `postmortem.quit`). Test files that assert on
 *  ticker arming also use this to start from a clean slate. */
export function stopSharedSpinnerTicker(): void {
	liveSpinnerBlocks.clear();
	if (sharedSpinnerTimer) {
		clearTimeout(sharedSpinnerTimer);
		sharedSpinnerTimer = undefined;
	}
}

/** Whether the shared spinner ticker has a tick armed. Test seam: other timers on a fake clock
 *  (collab relay heartbeats) make a raw timer count ambiguous. */
export function sharedSpinnerTickerArmed(): boolean {
	return sharedSpinnerTimer !== undefined;
}

// Stable per-instance counter so each tool execution's inline images get a
// graphics id that survives child re-creation (the image budget keys off it).
let toolExecutionInstanceSeq = 0;

/**
 * Component that renders a tool call with its result (updateable)
 */
export class ToolExecutionComponent extends Container {
	#shellPreferences: ShellVizPreferences = defaultShellVizPreferences();
	#shellPendingTrace: RunTrace | undefined;
	#shellPendingScript: string | undefined;
	#shellPresentation: ShellVizPresentation | undefined;
	#shellPresentationKey: string | undefined;
	#shellTrace: ShellTrace | undefined;
	#shellTraceDetails: unknown;
	#shellReplayTimer: NodeJS.Timeout | undefined;
	#shellReplayAt = 0;
	#shellReplayNs = 0;
	#shellReplayPositioned = false;
	#shellReplayEpoch = 0;
	#shellInspector: { hide(): void } | undefined;
	#contentBox: Box; // Used for custom tools and bash visual truncation
	#contentText: WidthAwareText; // Generic fallback (no custom/built-in renderer)
	// Which container the constructor mounted: bespoke/built-in renderers use
	// #contentBox, everything else the generic #contentText fallback.
	#usesContentBox = false;
	#multiFileBoxes: (Box | Spacer)[] = []; // Extra boxes for multi-file edit results
	#imageComponents: Image[] = [];
	#imageSpacers: Spacer[] = [];
	/** The renderer's {@link ToolRenderer.figure} drawing; kept across rebuilds while its language is unchanged, so it redraws in place and its raster survives them. */
	#figure: FenceFigure | undefined;
	readonly #instanceId = ++toolExecutionInstanceSeq;
	#toolName: string;
	#toolLabel: string;
	#args: unknown;
	#expanded = false;
	#allocation = Number.POSITIVE_INFINITY;
	#presentationFrame: AnimationFrame = { tick: 0, now: 0 };
	#toolActivityVisible = true;
	#showImages: boolean;
	#isPartial = true;
	// A background task whose call already returned; later async job frames are
	// partial updates, but the block is ready to retire as history.
	#parkedBackground = false;
	#resultVersion = 0;
	// Post-finalize mutation counter (see FinalizableBlock.getTranscriptBlockVersion):
	// a tool block can keep changing after isTranscriptBlockFinalized() first
	// returns true — an async task's terminal result settlement, seal(), or an
	// expansion toggle — and the transcript's width-epoch resolution and
	// committed-render bypass must observe those mutations.
	#blockVersion = 0;
	#lastDisplayKey: string | undefined;
	// Bumped whenever a render input that #rebuildDisplay consumes but the memo
	// key cannot cheaply hash changes: streamed call args, native edit-diff
	// previews, and Kitty PNG conversions. Folded into the dirty key so those
	// updates are not swallowed by the memo (see #updateDisplay).
	#displayInputVersion = 0;
	// Set once #rebuildDisplay has populated the display. Replaces a
	// #contentBox.children.length probe so the memo fast-path also covers the
	// #contentText fallback path (which leaves #contentBox empty).
	#displayBuilt = false;
	// Number of Image children the last rebuild emitted. Only when this is > 0 does
	// the memo key fold in viewport-dependent image sizing (resolveImageOptions),
	// so a terminal resize re-shapes image-bearing results to rescale them without
	// forcing the common image-free result to re-shape on every resize tick.
	#renderedImageCount = 0;
	// `stateBgKey|themeEpoch` of the tint last handed to #contentText. Re-tinting
	// drops its wrap cache, so a rebuild whose tint is unchanged skips it and the
	// inner Text re-wraps only when the reformatted card text actually differs.
	#contentTextBgKey: string | undefined;
	// Memoized #getTextOutput(), keyed by every input it reads: the result
	// (versioned by #resultVersion), #showImages, and the image protocol.
	#textOutput = "";
	#textOutputTrimmed: string | undefined;
	#textOutputKey: string | undefined;
	#tool?: AgentTool;
	#renderer?: ToolRenderer;
	#ui: ToolExecutionUi;
	#result?: {
		content: Array<{ type: string; text?: string; data?: string; mimeType?: string }>;
		isError?: boolean;
		details?: unknown;
	};
	// Machine paths remain verbatim; only #result.details is handed to display renderers.
	#rawDetails: unknown;
	// Edit preview state
	#editMode?: EditMode;
	#editDiffPreview?: PerFileDiffPreview[];
	#previewReady?: PromiseWithResolvers<void>;
	// Payload keys whose Kitty PNG conversion is already awaited; the converted
	// images themselves live in the process-wide cache behind
	// `convertImageToPngShared`, so rebuilt components reuse them.
	#kittyConversionsAwaited = new Set<string>();
	// Conversions this component displays, held so a later re-render still finds
	// them after the bounded shared cache evicts them.
	#kittyConverted = new Map<string, ImageContent>();
	// Spinner animation for partial task results
	#spinnerFrame?: number;
	#spinnerActive = false;
	// Todo write completion strikethrough reveal animation
	#todoStrikeInterval?: NodeJS.Timeout;
	// Once-a-second repaint for renderers that show live elapsed time (`tickElapsed`)
	#elapsedTicker?: NodeJS.Timeout;
	// Track if args are still being streamed (for edit/write spinner)
	#argsComplete = false;
	#executionStarted = false;
	// Sealed once the tool reaches a terminal state (result delivered, or the
	// turn abandoned it without one). Until then the block remains active so a
	// late result can update its streaming preview.
	#sealed = false;
	// Tool result snapshots that may be superseded by a later same-tool call
	// while still in the mutable viewport. `wait` uses this for repeated all-running polls; `todo` uses
	// it for per-turn state snapshots so only the latest list remains visible.
	#displaceableByToolName: DisplaceableToolName | undefined;
	// Execution start on the presentation clock (performance.now domain, the
	// same domain as AnimationFrame.now supplied by the transcript allocator).
	#executionStartedAtNow: number | undefined;
	// When the call settled (final result or seal), same clock; freezes the native elapsed timer.
	#executionEndedAtNow: number | undefined;
	#toolCallId: string | undefined;
	readonly #native = new Memo();
	// LSP diagnostics that arrived after the result (native only), shown in the frame.
	#lateDiagnostics: readonly FileDiagnosticsResult[] | undefined;
	/** The standalone block showing {@link #lateDiagnostics} while the card is not drawn in full. */
	#lateDiagnosticsBlock:
		| { files: readonly FileDiagnosticsResult[]; block: LateDiagnosticsMessageComponent }
		| undefined;
	/** Whether presenters draw this card (not a replayed transcript). */
	#presented = true;
	/** What the presenters chose; an expanded card always draws in full. */
	readonly #presentation = new TranscriptPresentationState(
		() =>
			this.#presented
				? {
						type: "toolCall",
						id: this.#toolCallId ?? "",
						toolName: this.#toolName,
						args: this.#args,
						result: this.#result ? { content: this.#result.content, details: this.#rawDetails } : undefined,
						isError: this.#result?.isError === true,
						isPartial: this.#result === undefined || this.#isPartial,
					}
				: undefined,
		() => this.#expanded,
		this,
	);
	readonly #nativeImages = new NativeImageCache();
	// The Spotlight notice drawn after the card in a native transcript (see nativeTrailers).
	readonly #spotlight = new SpotlightNotices();
	// Wall clock captured whenever a task card is rebuilt.
	#taskRenderNowMs = Date.now();
	// Set on each `render()` when the last painted pending shape must be
	// replayed wholesale when the first result arrives. Reset gates key off
	// these so a topology-changing update that lands before the shape reaches
	// the terminal never triggers an unnecessary full-viewport replay.
	#firstResultViewportRepaintShapePainted = false;
	#partialResultShapePainted = false;
	#renderState: {
		spinnerFrame?: number;
		expanded: boolean;
		isPartial: boolean;
		argsComplete?: boolean;
		executionStarted?: boolean;
		renderContext?: Record<string, unknown>;
		readonly shellPresentation?: ShellVizPresentation;
		shellTrace?: ShellTrace;
		shellReplayEpoch?: number;
		/** Live: read at render time, so a ticking spinner advances it. */
		readonly elapsedMs?: number;
	} = {
		expanded: false,
		isPartial: true,
		argsComplete: false,
		executionStarted: false,
	};

	constructor(
		toolName: string,
		args: unknown,
		options: ToolExecutionOptions = {},
		tool: AgentTool | undefined,
		ui: ToolExecutionUi,
		_cwd: string = getProjectDir(),
		toolCallId?: string,
	) {
		super();
		Object.defineProperty(this.#renderState, "elapsedMs", {
			get: () => this.#elapsedMs(this.#nativeStatus()),
			enumerable: true,
		});
		Object.defineProperty(this.#renderState, "shellPresentation", {
			get: () => (this.#toolName === "bash" ? this.#getShellPresentation() : undefined),
			enumerable: true,
		});
		ensureThemeSync();
		this.#toolCallId = toolCallId;
		this.#toolName = toolName;
		this.#toolLabel = tool?.label ?? toolName;
		this.#renderer = options.useBuiltInRenderer === false ? undefined : toolRenderers[toolName];
		this.#showImages = options.showImages ?? true;
		this.#presented = options.transcriptPresenters ?? true;
		this.#tool = tool;
		this.#ui = ui;
		this.#args = args;
		this.#editMode = resolveEditModeForTool(toolName, tool);
		if (this.#editMode) this.#previewReady = Promise.withResolvers<void>();

		// Always create both - contentBox for custom tools/bash/tools with renderers, contentText for other built-ins.
		// paddingY is 1 so background-tinted blocks (custom/extension tools and the
		// generic fallback) get top/bottom breathing room. TranscriptContainer
		// strips PLAIN-blank edges, so framed/minimal blocks (no bg set) drop these
		// lines and keep their tight spacing — only tinted lines survive.
		this.#contentBox = new Box(0, 1);
		this.#contentText = new WidthAwareText(contentWidth => this.#renderDefaultCard(contentWidth), 1, 1);

		// Use Box for custom tools or built-in tools with rich renderers.
		const hasCustomRenderer = !!(tool?.renderCall || tool?.renderResult);
		this.#usesContentBox = hasCustomRenderer || this.#renderer !== undefined;
		if (this.#usesContentBox) {
			this.addChild(this.#contentBox);
		} else {
			this.addChild(this.#contentText);
		}
		// Tool blocks are visually distinct cards (background-tinted or framed),
		// so keep their horizontal padding even when the user enables tight layout.
		this.setIgnoreTight(true);

		this.#updateSpinnerAnimation();
		this.#updateDisplay();
	}

	#updateShellTrace(details: unknown): void {
		if (this.#toolName !== "bash" || details === this.#shellTraceDetails) return;
		this.#shellTraceDetails = details;
		const candidate = isRecord(details) ? details.trace : undefined;
		if (candidate === undefined || candidate === this.#shellTrace) return;
		const next = isShellTrace(candidate) ? candidate : undefined;
		const old = this.#shellTrace;
		if (old === next) return;
		if (this.#shellPreferences.cursor !== undefined) {
			const applied = old?.history?.[this.#shellPreferences.cursor - 1]?.seq;
			const records = next?.history ?? [];
			this.#shellPreferences = {
				...this.#shellPreferences,
				cursor:
					applied === undefined
						? Math.min(this.#shellPreferences.cursor, records.length)
						: records.filter(record => record.seq <= applied).length,
			};
		}
		this.#shellTrace = next;
		if (next?.historyTruncated && this.#shellPreferences.cursor === 0 && this.#shellReplayPositioned) {
			this.#shellReplayNs = Math.max(this.#shellReplayNs, next.history?.[0]?.t_ns ?? 0);
		}
		this.#shellPresentationKey = undefined;
	}

	#getShellPresentation(): ShellVizPresentation | undefined {
		if (this.#toolName !== "bash" || !chatTranscriptDisplayPreferences.shellVisualization) return undefined;
		const script =
			this.#shellTrace?.script ??
			(isRecord(this.#args) && typeof this.#args.command === "string" ? this.#args.command : undefined);
		if (!script) return undefined;
		if (script !== this.#shellPendingScript) {
			this.#shellPendingTrace = undefined;
			this.#shellPendingScript = script;
			this.#shellPresentationKey = undefined;
		}
		const key = `${this.#resultVersion}|${this.#displayInputVersion}`;
		if (this.#shellPresentation && key === this.#shellPresentationKey) return this.#shellPresentation;
		const source = this.#shellTrace
			? shellVisualization(this.#shellTrace)
			: (this.#shellPendingTrace ??= new RunTrace(script));
		// An unrestorable stored trace renders like visualization-off: plain command and output.
		if (!source) {
			this.#shellPresentation = undefined;
			return undefined;
		}
		this.#shellPresentation = readShellPresentation(
			source,
			this.#shellPreferences,
			this.#shellTrace,
			this.#result ? resultText(this.#result) : undefined,
			!this.#shellTrace && !this.#argsComplete,
		);
		this.#shellPresentationKey = key;
		return this.#shellPresentation;
	}

	#shellChanged(): void {
		this.#shellPresentationKey = undefined;
		this.#displayInputVersion++;
		this.#blockVersion++;
		this.#updateDisplay();
		this.#ui.requestRender();
	}

	#stopShellReplay(): void {
		clearInterval(this.#shellReplayTimer);
		this.#shellReplayTimer = undefined;
		this.#shellPreferences = { ...this.#shellPreferences, playing: false };
	}

	/** Handle exactly the shared native action vocabulary; inspector uses this same controller. */
	shellVizAction(action: string): void {
		if (this.#toolName !== "bash" || !chatTranscriptDisplayPreferences.shellVisualization) return;
		if (action === "inspect") {
			this.openShellVisualizer();
			return;
		}
		const before = this.#shellPreferences;
		const wasPlaying = before.playing;
		const history = this.#shellTrace?.history ?? [];
		const now = performance.now();
		if (wasPlaying) this.#shellReplayNs += (now - this.#shellReplayAt) * 1_000_000 * before.speed;
		this.#shellPreferences = changeShellVizPreferences(before, action, history.length);
		const seeking = action === "reset" || action === "step" || /^seek:[0-9]+$/.test(action);
		const restarting = action === "play" && (before.cursor === undefined || before.cursor >= history.length);
		if (action === "reset" || action === "live" || /^seek:[0-9]+$/.test(action) || restarting)
			this.#shellReplayEpoch++;
		if (action === "live") this.#shellReplayPositioned = false;
		else if (seeking || restarting || (!this.#shellReplayPositioned && this.#shellPreferences.playing)) {
			const cursor = this.#shellPreferences.cursor ?? 0;
			this.#shellReplayNs =
				history[cursor - 1]?.t_ns ?? (this.#shellTrace?.historyTruncated ? (history[0]?.t_ns ?? 0) : 0);
			this.#shellReplayPositioned = true;
		}
		if (this.#shellPreferences.playing) {
			this.#shellReplayAt = now;
			if (!this.#shellReplayTimer) {
				this.#shellReplayTimer = setInterval(() => {
					const history = this.#shellTrace?.history ?? [];
					const now = performance.now();
					this.#shellReplayNs += (now - this.#shellReplayAt) * 1_000_000 * this.#shellPreferences.speed;
					this.#shellReplayAt = now;
					let cursor = this.#shellPreferences.cursor ?? 0;
					while (cursor < history.length && history[cursor].t_ns <= this.#shellReplayNs) cursor++;
					if (cursor === history.length) this.#stopShellReplay();
					if (cursor !== this.#shellPreferences.cursor || !this.#shellPreferences.playing) {
						this.#shellPreferences = { ...this.#shellPreferences, cursor };
						this.#shellChanged();
					}
				}, 80);
				this.#shellReplayTimer.unref();
			}
		} else this.#stopShellReplay();
		this.#shellChanged();
	}

	/** Open the focused inspector without intercepting composer input while it is closed. */
	openShellVisualizer(): void {
		if (this.#toolName !== "bash" || !chatTranscriptDisplayPreferences.shellVisualization || !this.#ui.showOverlay)
			return;
		if (this.#shellInspector) return;
		const inspector = new ShellVisualizer({
			presentation: () => this.#getShellPresentation(),
			replayEpoch: () => this.#shellReplayEpoch,
			liveOrigin: () => this.#executionStarted,
			action: action => this.shellVizAction(action),
			close: () => {
				this.#stopShellReplay();
				this.#shellInspector?.hide();
				this.#shellInspector = undefined;
				this.#shellChanged();
			},
			requestRender: () => this.#ui.requestRender(),
			height: () => this.#ui.terminal?.rows ?? 24,
		});
		this.#shellInspector = this.#ui.showOverlay(inspector, {
			anchor: "top-left",
			width: "100%",
			maxHeight: "100%",
			fullscreen: true,
			margin: 0,
		});
		this.#ui.setFocus?.(inspector);
		this.#ui.requestRender();
	}

	updateArgs(args: unknown, _toolCallId?: string): void {
		// Reference-equality short-circuit before any further work. Callers
		// always allocate a new arg object on each streamed delta (see
		// event-controller.ts and ui-helpers.ts), so a same-reference assignment
		// signals "nothing meaningful changed" and the renderer can skip.
		if (args === this.#args) return;
		this.#args = args;
		this.#presentation.markStale();
		this.#displayInputVersion++;
		this.#updateSpinnerAnimation();
		this.#updateDisplay();
	}

	/**
	 * Signal that args are complete (tool is about to execute).
	 * This triggers an immediate final diff computation for edit-like tools.
	 */
	setArgsComplete(_toolCallId?: string): void {
		const alreadyComplete = this.#argsComplete;
		this.#argsComplete = true;
		this.#updateSpinnerAnimation();
		if (alreadyComplete) return;
		this.#displayInputVersion++;
		this.#updateDisplay();
	}

	/**
	 * Signal that this specific call has begun executing (`tool_execution_start`).
	 * Distinct from {@link setArgsComplete}: exclusive writes are marked complete
	 * at `message_end` but stay queued until this fires for that call.
	 */
	setExecutionStarted(_toolCallId?: string): void {
		if (this.#executionStarted) return;
		this.#executionStarted = true;
		this.#executionStartedAtNow = performance.now();
		this.#argsComplete = true;
		this.#updateSpinnerAnimation();
		this.#displayInputVersion++;
		this.#updateDisplay();
	}

	/**
	 * Resolve once the final (`streaming: false`) preview batch lands or the
	 * result settles. Callers without a live batch source (gallery snapshots)
	 * pass a budget so a component that will never receive a batch cannot
	 * hang them; live approval gates omit it and wait indefinitely.
	 */
	async whenPreviewSettled(timeoutMs?: number): Promise<void> {
		if (this.#previewReady === undefined) return;
		if (timeoutMs === undefined) {
			await this.#previewReady.promise;
			return;
		}
		await Promise.race([this.#previewReady.promise, Bun.sleep(timeoutMs)]);
	}

	updateStreamPreview(update: unknown): void {
		if (
			this.#previewDiffSettled() ||
			update === null ||
			typeof update !== "object" ||
			!("files" in update) ||
			!Array.isArray(update.files)
		) {
			return;
		}
		if ("streaming" in update && update.streaming === false) this.#previewReady?.resolve();
		if (update.files.length === 0) return;
		const rawFiles: unknown[] = update.files;
		const files = rawFiles.filter(
			(
				file,
			): file is {
				path: string;
				diff?: string | null;
				firstChangedLine?: number | null;
				error?: string | null;
			} => file !== null && typeof file === "object" && "path" in file && typeof file.path === "string",
		);
		if (files.length === 0) return;
		this.#editDiffPreview = files.map(file => ({
			path: file.path,
			diff: file.diff ?? undefined,
			firstChangedLine: file.firstChangedLine ?? undefined,
			error: file.error ?? undefined,
		}));
		this.#displayInputVersion++;
		this.#updateDisplay();
		this.#ui.requestRender();
	}

	/**
	 * True once a terminal result makes the streaming preview moot: renderResult
	 * prefers `details.diff` and renders errors from the result text, consulting
	 * the computed preview only for a non-error result that carries no details.
	 */
	#previewDiffSettled(): boolean {
		const result = this.#result;
		return result !== undefined && !this.#isPartial && (result.isError === true || result.details != null);
	}

	updateResult(result: ToolResultFrame, isPartial = false, _toolCallId?: string): void {
		const hadNoResult = this.#result === undefined;
		const wasPartialResult = this.#result !== undefined && this.#isPartial;
		const firstResultRepaintShapePainted = this.#firstResultViewportRepaintShapePainted;
		const partialResultPainted = this.#partialResultShapePainted;
		this.#firstResultViewportRepaintShapePainted = false;
		this.#partialResultShapePainted = false;
		this.#rawDetails = result.details;
		this.#updateShellTrace(result.details);
		// Renderers receive sanitized details for display; raw paths are available
		// separately for links and media through the built-in render context.
		const details = sanitizeTextDeep(result.details);
		this.#result = details === result.details ? result : { ...result, details };
		this.#resultVersion++;
		this.#blockVersion++;
		this.#isPartial = isPartial;
		this.#presentation.markStale();
		// A final frame can land after the card retired to scrollback, which is never drawn again.
		if (!isPartial) this.#presentation.recheck();
		this.#displaceableByToolName = displaceableToolName(this.#toolName, result, isPartial);
		if (!isPartial && this.#toolCallId !== undefined) {
			this.#spotlight.set(this.#toolCallId, result.details, resultText(result));
		}
		// When tool is complete, ensure args are marked complete so spinner stops
		if (!isPartial) {
			this.#argsComplete = true;
			this.#previewReady?.resolve();
			this.#executionEndedAtNow ??= performance.now();
		}
		this.#updateSpinnerAnimation();
		this.#updateTodoStrikeAnimation();
		this.#updateDisplay();
		this.#resetDisplayForResultTopologyChange(
			hadNoResult && firstResultRepaintShapePainted,
			wasPartialResult && partialResultPainted,
			isPartial,
		);
		// Convert non-PNG images to PNG for Kitty protocol (async)
		this.#maybeConvertImagesForKitty();
	}

	/**
	 * Get all image blocks from result content and details.
	 * Some tools (like generate_image) store images in details to avoid bloating
	 * model context. Xdev-dispatched tools preserve those details under
	 * details.xdev.inner.
	 */
	#getAllImageBlocks(): ToolImageBlock[] {
		if (!this.#result) return [];
		const contentImages = this.#result.content.filter(block => block.type === "image");
		const details = this.#result.details;
		const detailImages = imageBlocksFromDetails(details);
		const xdevImages = isRecord(details) && isRecord(details.xdev) ? imageBlocksFromDetails(details.xdev.inner) : [];
		return [...contentImages, ...detailImages, ...xdevImages];
	}

	/**
	 * Convert non-PNG images to PNG for Kitty graphics protocol.
	 * Kitty requires PNG format (f=100), so JPEG/GIF/WebP won't display.
	 */
	#maybeConvertImagesForKitty(): void {
		// Only needed for Kitty protocol
		if (TERMINAL.imageProtocol !== ImageProtocol.Kitty) return;
		if (!this.#result) return;

		for (const img of this.#getAllImageBlocks()) {
			if (!img.data || !img.mimeType) continue;
			// Skip if already PNG or already converted anywhere in this process
			if (img.mimeType === "image/png") continue;
			const image: ImageContent = { type: "image", data: img.data, mimeType: img.mimeType };
			const key = imagePayloadKey(image);
			if (this.#kittyConverted.has(key)) continue;
			const cached = cachedPngConversion(image);
			if (cached) {
				this.#kittyConverted.set(key, cached);
				continue;
			}
			if (this.#kittyConversionsAwaited.has(key)) continue;
			this.#kittyConversionsAwaited.add(key);

			// Convert async - catch errors from processing
			convertImageToPngShared(image)
				.then(converted => {
					this.#kittyConversionsAwaited.delete(key);
					this.#kittyConverted.set(key, converted);
					this.#displayInputVersion++;
					this.#updateDisplay();
					this.#ui.requestRender();
				})
				.catch(() => {
					this.#kittyConversionsAwaited.delete(key);
					this.#ui.requestRender();
				});
		}
	}

	/**
	 * Start or stop spinner animation for live states that visibly tick.
	 */
	#updateSpinnerAnimation(): void {
		// Live partial tool blocks stay repaintable until a terminal result seals
		// them. Todo snapshots and detached background tool progress are deliberate
		// static exceptions because their rows can be superseded or committed to
		// scrollback while later updates continue elsewhere.
		const isStreamingArgs = !this.#argsComplete && streamsBody(this.#toolName);
		const isBackgroundAsyncRunning =
			(this.#result?.details as { async?: { state?: string } } | undefined)?.async?.state === "running";
		const renderer = this.#renderer;
		const pendingAnimation = renderer?.animatedPendingPreview;
		const partialAnimation = renderer?.animatedPartialResult;
		const pendingCallConsumesSpinner =
			this.#result === undefined &&
			(renderer === undefined
				? // Only the generic #formatToolExecution fallback consumes the frame;
					// a custom renderCall/renderResult pair routes through the custom
					// branch whose pending label is a static tool-name Text.
					!this.#tool?.renderCall && !this.#tool?.renderResult
				: typeof pendingAnimation === "function"
					? pendingAnimation(this.#args)
					: pendingAnimation === true);
		const partialResultConsumesSpinner =
			this.#result !== undefined &&
			(renderer === undefined
				? !this.#tool?.renderCall && !this.#tool?.renderResult
				: typeof partialAnimation === "function"
					? partialAnimation(this.#args)
					: partialAnimation === true);
		const isLivePartialTool =
			this.#isPartial &&
			this.#toolName !== "todo" &&
			!isBackgroundAsyncRunning &&
			(pendingCallConsumesSpinner || partialResultConsumesSpinner);
		// TSP terminals clock spinners themselves; the frame counter is ANSI-only.
		const needsSpinner =
			!isNativeRendering() && (isStreamingArgs || isLivePartialTool || this.#displaceableByToolName === "wait");
		if (needsSpinner && !this.#spinnerActive) {
			const frameCount = theme.spinnerFrames.length;
			const frame = sharedSpinnerFrame(frameCount);
			this.#spinnerFrame = frame;
			this.#renderState.spinnerFrame = frame;
			this.#spinnerActive = true;
			registerSpinnerBlock(this);
		} else if (!needsSpinner && this.#spinnerActive) {
			this.#spinnerActive = false;
			unregisterSpinnerBlock(this);
			// Clear the last drawn frame so a non-live renderCall (e.g. a write whose
			// args just completed) stops showing a frozen spinner glyph. Skip when a
			// todo strike owns the frame — it sets its own value right after this.
			if (!this.#todoStrikeInterval) {
				this.#spinnerFrame = undefined;
				this.#renderState.spinnerFrame = undefined;
			}
		}
		this.#updateElapsedTicker(isBackgroundAsyncRunning);
	}

	/**
	 * Repaint once a second while a `tickElapsed` renderer's call executes, so a
	 * quiet command's elapsed time advances without the 30fps spinner ticker.
	 */
	#updateElapsedTicker(isBackgroundAsyncRunning: boolean): void {
		const needsTicker =
			this.#renderer?.tickElapsed === true &&
			this.#executionStarted &&
			this.#isPartial &&
			!this.#sealed &&
			!isBackgroundAsyncRunning &&
			!isNativeRendering();
		if (needsTicker && !this.#elapsedTicker) {
			this.#elapsedTicker = setInterval(() => this.#ui.requestComponentRender(this), 1000);
		} else if (!needsTicker) {
			this.#stopElapsedTicker();
		}
	}

	#stopElapsedTicker(): void {
		if (!this.#elapsedTicker) return;
		clearInterval(this.#elapsedTicker);
		this.#elapsedTicker = undefined;
	}

	/**
	 * Advance to the shared spinner glyph and repaint just this block. Driven by
	 * the single shared spinner ticker (see `registerSpinnerBlock`); the tick is
	 * component-scoped so the TUI reuses every other root subtree (issue #4377).
	 */
	tickSpinner(frame: number): void {
		this.#spinnerFrame = frame;
		this.#renderState.spinnerFrame = frame;
		this.#ui.requestComponentRender(this);
	}

	#updateTodoStrikeAnimation(): void {
		// TSP terminals draw the completion strike from the `del` token; no repaint ticks.
		if (this.#toolName !== "todo" || this.#isPartial || this.#result?.isError || isNativeRendering()) {
			this.#stopTodoStrikeAnimation();
			return;
		}
		const completedTasks = (this.#result?.details as { completedTasks?: unknown[] } | undefined)?.completedTasks;
		if (!completedTasks || completedTasks.length === 0) {
			this.#stopTodoStrikeAnimation();
			return;
		}
		if (this.#todoStrikeInterval) return;

		this.#spinnerFrame = 0;
		this.#renderState.spinnerFrame = 0;
		this.#todoStrikeInterval = setInterval(() => {
			const nextFrame = (this.#spinnerFrame ?? 0) + 1;
			if (nextFrame > TODO_STRIKE_TOTAL_FRAMES) {
				this.#stopTodoStrikeAnimation();
			} else {
				this.#spinnerFrame = nextFrame;
				this.#renderState.spinnerFrame = nextFrame;
			}
			// Component-scoped: strike animation only mutates this tool block's
			// glyph, so the TUI reuses every other root subtree (issue #4377).
			this.#ui.requestComponentRender(this);
		}, 65);
	}

	#stopTodoStrikeAnimation(): void {
		if (this.#todoStrikeInterval) {
			clearInterval(this.#todoStrikeInterval);
			this.#todoStrikeInterval = undefined;
		}
		if (!this.#spinnerActive) {
			this.#spinnerFrame = undefined;
			this.#renderState.spinnerFrame = undefined;
		}
	}

	/** Hold visible results until their figures and Kitty images are ready for immutable scrollback. */
	isTranscriptBlockPending(): boolean {
		return (
			this.#toolActivityVisible &&
			this.#presentation.shown.mode === "full" &&
			((this.#showImages && this.#kittyConversionsAwaited.size > 0) || this.#figure?.pending === true)
		);
	}

	/**
	 * Whether this block is ready to retire as immutable history. Partial
	 * results, including detached background tasks, remain active and mutable
	 * until they settle. Hidden blocks render no rows and cannot gate history.
	 */
	isTranscriptBlockFinalized(): boolean {
		if (!this.#toolActivityVisible) return true;
		if (this.#sealed) return true;
		if (this.#result === undefined) return false;
		// A parked background task's call already returned; job frames that land
		// while it is still live keep updating it, but it must not gate history.
		if (this.#parkedBackground) return true;
		return !this.#isPartial;
	}

	/**
	 * Subagent ids visible on this card for click-to-focus hit-testing. Empty
	 * unless this is a task card whose details already name spawned agents.
	 * Callers intersect with the live registry, which decides focusability.
	 */
	getClickFocusAgentIds(): string[] {
		if (this.#toolName !== "task") return [];
		return taskCardAgentIds(this.#result?.details);
	}

	getTranscriptBlockVersion(): number {
		return this.#blockVersion;
	}
	/** Mark the call parked: it returned, but stays tracked for async job frames. */
	parkAsBackground(): void {
		this.#parkedBackground = true;
	}

	/**
	 * Mark the tool terminal even though no result arrived (the turn aborted or
	 * abandoned it) and stop animating so the container can retire it.
	 */
	seal(): void {
		if (this.#sealed) return;
		this.#sealed = true;
		this.#blockVersion++;
		this.#displaceableByToolName = undefined;
		this.#executionEndedAtNow ??= performance.now();
		this.stopAnimation();
		this.#updateDisplay();
		this.#ui.requestRender();
	}

	/**
	 * Whether this block is a supersedable result snapshot that has not been
	 * sealed. Displacement is best-effort: the snapshot finalizes like any other
	 * block, so under capacity pressure it may retire to native scrollback
	 * first — then the follow-up call appends a fresh snapshot instead of
	 * removing this one (see {@link TranscriptContainer.canRemoveBlock}).
	 */
	isDisplaceableBlock(): boolean {
		return this.#displaceableByToolName !== undefined && !this.#sealed;
	}

	canBeDisplacedBy(nextToolName: string | undefined): boolean {
		return (
			this.#displaceableByToolName !== undefined && this.#displaceableByToolName === nextToolName && !this.#sealed
		);
	}

	/**
	 * A live block torn down through the generic Container path (transcript
	 * clear, session switch mid-run) must not leak its shared-ticker
	 * registration: the dead component would keep the process-wide 80ms
	 * interval alive and keep being repainted.
	 */
	override dispose(): void {
		this.#stopShellReplay();
		this.#shellInspector?.hide();
		this.#shellInspector = undefined;
		this.stopAnimation();
		super.dispose();
	}

	/**
	 * Stop spinner animation and cleanup resources.
	 */
	stopAnimation(): void {
		if (this.#spinnerActive) {
			this.#spinnerActive = false;
			unregisterSpinnerBlock(this);
			this.#spinnerFrame = undefined;
			this.#renderState.spinnerFrame = undefined;
		}
		this.#stopTodoStrikeAnimation();
		this.#stopElapsedTicker();
		this.#previewReady?.resolve();
	}

	setExpanded(expanded: boolean): void {
		if (this.#expanded !== expanded) this.#blockVersion++;
		this.#expanded = expanded;
		this.#updateDisplay();
	}

	/** Mirrors the card collapsed or expanded in the terminal, so `Ctrl+O` and native toggles share one state. */
	handleNativeEvent(event: NativeUiEvent): void {
		if (this.#toolName === "bash" && chatTranscriptDisplayPreferences.shellVisualization) {
			const action = shellVizEventAction(event, this.#shellPreferences);
			if (action) {
				this.shellVizAction(action);
				return;
			}
		}
		const expanded = rootToggleExpanded(event);
		if (expanded !== undefined) this.setExpanded(expanded);
	}

	/**
	 * Blocks of their own right after the card: the result's Spotlight notice (visible while it is
	 * collapsed), and late diagnostics the card absorbed while a presenter compacts or hides it, so
	 * they stay visible.
	 */
	nativeTrailers(): readonly Component[] {
		const mode = this.#presentation.shown.mode;
		const late = this.#lateDiagnostics;
		// Drawn in full, the card shows its diagnostics itself: the notices' own (stable) list.
		if (mode === "full" || late === undefined) return mode === "hidden" ? EMPTY_TRAILERS : this.#spotlight.list();
		if (this.#lateDiagnosticsBlock?.files !== late) {
			this.#lateDiagnosticsBlock = { files: late, block: new LateDiagnosticsMessageComponent([...late]) };
		}
		const diagnostics = this.#lateDiagnosticsBlock.block;
		// Not a transcript child: the transcript-wide visibility reaches it only through this card.
		diagnostics.setToolActivityVisible(this.#toolActivityVisible);
		// A call a presenter hides takes its notice with it.
		return mode === "hidden" ? [diagnostics] : [...this.#spotlight.list(), diagnostics];
	}

	refreshTranscriptPresentation(ids?: ReadonlySet<string>): boolean {
		if (!this.#presentation.refresh(ids)) return false;
		this.#blockVersion++;
		super.invalidate();
		return true;
	}

	/** The streamed call's id changed (or an empty one was filled in): presenters see, and refresh by, the new one. */
	renameToolCallId(toolCallId: string): void {
		if (toolCallId === this.#toolCallId) return;
		this.#toolCallId = toolCallId;
		this.#presentation.markStale();
		this.#blockVersion++;
		super.invalidate();
	}

	isTranscriptBlockCompact(): boolean {
		if (!this.#toolActivityVisible || this.#allocation === 0 || (this.#toolName === "wait" && this.#isBenignSkip())) {
			return false;
		}
		return this.#presentation.shown.mode === "compact";
	}

	/** The file paths this call targets (edit/write/apply_patch args), display-relative. */
	#targetPaths(): string[] {
		const args = this.#args;
		if (!isRecord(args)) return [];
		const out: string[] = [];
		const add = (value: unknown) => {
			if (typeof value === "string" && value) out.push(displayPath(value));
		};
		add(args.path);
		add(args.file_path);
		for (const key of ["edits", "files"] as const) {
			const list = args[key];
			if (Array.isArray(list)) for (const entry of list) if (isRecord(entry)) add(entry.path);
		}
		return out;
	}

	/** Whether this call targets `filePath` (the late-diagnostics router matches with it). */
	matchesPath(filePath: string): boolean {
		const wanted = displayPath(filePath);
		return this.#targetPaths().includes(wanted);
	}

	/**
	 * Attaches LSP diagnostics that arrived after the result into this call's
	 * frame (§7.3: a diagnostics section plus a count chip in the head). Native
	 * rendering only; returns false when nothing matched, so the caller shows
	 * its standalone notice instead.
	 */
	attachLateDiagnostics(files: readonly (FileDiagnosticsResult & { readonly path: string })[]): boolean {
		if (!isNativeRendering()) return false;
		const mine = files.filter(file => this.matchesPath(file.path));
		if (mine.length === 0) return false;
		this.#lateDiagnostics = mine;
		this.#blockVersion++;
		this.#displayInputVersion++;
		this.invalidate();
		return true;
	}

	/**
	 * The tool card: `card` role `omp.tool.<name>` with the renderer's
	 * {@link NativeToolView} (head spans, body nodes), a status chip, an
	 * `elapsed` timer in the head and terminal-local collapse clamped to the
	 * view's preview. Renderers without describe hooks (and extension tools
	 * with only render hooks) get the generic card. Hidden tool activity stays
	 * mounted so toggling it is one prop change; a presenter's answer applies on top.
	 */
	override describe(cx?: DescribeContext): NativeNode {
		if (this.#toolName === "wait" && this.#isBenignSkip()) return EMPTY_NODE;
		const dataFirst = cx?.supports("tool") === true;
		const host: NativeHostKinds = {
			media: cx?.supports("media") === true,
			json: cx?.supports("json") === true,
			shell: cx?.supports("shell") === true,
			tray: cx?.feature("tray") === true,
		};
		const presentation = this.#presentation.draw();
		const key = [
			dataFirst,
			this.#resultVersion,
			this.#toolCallId,
			this.#expanded,
			this.#isPartial,
			this.#argsComplete,
			this.#executionStarted,
			this.#sealed,
			this.#parkedBackground,
			this.#showImages,
			this.#toolName === "bash" && chatTranscriptDisplayPreferences.shellVisualization,
			this.#displayInputVersion,
			this.#toolActivityVisible,
			host.media,
			host.json,
			host.shell,
			host.tray,
			getThemeEpoch(),
			presentation,
		];
		return this.#native.get(key, () => {
			const full = dataFirst ? this.#describeTool(host) : this.#describeCard(host);
			const shown = presentNative(full, presentation, {
				role: `omp.tool.${this.#toolName}`,
				title: this.#toolLabel,
				target: this.#activitySummary().detail,
			});
			return withHidden(shown, !this.#toolActivityVisible);
		});
	}

	/** Milliseconds since execution started (running) or its total (settled); undefined before it starts. */
	#elapsedMs(status: TspCardStatus): number | undefined {
		const started = this.#executionStartedAtNow;
		if (started === undefined) return undefined;
		const ended = status === "running" ? undefined : this.#executionEndedAtNow;
		return Math.max(0, Math.round((ended ?? performance.now()) - started));
	}

	/**
	 * The native `collapsed` prop: the transcript's expand state, except that a
	 * view that asks to be {@link NativeToolView.open} never starts folded, one
	 * that asks to be {@link NativeToolView.folded} always does, and
	 * a call streaming its body (edit, write) stays open until it settles, then
	 * folds like a finished thought. The user's own toggle still wins meanwhile:
	 * the terminal keeps local collapse state until this prop changes.
	 */
	#nativeCollapsed(status: TspCardStatus, view: NativeToolView): boolean {
		if (view.open) return false;
		if (view.folded) return true;
		const live = status === "pending" || status === "running";
		return !this.#expanded && !(live && streamsBody(this.#toolName));
	}

	/** The late diagnostics section and head chip, when LSP reported after the result. */
	#lateDiagnosticsParts(): { section?: NativeNode; chip?: { text: string; tone: TspTone } } {
		const files = this.#lateDiagnostics;
		if (!files || files.length === 0) return {};
		const sections = files.map(file => diagnosticsSection(file)).filter((n): n is NativeNode => n !== undefined);
		const count = files.reduce((sum, file) => sum + file.messages.length, 0);
		const errored = files.some(file => file.errored);
		const section =
			sections.length === 1
				? sections[0]
				: node("col", { gap: "sm", role: "omp.tool.diagnostics" }, sections, "late");
		return {
			section,
			chip: { text: count === 1 ? "1 diagnostic" : `${count} diagnostics`, tone: errored ? "error" : "warning" },
		};
	}

	/**
	 * The data-first `tool` node (§7.2): the renderer's head data, status,
	 * timer, exit and intent as props; its body as borderless children.
	 */
	#describeTool(host: NativeHostKinds): NativeNode {
		const view = this.#nativeView(host);
		const status = this.#nativeStatus();
		const head = view.tool;
		const late = this.#lateDiagnosticsParts();
		const body: NativeChild[] = [...(view.body ?? []), ...this.#nativeResultImages(view.body)];
		if (late.section) body.push(late.section);
		const inline = view.inline === true;
		const hasBody = body.length > 0;
		const ms = this.#elapsedMs(status);
		const live = status === "running" || status === "pending";
		const intent = isRecord(this.#args) ? this.#args[INTENT_FIELD] : undefined;
		const badges = [...(head?.badges ?? []), ...(late.chip ? [late.chip] : [])];
		const title: TspText = head?.title ?? (head ? this.#toolLabel : (view.head ?? this.#toolLabel));
		const preview = view.preview ?? (inline ? "none" : { lines: DEFAULT_TERMINAL_PREVIEW_LINES });
		return node(
			"tool",
			{
				role: `omp.tool.${this.#toolName}`,
				key: this.#toolCallId,
				name: this.#toolName,
				// `title` here is the head verb (TspToolProps), not the common tooltip.
				title: title as string,
				target: head?.target,
				targetKind: head?.targetKind,
				lang: head?.lang,
				command: head?.command,
				href: head?.href,
				meta: head?.meta,
				badges: badges.length > 0 ? badges : undefined,
				note: head?.note ?? (status === "cancelled" && !this.#isBenignSkip() ? "cancelled" : undefined),
				exit: head?.exit ?? undefined,
				status,
				age: live ? ms : undefined,
				took: live ? undefined : ms,
				intent: typeof intent === "string" && intent ? plainText(intent) : undefined,
				frame: inline ? "inline" : "card",
				collapsible: hasBody,
				collapsed: hasBody ? this.#nativeCollapsed(status, view) : undefined,
				preview: hasBody ? (preview === "auto" ? { lines: DEFAULT_TERMINAL_PREVIEW_LINES } : preview) : undefined,
				tools: view.tools,
				tone: view.tone,
			},
			body,
		);
	}

	/** The fallback card head: the renderer's spans, else spans from its data head. */
	#fallbackHead(view: NativeToolView): NativeToolView["head"] {
		if (view.head !== undefined) return view.head;
		const head = view.tool;
		if (!head) return undefined;
		const title =
			typeof head.title === "string"
				? head.title
				: head.title
					? plainText(head.title.map(s => s.t).join(""))
					: this.#toolLabel;
		const target = typeof head.target === "string" ? span(head.target, "muted") : head.target?.map(s => ({ ...s }));
		const meta = (head.meta ?? []).map(m => (typeof m === "string" ? m : m.map(s => s.t).join("")));
		const spans = toolHead(title, ...(Array.isArray(target) ? target : [target]), ...meta);
		if (head.exit) spans.push(span(" "), span(`exit ${head.exit}`, "error"));
		if (head.note)
			spans.push(
				span(" "),
				span(typeof head.note === "string" ? head.note : head.note.map(s => s.t).join(""), "muted"),
			);
		return spans;
	}

	#describeCard(host: NativeHostKinds): NativeNode {
		const view = this.#nativeView(host);
		const status = this.#nativeStatus();
		const late = this.#lateDiagnosticsParts();
		const fallbackHead = this.#fallbackHead(view);
		const headChildren: NativeChild[] = [
			// One line; paths drop whole directories first (path-aware middle cut), the full head in the tooltip.
			text(fallbackHead ?? [span(this.#toolLabel, "toolTitle")], {
				lines: 1,
				truncate: "middle",
				grow: 1,
				title: typeof fallbackHead === "string" ? fallbackHead : fallbackHead?.map(s => s.t).join(""),
			}),
		];
		const started = this.#executionStartedAtNow;
		if (started !== undefined) {
			const ended = status === "running" ? undefined : this.#executionEndedAtNow;
			const took = Math.max(0, Math.round((ended ?? performance.now()) - started));
			headChildren.push(node("elapsed", ended === undefined ? { age: took } : { age: took, stopped: took }));
		}
		const children: NativeChild[] = [
			node("row", { gap: "sm", align: "baseline" }, headChildren, "head"),
			...(view.body ?? []),
			...this.#nativeResultImages(view.body),
			...(late.section ? [late.section] : []),
		];
		const role = `omp.tool.${this.#toolName}`;
		if (view.inline) return col(children, { role });
		const hasBody = children.length > 1;
		return card(
			{
				role,
				key: this.#toolCallId,
				tone: view.tone ?? NATIVE_STATUS_TONE[status],
				status,
				collapsible: hasBody,
				collapsed: hasBody ? this.#nativeCollapsed(status, view) : undefined,
				preview: hasBody ? cardPreview(view.preview) : undefined,
			},
			children,
		);
	}

	#nativeStatus(): TspCardStatus {
		if (this.#isBenignSkip()) return "cancelled";
		if (this.#result !== undefined && !this.#isPartial) return this.#result.isError ? "error" : "done";
		if (this.#sealed) return "cancelled";
		return this.#result !== undefined || this.#executionStarted ? "running" : "pending";
	}

	/**
	 * The renderer's semantic view: the call view until a result exists, then
	 * the result view (merged renderers) or the call head over both bodies.
	 * A renderer that throws falls back to the generic card.
	 */
	#nativeView(host: NativeHostKinds): NativeToolView {
		const status = this.#nativeStatus();
		const options: RenderResultContextOptions = {
			...host,
			expanded: this.#expanded,
			isPartial: this.#isPartial,
			argsComplete: this.#argsComplete,
			executionStarted: this.#executionStarted,
			elapsedMs: this.#elapsedMs(status),
			cancelled: status === "cancelled",
			renderContext: this.#buildRenderContext(),
			shellPresentation: this.#getShellPresentation(),
			shellTrace: this.#shellTrace,
			shellReplayEpoch: this.#shellReplayEpoch,
		};
		// Custom tools (MCP, extensions) carry their own describe hooks, mirroring
		// the ANSI path's preference for the tool's renderCall/renderResult.
		const toolDescriber = this.#tool as ToolDescriber | undefined;
		const renderer: ToolDescriber | undefined =
			toolDescriber?.describeCall || toolDescriber?.describeResult ? toolDescriber : this.#renderer;
		if (this.#isBenignSkip() || !renderer || (!renderer.describeCall && !renderer.describeResult)) {
			return this.#defaultNativeView(options);
		}
		try {
			const args = this.#getCallArgsForRender();
			const result = this.#result;
			const merged = renderer.mergeCallAndResult === true;
			const resultView = result
				? renderer.describeResult?.(
						{ content: result.content, details: result.details, isError: result.isError },
						options,
						args,
					)
				: undefined;
			const callView = !result || !merged || !resultView ? renderer.describeCall?.(args, options) : undefined;
			if (merged || !callView || !resultView) {
				return resultView ?? callView ?? { head: [span(this.#toolLabel, "toolTitle")] };
			}
			return {
				tool: callView.tool || resultView.tool ? { ...callView.tool, ...resultView.tool } : undefined,
				head: callView.head ?? resultView.head,
				body: [...(callView.body ?? []), ...(resultView.body ?? [])],
				tone: resultView.tone ?? callView.tone,
				preview: resultView.preview ?? callView.preview,
				open: resultView.open ?? callView.open,
				folded: resultView.folded ?? callView.folded,
				inline: resultView.inline ?? callView.inline,
				tools: resultView.tools ?? callView.tools,
			};
		} catch (err) {
			logger.warn("Tool describe failed", { tool: this.#toolName, error: String(err) });
			return this.#defaultNativeView(options);
		}
	}

	#defaultNativeView(options: RenderResultContextOptions): NativeToolView {
		const result = this.#result;
		return describeDefaultToolExecution({
			label: this.#toolLabel,
			args: this.#args,
			result: result
				? { output: this.#nativeTextOutput(), isError: result.isError, skipped: this.#isBenignSkip() }
				: undefined,
			options,
		});
	}

	/** Result text for the generic card; images are native nodes unless images are hidden. */
	#nativeTextOutput(): string {
		const result = this.#result;
		if (!result) return "";
		const output = result.content
			.filter(block => block.type === "text")
			.map(block => sanitizeText(block.text || ""))
			.join("\n");
		if (this.#showImages) return output;
		const indicators = this.#getAllImageBlocks()
			.map(image => {
				const mimeType = String(image.mimeType);
				const dims = image.data ? (getImageDimensions(image.data, mimeType) ?? undefined) : undefined;
				return imageFallback(mimeType, dims);
			})
			.join("\n");
		return indicators ? (output ? `${output}\n${indicators}` : indicators) : output;
	}

	/** Result images under the renderer's body, minus those the body already shows (as an `image` blob or a `media` file). */
	#nativeResultImages(body: readonly NativeChild[] | undefined): NativeNode[] {
		if (!this.#result || !this.#showImages) return [];
		const shown = shownMedia(body);
		const mediaPath = readMediaPath(this.#rawDetails);
		if (mediaPath && shown.paths.has(mediaPath)) return [];
		const images: NativeNode[] = [];
		this.#getAllImageBlocks().forEach((image, index) => {
			if (!image.data || !image.mimeType) return;
			const described = this.#nativeImages.get(`img${index}`, image.data, image.mimeType, mediaPath);
			if (!shown.blobs.has((described.p as { blob?: string } | undefined)?.blob ?? "")) images.push(described);
		});
		return images;
	}

	/** Apply the transcript allocator's current viewport reservation. */
	setTranscriptAllocation(rows: number, frame: AnimationFrame): void {
		this.#allocation = Math.max(0, Math.trunc(rows));
		this.#presentationFrame = frame;
	}

	setToolActivityVisible(visible: boolean): void {
		this.#toolActivityVisible = visible;
		this.#spotlight.setHidden(!visible);
		this.#lateDiagnosticsBlock?.block.setToolActivityVisible(visible);
		super.invalidate();
	}

	setShowImages(show: boolean): void {
		this.#showImages = show;
		this.#updateDisplay();
	}

	override invalidate(): void {
		super.invalidate();
		this.#updateDisplay();
	}

	override releaseRenderCaches(): void {
		super.releaseRenderCaches();
		this.#textOutput = "";
		this.#textOutputTrimmed = undefined;
		this.#textOutputKey = undefined;
		this.#shellPresentation = undefined;
		this.#shellPresentationKey = undefined;
		this.#shellPendingTrace = undefined;
		this.#shellPendingScript = undefined;
		this.#lateDiagnosticsBlock?.block.releaseRenderCaches();
	}

	#updateDisplay(): void {
		// `TERMINAL.imageProtocol` is resolved by an async capability probe during
		// TUI startup, so a result rendered before it lands must re-shape once it
		// does (it gates Image children vs text fallback in #rebuildDisplay); keyed
		// here for the same reason markdown.ts keys its render cache on it.
		const key = `${this.#resultVersion}|${this.#expanded}|${this.#isPartial}|${this.#argsComplete ? "1" : "0"}|${this.#executionStarted ? "1" : "0"}|${this.#spinnerFrame ?? "-"}|${this.#showImages}|${getThemeEpoch()}|${this.#displayInputVersion}|${TERMINAL.imageProtocol ?? "-"}|${this.#imageSizeKey()}|${imageLinksEnabled()}|${this.#toolName === "bash" && chatTranscriptDisplayPreferences.shellVisualization}`;
		if (key === this.#lastDisplayKey && this.#displayBuilt) return;
		this.#lastDisplayKey = key;

		this.#rebuildDisplay();
		this.#displayBuilt = true;
	}

	#rendererFlag(name: "forceResultViewportRepaintOnSettle"): boolean {
		const toolValue = (this.#tool as Record<string, unknown> | undefined)?.[name];
		const rendererValue = this.#renderer?.[name];
		return toolValue === true || (toolValue === undefined && rendererValue === true);
	}

	/**
	 * True while the last painted pending-call shape opted into a full viewport
	 * repaint at the first result (`forceFirstResultViewportRepaint`) — e.g. a
	 * collapsed write tail window, which the first result render re-anchors
	 * instead of preserving. Kept as a per-paint fact so a topology-changing update that
	 * lands before the pending rows reach the terminal skips the reset.
	 */
	#needsFirstResultViewportRepaintAtRender(): boolean {
		if (this.#result !== undefined) return false;
		const toolValue = (this.#tool as { forceFirstResultViewportRepaint?: FirstResultViewportRepaint } | undefined)
			?.forceFirstResultViewportRepaint;
		const value = toolValue !== undefined ? toolValue : this.#renderer?.forceFirstResultViewportRepaint;
		if (typeof value === "function") return value(this.#args, this.#renderState);
		return value === true;
	}

	#resetDisplayForResultTopologyChange(
		firstResultAfterRepaintShapePaint: boolean,
		partialResultPaintedBeforeSettle: boolean,
		isPartial: boolean,
	): void {
		const provisionalResultSettled =
			partialResultPaintedBeforeSettle && !isPartial && this.#rendererFlag("forceResultViewportRepaintOnSettle");
		if (firstResultAfterRepaintShapePaint || provisionalResultSettled) {
			this.#ui.requestRender();
		}
	}

	override render(width: number): readonly string[] {
		if (!this.#toolActivityVisible || this.#allocation === 0 || (this.#toolName === "wait" && this.#isBenignSkip())) {
			return [];
		}
		const presentation = this.#presentation.draw();
		if (presentation.mode === "hidden") return [];
		if (presentation.mode === "compact") {
			// A squeezed allocation keeps the head (identity, spinner) and as many rows as fit.
			return compactRows(this.#compactText(width), presentation, width, this.#compactGlyph()).slice(
				0,
				this.#allocation,
			);
		}
		let lines = super.render(width);
		if (this.#allocation < 3) {
			// A squeezed allocation degrades only blocks that genuinely overflow it.
			// The allocator measures blocks by trimmed height and never squeezes one
			// below that, so inline tools whose real content is 1-2 rows (wait
			// results, one-line receipts) keep that content instead of an equally
			// tall but contentless frame.
			const trimmed = trimBlankEdges(lines);
			if (trimmed.length > this.#allocation) return this.#renderCompact(width);
			lines = trimmed;
		}
		this.#firstResultViewportRepaintShapePainted = this.#needsFirstResultViewportRepaintAtRender();
		this.#partialResultShapePainted = this.#result !== undefined && this.#isPartial;
		return lines;
	}

	/** The one-row summary: bold label, muted detail, and the elapsed seconds of a running call. */
	#compactText(width: number): string {
		const summary = this.#activitySummary();
		// Raw call input (a bash command): stripped of ANSI and control characters before theming.
		const shownDetail = summary.detail ? plainLine(summary.detail) : "";
		const detail = shownDetail ? theme.fg("muted", ` · ${shownDetail}`) : "";
		// Elapsed ticks only while the call is genuinely running; a settled
		// placeholder row must not read as live ("Todo · running 0s").
		const elapsed =
			this.#isRunning() && this.#executionStartedAtNow !== undefined
				? theme.fg(
						"dim",
						` ${Math.max(0, Math.floor((this.#presentationFrame.now - this.#executionStartedAtNow) / 1000))}s`,
					)
				: "";
		return truncateToWidth(
			`${theme.fg("toolTitle", theme.bold(plainLine(summary.label)))}${detail}${elapsed}`,
			Math.max(1, width - 4),
		);
	}

	/** The one-row form's lead glyph: the spinner while it animates, else a dim bullet. */
	#compactGlyph(): string {
		const glyph = this.#spinnerFrame === undefined ? "•" : (theme.spinnerFrames[this.#spinnerFrame] ?? "•");
		return theme.fg(this.#spinnerFrame === undefined ? "dim" : "muted", glyph);
	}

	#renderCompact(width: number): readonly string[] {
		const text = this.#compactText(width);
		if (this.#allocation === 1) return [truncateToWidth(`${this.#compactGlyph()} ${text}`, width)];
		return [truncateToWidth(`${theme.fg("dim", "╭─")} ${text}`, width), theme.fg("dim", "╰")];
	}

	#activitySummary(): ToolActivitySummary {
		this.#renderState.renderContext ??= this.#buildRenderContext();
		const summary = this.#renderer?.activitySummary?.(this.#args, {
			expanded: this.#expanded,
			isPartial: this.#isPartial,
			spinnerFrame: this.#spinnerFrame,
			renderContext: this.#renderState.renderContext,
		});
		if (summary !== undefined) {
			if (summary.detail) return summary;
			// A detail-less custom summary (e.g. wait before its result
			// parse) must not fold to a bare `╭─ Label` frame under viewport
			// pressure — keep the generic liveness hint for in-flight calls.
			return this.#isRunning() ? { ...summary, detail: "running" } : summary;
		}
		if (isRecord(this.#args)) {
			for (const key of ["command", "path", "input"] as const) {
				const value = this.#args[key];
				if (typeof value === "string" && value.length > 0) {
					return { label: this.#toolLabel, detail: value.split("\n", 1)[0] };
				}
			}
		}
		return { label: this.#toolLabel, detail: this.#isRunning() ? "running" : undefined };
	}
	/** Still executing: no settled result yet and the turn has not sealed it. */
	#isRunning(): boolean {
		return !this.#sealed && (this.#result === undefined || this.#isPartial);
	}

	// Viewport-/settings-dependent image sizing folded into the memo key only when
	// the last rebuild actually emitted images, so a terminal resize re-shapes an
	// image-bearing result (to rescale it) without re-shaping every image-free
	// result on each resize tick.
	#imageSizeKey(): string {
		if (this.#renderedImageCount === 0) return "-";
		const o = resolveImageOptions();
		return `${o.maxWidthCells}:${o.maxHeightCells ?? "-"}`;
	}

	#rebuildDisplay(): void {
		// Sync shared mutable render state for component closures
		this.#renderState.expanded = this.#expanded;
		this.#renderState.isPartial = this.#isPartial;
		this.#renderState.argsComplete = this.#argsComplete;
		this.#renderState.executionStarted = this.#executionStarted;
		this.#renderState.spinnerFrame = this.#spinnerFrame;

		// Interrupted waits carry only model-facing retry guidance, not user-facing output.
		if (this.#toolName === "wait" && this.#isBenignSkip()) {
			this.#contentBox.clear();
			return;
		}

		// Non-self-framing tools (custom/extension renderers and the generic
		// fallback) get a padded, state-tinted block — built-ins that draw their
		// own frame opt out below via the framed-component mark. A benign skip
		// (steering/peer interrupt aborted a still-pending call) never ran, so it
		// gets the neutral pending tint rather than the error tint (#7199).
		const benignSkip = this.#isBenignSkip();
		const stateBgKey =
			this.#isPartial || benignSkip ? "toolPendingBg" : this.#result?.isError ? "toolErrorBg" : "toolSuccessBg";
		// bgFill, not bg: rows carry nested full resets (e.g. truncateToWidth's
		// `\x1b[0m` before its ellipsis) that would otherwise punch holes in the tint.
		const stateBgFn = (t: string) => theme.bgFill(stateBgKey, t);

		// A benign skip is a synthetic placeholder for a call that never executed,
		// so bypass any bespoke error frame and draw the neutral generic card —
		// the per-tool ✘/red-border would misread normal mid-turn steering as a
		// failure (#7199).
		if (benignSkip) {
			this.#renderBenignSkipCard(stateBgFn);
		} else if (this.#tool && (this.#tool.renderCall || this.#tool.renderResult)) {
			const tool = this.#tool;
			const mergeCallAndResult = Boolean((tool as { mergeCallAndResult?: boolean }).mergeCallAndResult);
			// Custom tools use Box for flexible component rendering
			this.#contentBox.setBgFn(undefined);
			this.#contentBox.clear();
			// Mirror the built-in renderer branch so custom renderers (notably the
			// task tool, whose live instance routes through here) receive the same
			// render context — e.g. the `hasResult` flag that suppresses the task
			// call preview once result lines exist.
			this.#renderState.renderContext = this.#buildRenderContext();

			// Render call component. The fallback label only stands in for a
			// missing `renderCall`; when the call is intentionally suppressed
			// (mergeCallAndResult once a result exists) we render nothing here so
			// the result component isn't preceded by a redundant tool-name line.
			const shouldRenderCall = !this.#result || !mergeCallAndResult;
			if (shouldRenderCall) {
				if (tool.renderCall) {
					try {
						const callArgs = this.#getCallArgsForRender();
						const callComponent = tool.renderCall(callArgs, this.#renderState, theme) as Component | undefined;
						if (callComponent) {
							this.#contentBox.addChild(
								new SafeToolRendererComponent(
									this.#toolName,
									"call",
									callComponent,
									() => new Text(theme.fg("toolTitle", theme.bold(this.#toolLabel)), 0, 0),
								),
							);
						}
					} catch (err) {
						logger.warn("Tool renderer failed", { tool: this.#toolName, error: String(err) });
						// Fall back to default on error
						this.#contentBox.addChild(new Text(theme.fg("toolTitle", theme.bold(this.#toolLabel)), 0, 0));
					}
				} else {
					// No custom renderCall, show tool name
					this.#contentBox.addChild(new Text(theme.fg("toolTitle", theme.bold(this.#toolLabel)), 0, 0));
				}
			}

			// Render result component if we have a result
			if (this.#result && tool.renderResult) {
				try {
					const renderResult = tool.renderResult as (
						result: { content: Array<{ type: string; text?: string }>; details?: unknown; isError?: boolean },
						options: { expanded: boolean; isPartial: boolean; spinnerFrame?: number },
						theme: Theme,
						args?: unknown,
					) => Component;
					const resultComponent = renderResult(
						{
							content: this.#result.content,
							details: this.#result.details,
							isError: this.#result.isError,
						},
						this.#renderState,
						theme,
						this.#args,
					);
					if (resultComponent) {
						this.#contentBox.addChild(
							new SafeToolRendererComponent(this.#toolName, "result", resultComponent, () => {
								const output = this.#getTextOutput();
								if (!output) return undefined;
								return new Text(theme.fg("toolOutput", replaceTabs(output)), 0, 0);
							}),
						);
					}
				} catch (err) {
					logger.warn("Tool renderer failed", { tool: this.#toolName, error: String(err) });
					// Fall back to showing raw output on error
					const output = this.#getTextOutput();
					if (output) {
						this.#contentBox.addChild(new Text(theme.fg("toolOutput", replaceTabs(output)), 0, 0));
					}
				}
			} else if (this.#result) {
				// Has result but no custom renderResult
				const output = this.#getTextOutput();
				if (output) {
					this.#contentBox.addChild(new Text(theme.fg("toolOutput", replaceTabs(output)), 0, 0));
				}
			}
			// Custom tools that draw their own frame (task) render flush; plain
			// extension renderers get the padded, state-tinted block back.
			const customFramed = this.#contentBox.children.some(isFramedBlockComponent);
			this.#contentBox.setPaddingX(customFramed ? 0 : 1);
			this.#contentBox.setBgFn(customFramed ? undefined : stateBgFn);
		} else if (this.#renderer) {
			// The active registry entry is a built-in tool with a rich renderer.
			const renderer = this.#renderer;

			// Clean up previous multi-file boxes
			for (const box of this.#multiFileBoxes) {
				this.removeChild(box);
			}
			this.#multiFileBoxes = [];

			// Check for multi-file edit results
			const details = this.#result?.details;
			const perFileResults = (isRecord(details) ? details.perFileResults : undefined) as
				| Array<{ path: string; isError?: boolean }>
				| undefined;
			if (perFileResults && perFileResults.length > 1) {
				// Multi-file: render each file as its own Box (identical to separate tool calls)
				this.#contentBox.setBgFn(undefined);
				this.#contentBox.clear();

				const renderContext = this.#buildRenderContext();
				const rawPerFileResults =
					isRecord(this.#rawDetails) && Array.isArray(this.#rawDetails.perFileResults)
						? this.#rawDetails.perFileResults
						: undefined;
				this.#renderState.renderContext = renderContext;

				for (let i = 0; i < perFileResults.length; i++) {
					const fileResult = perFileResults[i];
					if (i > 0) {
						const spacer = new Spacer(1);
						this.#multiFileBoxes.push(spacer);
						this.addChild(spacer);
					}
					const fileBox = new Box(0, 0);
					try {
						const fileOptions = {
							...this.#renderState,
							renderContext: { ...renderContext, rawDetails: rawPerFileResults?.[i] },
						};
						const resultComponent = renderer.renderResult(
							{ content: [], details: fileResult, isError: fileResult.isError },
							fileOptions,
							theme,
						);
						if (resultComponent) {
							fileBox.addChild(
								new SafeToolRendererComponent(this.#toolName, "result", resultComponent, () => undefined),
							);
						}
					} catch (err) {
						logger.warn("Tool renderer failed", { tool: this.#toolName, error: String(err) });
					}
					this.#multiFileBoxes.push(fileBox);
					this.addChild(fileBox);
				}

				// Show pending indicator for remaining files
				const edits = isRecord(this.#args) ? this.#args.edits : undefined;
				const totalFiles = Array.isArray(edits)
					? new Set(edits.map((entry: unknown) => (isRecord(entry) ? entry.path : undefined)).filter(Boolean)).size
					: 0;
				const remaining = Math.max(0, totalFiles - perFileResults.length);
				if (remaining > 0 && this.#isPartial) {
					const pendingSpacer = new Spacer(1);
					this.#multiFileBoxes.push(pendingSpacer);
					this.addChild(pendingSpacer);
					const pendingBox = new Box(0, 0);
					const spinner =
						this.#spinnerFrame !== undefined ? formatStatusIcon("running", theme, this.#spinnerFrame) : "";
					const pendingText = renderStatusLine(
						{
							iconOverride: spinner,
							title: "Edit",
							description: theme.fg("dim", `${remaining} more file${remaining > 1 ? "s" : ""} pending…`),
						},
						theme,
					);
					pendingBox.addChild(new Text(pendingText, 0, 0));
					this.#multiFileBoxes.push(pendingBox);
					this.addChild(pendingBox);
				}
			} else {
				// Single-file or no result: standard rendering
				// Inline renderers skip background styling
				this.#contentBox.setBgFn(undefined);
				this.#contentBox.clear();

				const renderContext = this.#buildRenderContext();
				this.#renderState.renderContext = renderContext;

				const shouldRenderCall = !this.#result || !renderer.mergeCallAndResult;
				if (shouldRenderCall) {
					// Render call component
					try {
						const callArgs = this.#getCallArgsForRender();
						const callComponent = renderer.renderCall(callArgs, this.#renderState, theme);
						if (callComponent) {
							this.#contentBox.addChild(
								new SafeToolRendererComponent(
									this.#toolName,
									"call",
									callComponent,
									() => new Text(theme.fg("toolTitle", theme.bold(this.#toolLabel)), 0, 0),
								),
							);
						}
					} catch (err) {
						logger.warn("Tool renderer failed", { tool: this.#toolName, error: String(err) });
						// Fall back to default on error
						this.#contentBox.addChild(new Text(theme.fg("toolTitle", theme.bold(this.#toolLabel)), 0, 0));
					}
				}

				// Render result component if we have a result
				if (this.#result) {
					try {
						const resultComponent = renderer.renderResult(
							{
								content: this.#result.content,
								details: this.#result.details,
								isError: this.#result.isError,
							},
							this.#renderState,
							theme,
							this.#getCallArgsForRender(),
						);
						if (resultComponent) {
							this.#contentBox.addChild(
								new SafeToolRendererComponent(this.#toolName, "result", resultComponent, () => {
									const output = this.#getTextOutput();
									if (!output) return undefined;
									return new Text(theme.fg("toolOutput", replaceTabs(output)), 0, 0);
								}),
							);
						}
					} catch (err) {
						logger.warn("Tool renderer failed", { tool: this.#toolName, error: String(err) });
						// Fall back to showing raw output on error
						const output = this.#getTextOutput();
						if (output) {
							this.#contentBox.addChild(new Text(theme.fg("toolOutput", replaceTabs(output)), 0, 0));
						}
					}
				}
			}
		} else {
			// Generic fallback (no custom/built-in renderer). WidthAwareText
			// reformats at render time so output fills the actual terminal width
			// instead of a fixed column cap.
			this.#refreshContentText(stateBgKey, stateBgFn);
		}

		// Handle images (same for both custom and built-in)
		for (const img of this.#imageComponents) {
			this.removeChild(img);
		}
		this.#imageComponents = [];
		for (const spacer of this.#imageSpacers) {
			this.removeChild(spacer);
		}
		this.#imageSpacers = [];
		this.#syncFigure();

		if (this.#result) {
			const imageBlocks = this.#getAllImageBlocks();
			const sourcePath = readMediaPath(this.#rawDetails);

			for (let i = 0; i < imageBlocks.length; i++) {
				const img = imageBlocks[i];
				if (TERMINAL.imageProtocol && this.#showImages && img.data && img.mimeType) {
					// Use converted PNG for Kitty protocol if available
					const source: ImageContent = { type: "image", data: img.data, mimeType: img.mimeType };
					const converted =
						TERMINAL.imageProtocol === ImageProtocol.Kitty && img.mimeType !== "image/png"
							? (this.#kittyConverted.get(imagePayloadKey(source)) ?? cachedPngConversion(source))
							: undefined;
					const imageData = converted?.data ?? img.data;
					const imageMimeType = converted?.mimeType ?? img.mimeType;

					// For Kitty, skip non-PNG images that haven't been converted yet
					if (TERMINAL.imageProtocol === ImageProtocol.Kitty && imageMimeType !== "image/png") {
						continue;
					}

					const spacer = new Spacer(1);
					this.addChild(spacer);
					this.#imageSpacers.push(spacer);
					const imageComponent = new Image(
						imageData,
						imageMimeType,
						{ fallbackColor: (s: string) => theme.fg("toolOutput", s) },
						{
							...resolveImageOptions(),
							sourcePath,
							budget: this.#ui.imageBudget,
							imageKey: `te${this.#instanceId}:${i}`,
							requestRender: () => this.#ui.requestRender(),
						},
					);
					this.#imageComponents.push(imageComponent);
					this.addChild(imageComponent);
				}
			}
		}
		this.#renderedImageCount = this.#imageComponents.length;
	}

	/**
	 * Mount the built-in renderer's figure under the card and feed it the fence
	 * as it stands: the mounted one stays while its language is unchanged, so it
	 * redraws in place as the args stream.
	 */
	#syncFigure(): void {
		const result = this.#result;
		const renderer = this.#tool?.renderCall || this.#tool?.renderResult ? undefined : this.#renderer;
		const fence =
			this.#isBenignSkip() || isNativeRendering()
				? undefined
				: renderer?.figure?.(
						this.#args,
						result && { content: result.content, details: result.details, isError: result.isError },
						this.#renderState,
					);
		const drawable = fence !== undefined && FenceFigure.draws(fence, { showImages: this.#showImages });
		let figure = this.#figure;
		if (figure && (!drawable || figure.lang !== fence.lang)) {
			this.removeChild(figure);
			figure.dispose();
			figure = this.#figure = undefined;
		}
		if (!drawable) return;
		if (!figure) {
			figure = this.#figure = new FenceFigure(fence.lang, {
				budget: this.#ui.imageBudget,
				onChange: () => {
					this.#blockVersion++;
					this.#ui.requestRender();
				},
			});
			this.addChild(figure);
		}
		figure.update(fence);
	}

	#getCallArgsForRender(): unknown {
		const renderArgs = this.#args;
		if (!isEditLikeToolName(this.#toolName)) {
			return renderArgs;
		}
		const previews = this.#editDiffPreview;
		if (!previews || previews.length === 0) {
			return renderArgs;
		}
		// Single-file previews feed the existing `previewDiff` channel consumed
		// by `formatStreamingDiff` in the renderer.
		const first = previews[0];
		if (!first?.diff) {
			return renderArgs;
		}
		return { ...(renderArgs as Record<string, unknown>), previewDiff: first.diff };
	}

	/**
	 * Build render context for tools that need extra state (bash, python, edit)
	 */
	#buildRenderContext(): Record<string, unknown> {
		const context: Record<string, unknown> = {};
		const normalizeTimeoutSeconds = (value: unknown, maxSeconds: number): number | undefined => {
			if (typeof value !== "number" || !Number.isFinite(value)) return undefined;
			return Math.max(1, Math.min(maxSeconds, value));
		};

		if (this.#renderer && !this.#tool?.renderResult && this.#rawDetails !== undefined) {
			context.rawDetails = this.#rawDetails;
		}
		if (this.#toolName === "bash") {
			this.#renderState.shellTrace = this.#shellTrace;
			this.#renderState.shellReplayEpoch = this.#shellReplayEpoch;
			// Bash needs render context even before a result exists. The renderer uses the pending-call args
			// plus this context to keep the inline command preview visible while tool-call JSON is still streaming.
			if (this.#result) {
				// Pass raw output and expanded state - renderer handles width-aware truncation
				Object.defineProperty(context, "output", {
					get: () => this.#getTrimmedTextOutput(),
					enumerable: true,
				});
			}
			context.expanded = this.#expanded;
			context.previewLines = DEFAULT_TERMINAL_PREVIEW_LINES;
			context.timeout = normalizeTimeoutSeconds(isRecord(this.#args) ? this.#args.timeout : undefined, 3600);
		} else if (this.#toolName === "eval" && this.#result) {
			Object.defineProperty(context, "output", {
				get: () => this.#getTrimmedTextOutput(),
				enumerable: true,
			});
			context.expanded = this.#expanded;
			context.previewLines = DEFAULT_TERMINAL_PREVIEW_LINES;
		} else if (this.#toolName === "task") {
			// Once a result snapshot exists the task renderer's `renderResult`
			// draws every dispatched agent as a progress/result line, so tell
			// `renderCall` to drop its duplicate streaming preview list.
			context.hasResult = Boolean(this.#result);
			this.#taskRenderNowMs = Date.now();
			context.nowMs = this.#taskRenderNowMs;
		} else if (isEditLikeToolName(this.#toolName)) {
			context.editMode = this.#editMode;
			const previews = this.#editDiffPreview;
			if (previews && previews.length > 0) {
				const first = previews[0];
				if (first?.diff || first?.error) {
					context.editDiffPreview = first.error
						? { error: first.error }
						: { diff: first.diff ?? "", firstChangedLine: first.firstChangedLine };
				}
				if (previews.length > 1) {
					context.perFileDiffPreview = previews;
				}
			}
			if (!previews?.some(preview => preview.diff)) {
				const editMode = this.#editMode;
				const fallback = editMode ? renderStreamingFallback(editMode, this.#args, theme) : "";
				if (fallback) context.editStreamingFallback = fallback;
			}
			context.renderDiff = renderDiff;
		} else if (this.#toolName === "write") {
			// Device-dispatch previews render through the host's canonical resolver,
			// which covers mounted devices and active top-level tools (the `write`
			// transport accepts both). Deciding the predicate here instead would
			// leave a `write xd://<top-level tool>` card on the generic fallback.
			const writeTool = this.#tool as { session?: { xdev?: XdevMountedState } } | undefined;
			const resolveXdevMounted = writeTool?.session?.xdev?.resolve;
			if (resolveXdevMounted) {
				context.resolveXdevMounted = resolveXdevMounted;
			}
		}

		return context;
	}

	#getTextOutput(): string {
		if (!this.#result) return "";
		// Image placeholders embed a link only under an enabled hyperlink policy.
		const key = `${this.#resultVersion}|${this.#showImages}|${TERMINAL.imageProtocol ?? "-"}|${imageLinksEnabled()}`;
		if (key === this.#textOutputKey) return this.#textOutput;

		const textBlocks = this.#result.content.filter(c => c.type === "text");
		const imageBlocks = this.#getAllImageBlocks();

		let output = textBlocks
			.map(c => {
				return sanitizeWithOptionalSixelPassthrough(c.text || "", sanitizeText);
			})
			.join("\n");

		if (imageBlocks.length > 0 && (!TERMINAL.imageProtocol || !this.#showImages)) {
			const imageIndicators = imageBlocks
				.map(img => {
					const mimeType = String(img.mimeType);
					const dims = img.data ? (getImageDimensions(img.data, mimeType) ?? undefined) : undefined;
					const placeholder = imageFallback(mimeType, dims);
					return img.data
						? linkedImageText(placeholder, { data: img.data, mimeType }, readMediaPath(this.#rawDetails))
						: placeholder;
				})
				.join("\n");
			output = output ? `${output}\n${imageIndicators}` : imageIndicators;
		}

		this.#textOutputKey = key;
		this.#textOutput = output;
		this.#textOutputTrimmed = undefined;
		return output;
	}

	#getTrimmedTextOutput(): string {
		const output = this.#getTextOutput();
		this.#textOutputTrimmed ??= output.trimEnd();
		return this.#textOutputTrimmed;
	}

	/** Re-tint (only when the tint changed) and reformat the generic #contentText card. */
	#refreshContentText(stateBgKey: string, stateBgFn: (text: string) => string): void {
		const bgKey = `${stateBgKey}|${getThemeEpoch()}`;
		if (bgKey !== this.#contentTextBgKey) {
			this.#contentTextBgKey = bgKey;
			this.#contentText.setCustomBgFn(stateBgFn);
		}
		this.#contentText.reformat();
	}

	/**
	 * Format the generic call/result card at `contentWidth`. Shared by the
	 * #contentText fallback and the benign-skip path so both render identically.
	 */
	#renderDefaultCard(contentWidth: number): string {
		return formatDefaultToolExecution(
			{
				label: this.#toolLabel,
				args: this.#args,
				result: this.#result
					? { output: this.#getTextOutput(), isError: this.#result.isError, skipped: this.#isBenignSkip() }
					: undefined,
				options: this.#renderState,
			},
			contentWidth,
			theme,
		);
	}

	/**
	 * True for a steering/peer-interrupt placeholder. A synthetic placeholder
	 * identifies a call that never entered `tool.execute`; an interrupted
	 * placeholder identifies one that started but threw before returning usable
	 * output. Both are normal steering control flow and render neutrally (#7199).
	 */
	#isBenignSkip(): boolean {
		if (this.#isPartial || !this.#result) return false;
		const details = this.#result.details as
			| { __synthetic?: boolean; __interrupted?: boolean; source?: string; execution?: string }
			| undefined;
		if (details?.source !== "interrupt_skipped") return false;
		return details.__synthetic === true || (details.__interrupted === true && details.execution === "started");
	}

	/**
	 * Render a benign skip as the neutral generic card, replacing any bespoke
	 * renderer's error frame. Generic-fallback tools already route through
	 * {@link #renderDefaultCard} (which emits the info card for a skip); they
	 * only need the neutral tint. Bespoke-renderer tools get their content box
	 * swapped for the same neutral card.
	 */
	#renderBenignSkipCard(stateBgFn: (text: string) => string): void {
		if (!this.#usesContentBox) {
			this.#refreshContentText("toolPendingBg", stateBgFn);
			return;
		}
		for (const box of this.#multiFileBoxes) {
			this.removeChild(box);
		}
		this.#multiFileBoxes = [];
		this.#contentBox.setBgFn(undefined);
		this.#contentBox.clear();
		this.#contentBox.setPaddingX(1);
		this.#contentBox.setBgFn(stateBgFn);
		this.#contentBox.addChild(new WidthAwareText(contentWidth => this.#renderDefaultCard(contentWidth), 0, 0));
	}
}
