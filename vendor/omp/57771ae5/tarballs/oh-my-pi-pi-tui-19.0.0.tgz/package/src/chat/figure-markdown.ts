import type { Tokens } from "@oh-my-pi/pi-utils/marked";
import type { ImageBudget } from "../components/image";
import { type Markdown, streamingMarkdownSource, type TableLocks } from "../components/markdown";
import { Spacer } from "../components/spacer";
import { TERMINAL } from "../terminal-capabilities";
import { Container } from "../tui";
import { EmbedFigure } from "./embed-figure";
import { embedHost } from "./embed-host";
import { type Embed, type EmbedSegment, hasEmbed, splitEmbeds } from "./embed-source";
import { SvgFigure, svgFigureRendering } from "./svg-figure";
import { type FigureSegment, splitSvgFences } from "./svg-source";
import { type ChartSegment, hasChartTable, splitTableCharts, TableChartFigure } from "./table-chart";

export interface FigureMarkdownOptions {
	/** Markdown for one prose run (and a failed figure's code fallback); FigureMarkdown drives its transience. */
	markdown: (text: string) => Markdown;
	/**
	 * Table locks for the leading prose run (see {@link Markdown.tableLocks}),
	 * the only run a transcript publishes stable rows from.
	 */
	tableLocks?: TableLocks;
	/** Draw charts under numeric tables; off for transcripts that are not the main session's. */
	charts: boolean;
	/** Whether the transcript shows pictures; off, fences and tables stay Markdown and an embed is its one-row note. */
	showImages: boolean;
	/** Shared inline-image budget for the figures. */
	budget?: ImageBudget;
	/** Rows each figure may fill, read on every render; callers reserve prose, chrome and separators themselves. Unset or `undefined` takes a share of the terminal viewport. */
	maxRows?: () => number | undefined;
	/** A figure's rows changed outside a text update (raster landed, fell back to code). */
	onChange: () => void;
}

type Segment = FigureSegment | EmbedSegment | ChartSegment;

type Part =
	| { readonly kind: "markdown"; readonly md: Markdown; text: string }
	| { readonly kind: "svg"; readonly figure: SvgFigure; source: string; closed: boolean }
	| { readonly kind: "embed"; readonly figure: EmbedFigure; embed: Embed }
	| { readonly kind: "chart"; readonly figure: TableChartFigure; table: Tokens.Table };

/**
 * Assistant Markdown whose top-level ```svg fences are lifted out of the prose
 * and drawn as images ({@link SvgFigure}), whose `<img>`/`<iframe>` lines are
 * drawn as pictures ({@link EmbedFigure}), and whose numeric tables get a chart
 * drawn under them ({@link TableChartFigure}), with ordinary {@link Markdown}
 * for the prose between them. Stands in for Markdown on an assistant text
 * block that holds an svg fence, an embed or a chartable table: {@link setText} streams
 * in place, reusing every part whose kind is unchanged, and
 * {@link transientRenderCache} marks the block's tail as still streaming — the
 * last prose run renders transient, the last figure throttles its rasters
 * until its fence closes, and a table at the tail waits for its last row.
 */
export class FigureMarkdown extends Container {
	readonly #options: FigureMarkdownOptions;
	#text = "";
	#transient = false;
	#parts: Part[] = [];

	constructor(text: string, options: FigureMarkdownOptions) {
		super();
		this.#options = options;
		this.setText(text);
	}

	/** Replace the source; returns whether it changed. */
	setText(text: string): boolean {
		if (text === this.#text) return false;
		this.#text = text;
		this.#reconcile();
		return true;
	}

	get transientRenderCache(): boolean {
		return this.#transient;
	}

	set transientRenderCache(value: boolean) {
		if (this.#transient === value) return;
		this.#transient = value;
		// The end of the stream completes a tail table, which may now get its chart.
		this.#reconcile();
	}

	/**
	 * The trimmed prose ahead of the first figure, or "" when the block opens
	 * with one. These are the only rows plain Markdown reproduces byte for
	 * byte, so they are all a transcript may publish ahead of the figure. While
	 * that prose is still the streaming tail (no figure follows it yet), only
	 * its settled prefix ({@link Markdown.getLastRenderStableText}) qualifies:
	 * the rest is still being written. Both forms are in
	 * {@link streamingMarkdownSource} form, so the settled prefix stays a byte
	 * prefix of the whole run once a figure splits it off.
	 */
	get leadingProse(): string {
		const first = this.#parts[0];
		if (first?.kind !== "markdown") return "";
		if (this.#transient && this.#parts.length === 1) return first.md.getLastRenderStableText().trim();
		return streamingMarkdownSource(first.text);
	}

	/** Whether {@link leadingProse} ends inside a locked table that is still streaming. */
	get leadingProseEndsInOpenTable(): boolean {
		const first = this.#parts[0];
		return (
			first?.kind === "markdown" &&
			this.#transient &&
			this.#parts.length === 1 &&
			first.md.lastRenderStableTextEndsInOpenTable()
		);
	}

	/** Lock a table streaming at the tail of the leading prose; see {@link Markdown.lockOpenTable}. */
	lockOpenTable(): boolean {
		const first = this.#parts[0];
		return first?.kind === "markdown" && this.#transient && this.#parts.length === 1 && first.md.lockOpenTable();
	}

	/** Whether a figure's final source still waits for its raster, or a chart for its pick or raster. */
	get pending(): boolean {
		return this.#parts.some(part => part.kind !== "markdown" && part.figure.pending);
	}

	/** Rebuild the prose runs through the Markdown factory after its theme changed; figures keep their rasters. */
	restyle(): void {
		this.#parts = this.#parts.map((part, index) =>
			part.kind === "markdown" ? { kind: "markdown", md: this.#proseRun(part.text, index), text: part.text } : part,
		);
		this.#mount();
		this.#syncTails();
	}

	#proseRun(text: string, index: number): Markdown {
		const md = this.#options.markdown(text);
		if (index === 0) md.tableLocks = this.#options.tableLocks;
		return md;
	}

	#reconcile(): void {
		const previous = this.#parts;
		const segments = this.#segments();
		let reshaped = previous.length !== segments.length;
		this.#parts = segments.map((segment, index): Part => {
			const old = previous[index];
			if (segment.kind === "chart") {
				if (old?.kind === "chart") {
					old.table = segment.table;
					return old;
				}
				reshaped = true;
				const { budget, maxRows, onChange } = this.#options;
				return { kind: "chart", figure: new TableChartFigure({ budget, maxRows, onChange }), table: segment.table };
			}
			if (segment.kind === "embed") {
				if (old?.kind === "embed") {
					old.embed = segment.embed;
					return old;
				}
				reshaped = true;
				const { budget, maxRows, showImages, onChange } = this.#options;
				return {
					kind: "embed",
					figure: new EmbedFigure({ budget, maxRows, showImages, onChange }),
					embed: segment.embed,
				};
			}
			if (segment.kind === "markdown") {
				const text = segment.text.trim();
				if (old?.kind === "markdown") {
					old.md.setText(text);
					old.text = text;
					return old;
				}
				reshaped = true;
				return { kind: "markdown", md: this.#proseRun(text, index), text };
			}
			if (old?.kind === "svg") {
				old.source = segment.source;
				old.closed = segment.closed;
				return old;
			}
			reshaped = true;
			const { markdown, budget, maxRows, onChange } = this.#options;
			return {
				kind: "svg",
				figure: new SvgFigure({ markdown, budget, maxRows, onChange }),
				source: segment.source,
				closed: segment.closed,
			};
		});
		if (reshaped) {
			for (const old of previous) {
				if (old.kind !== "markdown" && !this.#parts.includes(old)) old.figure.dispose();
			}
			this.#mount();
		}
		this.#syncTails();
	}

	/**
	 * The block as prose, ```svg fences (when figures are on), embed lines
	 * (when embeds are on) and charts after complete tables (when charts are
	 * on); only the last run can still stream. Fences and tables lift only
	 * where pictures show; an embed lifts anywhere, as its note.
	 */
	#segments(): Segment[] {
		const pictures = this.#options.showImages && TERMINAL.imageProtocol !== null;
		let segments: Segment[] =
			pictures && svgFigureRendering() ? splitSvgFences(this.#text) : [{ kind: "markdown", text: this.#text }];
		if (embedHost() && hasEmbed(this.#text)) {
			segments = this.#splitProse(segments, (text, streaming) => splitEmbeds(text, { streaming }));
		}
		if (pictures && this.#options.charts && hasChartTable(this.#text)) {
			segments = this.#splitProse(segments, splitTableCharts);
		}
		return segments;
	}

	/** Split each prose run of `segments` further; `streaming` marks the run the block's tail is still writing. */
	#splitProse(segments: Segment[], split: (text: string, streaming: boolean) => Segment[]): Segment[] {
		const last = segments.length - 1;
		return segments.flatMap((segment, index) =>
			segment.kind === "markdown" ? split(segment.text, this.#transient && index === last) : [segment],
		);
	}

	/** Mount the parts as children, a blank row between neighbours; a chart draws its own when it has rows. */
	#mount(): void {
		this.clear();
		this.#parts.forEach((part, index) => {
			if (index > 0 && part.kind !== "chart") this.addChild(new Spacer(1));
			this.addChild(part.kind === "markdown" ? part.md : part.figure);
		});
	}

	/** Push sources and streaming state down: only the last part can still be streaming. */
	#syncTails(): void {
		const last = this.#parts.length - 1;
		this.#parts.forEach((part, index) => {
			const streaming = this.#transient && index === last;
			if (part.kind === "markdown") part.md.transientRenderCache = streaming;
			else if (part.kind === "svg") part.figure.update(part.source, part.closed || !streaming);
			else if (part.kind === "embed") part.figure.update(part.embed);
			else part.figure.update(part.table);
		});
	}
}
