/**
 * Component for displaying bash command execution with streaming output.
 */

import type { ImageContent } from "@oh-my-pi/pi-ai";
import { Image } from "../components/image";
import type { Loader } from "../components/loader";
import { Text } from "../components/text";
import { getImageDimensions, imageFallback, ImageProtocol, TERMINAL } from "../terminal-capabilities";
import { Container, type TUI } from "../tui";
import { sanitizeText } from "@oh-my-pi/pi-utils";
import type { Terminal as XtermTerminalType } from "@oh-my-pi/pi-utils/vterm";
import { theme } from "../theme/theme";
import type { OutputArtifactError } from "../tools/streaming-output";
import type { MinimizedMeta, TruncationMeta } from "../tools/output-meta";
import { resolveImageOptions } from "../render/render-utils";
import { OutputPane } from "../render/output-pane";
import { loadXtermTerminal, readTerminalRows, styleTerminalRow } from "../tools/terminal-output";
import { normalizeInputForPty } from "../tools/bash-interactive";
import { getSixelLineMask, isSixelPassthroughEnabled, sanitizeWithOptionalSixelPassthrough } from "../render/sixel";
import {
	buildExecutionFrame,
	buildStatusFooter,
	clampDisplayLine,
	describeExecutionCard,
	describeExecutionTool,
	type ExecutionColorKey,
	type ExecutionStatus,
	executionStatusLabel,
	PREVIEW_LINES,
	resolveExecutionStatus,
} from "./execution-shared";
import { span, text } from "../native/describe";
import { type DescribeContext, type NativeNode, type NativeUiEvent, rootToggleExpanded } from "../native/node";
import { NativeImageCache } from "../native/blobs";
import { imageLinksEnabled, linkedImageSpan, linkedImageText } from "../prompt/image-references";
import { Memo } from "../native/memo";
import type { DynamicBorder } from "../chrome/dynamic-border";

const STREAMING_LINE_CAP = PREVIEW_LINES * 5;
// Minimum interval between processing incoming chunks for display (ms).
// Chunks arriving faster than this are accumulated and processed in one batch.
const CHUNK_THROTTLE_MS = 50;
// Scrollback retained by the PTY replay terminal; bounds memory and the
// expanded view for long-running commands.
const PTY_SCROLLBACK_ROWS = 4096;
// Caps the unwritten PTY chunk backlog while xterm.write drains.
const MAX_PTY_QUEUE_CHUNKS = 512;
let nextBashExecutionId = 0;

/** PTY size for `!` commands: the execution frame's inner content area. */
export function bashPtyViewport(ui: TUI): { cols: number; rows: number } {
	return {
		cols: Math.max(20, (ui.terminal?.columns ?? 80) - 2),
		rows: Math.max(5, (ui.terminal?.rows ?? 24) - 4),
	};
}

export class BashExecutionComponent extends Container {
	#outputLines: string[] = [];
	#status: ExecutionStatus = "running";
	#exitCode: number | undefined = undefined;
	#loader: Loader;
	readonly #bottomBorder: DynamicBorder;
	#truncation?: TruncationMeta;
	#artifactError?: OutputArtifactError;
	#minimized?: MinimizedMeta;
	#expanded = false;
	// Post-finalize mutation counter (FinalizableBlock.getTranscriptBlockVersion):
	// a completed command's block still mutates on expansion toggles, and the
	// transcript's width-epoch resolution and committed-render bypass must
	// observe that.
	#blockVersion = 0;
	#displayDirty = false;
	#chunkGate = false;
	#contentContainer: Container;
	#outputPane: OutputPane;
	#headerText: Text;
	#ui: TUI;
	// PTY replay state: raw terminal bytes stream into a headless xterm and the
	// display lines are re-read from its screen+scrollback (same pipeline as
	// `launch` logs), so color survives and CR/cursor movement render correctly.
	#ptyMode = false;
	#ptyTerminal?: XtermTerminalType;
	#ptyLoadStarted = false;
	#ptyQueue: string[] = [];
	#ptyWriting = false;
	#ptyRefreshQueued = false;
	#ptyReplayFinalized = false;
	#images: readonly ImageContent[] = [];
	#showImages = true;
	readonly #instanceId = nextBashExecutionId++;
	readonly #command: string;
	readonly #colorKey: ExecutionColorKey;
	readonly #startedAt = performance.now();
	#endedAt: number | undefined;
	// Bumped whenever the displayed output lines change.
	#outputVersion = 0;
	readonly #native = new Memo();
	readonly #nativeImages = new NativeImageCache();

	constructor(command: string, ui: TUI, excludeFromContext = false) {
		super();
		this.#command = command;
		this.#ui = ui;

		// Use dim border for excluded-from-context commands (!! prefix)
		const colorKey = excludeFromContext ? "dim" : "bashMode";
		this.#colorKey = colorKey;
		const { contentContainer, loader, bottomBorder } = buildExecutionFrame(this, ui, colorKey);
		this.#contentContainer = contentContainer;
		this.#loader = loader;
		this.#bottomBorder = bottomBorder;
		this.#outputPane = new OutputPane(theme, {
			expanded: false,
			collapsedMaxLines: PREVIEW_LINES,
			edge: "tail",
			visual: true,
			paddingX: 1,
			leadingBlank: true,
			showHiddenMarker: false,
			showExpandHint: false,
			styleLine: line => this.#styleDisplayLine(line),
		});

		// Command header
		this.#headerText = new Text(theme.fg(colorKey, theme.bold(`$ ${command}`)), 1, 0);
		this.#contentContainer.addChild(this.#headerText);
	}

	/**
	 * Transcript finalization contract (see `FinalizableBlock`): the collapsed
	 * streaming preview rewrites its tail window every chunk, so the block must
	 * stay out of native scrollback until the command completes.
	 */
	isTranscriptBlockFinalized(): boolean {
		return this.#status !== "running" && (!this.#ptyMode || this.#ptyReplayFinalized);
	}

	getTranscriptBlockVersion(): number {
		return this.#blockVersion;
	}

	/**
	 * Set whether the output is expanded (shows full output) or collapsed (preview only).
	 */
	setExpanded(expanded: boolean): void {
		if (this.#expanded !== expanded) this.#blockVersion++;
		this.#expanded = expanded;
		this.#outputPane.setExpanded(expanded);
		this.#updateDisplay();
	}

	override invalidate(): void {
		super.invalidate();
		this.#displayDirty = false;
		this.#updateDisplay();
	}

	handleNativeEvent(event: NativeUiEvent): void {
		const expanded = rootToggleExpanded(event);
		if (expanded !== undefined) this.setExpanded(expanded);
	}

	/**
	 * The agent's bash `tool` frame (role `omp.bash`) with a `you` badge: the
	 * command in the head, the output as an `ansi` mini terminal following its
	 * tail. Terminals without the `tool` kind get a `card` headed by the
	 * command.
	 */
	override describe(cx?: DescribeContext): NativeNode {
		const dataFirst = cx?.supports("tool") === true;
		const key = [
			dataFirst,
			this.#outputVersion,
			this.#blockVersion,
			this.#status,
			this.#expanded,
			this.#showImages,
			this.#images.length,
			// Image nodes and placeholders carry links only under an enabled policy.
			imageLinksEnabled(),
		];
		return this.#native.get(key, () => {
			const images = this.#images.map((image, index) =>
				this.#showImages
					? this.#nativeImages.get(`img${index}`, image.data, image.mimeType)
					: text([
							linkedImageSpan(
								imageFallback(image.mimeType, getImageDimensions(image.data, image.mimeType) ?? undefined),
								image,
								undefined,
								"muted",
							),
						]),
			);
			const common = {
				role: "omp.bash",
				status: this.#status,
				startedAt: this.#startedAt,
				expanded: this.#expanded,
				output: this.#outputLines.join("\n"),
				images,
				exitCode: this.#exitCode,
				truncation: this.#truncation,
				artifactError: this.#artifactError,
				minimized: this.#minimized,
			};
			return dataFirst
				? describeExecutionTool({
						...common,
						name: "bash",
						title: "Bash",
						command: this.#command,
						lang: "bash",
						excluded: this.#colorKey === "dim",
						endedAt: this.#endedAt,
					})
				: describeExecutionCard({
						...common,
						head: [span(`$ ${this.#command}`, `${this.#colorKey} strong`)],
						muted: this.#colorKey === "dim",
					});
		});
	}

	appendOutput(chunk: string): void {
		if (this.#ptyMode) return;
		// During high-throughput output (e.g. seq 1 500M), processing every
		// chunk would saturate the event loop. Instead, accept one chunk per
		// throttle window and drop the rest — the OutputSink captures everything
		// for the artifact, and setComplete() replaces with the final output.
		if (this.#chunkGate) return;
		this.#chunkGate = true;
		setTimeout(() => {
			this.#chunkGate = false;
		}, CHUNK_THROTTLE_MS);

		const incomingLines = chunk.split("\n");
		if (this.#outputLines.length > 0 && incomingLines.length > 0) {
			const lastIndex = this.#outputLines.length - 1;
			const mergedLines = [`${this.#outputLines[lastIndex]}${incomingLines[0]}`, ...incomingLines.slice(1)];
			const clampedMergedLines = this.#clampLinesPreservingSixel(mergedLines);
			this.#outputLines[lastIndex] = clampedMergedLines[0] ?? "";
			this.#outputLines.push(...clampedMergedLines.slice(1));
		} else {
			this.#outputLines.push(...this.#clampLinesPreservingSixel(incomingLines));
		}

		// Cap stored lines during streaming to avoid unbounded memory growth
		if (this.#outputLines.length > STREAMING_LINE_CAP) {
			this.#outputLines = this.#outputLines.slice(-STREAMING_LINE_CAP);
		}

		this.#displayDirty = true;
		this.#outputVersion++;
	}

	/** Switch to PTY rendering and feed raw terminal bytes through the vterm replay. */
	appendPtyChunk(chunk: string): void {
		if (this.#status !== "running" && !this.#ptyWriting && this.#ptyQueue.length === 0) return;
		if (!this.#ptyMode) {
			this.#ptyMode = true;
			// The pane's `styleLine` reads `#ptyMode`, so its styled rows change
			// the moment this flips — with the rows themselves unchanged. The pane
			// memoizes its styled output, so it has to be told.
			this.#outputPane.invalidate();
		}
		this.#ptyReplayFinalized = false;
		this.#ptyQueue.push(chunk);
		if (this.#ptyQueue.length > MAX_PTY_QUEUE_CHUNKS) {
			const firstPending = this.#ptyWriting ? 1 : 0;
			this.#ptyQueue.splice(firstPending, this.#ptyQueue.length - firstPending - MAX_PTY_QUEUE_CHUNKS);
			// A dropped chunk can split an in-flight DCS/OSC string; a stray string
			// terminator is a no-op in the ground state but resynchronizes the parser.
			this.#ptyQueue[firstPending] = `\u001b\\${this.#ptyQueue[firstPending]}`;
		}
		if (!this.#ptyLoadStarted) {
			this.#ptyLoadStarted = true;
			void loadXtermTerminal().then(Terminal => {
				const { cols, rows } = bashPtyViewport(this.#ui);
				this.#ptyTerminal = new Terminal({
					cols,
					rows,
					disableStdin: true,
					allowProposedApi: true,
					scrollback: PTY_SCROLLBACK_ROWS,
				});
				this.#drainPtyQueue();
			});
		}
		this.#drainPtyQueue();
	}

	/** Bytes a terminal would send for a key event, honoring the command's cursor-key mode; "" for key releases. */
	encodePtyInput(data: string): string {
		return normalizeInputForPty(data, this.#ptyTerminal?.modes.applicationCursorKeysMode ?? false);
	}

	#drainPtyQueue(): void {
		const terminal = this.#ptyTerminal;
		if (!terminal || this.#ptyWriting) return;
		const chunk = this.#ptyQueue.shift();
		if (chunk === undefined) {
			if (this.#status !== "running") this.#finalizePtyOutput();
			return;
		}
		this.#ptyWriting = true;
		terminal.write(chunk, () => {
			this.#ptyWriting = false;
			this.#schedulePtyRefresh();
			this.#drainPtyQueue();
		});
	}

	#schedulePtyRefresh(): void {
		if (this.#chunkGate) {
			this.#ptyRefreshQueued = true;
			return;
		}
		this.#chunkGate = true;
		this.#refreshPtyLines(false);
		setTimeout(() => {
			this.#chunkGate = false;
			if (this.#ptyRefreshQueued) {
				this.#ptyRefreshQueued = false;
				this.#schedulePtyRefresh();
			}
		}, CHUNK_THROTTLE_MS);
	}

	/** Re-read display lines from the replay terminal (tail window while streaming). */
	#refreshPtyLines(full: boolean): void {
		const terminal = this.#ptyTerminal;
		if (!terminal) return;
		const buffer = terminal.buffer.active;
		const startRow = full ? 0 : Math.max(0, buffer.length - STREAMING_LINE_CAP);
		const rows = readTerminalRows(terminal, startRow, buffer.length - startRow);
		while (rows.length > 0 && rows[rows.length - 1] === "") rows.pop();
		const base = theme.getFgAnsi("muted");
		this.#outputLines = rows.map(row => (row ? styleTerminalRow(row, base) : ""));
		this.#displayDirty = true;
		this.#outputVersion++;
	}

	/** Final full-scrollback read; the terminal is disposed once lines are snapshotted. */
	#finalizePtyOutput(): void {
		const terminal = this.#ptyTerminal;
		if (!terminal) return;
		this.#refreshPtyLines(true);
		this.#ptyTerminal = undefined;
		terminal.dispose();
		this.#ptyReplayFinalized = true;
		this.#blockVersion++;
		this.#updateDisplay();
		this.#ui.requestComponentRender(this);
	}

	setComplete(
		exitCode: number | undefined,
		cancelled: boolean,
		options?: {
			output?: string;
			truncation?: TruncationMeta;
			artifactError?: OutputArtifactError;
			minimized?: MinimizedMeta;
			images?: readonly ImageContent[];
			showImages?: boolean;
		},
	): void {
		this.#exitCode = exitCode;
		this.#status = resolveExecutionStatus(exitCode, cancelled);
		this.#endedAt ??= performance.now();
		this.#truncation = options?.truncation;
		this.#artifactError = options?.artifactError;
		this.#minimized = options?.minimized;
		this.#images = options?.images ?? [];
		this.#showImages = options?.showImages ?? true;
		if (options?.output !== undefined && !this.#ptyMode) {
			this.#setOutput(options.output);
		}

		// Stop loader
		this.#loader.stop();
		// PTY lines still queued keep draining; the empty-queue drain finalizes.
		if (this.#ptyMode && !this.#ptyWriting && this.#ptyQueue.length === 0) {
			this.#finalizePtyOutput();
		}

		this.#updateDisplay();
	}

	/** The loader animates the bottom border from outside the child tree, so teardown stops it here. */
	override dispose(): void {
		this.#loader.dispose();
		super.dispose();
	}

	override render(width: number): readonly string[] {
		if (this.#displayDirty) {
			this.#displayDirty = false;
			this.#updateDisplay();
		}
		return super.render(width);
	}

	#updateDisplay(): void {
		const availableLines = this.#outputLines;

		// Full output is shown when expanded or when sixel passthrough renders
		// the raw payload; the collapsed preview shows only the tail window.
		const sixelLineMask =
			TERMINAL.imageProtocol === ImageProtocol.Sixel && isSixelPassthroughEnabled()
				? getSixelLineMask(availableLines)
				: undefined;
		const hasSixelOutput = sixelLineMask?.some(Boolean) ?? false;
		const showingAllLines = this.#expanded || hasSixelOutput;
		// Only the collapsed preview hides lines; when the full output is shown
		// the footer must not keep advertising hidden lines / ctrl+o.
		const hiddenLineCount = showingAllLines ? 0 : Math.max(0, availableLines.length - PREVIEW_LINES);
		this.#outputPane.configure({ uncapSixel: hasSixelOutput });
		this.#outputPane.setLines(availableLines);

		// Rebuild content container
		this.#contentContainer.clear();

		// Command header
		this.#contentContainer.addChild(this.#headerText);

		// Output
		if (availableLines.length > 0) this.#contentContainer.addChild(this.#outputPane);

		for (let index = 0; index < this.#images.length; index++) {
			const image = this.#images[index]!;
			if (TERMINAL.imageProtocol && this.#showImages) {
				this.#contentContainer.addChild(
					new Image(
						image.data,
						image.mimeType,
						{ fallbackColor: text => theme.fg("muted", text) },
						{
							...resolveImageOptions(),
							budget: this.#ui.imageBudget,
							imageKey: `be${this.#instanceId}:${index}`,
						},
					),
				);
			} else {
				const dimensions = getImageDimensions(image.data, image.mimeType) ?? undefined;
				this.#contentContainer.addChild(
					new Text(theme.fg("muted", linkedImageText(imageFallback(image.mimeType, dimensions), image)), 1, 0),
				);
			}
		}

		// The bottom border keeps the live loader until the run settles, then its exit/cancel marker.
		if (this.#status !== "running") {
			this.#bottomBorder.setLabel(executionStatusLabel(this.#status, this.#exitCode));
			const footer = buildStatusFooter({
				truncation: this.#truncation,
				artifactError: this.#artifactError,
				minimized: this.#minimized,
				hiddenLineCount,
				suppressHiddenCount: hasSixelOutput,
			});
			if (footer) this.#contentContainer.addChild(footer);
		}
	}

	/** PTY replay rows arrive pre-styled (safe SGR + reset); plain lines get muted. */
	#styleDisplayLine(line: string): string {
		return this.#ptyMode ? line : theme.fg("muted", line);
	}

	#clampLinesPreservingSixel(lines: string[]): string[] {
		if (lines.length === 0) return [];
		const sixelLineMask = getSixelLineMask(lines);
		if (!sixelLineMask.some(Boolean)) {
			return lines.map(clampDisplayLine);
		}
		return lines.map((line, index) => (sixelLineMask[index] ? line : clampDisplayLine(line)));
	}

	#setOutput(output: string): void {
		const clean = sanitizeWithOptionalSixelPassthrough(output, sanitizeText);
		this.#outputLines = clean ? this.#clampLinesPreservingSixel(clean.split("\n")) : [];
		this.#outputVersion++;
	}

	/**
	 * Get the raw output for creating BashExecutionMessage.
	 */
	getOutput(): string {
		return this.#outputLines.join("\n");
	}

	/**
	 * Get the command that was executed.
	 */
	getCommand(): string {
		return this.#command;
	}
}
