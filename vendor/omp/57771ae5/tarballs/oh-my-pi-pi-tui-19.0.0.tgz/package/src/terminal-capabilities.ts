import { encodeSixel } from "@oh-my-pi/pi-natives";
import { $env, isBunTestRuntime, isTerminalHeadless, isWsl } from "@oh-my-pi/pi-utils/env";
import { writeTerminalSequence } from "./active-terminal";
import { sendDesktopNotification, shouldDeliverDesktopNotification } from "./desktop-notify";
import {
	detectKittyUnicodePlaceholdersSupport,
	getKittyGraphics,
	KITTY_PLACEHOLDER,
	kittyPlaceholdersFit,
	renderKittyPlaceholderLines,
	setKittyGraphics,
} from "./kitty-graphics";
import { ensureSixelRasterWidth } from "./sixel";
import {
	isInsideTerminalMultiplexer,
	isTerminalBackgroundQueryTrusted,
	routeTerminalMultiplexerNotification,
	terminalMultiplexerForTerm,
	terminalMultiplexerSessions,
} from "./terminal-multiplexer";
import { resolveTmuxClientTerminalNames, tmuxPaneAllowsPassthrough, wrapTmuxPassthroughIfNeeded } from "./tmux";
import { detectTerminalBackground } from "./theme/theme";
import type { HangulCompatibilityJamoWidth } from "./utils";

export * from "./terminal-multiplexer";
export { wrapTmuxPassthrough } from "./tmux";

/** Last valid OSC 11 background, packed as 0xRRGGBB. */
let terminalBackgroundColor: number | undefined;

/**
 * Trusted terminal background when reported; otherwise black for detected dark
 * appearance or white for detected light appearance, using theme auto-detection.
 */
export function getTerminalBackgroundColor(): number {
	if (isTerminalBackgroundQueryTrusted() && terminalBackgroundColor !== undefined) return terminalBackgroundColor;
	return detectTerminalBackground() === "light" ? 0xffffff : 0x000000;
}

/** Store an OSC 11 background, or reset to appearance detection (also for tests). */
export function setTerminalBackgroundColor(color: number | undefined): void {
	terminalBackgroundColor = color;
}

export enum ImageProtocol {
	Kitty = "\x1b_G",
	Iterm2 = "\x1b]1337;File=",
	Sixel = "\x1bPq",
}

export enum NotifyProtocol {
	Bell = "\x07",
	Osc99 = "\x1b]99;;",
	Osc9 = "\x1b]9;",
}

export type TerminalId =
	| "kitty"
	| "ghostty"
	| "wezterm"
	| "iterm2"
	| "vscode"
	| "alacritty"
	| "warp"
	| "orca"
	| "otty"
	| "rio"
	| "tern"
	| "monstar"
	| "rex"
	| "base"
	| "trueColor";

const IMAGE_MARKER_SCAN_LIMIT = 512;
const SIXEL_MARKER_SCAN_LIMIT = 128;
const KITTY_PLACEHOLDER_HIGH_SURROGATE = KITTY_PLACEHOLDER.charCodeAt(0);
const KITTY_PLACEHOLDER_LOW_SURROGATE = KITTY_PLACEHOLDER.charCodeAt(1);

/** Terminal capability details used for rendering and protocol selection. */
export class TerminalInfo {
	constructor(
		public readonly id: TerminalId,
		public readonly imageProtocol: ImageProtocol | null,
		public readonly trueColor: boolean,
		public readonly hyperlinks: boolean,
		public readonly notifyProtocol: NotifyProtocol = NotifyProtocol.Bell,
		public readonly deccara: boolean = false,
		readonly supportsScreenToScrollback: boolean = false,
		/** Renders the Kitty OSC 66 text-sizing protocol (scaled spans). Kitty only. */
		public readonly supportsTextSizing: boolean = false,
		/**
		 * Hangul Compatibility Jamo (U+3131..=U+318E) cell width. Ghostty and Orca follow
		 * UAX#11 (2 cells); Warp paints 1; "platform" keeps the OS default
		 * (macOS narrow, otherwise UAX#11).
		 */
		public readonly hangulJamoWidth: HangulCompatibilityJamoWidth = "platform",
	) {}

	/**
	 * Mutable clone for the {@link TERMINAL} singleton: copies every field and
	 * keeps the prototype methods, so the builder and runtime setters flip
	 * runtime-resolved {@link RuntimeTerminal} capabilities in place instead of
	 * reconstructing positional constructor args.
	 */
	clone(): RuntimeTerminal {
		return Object.assign(Object.create(TerminalInfo.prototype), this) as RuntimeTerminal;
	}

	/**
	 * Whether an image marker begins at `start`. Kept as the shared primitive
	 * for both standalone image checks and the renderer's combined ANSI/width
	 * scan, so their protocol windows and sixel grammar cannot drift.
	 */
	hasImageMarkerAt(line: string, start: number): boolean {
		const protocol = this.imageProtocol;
		if (!protocol) return false;
		if (protocol === ImageProtocol.Sixel) {
			const limit = Math.min(line.length, SIXEL_MARKER_SCAN_LIMIT);
			if (start + 3 > limit || line.charCodeAt(start) !== 0x1b || line.charCodeAt(start + 1) !== 0x50) {
				return false;
			}
			let i = start + 2;
			while (i < limit) {
				const code = line.charCodeAt(i);
				if ((code >= 0x30 && code <= 0x39) || code === 0x3b) {
					i++;
					continue;
				}
				break;
			}
			return i < limit && line.charCodeAt(i) === 0x71;
		}

		const limit = Math.min(line.length, IMAGE_MARKER_SCAN_LIMIT);
		let protocolMatches = start + protocol.length <= limit;
		for (let offset = 0; protocolMatches && offset < protocol.length; offset++) {
			protocolMatches = line.charCodeAt(start + offset) === protocol.charCodeAt(offset);
		}
		return (
			protocolMatches ||
			(start + 2 <= limit &&
				line.charCodeAt(start) === KITTY_PLACEHOLDER_HIGH_SURROGATE &&
				line.charCodeAt(start + 1) === KITTY_PLACEHOLDER_LOW_SURROGATE)
		);
	}

	isImageLine(line: string): boolean {
		if (!this.imageProtocol) return false;
		const limit = Math.min(
			line.length,
			this.imageProtocol === ImageProtocol.Sixel ? SIXEL_MARKER_SCAN_LIMIT : IMAGE_MARKER_SCAN_LIMIT,
		);
		for (let i = 0; i < limit; i++) {
			const code = line.charCodeAt(i);
			if (code !== 0x1b && code !== KITTY_PLACEHOLDER_HIGH_SURROGATE) continue;
			if (this.hasImageMarkerAt(line, i)) return true;
		}
		return false;
	}

	formatNotification(message: string | TerminalNotification): string {
		if (this.notifyProtocol === NotifyProtocol.Bell) {
			return NotifyProtocol.Bell;
		}
		// Structured notifications use OSC 99's rich metadata only once the
		// terminal confirms support; otherwise collapse to a single message line
		// (basic OSC 99 / OSC 9 still work).
		if (typeof message !== "string") {
			if (this.notifyProtocol === NotifyProtocol.Osc99 && osc99CapabilitiesConfirmed) {
				return formatOsc99Notification(message);
			}
			return `${this.notifyProtocol}${notificationToLine(message)}\x1b\\`;
		}
		return `${this.notifyProtocol}${message}\x1b\\`;
	}

	sendNotification(message: string | TerminalNotification): void {
		if (isNotificationSuppressed() || isTerminalHeadless()) return;
		const formatted = this.formatNotification(message);
		// Multiplexers that swallow or rewrite the terminal's notification get it
		// first, innermost target first; the terminal sequence is the fallback.
		const routed = routeTerminalMultiplexerNotification({
			message,
			env: Bun.env,
			sequence: this.notifyProtocol === NotifyProtocol.Bell ? null : formatted,
			write: writeTerminalSequence,
		});
		if (routed) return;
		writeTerminalSequence(formatted);
		// VTE-family terminals (Ptyxis, GNOME Terminal, Tilix, …) plus Alacritty
		// and bare xterm-on-Wayland have no in-band escape that surfaces an
		// arbitrary desktop toast (#3685). When the chosen `notifyProtocol` is
		// BEL on a Linux session bus, also fan the notification out via
		// libnotify so users see the toast and the BEL still fires for tmux
		// `monitor-bell` / X11 urgency hints / audible bell.
		if (this.notifyProtocol === NotifyProtocol.Bell && shouldDeliverDesktopNotification(this.id, true)) {
			sendDesktopNotification(message);
		}
	}
}

/**
 * Whether the agent process runs in an SSH session, so the terminal emulator
 * is remote and host-local input/keyboard modes cannot be assumed.
 */
export function isSshSession(env: NodeJS.ProcessEnv = Bun.env): boolean {
	return Boolean(env.SSH_CONNECTION || env.SSH_TTY || env.SSH_CLIENT);
}

export function isNotificationSuppressed(): boolean {
	const value = $env.PI_NOTIFICATIONS;
	if (!value) return false;
	return value === "off" || value === "0" || value === "false";
}

function getForcedImageProtocol(): ImageProtocol | null | undefined {
	const raw = $env.PI_FORCE_IMAGE_PROTOCOL?.trim().toLowerCase();
	if (!raw) return undefined;
	if (raw === "kitty") return ImageProtocol.Kitty;
	if (raw === "iterm2" || raw === "iterm") return ImageProtocol.Iterm2;
	if (raw === "sixel") return ImageProtocol.Sixel;
	if (raw === "off" || raw === "none" || raw === "0" || raw === "false") return null;
	return null;
}

/**
 * Whether `PI_FORCE_IMAGE_PROTOCOL` pins the image protocol, including its
 * `off`/`none` kill switch. A runtime capability probe must not override an
 * explicit user choice: a forced protocol is already applied to {@link TERMINAL},
 * and a forced "off" leaves `imageProtocol` null on purpose.
 */
export function isImageProtocolForced(): boolean {
	return getForcedImageProtocol() !== undefined;
}

function parseMajorMinorVersion(versionRaw?: string): { major: number; minor: number } | null {
	if (!versionRaw) return null;
	const match = /^(\d+)\.(\d+)/u.exec(versionRaw.trim());
	if (!match) return null;
	const major = Number.parseInt(match[1] ?? "", 10);
	const minor = Number.parseInt(match[2] ?? "", 10);
	if (!Number.isFinite(major) || !Number.isFinite(minor)) return null;
	return { major, minor };
}

/**
 * Returns true when running in Windows Terminal with known SIXEL support.
 *
 * Windows Terminal introduced SIXEL support in preview 1.22.
 */
export function isWindowsTerminalPreviewSixelSupported(
	env: NodeJS.ProcessEnv = Bun.env,
	platform: NodeJS.Platform = process.platform,
): boolean {
	if (
		platform !== "win32" ||
		!env.WT_SESSION ||
		(env.TERM_PROGRAM && env.TERM_PROGRAM.toLowerCase() !== "windows_terminal")
	) {
		return false;
	}
	const version = parseMajorMinorVersion(env.TERM_PROGRAM_VERSION);
	if (!version) return false;
	return version.major > 1 || (version.major === 1 && version.minor >= 22);
}

/**
 * Resolve an explicit user override for DEC 2026 synchronized output. Returns
 * `false` for an opt-out, `true` for a force-on, or `null` when the user has
 * expressed no preference. Shared by the static default and the runtime DECRQM
 * probe so both honor the same precedence — an opt-out beats a force-on.
 */
export function synchronizedOutputUserOverride(env: NodeJS.ProcessEnv = Bun.env): boolean | null {
	if (env.PI_NO_SYNC_OUTPUT || env.PI_TUI_SYNC_OUTPUT === "0") return false;
	if (env.PI_FORCE_SYNC_OUTPUT === "1" || env.PI_TUI_SYNC_OUTPUT === "1") return true;
	return null;
}

/**
 * Whether `TERM_FEATURES` advertises DEC 2026 synchronized output via the `Sy`
 * capability token. `TERM_FEATURES` is a run of capitalized two-letter codes
 * (e.g. `…Sy…`), so a case-sensitive substring match is unambiguous: `Sy`
 * cannot straddle a code boundary because those are always lowercase→uppercase.
 */
function advertisesSynchronizedOutput(termFeatures: string | undefined): boolean {
	return termFeatures?.includes("Sy") ?? false;
}

/**
 * Whether DEC 2026 synchronized-output wrappers should be enabled by default.
 *
 * Policy (highest precedence first):
 *   1. Explicit user override (`PI_NO_SYNC_OUTPUT`/`PI_TUI_SYNC_OUTPUT=0` off,
 *      `PI_FORCE_SYNC_OUTPUT=1`/`PI_TUI_SYNC_OUTPUT=1` on).
 *   2. Positive `TERM_FEATURES` advertisement (`Sy`) — survives SSH/mux wrapping.
 *   3. Windows Terminal (1.24+) via `WT_SESSION`, on native win32 and the
 *      WSL/SSH-fronted host alike.
 *   4. A multiplexer session whose pane VTE honors DEC 2026 regardless of its
 *      DECRQM reply (Herdr's libghostty pane). Such a multiplexer still owns
 *      the grid, so leaked kitty/ghostty identities cannot enable placeholder
 *      graphics, but leaving sync off lets CUP-diff paints and split write(2)
 *      chunks composite as dirty-row patches — the live viewport tears, with
 *      the top frozen while only the bottom refreshes.
 *   5. Known direct terminals with confirmed support. SSH does *not* disable —
 *      DEC 2026 passes through SSH when the outer terminal honors it.
 *   6. Everything else starts off, including risky multiplexers; the runtime
 *      DECRQM probe upgrades any of them when the terminal actually reports
 *      `?2026` supported (current zellij, tmux master, foot, contour, mintty…).
 */
export function shouldEnableSynchronizedOutputByDefault(
	env: NodeJS.ProcessEnv = Bun.env,
	terminalId: TerminalId = TERMINAL_ID,
): boolean {
	const override = synchronizedOutputUserOverride(env);
	if (override !== null) return override;

	if (advertisesSynchronizedOutput(env.TERM_FEATURES)) return true;
	if (env.WT_SESSION && (!env.TERM_PROGRAM || env.TERM_PROGRAM.toLowerCase() === "windows_terminal")) return true;
	if (terminalMultiplexerSessions(env).some(multiplexer => multiplexer.honorsSynchronizedOutput)) return true;

	// Risky multiplexers start off even when an inner terminal id leaks through:
	// older tmux/screen synchronized-output handling is flaky and a mux may not
	// pass DEC 2026 to the outer host. The DECRQM probe re-enables sync when the
	// mux reports `?2026` supported.
	if (isInsideTerminalMultiplexer(env)) {
		return false;
	}

	switch (terminalId) {
		case "kitty":
		case "ghostty":
		case "monstar":
		case "wezterm":
		case "iterm2":
		case "alacritty":
		case "vscode":
			return true;
		default:
			// VTE family, GNU screen, Apple Terminal, Warp, legacy native console
			// host (no WT_SESSION), and bare/unknown xterm profiles stay off until
			// the DECRQM probe proves support.
			return false;
	}
}

/**
 * Whether the terminal applies Kitty-style DECCARA rectangular SGR changes
 * (`CSI Pt ; Pl ; Pb ; Pr ; <sgr> $ r`) extended to background color, so large
 * filled regions can be painted as rectangles instead of background-padded
 * strings on every row.
 *
 * Verified against terminal sources rather than terminfo, because a bare
 * `Cara`/DECCARA terminfo capability does not imply the Kitty SGR-background
 * extension:
 * - Kitty implements it for *all* SGR attributes including background (see
 *   kitty `docs/deccara.rst` and the `test_deccara` parser test).
 * - Ghostty does NOT: its `CSI $ r` dispatch falls through to an "unknown CSI"
 *   warning and DECCARA/DECSACE are tracked as unsupported
 *   (ghostty-org/ghostty#632). Enabling it there would silently drop panel
 *   backgrounds, so ghostty stays on the padded-string fallback.
 *
 * Disabled under tmux/screen/zellij multiplexers — screen-coordinate rectangle
 * protocols are not safe to assume through a multiplexer — and via the
 * `PI_NO_DECCARA` kill switch. Pure helper for tests and `TERMINAL` construction.
 */
export function detectRectangularSgrSupport(terminalId: TerminalId, env: NodeJS.ProcessEnv = Bun.env): boolean {
	if (terminalId !== "kitty") return false;
	const kill = env.PI_NO_DECCARA;
	if (kill && kill !== "0" && kill.toLowerCase() !== "false") return false;
	if (isInsideTerminalMultiplexer(env)) {
		return false;
	}
	return true;
}
/**
 * Whether the terminal implements colon-subparameter SGR styled underlines —
 * `CSI 4 : 3 m` (curly) plus `CSI 58` / `CSI 59` underline color — as opposed to
 * only the legacy `CSI 4 m` / `CSI 24 m` on/off underline.
 *
 * This is an underline-style capability, not a color depth, so it is keyed on
 * the detected terminal, never on `TERM`/`COLORTERM`. kitty, Ghostty, WezTerm,
 * and iTerm2 (>= 3.5) implement the full pair. Apple Terminal does NOT: it
 * renders `CSI 4 : 0 m` (the reset half) as a solid black background that
 * persists to end of line, and ignores SGR 58/59 — so it, along with every
 * other unproven terminal, gets the flat underline instead. Disabled under any
 * multiplexer: GNU screen and older tmux drop colon-form SGR, and the outer
 * terminal's id leaks into the session env, so a proven id is not proof the
 * bytes survive — the same reason DECCARA and synchronized output gate on it.
 */
export function detectStyledUnderlineSupport(terminalId: TerminalId, env: NodeJS.ProcessEnv = Bun.env): boolean {
	// A multiplexer in the path (GNU screen, older tmux) does not forward the
	// colon-form underline, yet the outer terminal's id leaks through the session
	// env, so the switch below would otherwise trust an unreachable capability.
	if (isInsideTerminalMultiplexer(env)) return false;
	switch (terminalId) {
		case "kitty":
		case "ghostty":
		case "monstar":
		case "wezterm":
			return true;
		case "iterm2": {
			// The full curly-and-colored pair did not ship together until iTerm2 3.5
			// (curly first targeted 3.3.12; SGR 58/59 underline color was beta,
			// expected for 3.5), so 3.0–3.4 would receive the colon reset they cannot
			// render. Enable only on a confirmed major.minor >= 3.5; an absent or
			// unparseable version keeps the flat fallback so only proven terminals
			// get the colon form.
			//
			// `LC_TERMINAL_VERSION` carries the same version over SSH, where
			// `TERM_PROGRAM_VERSION` is stripped, so it is the fallback source.
			const version =
				parseMajorMinorVersion(env.TERM_PROGRAM_VERSION) ?? parseMajorMinorVersion(env.LC_TERMINAL_VERSION);
			return version !== null && (version.major > 3 || (version.major === 3 && version.minor >= 5));
		}
		default:
			return false;
	}
}
/**
 * Resolve an explicit user override for OSC 8 hyperlinks. Returns `false` for
 * an opt-out, `true` for a force-on, or `null` when the user has expressed no
 * preference. Opt-out beats force-on so a kill switch is unambiguous, mirroring
 * {@link synchronizedOutputUserOverride}.
 */
export function hyperlinksUserOverride(env: NodeJS.ProcessEnv = Bun.env): boolean | null {
	if (env.PI_NO_HYPERLINKS === "1") return false;
	if (env.PI_FORCE_HYPERLINKS === "1") return true;
	return null;
}

/**
 * Whether OSC 8 hyperlinks should be enabled by default.
 *
 * Policy (highest precedence first):
 *   1. Explicit user override (`PI_NO_HYPERLINKS=1` off, `PI_FORCE_HYPERLINKS=1`
 *      on). Opt-out wins ties.
 *   2. Every multiplexer session with a hyperlink policy renders OSC 8 itself
 *      (`render`, e.g. Herdr): on. Herdr hides the outer terminal
 *      (`TERM=xterm-256color`, no `TERM_PROGRAM`), so the outer terminal's
 *      support does not matter.
 *   3. Static terminal capability — terminals whose {@link TerminalInfo} marks
 *      `hyperlinks: false` (e.g. `base`) stay off unless the user forced on.
 *   4. A session that never forwards OSC 8 (`drop`, e.g. GNU screen's `STY`)
 *      always off, even when a forwarding multiplexer is also present.
 *   5. Forwarding sessions (`forward`, e.g. `TMUX`): enabled when every one
 *      self-reports at least its forwarding version via `TERM_PROGRAM` /
 *      `TERM_PROGRAM_VERSION` (tmux 3.4). Older or unknown versions stay off;
 *      on outer terminals without the feature configured, tmux silently drops
 *      the sequence. Checked before the TERM heuristic because tmux's
 *      historical `default-terminal` is `screen-256color`, so `TERM=screen*`
 *      inside a tmux session must NOT short-circuit to off.
 *   6. TERM naming a multiplexer whose session markers were stripped: off,
 *      since no session proves the multiplexer forwards OSC 8 (screen never
 *      does; tmux has no version to check).
 *   7. Otherwise honor the static terminal capability.
 */
export function shouldEnableHyperlinksByDefault(
	env: NodeJS.ProcessEnv = Bun.env,
	terminalId: TerminalId = TERMINAL_ID,
): boolean {
	const override = hyperlinksUserOverride(env);
	if (override !== null) return override;

	const policies = terminalMultiplexerSessions(env).flatMap(multiplexer =>
		multiplexer.hyperlinks === undefined ? [] : [multiplexer.hyperlinks],
	);
	if (policies.length > 0 && policies.every(policy => policy === "render")) return true;

	if (!getTerminalInfo(terminalId).hyperlinks) return false;

	if (policies.includes("drop")) return false;

	const forwarders = policies.flatMap(policy => (typeof policy === "object" ? [policy.forward] : []));
	if (forwarders.length > 0) {
		const termProgram = env.TERM_PROGRAM?.toLowerCase();
		return forwarders.every(forward => {
			if (termProgram !== forward.termProgram) return false;
			const version = parseMajorMinorVersion(env.TERM_PROGRAM_VERSION);
			if (!version) return false;
			return version.major > forward.major || (version.major === forward.major && version.minor >= forward.minor);
		});
	}

	if (terminalMultiplexerForTerm(env)) return false;

	return true;
}

function getFallbackImageProtocol(
	terminalId: TerminalId,
	env: NodeJS.ProcessEnv = Bun.env,
	isTTY: boolean = process.stdout.isTTY === true,
): ImageProtocol | null {
	if (!isTTY) return null;
	if (terminalId === "vscode" || terminalId === "alacritty") return null;
	const term = env.TERM?.toLowerCase() ?? "";
	// tmux TERM names the pane, not the attached client's graphics support.
	// Leave unknown clients unselected so the runtime SIXEL probe can run.
	if (env.TMUX || term.includes("tmux")) return null;
	if (term.includes("screen") || term.includes("ghostty")) return ImageProtocol.Kitty;
	return null;
}
/**
 * Warp implements the Kitty graphics protocol only on macOS/Linux; its Windows
 * build (including Warp-hosted WSL shells) renders the same APC sequences as
 * visible garbage. Keep platform/env injectable so the carve-out is testable
 * without mutating `process.platform`.
 */
export function resolveWarpImageProtocol(
	platform: NodeJS.Platform = process.platform,
	env: NodeJS.ProcessEnv = Bun.env,
): ImageProtocol | null {
	const windowsHost = platform === "win32" || isWsl(platform, env);
	return windowsHost ? null : ImageProtocol.Kitty;
}

/**
 * Paseo (getpaseo/paseo) hardcodes `TERM_PROGRAM=kitty` into every PTY
 * (`buildTerminalEnvironment`) while its xterm.js renderer implements neither
 * Kitty graphics nor Unicode placeholders — trusting the advertisement turns
 * image previews into literal PUA garbage (getpaseo/paseo#3850). Paseo
 * injects `PASEO_TERMINAL_ID` into every terminal it hosts, which makes a
 * reliable embedder signal.
 */
export function isPaseoEmbedder(env: NodeJS.ProcessEnv = Bun.env): boolean {
	return Boolean(env.PASEO_TERMINAL_ID);
}

/**
 * Resolve the image protocol for a non-forced runtime: static per-terminal
 * support (with Warp's platform carve-out), then the multiplexer fallback,
 * then host carve-outs. `isTTY` is injectable because the fallback only fires
 * on a real TTY — a piped subprocess cannot exercise that path, so regression
 * tests call this directly.
 */
export function resolveImageProtocol(
	terminalId: TerminalId,
	env: NodeJS.ProcessEnv = Bun.env,
	isTTY: boolean = process.stdout.isTTY === true,
): ImageProtocol | null {
	let imageProtocol: ImageProtocol | null;
	if (terminalId === "warp") {
		// Warp advertises Kitty graphics on macOS/Linux only; drop it on win32.
		imageProtocol = resolveWarpImageProtocol(process.platform, env);
	} else {
		imageProtocol = getTerminalInfo(terminalId).imageProtocol;
		if (!imageProtocol) {
			const fallbackImageProtocol = getFallbackImageProtocol(terminalId, env, isTTY);
			if (fallbackImageProtocol) imageProtocol = fallbackImageProtocol;
		}
	}
	// Paseo's xterm.js renderer draws neither Kitty APC nor placeholders —
	// applied after the multiplexer fallback so tmux/screen inside a Paseo
	// pane cannot restore Kitty via getFallbackImageProtocol
	// (getpaseo/paseo#3850).
	if (imageProtocol !== null && isPaseoEmbedder(env)) {
		return null;
	}
	// Some multiplexers own the pane grid without exposing whether the attached
	// client renders graphics (Herdr's experimental Kitty renderer). Outer-
	// terminal identity variables can leak into the pane, so only the explicit
	// protocol override is safe.
	if (
		imageProtocol !== null &&
		terminalMultiplexerSessions(env).some(multiplexer => multiplexer.imagesRequireOverride)
	) {
		return null;
	}
	// Kitty graphics reach a tmux client only through the DCS passthrough
	// envelope, which tmux drops unless `allow-passthrough` is enabled. A Kitty
	// client identity alone would otherwise send images into the void.
	if (imageProtocol === ImageProtocol.Kitty && env.TMUX && !tmuxPaneAllowsPassthrough(env)) {
		return null;
	}
	return imageProtocol;
}

function getWarpTerminalInfo(platform: NodeJS.Platform, env: NodeJS.ProcessEnv = Bun.env): TerminalInfo {
	return new TerminalInfo(
		"warp",
		resolveWarpImageProtocol(platform, env),
		true,
		false,
		NotifyProtocol.Osc9,
		false,
		false,
		false,
		1,
	);
}
const KNOWN_TERMINALS = Object.freeze({
	// Fallback terminals
	base: new TerminalInfo("base", null, false, false, NotifyProtocol.Bell),
	trueColor: new TerminalInfo("trueColor", null, true, false, NotifyProtocol.Bell),
	// Recognized terminals
	kitty: new TerminalInfo("kitty", ImageProtocol.Kitty, true, true, NotifyProtocol.Osc99, true, true, true),
	ghostty: new TerminalInfo("ghostty", ImageProtocol.Kitty, true, true, NotifyProtocol.Osc9, false, false, false, 2),
	wezterm: new TerminalInfo("wezterm", ImageProtocol.Kitty, true, true, NotifyProtocol.Osc9),
	iterm2: new TerminalInfo("iterm2", ImageProtocol.Iterm2, true, true, NotifyProtocol.Osc9),
	vscode: new TerminalInfo("vscode", null, true, true, NotifyProtocol.Bell),
	alacritty: new TerminalInfo("alacritty", null, true, true, NotifyProtocol.Bell),
	orca: new TerminalInfo("orca", null, true, false, NotifyProtocol.Bell, false, false, false, 2),
	// Warp identifies via TERM_PROGRAM=WarpTerminal and ships the Kitty graphics
	// protocol on macOS/Linux (direct placement only — no Unicode placeholders, so
	// detectKittyUnicodePlaceholdersSupport correctly excludes it). It does not
	// honor OSC 8 yet (the escape renders as visible text), so hyperlinks stay off,
	// but it does support OSC 9 notifications.
	warp: new TerminalInfo("warp", ImageProtocol.Kitty, true, false, NotifyProtocol.Osc9, false, false, false, 1),
	// Otty (appmakes, macOS) identifies via TERM_PROGRAM=otty. Its documented
	// Kitty implementation covers direct and virtual (U+10EEEE placeholder)
	// placement, and it honors OSC 8 hyperlinks and OSC 99 notifications
	// (docs.otty.sh terminal comparison). Sixel is not implemented, DECCARA and
	// OSC 66 text sizing are unverified, so those stay on conservative defaults;
	// synchronized output is left to the runtime DECRQM probe.
	otty: new TerminalInfo("otty", ImageProtocol.Kitty, true, true, NotifyProtocol.Osc99),
	// rio publishes its supported escape sequences at
	// rioterm.com/docs/escape-sequence-support: OSC 8 hyperlinks are opened via
	// the hints system (Alt+click on Windows/Linux) — live-verified on
	// rio 0.5.28/Win11 26100 where an OSC 8 span Alt+click opened the target
	// URL in the browser, and an OSC 52 clipboard query round-tripped. Kitty
	// graphics direct placement plus U=1 Unicode placeholders verified by the
	// reporter (#12205). Notifications stay on BEL: rio parses OSC 9/777 into
	// its own notifier, but its Windows path raises an unpackaged WinRT toast
	// with AppId "Rio" that Windows silently drops without a registered AUMID
	// shortcut — observed as a no-op live — so flipping it would only remove
	// the D-Bus fallback for Linux rio users. DECCARA, screen-to-scrollback,
	// OSC 99, and OSC 66 text sizing are outside rio's supported set and keep
	// the conservative defaults.
	rio: new TerminalInfo("rio", ImageProtocol.Kitty, true, true),
	// Rex (Superlogical's terminal) identifies via TERM_PROGRAM=rex, or
	// TERM=xterm-rex over SSH. It renders Kitty graphics and OSC 8
	// hyperlinks — a link opens on command-click, and
	// Settings > Terminal > Links only decides whether an `ssh://`-style link
	// that launches another app asks first — so links are on. Notifications
	// keep the BEL default.
	rex: new TerminalInfo("rex", ImageProtocol.Kitty, true, true),
	// Tern (Stencil's terminal, `stencil-term`) sets TERM_PROGRAM=tern and
	// implements Kitty graphics (Unicode placeholders included), OSC 8 and
	// OSC 9/99 notifications. Whether omp renders natively (Tern Surface
	// Protocol) is decided by the `hello` handshake alone, never by this identity.
	tern: new TerminalInfo("tern", ImageProtocol.Kitty, true, true, NotifyProtocol.Osc99),
	// Monstar (rockorager/monstar) is a Wayland terminal built on libghostty. It
	// sets TERM=monstar and answers XTVERSION with `monstar <version>`. It
	// documents Kitty graphics with Unicode placeholders, OSC 8 hyperlinks, and
	// synchronized output. libghostty reports Hangul Jamo as 2 cells, and the
	// Monstar renderer draws curly underlines in the SGR 58 underline color, so
	// the id-keyed allowlists treat Monstar like Ghostty.
	// Monstar clears OSC 9;4 progress after 15 s without an update, so it also
	// gets the Ghostty progress keepalive. The Ghostty initial image delay stays
	// Ghostty-only: it works around a Ghostty app startup race, not libghostty.
	// Monstar turns OSC 9 into a D-Bus notification with a default action;
	// activating it focuses the Monstar window. The BEL path uses omp's own
	// `notify-send` fallback instead, which cannot focus a window.
	monstar: new TerminalInfo("monstar", ImageProtocol.Kitty, true, true, NotifyProtocol.Osc9, false, false, false, 2),
});

/** Resolve terminal identity from environment markers used by common emulators. */
export function detectTerminalId(env: NodeJS.ProcessEnv = Bun.env): TerminalId {
	function caseEq(a: string, b: string): boolean {
		return a.toLowerCase() === b.toLowerCase(); // For compiler to pattern match
	}

	function fromProgram(program: string | undefined): TerminalId | null {
		if (!program) return null;
		if (caseEq(program, "kitty")) return "kitty";
		if (caseEq(program, "ghostty")) return "ghostty";
		if (caseEq(program, "wezterm")) return "wezterm";
		if (caseEq(program, "iterm.app") || caseEq(program, "iterm2")) return "iterm2";
		if (caseEq(program, "vscode")) return "vscode";
		if (caseEq(program, "alacritty")) return "alacritty";
		if (caseEq(program, "warpterminal")) return "warp";
		if (caseEq(program, "orca")) return "orca";
		if (caseEq(program, "otty")) return "otty";
		if (caseEq(program, "rio")) return "rio";
		if (caseEq(program, "tern")) return "tern";
		if (caseEq(program, "monstar")) return "monstar";
		if (caseEq(program, "rex")) return "rex";
		return null;
	}

	const {
		KITTY_WINDOW_ID,
		GHOSTTY_RESOURCES_DIR,
		WEZTERM_PANE,
		ITERM_SESSION_ID,
		VSCODE_PID,
		ALACRITTY_WINDOW_ID,
		TERM_PROGRAM,
		LC_TERMINAL,
		TERM,
		COLORTERM,
	} = env;

	if (KITTY_WINDOW_ID) return "kitty";
	if (GHOSTTY_RESOURCES_DIR) return "ghostty";
	if (WEZTERM_PANE) return "wezterm";
	if (ITERM_SESSION_ID) return "iterm2";
	if (VSCODE_PID) return "vscode";
	if (ALACRITTY_WINDOW_ID) return "alacritty";

	const programId = fromProgram(TERM_PROGRAM);
	if (programId) return programId;

	// iTerm2 sets `LC_TERMINAL=iTerm2` (plus `LC_TERMINAL_VERSION`) in the local
	// session precisely so it survives SSH: openssh/mosh forward `LC_*` to the
	// remote host, while `ITERM_SESSION_ID` and `TERM_PROGRAM` are stripped. Its
	// own shell integration says the same: "TERM_PROGRAM is set by the local
	// terminal but not forwarded over SSH. LC_TERMINAL is set by iTerm2 and may
	// be forwarded over SSH." Without this branch the remote session falls to
	// the true-color profile and loses the iTerm2 inline-image protocol, OSC 8
	// hyperlinks and OSC 9 notifications.
	//
	// Gated on the absence of a multiplexer: iTerm2's OSC 1337 encoder is the
	// only image encoder that does not wrap its payload in a tmux passthrough
	// envelope, so inside a multiplexer the sequence would be swallowed by the
	// multiplexer instead of reaching the outer terminal. The multiplexer path
	// resolves the outer client on its own.
	if (LC_TERMINAL && caseEq(LC_TERMINAL, "iTerm2") && !isInsideTerminalMultiplexer(env)) return "iterm2";

	// tmux >= 3.2 replaces the pane's identity with `TERM_PROGRAM=tmux`.
	// Its server still holds the attached client's terminal-type reply and TERM.
	for (const clientProgram of resolveTmuxClientTerminalNames(env)) {
		const clientProgramId = fromProgram(clientProgram);
		if (clientProgramId) return clientProgramId;
	}

	if (TERM?.toLowerCase().includes("ghostty")) return "ghostty";
	if (TERM && caseEq(TERM, "monstar")) return "monstar";
	if (TERM && caseEq(TERM, "xterm-rex")) return "rex";

	if (COLORTERM) {
		if (caseEq(COLORTERM, "truecolor") || caseEq(COLORTERM, "24bit")) return "trueColor";
	}
	return "base";
}

export const TERMINAL_ID: TerminalId = detectTerminalId(Bun.env);

/**
 * The process-wide {@link TERMINAL} singleton: a {@link TerminalInfo} whose
 * post-construction capabilities — the image protocol and the probe-driven
 * flags — are writable, so the runtime setters and tests mutate them directly
 * instead of through an unsound cast. Every other field stays readonly.
 */
export interface RuntimeTerminal extends TerminalInfo {
	imageProtocol: ImageProtocol | null;
	hyperlinks: boolean;
	deccara: boolean;
	supportsScreenToScrollback: boolean;
	/** Whether OSC 66 text sizing is currently enabled. */
	textSizing: boolean;
	/** Whether the terminal implements colon-subparameter styled underlines (curly + colored). */
	styledUnderlines: boolean;
	/**
	 * Whether the terminal answered the Glyph Protocol support query with a
	 * `glyf`-capable reply and the bundled icons have been registered. Probe-
	 * driven: false until {@link ProcessTerminal} resolves it.
	 */
	glyphProtocol: boolean;
}

export const TERMINAL: RuntimeTerminal = (() => {
	const resolved = getTerminalInfo(TERMINAL_ID).clone();
	// Detection records support; hosts opt into OSC 66 separately.
	resolved.textSizing = false;

	const forcedImageProtocol = getForcedImageProtocol();
	if (forcedImageProtocol !== undefined) {
		resolved.imageProtocol = forcedImageProtocol;
	} else {
		resolved.imageProtocol = resolveImageProtocol(resolved.id, Bun.env, process.stdout.isTTY === true);
	}
	// Hyperlink (OSC 8) capability. The static per-terminal flag lives on
	// KNOWN_TERMINALS; shouldEnableHyperlinksByDefault folds in runtime context —
	// PI_FORCE_HYPERLINKS / PI_NO_HYPERLINKS overrides plus a tmux>=3.4 gate so
	// modern tmux forwards OSC 8 to outer terminals that opt in via
	// `terminal-features "*:hyperlinks"`.
	resolved.hyperlinks = shouldEnableHyperlinksByDefault(Bun.env, resolved.id);
	// DECCARA rectangular-SGR background fills. The static per-terminal capability
	// lives on KNOWN_TERMINALS; here we fold in runtime context — multiplexer and
	// the PI_NO_DECCARA kill switch via detectRectangularSgrSupport — and force it
	// off inside the test runtime so the xterm.js-backed virtual terminal (which
	// ignores DECCARA) exercises the padded-string fallback. Integration tests opt
	// in explicitly through setTerminalDeccara.
	resolved.deccara = detectRectangularSgrSupport(resolved.id, Bun.env) && !isBunTestRuntime();
	// Styled-underline capability: colon-form curly underline + SGR 58/59 color.
	// Keyed on the detected terminal (an underline-style capability, not a color
	// depth), so Apple Terminal and other unproven hosts fall back to the flat
	// CSI 4 m / CSI 24 m underline the typo renderer needs to avoid black bars.
	resolved.styledUnderlines = detectStyledUnderlineSupport(resolved.id, Bun.env);
	resolved.glyphProtocol = false;
	return resolved;
})();

// Seed Kitty Unicode placeholder support from the resolved terminal id. Only
// kitty/ghostty/otty are known to honor `U=1` placement; other Kitty-protocol paths
// (wezterm, tmux/screen fallback) treat the placeholder cells as literal PUA
// glyphs, which is the "ASCII artifact + laggy scrolling" reported in #1877.
setKittyGraphics({ unicodePlaceholders: detectKittyUnicodePlaceholdersSupport(TERMINAL.id, Bun.env) });

/**
 * Override terminal image protocol at runtime after capability probes complete.
 */
export function setTerminalImageProtocol(imageProtocol: ImageProtocol | null): void {
	TERMINAL.imageProtocol = imageProtocol;
}

/**
 * Override DECCARA rectangular-SGR capability at runtime. Used by tests to
 * exercise the optimizer and fallback paths deterministically — the default is
 * resolved once at import and force-disabled under the test runtime.
 */
export function setTerminalDeccara(enabled: boolean): void {
	TERMINAL.deccara = enabled;
}

/** Record the Glyph Protocol probe result (called by ProcessTerminal). */
export function setTerminalGlyphProtocol(supported: boolean): void {
	TERMINAL.glyphProtocol = supported;
}

/** Override screen-to-scrollback clear support for targeted renderer tests. */
export function setTerminalScreenToScrollback(enabled: boolean): void {
	TERMINAL.supportsScreenToScrollback = enabled;
}

/**
 * Enable/disable OSC 66 text-sizing at runtime. The coding-agent calls this from
 * the `tui.textSizing` setting (gated on the terminal's static `supportsTextSizing`
 * capability); tests flip it directly to exercise the scaled-heading path.
 */
export function setTerminalTextSizing(enabled: boolean): void {
	TERMINAL.textSizing = enabled;
}

/**
 * Override OSC 8 hyperlink capability at runtime. The coding-agent calls this
 * from the `tui.hyperlinks` setting so its resolved policy (`off`/`auto`/`always`)
 * drives every renderer that gates on {@link TERMINAL}`.hyperlinks` — notably the
 * Markdown component's `[text](url)`/bare-URL links — consistently with the
 * path/resource links that already consult the setting directly. Tests flip it
 * to exercise the OSC 8 and plain-text paths deterministically.
 */
export function setTerminalHyperlinks(enabled: boolean): void {
	TERMINAL.hyperlinks = enabled;
}

export function getTerminalInfo(
	terminalId: TerminalId,
	platform: NodeJS.Platform = process.platform,
	env: NodeJS.ProcessEnv = Bun.env,
): TerminalInfo {
	return terminalId === "warp" ? getWarpTerminalInfo(platform, env) : KNOWN_TERMINALS[terminalId];
}

export interface CellDimensions {
	widthPx: number;
	heightPx: number;
}

export interface ImageDimensions {
	widthPx: number;
	heightPx: number;
}

export interface ImageRenderOptions {
	maxWidthCells?: number;
	maxHeightCells?: number;
	preserveAspectRatio?: boolean;
	/**
	 * Stable Kitty image id (`i=`). When set, the image is displayed via a
	 * transmit-once + placement scheme keyed off this id instead of re-sending the
	 * base64 each frame.
	 */
	imageId?: number;
	/** Stable Kitty placement id (`p=`); defaults to {@link imageId}. */
	placementId?: number;
	/** When true (Kitty + {@link imageId}), also return the one-time transmit sequence. */
	includeTransmit?: boolean;
	/**
	 * SIXEL sequence for the target pixel size renderImage computes, so the
	 * caller can encode off the JS thread: answer `undefined` while the encode
	 * is pending (the image's rows stay reserved) and `null` once it failed.
	 * Without a provider, renderImage encodes synchronously.
	 */
	sixel?: (widthPx: number, heightPx: number) => string | null | undefined;
}

// Default cell dimensions - updated by TUI when terminal responds to query
let cellDimensions: CellDimensions = { widthPx: 9, heightPx: 18 };

export function getCellDimensions(): CellDimensions {
	return cellDimensions;
}

export function setCellDimensions(dims: CellDimensions): void {
	cellDimensions = dims;
}

function chunkKittyApc(leadParams: string, base64Data: string): string {
	const CHUNK_SIZE = 4096;
	if (base64Data.length <= CHUNK_SIZE) {
		return wrapTmuxPassthroughIfNeeded(`\x1b_G${leadParams};${base64Data}\x1b\\`);
	}

	const chunks: string[] = [];
	let offset = 0;
	let isFirst = true;

	while (offset < base64Data.length) {
		const chunk = base64Data.slice(offset, offset + CHUNK_SIZE);
		const isLast = offset + CHUNK_SIZE >= base64Data.length;

		if (isFirst) {
			chunks.push(wrapTmuxPassthroughIfNeeded(`\x1b_G${leadParams},m=1;${chunk}\x1b\\`));
			isFirst = false;
		} else if (isLast) {
			chunks.push(wrapTmuxPassthroughIfNeeded(`\x1b_Gq=2,m=0;${chunk}\x1b\\`));
		} else {
			chunks.push(wrapTmuxPassthroughIfNeeded(`\x1b_Gq=2,m=1;${chunk}\x1b\\`));
		}

		offset += CHUNK_SIZE;
	}

	return chunks.join("");
}

/** Transmit-and-display (`a=T`) — the self-contained form used when no stable id is available. */
export function encodeKitty(
	base64Data: string,
	options: {
		columns?: number;
		rows?: number;
		imageId?: number;
	} = {},
): string {
	const params: string[] = ["a=T", "f=100", "q=2", "C=1"];
	if (options.columns) params.push(`c=${options.columns}`);
	if (options.rows) params.push(`r=${options.rows}`);
	if (options.imageId) params.push(`i=${options.imageId}`);
	return chunkKittyApc(params.join(","), base64Data);
}

/**
 * Transmit image data only (`a=t`), keyed by `imageId`, without displaying it.
 * Sent once per image; the data then persists in the terminal's store (it
 * survives scroll-off and text clears for images with a non-zero id), so
 * subsequent frames display it with the tiny {@link encodeKittyPlacement}
 * sequence instead of re-sending the base64.
 */
export function encodeKittyTransmit(base64Data: string, imageId: number): string {
	return chunkKittyApc(`a=t,f=100,q=2,i=${imageId}`, base64Data);
}

/**
 * Display a previously transmitted image (`a=p`) at the cursor. `C=1` keeps
 * the terminal cursor anchored at the placement origin so the renderer's
 * explicit cursor movement remains the only row accounting. Carrying a stable
 * `placementId` (`p=`) means re-emitting the sequence on a repaint *replaces*
 * the existing placement (moving/resizing it without flicker) rather than
 * stacking a duplicate.
 */
export function encodeKittyPlacement(options: {
	imageId: number;
	placementId?: number;
	columns?: number;
	rows?: number;
}): string {
	const params: string[] = ["a=p", "q=2", "C=1", `i=${options.imageId}`];
	if (options.placementId) params.push(`p=${options.placementId}`);
	if (options.columns) params.push(`c=${options.columns}`);
	if (options.rows) params.push(`r=${options.rows}`);
	return wrapTmuxPassthroughIfNeeded(`\x1b_G${params.join(",")}\x1b\\`);
}

/**
 * Exact shape of the direct-placement line {@link Image} emits as its block's
 * last row: optional `ESC 7` + `CUU(rows-1)` prefix, the {@link encodeKittyPlacement}
 * APC, optional `ESC 8` suffix. The parser unwraps tmux passthrough first.
 */
const KITTY_DIRECT_PLACEMENT_LINE =
	/^(?:\x1b7(?:\x1b\[(\d+)A)?)?\x1b_Ga=p,q=2,C=1,i=(\d+)(?:,p=(\d+))?(?:,c=(\d+))?(?:,r=(\d+))?\x1b\\(?:\x1b8)?$/;

export interface ParsedKittyPlacementLine {
	imageId: number;
	placementId: number | undefined;
	columns: number;
	rows: number;
}

/**
 * Parse a frame line that consists solely of a Kitty direct placement (the
 * last line of an {@link Image} block). Returns null for anything else —
 * placeholder grids, sixel/iTerm2 payloads — so
 * callers fall back to writing the line verbatim.
 */
export function parseKittyDirectPlacementLine(line: string): ParsedKittyPlacementLine | null {
	if (line.includes("\x1bPtmux;")) {
		line = line.replace(/\x1bPtmux;((?:[^\x1b]|\x1b\x1b)*)\x1b\\/g, (_match, payload: string) =>
			payload.replaceAll("\x1b\x1b", "\x1b"),
		);
	}
	const m = KITTY_DIRECT_PLACEMENT_LINE.exec(line);
	if (!m) return null;
	const columns = m[4] !== undefined ? Number(m[4]) : 0;
	const rows = m[5] !== undefined ? Number(m[5]) : 0;
	if (columns <= 0 || rows <= 0) return null;
	return {
		imageId: Number(m[2]),
		placementId: m[3] !== undefined ? Number(m[3]) : undefined,
		columns,
		rows,
	};
}

/** `ESC 7` + `CUU(n)` lead-in of an {@link Image} direct-placement line. */
const DIRECT_PLACEMENT_LIFT = /^\x1b7\x1b\[(\d+)A/;

/**
 * Rows above its own line that an {@link Image} direct-placement line paints
 * over: the `CUU(rows-1)` of its lead-in, or 0 for any other line. The renderer
 * erases those rows before a SIXEL/iTerm2 block is written again, because
 * those protocols have no delete command and the block's reserved rows are
 * byte-identical between frames, so the diff never rewrites them.
 */
export function directPlacementLift(line: string): number {
	const m = DIRECT_PLACEMENT_LIFT.exec(line);
	return m ? Number(m[1]) : 0;
}

/**
 * Re-anchor an {@link Image} direct-placement line `lift` rows above its own
 * row instead of its encoded `CUU(rows-1)`. The renderer lowers the lift when
 * the block's top is clipped by the frame: the cursor-up would otherwise climb
 * past the frame's first row into whatever the terminal shows above it.
 */
export function withDirectPlacementLift(line: string, lift: number): string {
	return line.replace(DIRECT_PLACEMENT_LIFT, lift > 0 ? `\x1b7\x1b[${lift}A` : "\x1b7");
}

/**
 * Rebuild an {@link Image} direct-placement line for the viewport row it is
 * written at. The component-rendered line encodes `CUU(rows-1)`, which clamps
 * at the viewport top once the block's leading rows have scrolled out — the
 * placement then re-anchors the full image shifted down over foreign rows.
 * Anchor at the block's first *visible* row instead, clipping the source
 * rectangle (`y=`/`h=`, image pixels) to the visible bottom slice.
 */
export function encodeKittyPlacementLine(options: {
	imageId: number;
	placementId: number;
	columns: number;
	/** Total cell rows of the image block. */
	rows: number;
	/** Viewport row the block's last line is being written at. */
	screenRow: number;
	/** Source image height in pixels, for the clipped source rectangle. */
	imageHeightPx: number;
}): string {
	// Without a source pixel height the slice cannot be expressed — emit the
	// component's own full form (status quo) rather than squashing the whole
	// image into the reduced row count.
	const clippable = options.imageHeightPx > 0;
	const hiddenRows = clippable ? Math.max(0, options.rows - 1 - options.screenRow) : 0;
	const visibleRows = options.rows - hiddenRows;
	const params: string[] = ["a=p", "q=2", "C=1", `i=${options.imageId}`, `p=${options.placementId}`];
	params.push(`c=${options.columns}`, `r=${visibleRows}`);
	if (hiddenRows > 0) {
		const srcY = Math.floor((options.imageHeightPx * hiddenRows) / options.rows);
		params.push(`y=${srcY}`, `h=${Math.max(1, options.imageHeightPx - srcY)}`);
	}
	const apc = wrapTmuxPassthroughIfNeeded(`\x1b_G${params.join(",")}\x1b\\`);
	const cuu = visibleRows - 1;
	return cuu > 0 ? `\x1b7\x1b[${cuu}A${apc}\x1b8` : apc;
}

/**
 * Kitty graphics delete command for a single image id. Uses `d=I` (capital)
 * which removes the image and every one of its placements — on screen *and* in
 * scrollback — and frees the backing data. `q=2` suppresses the terminal reply.
 * Text-clearing escapes (`CSI 2 J` / `CSI 3 J`) do not remove Kitty graphics, so
 * this is the only way to actually purge a placed image.
 */
export function encodeKittyDeleteImage(imageId: number): string {
	return wrapTmuxPassthroughIfNeeded(`\x1b_Ga=d,d=I,i=${imageId},q=2\x1b\\`);
}
/**
 * Delete every Kitty image and placement in the terminal. Used only by an
 * explicit destructive display reset: text erases leave untracked placements
 * painted, so per-image bookkeeping cannot guarantee a clean viewport.
 */
export function encodeKittyDeleteAllImages(): string {
	return wrapTmuxPassthroughIfNeeded("\x1b_Ga=d,d=A,q=2\x1b\\");
}

/**
 * Delete a single placement of an image (`d=i`, lowercase): removes its cells
 * and registry entry but keeps the transmitted data, so a later `a=p` under a
 * fresh placement id needs no retransmit. The frame writer uses this before
 * replacing a live image without deleting its archived copies.
 */
export function encodeKittyDeletePlacement(imageId: number, placementId: number): string {
	return wrapTmuxPassthroughIfNeeded(`\x1b_Ga=d,d=i,i=${imageId},p=${placementId},q=2\x1b\\`);
}

export function encodeITerm2(
	base64Data: string,
	options: {
		width?: number | string;
		height?: number | string;
		name?: string;
		preserveAspectRatio?: boolean;
		inline?: boolean;
	} = {},
): string {
	const params: string[] = [`inline=${options.inline !== false ? 1 : 0}`];

	if (options.width !== undefined) params.push(`width=${options.width}`);
	if (options.height !== undefined) params.push(`height=${options.height}`);
	if (options.name) {
		const nameBase64 = Buffer.from(options.name).toBase64();
		params.push(`name=${nameBase64}`);
	}
	if (options.preserveAspectRatio === false) {
		params.push("preserveAspectRatio=0");
	}

	return `\x1b]1337;File=${params.join(";")}:${base64Data}\x07`;
}

/**
 * The encoded image `encodeITerm2` wrote into `line`, without the size
 * parameters a rewrap changes; undefined for a line without one.
 */
export function iterm2ImagePayload(line: string): string | undefined {
	const start = line.indexOf(ImageProtocol.Iterm2);
	if (start === -1) return undefined;
	const colon = line.indexOf(":", start + ImageProtocol.Iterm2.length);
	if (colon === -1) return undefined;
	const end = line.indexOf("\x07", colon + 1);
	return line.slice(colon + 1, end === -1 ? undefined : end);
}

export function calculateImageRows(
	imageDimensions: ImageDimensions,
	targetWidthCells: number,
	cellDimensions: CellDimensions = { widthPx: 9, heightPx: 18 },
): number {
	const targetWidthPx = targetWidthCells * cellDimensions.widthPx;
	const scale = targetWidthPx / imageDimensions.widthPx;
	const scaledHeightPx = imageDimensions.heightPx * scale;
	const rows = Math.ceil(scaledHeightPx / cellDimensions.heightPx);
	return Math.max(1, rows);
}

function calculateImageFit(
	imageDimensions: ImageDimensions,
	options: ImageRenderOptions,
	cellDims: CellDimensions,
): { columns: number; rows: number } {
	const maxColumns = options.maxWidthCells !== undefined ? Math.max(1, Math.floor(options.maxWidthCells)) : undefined;
	const maxRows = options.maxHeightCells !== undefined ? Math.max(1, Math.floor(options.maxHeightCells)) : undefined;

	if (maxColumns === undefined && maxRows === undefined) {
		const columns = Math.max(1, Math.ceil(imageDimensions.widthPx / cellDims.widthPx));
		const rows = Math.max(1, Math.ceil(imageDimensions.heightPx / cellDims.heightPx));
		return { columns, rows };
	}

	const maxWidthPx = maxColumns !== undefined ? maxColumns * cellDims.widthPx : Number.POSITIVE_INFINITY;
	const maxHeightPx = maxRows !== undefined ? maxRows * cellDims.heightPx : Number.POSITIVE_INFINITY;
	const scale = Math.min(maxWidthPx / imageDimensions.widthPx, maxHeightPx / imageDimensions.heightPx);
	const fittedWidthPx = imageDimensions.widthPx * scale;
	const fittedHeightPx = imageDimensions.heightPx * scale;

	const columns = Math.max(1, Math.floor(fittedWidthPx / cellDims.widthPx));
	const rows = Math.max(1, Math.ceil(fittedHeightPx / cellDims.heightPx));

	return {
		columns: maxColumns !== undefined ? Math.min(columns, maxColumns) : columns,
		rows: maxRows !== undefined ? Math.min(rows, maxRows) : rows,
	};
}

export function getPngDimensions(base64Data: string): ImageDimensions | null {
	try {
		const buffer = Buffer.from(base64Data, "base64");

		if (buffer.length < 24) {
			return null;
		}

		if (buffer[0] !== 0x89 || buffer[1] !== 0x50 || buffer[2] !== 0x4e || buffer[3] !== 0x47) {
			return null;
		}

		const width = buffer.readUInt32BE(16);
		const height = buffer.readUInt32BE(20);

		return { widthPx: width, heightPx: height };
	} catch {
		return null;
	}
}

export function getJpegDimensions(base64Data: string): ImageDimensions | null {
	try {
		const buffer = Buffer.from(base64Data, "base64");

		if (buffer.length < 2) {
			return null;
		}

		if (buffer[0] !== 0xff || buffer[1] !== 0xd8) {
			return null;
		}

		let offset = 2;
		while (offset < buffer.length - 9) {
			if (buffer[offset] !== 0xff) {
				offset++;
				continue;
			}

			const marker = buffer[offset + 1];

			if (marker >= 0xc0 && marker <= 0xc2) {
				const height = buffer.readUInt16BE(offset + 5);
				const width = buffer.readUInt16BE(offset + 7);
				return { widthPx: width, heightPx: height };
			}

			if (offset + 3 >= buffer.length) {
				return null;
			}
			const length = buffer.readUInt16BE(offset + 2);
			if (length < 2) {
				return null;
			}
			offset += 2 + length;
		}

		return null;
	} catch {
		return null;
	}
}

export function getGifDimensions(base64Data: string): ImageDimensions | null {
	try {
		const buffer = Buffer.from(base64Data, "base64");

		if (buffer.length < 10) {
			return null;
		}

		const sig = buffer.slice(0, 6).toString("ascii");
		if (sig !== "GIF87a" && sig !== "GIF89a") {
			return null;
		}

		const width = buffer.readUInt16LE(6);
		const height = buffer.readUInt16LE(8);

		return { widthPx: width, heightPx: height };
	} catch {
		return null;
	}
}

export function getWebpDimensions(base64Data: string): ImageDimensions | null {
	try {
		const buffer = Buffer.from(base64Data, "base64");

		if (buffer.length < 30) {
			return null;
		}

		const riff = buffer.slice(0, 4).toString("ascii");
		const webp = buffer.slice(8, 12).toString("ascii");
		if (riff !== "RIFF" || webp !== "WEBP") {
			return null;
		}

		const chunk = buffer.slice(12, 16).toString("ascii");
		if (chunk === "VP8 ") {
			if (buffer.length < 30) return null;
			const width = buffer.readUInt16LE(26) & 0x3fff;
			const height = buffer.readUInt16LE(28) & 0x3fff;
			return { widthPx: width, heightPx: height };
		} else if (chunk === "VP8L") {
			if (buffer.length < 25) return null;
			const bits = buffer.readUInt32LE(21);
			const width = (bits & 0x3fff) + 1;
			const height = ((bits >> 14) & 0x3fff) + 1;
			return { widthPx: width, heightPx: height };
		} else if (chunk === "VP8X") {
			if (buffer.length < 30) return null;
			const width = (buffer[24] | (buffer[25] << 8) | (buffer[26] << 16)) + 1;
			const height = (buffer[27] | (buffer[28] << 8) | (buffer[29] << 16)) + 1;
			return { widthPx: width, heightPx: height };
		}

		return null;
	} catch {
		return null;
	}
}

export function getImageDimensions(base64Data: string, mimeType: string): ImageDimensions | null {
	if (mimeType === "image/png") {
		return getPngDimensions(base64Data);
	}
	if (mimeType === "image/jpeg") {
		return getJpegDimensions(base64Data);
	}
	if (mimeType === "image/gif") {
		return getGifDimensions(base64Data);
	}
	if (mimeType === "image/webp") {
		return getWebpDimensions(base64Data);
	}
	return null;
}

/**
 * SIXEL sequence for `base64Data` at the given pixel size, encoded on the JS
 * thread; `null` when the encode fails. For output that cannot wait for an
 * off-thread encode.
 */
export function encodeSixelNow(
	base64Data: string,
	widthPx: number,
	heightPx: number,
	backgroundRgb = getTerminalBackgroundColor(),
): string | null {
	try {
		return ensureSixelRasterWidth(
			encodeSixel(new Uint8Array(Buffer.from(base64Data, "base64")), widthPx, heightPx, backgroundRgb),
		);
	} catch {
		return null;
	}
}

export function renderImage(
	base64Data: string,
	imageDimensions: ImageDimensions,
	options: ImageRenderOptions = {},
): { sequence?: string; lines?: string[]; rows: number; transmit?: string } | null {
	if (!TERMINAL.imageProtocol) {
		return null;
	}

	const cellDims = getCellDimensions();
	const fit = calculateImageFit(imageDimensions, options, cellDims);

	if (TERMINAL.imageProtocol === ImageProtocol.Kitty) {
		if (options.imageId != null) {
			const placementId = options.placementId ?? options.imageId;
			const graphics = getKittyGraphics();
			// Transmit-once (keyed by id). Repaints reuse the stored image, so the
			// transmit is only emitted when requested.
			let transmit: string | undefined;
			if (options.includeTransmit) {
				transmit = encodeKittyTransmit(base64Data, options.imageId);
			}
			// Unicode placeholders render the image as real text cells (which survive
			// horizontal slicing, reflow and overlaps) instead of a cursor-positioned
			// `a=p` placement. Falls back to direct placement when disabled or when the
			// grid exceeds the diacritic table's addressable cell range.
			if (graphics.unicodePlaceholders && kittyPlaceholdersFit(fit.columns, fit.rows)) {
				const lines = renderKittyPlaceholderLines({
					imageId: options.imageId,
					placementId,
					columns: fit.columns,
					rows: fit.rows,
				});
				return { lines, rows: fit.rows, transmit };
			}
			// Direct placement: re-emit only the tiny `a=p` on repaints.
			const sequence = encodeKittyPlacement({
				imageId: options.imageId,
				placementId,
				columns: fit.columns,
				rows: fit.rows,
			});
			return { sequence, rows: fit.rows, transmit };
		}
		// No stable id (e.g. no budget): self-contained transmit-and-display.
		const sequence = encodeKitty(base64Data, {
			columns: fit.columns,
			rows: fit.rows,
		});
		return { sequence, rows: fit.rows };
	}

	if (TERMINAL.imageProtocol === ImageProtocol.Sixel) {
		// Encode the cell box itself, so a raster drawn at the cell size
		// (SvgFigure) is placed 1:1 instead of resampled. The encoder drops a
		// partial last 6px band rather than letting the terminal pad it into
		// the next row; only a box under one band (sub-6px cells) still takes
		// the rows of a whole one.
		const heightPx = fit.rows * cellDims.heightPx;
		const widthPx = fit.columns * cellDims.widthPx;
		const rows = heightPx < 6 ? Math.ceil(6 / cellDims.heightPx) : fit.rows;
		const sequence = options.sixel ? options.sixel(widthPx, heightPx) : encodeSixelNow(base64Data, widthPx, heightPx);
		if (sequence === null) return null;
		// Undefined while the provider's encode is pending: the rows stay reserved.
		return { sequence, rows };
	}
	if (TERMINAL.imageProtocol === ImageProtocol.Iterm2) {
		// The height is the rows reserved for the image, not `auto`: iTerm2
		// resolves `auto` only for a session on screen, so an image written to a
		// background tab is dropped, and its rows stay blank in scrollback too.
		const sequence = encodeITerm2(base64Data, {
			width: fit.columns,
			height: fit.rows,
			preserveAspectRatio: options.preserveAspectRatio ?? true,
		});
		return { sequence, rows: fit.rows };
	}

	return null;
}

export function imageFallback(mimeType: string, dimensions?: ImageDimensions, filename?: string): string {
	const parts: string[] = [];
	if (filename) parts.push(filename);
	parts.push(`[${mimeType}]`);
	if (dimensions) parts.push(`${dimensions.widthPx}x${dimensions.heightPx}`);
	return `[Image: ${parts.join(" ")}]`;
}

/**
 * Structured terminal notification. Rich fields are honored only by OSC 99
 * (Kitty) once support is confirmed; other protocols and the unconfirmed Kitty
 * path collapse to a single `title: body` line.
 */
export interface TerminalNotification {
	title?: string;
	body?: string;
	id?: string;
	type?: string | string[];
	urgency?: "low" | "normal" | "critical";
	iconName?: string;
	sound?: "silent" | "system" | "info" | "warning" | "error" | "question";
	actions?: "focus" | "report" | "focus-report" | "none";
	expiresMs?: number;
}

/**
 * Whether the terminal confirmed OSC 99 desktop-notification support via the
 * `p=?` query probe. Until confirmed, structured notifications collapse to a
 * single message line.
 */
let osc99CapabilitiesConfirmed = false;

/** Record the OSC 99 capability-probe result (called by ProcessTerminal). */
export function setOsc99Supported(supported: boolean): void {
	osc99CapabilitiesConfirmed = supported;
}

/** True when OSC 99 structured notifications have been confirmed available. */
export function isOsc99Supported(): boolean {
	return osc99CapabilitiesConfirmed;
}

/** Collapse a structured notification to a single line for non-OSC-99 sinks. */
function notificationToLine(n: TerminalNotification): string {
	if (n.title && n.body) return `${n.title}: ${n.body}`;
	return n.title ?? n.body ?? "";
}

// C0/C1 control characters that are unsafe inside an OSC payload (must base64).
const OSC99_UNSAFE = /[\x00-\x1f\x7f\x80-\x9f]/u;
const OSC99_MAX_PAYLOAD_BYTES = 2048;
const OSC99_APP_NAME = "omp";
// Kitty matches notification ids across its whole process, not per window, so
// a bare counter would collide between omp sessions sharing one kitty instance
// and turn a new notification into a silent replacement of another session's.
const OSC99_ID_PREFIX = `omp-${crypto.randomUUID().slice(0, 8)}`;
let nextOsc99NotificationId = 1;

function base64Utf8(value: string): string {
	return Buffer.from(value, "utf8").toString("base64");
}

function sanitizeOsc99Id(id: string | undefined): string {
	if (!id) return "";
	const safe = id.replace(/[^a-zA-Z0-9_+\-.]/gu, "");
	return safe === "0" ? "" : safe;
}

function osc99Id(id: string | undefined): string {
	return sanitizeOsc99Id(id) || `${OSC99_ID_PREFIX}-${nextOsc99NotificationId++}`;
}

function utf8CodePointBytes(char: string): number {
	const codePoint = char.codePointAt(0) ?? 0;
	if (codePoint <= 0x7f) return 1;
	if (codePoint <= 0x7ff) return 2;
	if (codePoint <= 0xffff) return 3;
	return 4;
}

function chunkUtf8(payload: string): string[] {
	if (payload === "") return [""];
	const chunks: string[] = [];
	let start = 0;
	let index = 0;
	let bytes = 0;
	for (const char of payload) {
		const charBytes = utf8CodePointBytes(char);
		if (bytes > 0 && bytes + charBytes > OSC99_MAX_PAYLOAD_BYTES) {
			chunks.push(payload.slice(start, index));
			start = index;
			bytes = 0;
		}
		bytes += charBytes;
		index += char.length;
	}
	chunks.push(payload.slice(start));
	return chunks;
}

function osc99Chunk(meta: string[], payload: string): string {
	if (OSC99_UNSAFE.test(payload)) {
		return `\x1b]99;${[...meta, "e=1"].join(":")};${base64Utf8(payload)}\x1b\\`;
	}
	return `\x1b]99;${meta.join(":")};${payload}\x1b\\`;
}

function osc99Payload(meta: string[], payload: string, holdUntilLaterPayload: boolean): string {
	const chunks = chunkUtf8(payload);
	let out = "";
	for (let i = 0; i < chunks.length; i++) {
		const chunkMeta = [...meta];
		if (holdUntilLaterPayload || i < chunks.length - 1) chunkMeta.push("d=0");
		out += osc99Chunk(chunkMeta, chunks[i]!);
	}
	return out;
}

function osc99Urgency(urgency: TerminalNotification["urgency"]): string | undefined {
	switch (urgency) {
		case "low":
			return "0";
		case "normal":
			return "1";
		case "critical":
			return "2";
		default:
			return undefined;
	}
}

function osc99Actions(actions: TerminalNotification["actions"]): string | undefined {
	switch (actions) {
		case "focus":
			return "focus";
		case "report":
			return "report";
		case "focus-report":
			return "focus,report";
		case "none":
			return "-focus";
		default:
			return undefined;
	}
}

/**
 * Format a structured notification as OSC 99 title/body payloads. Title and
 * body chunks share one id. Every non-final chunk carries `d=0`; the final
 * title or body chunk displays the notification. Metadata values that require
 * it (application name, type, icon name, sound) are base64-encoded.
 */
function formatOsc99Notification(n: TerminalNotification): string {
	const id = osc99Id(n.id);
	const meta: string[] = [`i=${id}`, `f=${base64Utf8(OSC99_APP_NAME)}`];
	const actions = osc99Actions(n.actions);
	if (actions) meta.push(`a=${actions}`);
	const urgency = osc99Urgency(n.urgency);
	if (urgency) meta.push(`u=${urgency}`);
	const types = n.type === undefined ? [] : Array.isArray(n.type) ? n.type : [n.type];
	for (const t of types) meta.push(`t=${base64Utf8(t)}`);
	if (n.iconName) meta.push(`n=${base64Utf8(n.iconName)}`);
	if (n.sound) meta.push(`s=${base64Utf8(n.sound)}`);
	if (n.expiresMs !== undefined && Number.isFinite(n.expiresMs)) {
		meta.push(`w=${Math.max(-1, Math.trunc(n.expiresMs))}`);
	}

	const title = n.title ?? n.body ?? "";
	const body = n.title ? n.body : undefined;

	if (body !== undefined && body !== "") {
		return osc99Payload(meta, title, true) + osc99Payload([`i=${id}`, "p=body"], body, false);
	}
	return osc99Payload(meta, title, false);
}
