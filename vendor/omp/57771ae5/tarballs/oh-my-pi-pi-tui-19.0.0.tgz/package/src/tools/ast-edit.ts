import type { Component } from "../tui";
import { Text } from "../components/text";
import type { Theme } from "../theme/theme";
import { Ellipsis, renderStatusLine, truncateToWidth } from "../render";
import { framedToolCard } from "../render/tool-card";
import {
	appendParseErrorsBulletList,
	formatCount,
	formatErrorDetail,
	formatParseErrorsCountLabel,
	PREVIEW_LIMITS,
} from "../render/render-utils";
import {
	classifyGroupedLines,
	createGroupedRowStyler,
	fitGroupsToBudget,
	formatScopedSubject,
	groupedLinkTargets,
	groupLineIndicesByBlank,
	groupsByFile,
	walkGroupedOutput,
} from "./grouped-file-output";
import type { OutputMeta } from "./output-meta";
import type {
	NativeToolHead,
	NativeToolView,
	RenderResultContextOptions,
	RenderResultOptions,
	ToolRenderer,
} from "./renderer";
import { code, compact, diff, node, span, text } from "../native/describe";
import type { NativeChild, NativeNode } from "../native/node";
import { diffStatsMeta, displayPath, errorText, fileDiffSection, noteText, resultText, statsText } from "./native-view";

/** Display metadata returned by ast-edit. */
export interface AstEditToolDetails {
	totalReplacements: number;
	filesTouched: number;
	filesSearched: number;
	applied: boolean;
	limitReached: boolean;
	parseErrors?: string[];
	/** Total parse error count before {@link PARSE_ERRORS_LIMIT} capping. Omitted when no errors. */
	parseErrorsTotal?: number;
	scopePath?: string;
	files?: string[];
	fileReplacements?: Array<{ path: string; count: number }>;
	meta?: OutputMeta;
	/** Pre-formatted text for the user-visible TUI render. Mirrors `result.text` lines but uses
	 * a `│` gutter (no model-only hashline anchors). The TUI uses this directly so it never parses model-facing text. */
	displayContent?: string;
	/** Absolute base directory used during the edit. Used by the renderer to resolve
	 * display-relative paths to absolute paths for OSC 8 hyperlinks. */
	searchPath?: string;
	/** Session cwd at edit time. Display header paths are cwd-relative, so the
	 * renderer resolves them against this; `searchPath` is the scope target. */
	cwd?: string;
}

interface AstEditRenderArgs {
	ops?: Array<{ pat?: string; out?: string }>;
	paths?: string[];
}

const COLLAPSED_CHANGE_LIMIT = PREVIEW_LIMITS.COLLAPSED_LINES * 2;

/**
 * Frame body lines for per-file change groups, styled on demand: files apart by
 * a blank line and without tree guides (the frame border is the container), fit
 * to `budget` with the rest summarized as `… N more files`.
 */
function buildChangeBody(
	groups: readonly (readonly number[])[],
	styleLine: (index: number) => string,
	isFileRow: (index: number) => boolean,
	budget: number,
	theme: Theme,
): string[] {
	const { shown, summary } = fitGroupsToBudget(groups, budget, { isUnit: isFileRow, unit: "file", gap: 1 });
	const lines: string[] = [];
	for (const group of shown) {
		if (lines.length > 0) lines.push("");
		for (const index of group) lines.push(styleLine(index));
	}
	if (summary) lines.push(theme.fg("muted", summary));
	return lines;
}

/** One-line header preview of an AST pattern. `renderStatusLine` only flattens
 * CR/LF, so a multi-line tab-indented pattern would otherwise punch raw tabs
 * into the status line; collapse all whitespace runs to single spaces. */
function patternPreview(pat: string | undefined): string | undefined {
	const collapsed = pat?.replace(/\s+/g, " ").trim();
	return collapsed || undefined;
}

/** The single rewrite's pattern preview, or `N rewrites` for several. */
function rewriteLabel(args: AstEditRenderArgs | undefined): string | undefined {
	const rewriteCount = args?.ops?.length ?? 0;
	if (rewriteCount === 1) return patternPreview(args?.ops?.[0]?.pat);
	return rewriteCount > 1 ? `${rewriteCount} rewrites` : undefined;
}

/**
 * Header subject: `pattern in scope` (or `N rewrites in scope`). The scope is the
 * result's display scope, else the call's requested paths, as in Grep and AST Grep.
 */
function astEditSubject(
	label: string | undefined,
	args: AstEditRenderArgs | undefined,
	theme: Theme,
	scopePath?: string,
): string | undefined {
	const scope = scopePath || args?.paths?.join(", ") || undefined;
	return formatScopedSubject(label, scope, theme);
}

const AST_EDIT_CHANGE_LINE_RE = /^([+\- ])\s*(\d+)(?:│|[:|])(.*)$/;

/** One file's proposed rewrite: its unified diff text and change counts. */
interface AstEditFileDiff {
	path: string;
	lines: string[];
	added: number;
	removed: number;
	lastOld?: number;
}

/**
 * Parse ast-edit display content (`# dir/`, `## file (N replacements)`,
 * `-12│old` / `+12│new`) into one unified diff per file.
 */
function parseAstEditChanges(lines: readonly string[]): AstEditFileDiff[] {
	const files: AstEditFileDiff[] = [];
	let file: AstEditFileDiff | undefined;
	for (const event of walkGroupedOutput(lines)) {
		if (event.kind !== "line") {
			if (file && file.lines.length > 0) files.push(file);
			file = event.kind === "file" ? { path: event.path, lines: [], added: 0, removed: 0 } : undefined;
			continue;
		}
		if (!file) continue;
		const change = AST_EDIT_CHANGE_LINE_RE.exec(event.text);
		if (!change) continue;
		const lineNumber = Number.parseInt(change[2]!, 10);
		if (file.lastOld === undefined || lineNumber > file.lastOld + 1 || lineNumber < file.lastOld) {
			file.lines.push(`@@ -${lineNumber} +${lineNumber} @@`);
		}
		file.lastOld = lineNumber;
		if (change[1] === "+") file.added++;
		else if (change[1] === "-") file.removed++;
		file.lines.push(`${change[1]}${change[3]}`);
	}
	if (file && file.lines.length > 0) files.push(file);
	return files;
}

/** A file's proposed rewrite as a `diff`: Tern highlights it by the file's grammar and draws no path header. */
function astEditDiff(file: AstEditFileDiff): NativeNode {
	return diff(file.lines.join("\n"), { path: file.path });
}

/** The single rewrite pattern (`target:"pattern"`), or the rewrite count, for the head. */
function astEditPatternHead(args: AstEditRenderArgs | undefined): Pick<NativeToolHead, "target" | "targetKind"> {
	const label = rewriteLabel(args);
	if (!label) return {};
	return { target: label, targetKind: args?.ops?.length === 1 ? "pattern" : "text" };
}

/** Scope facts for the final quiet line: `in src · searched 12 files · limit reached; narrow path`. */
function astEditScopeStats(details: AstEditToolDetails | undefined): NativeNode | undefined {
	const parts: string[] = [];
	if (details?.scopePath) parts.push(`in ${details.scopePath}`);
	if (details?.filesSearched) parts.push(`searched ${formatCount("file", details.filesSearched)}`);
	if (details?.limitReached) parts.push("limit reached; narrow path");
	return statsText(parts);
}

/** Render AST edit calls and results. */
export const astEditToolRenderer = {
	inline: true,
	renderCall(args: AstEditRenderArgs, _options: RenderResultOptions, uiTheme: Theme): Component {
		const description = astEditSubject(rewriteLabel(args) ?? "?", args, uiTheme);
		const header = renderStatusLine({ icon: "pending", title: "AST Edit", description }, uiTheme);
		// Pending call has no body yet — a lone status line is sleeker than an empty frame.
		return new Text(header, 0, 0);
	},

	renderResult(
		result: { content: Array<{ type: string; text?: string }>; details?: AstEditToolDetails; isError?: boolean },
		options: RenderResultContextOptions,
		uiTheme: Theme,
		args?: AstEditRenderArgs,
	): Component {
		const details = result.details;
		const description = astEditSubject(rewriteLabel(args), args, uiTheme, details?.scopePath);

		if (result.isError) {
			const errorText = result.content?.find(c => c.type === "text")?.text || "Unknown error";
			const header = renderStatusLine({ icon: "error", title: "AST Edit", description }, uiTheme);
			return framedToolCard(uiTheme, () => ({
				header,
				sections: [{ content: formatErrorDetail(errorText, uiTheme).split("\n") }],
				phase: "error",
				borderColor: "error",
			}));
		}

		const totalReplacements = details?.totalReplacements ?? 0;
		const filesTouched = details?.filesTouched ?? 0;
		const filesSearched = details?.filesSearched ?? 0;
		const limitReached = details?.limitReached ?? false;

		if (totalReplacements === 0) {
			const meta = ["0 replacements"];
			if (filesSearched > 0) meta.push(`searched ${filesSearched}`);
			// Only parse errors are worth a body, so frame solely when there are some; a
			// framed card carries the counts in its bottom border, as a successful one does.
			const bodyLines: string[] = [];
			appendParseErrorsBulletList(bodyLines, details?.parseErrors, uiTheme, details?.parseErrorsTotal);
			if (bodyLines.length === 0) {
				return new Text(renderStatusLine({ icon: "warning", title: "AST Edit", description, meta }, uiTheme), 0, 0);
			}
			const header = renderStatusLine({ icon: "warning", title: "AST Edit", description }, uiTheme);
			const footerMeta = uiTheme.fg("dim", meta.join(uiTheme.sep.dot));
			return framedToolCard(uiTheme, () => ({
				header,
				footerMeta,
				sections: [{ content: bodyLines }],
				phase: "warning",
				borderColor: "borderMuted",
			}));
		}

		const summaryParts = [
			formatCount("replacement", totalReplacements),
			formatCount("file", filesTouched),
			`searched ${filesSearched}`,
		];

		const textContent = result.details?.displayContent ?? result.content?.find(c => c.type === "text")?.text ?? "";
		const allLines = textContent.split("\n");
		// Classify the whole output so nested directory headers resolve across blank-line groups.
		const contexts = classifyGroupedLines(allLines, details?.cwd ?? details?.searchPath, details?.searchPath);
		const styleLine = createGroupedRowStyler(allLines, contexts, uiTheme, {
			linkTarget: groupedLinkTargets(contexts, textContent, details, options.renderContext?.rawDetails),
			styleBody: index => {
				// Swap the code-frame gutter `│` for a space so it does not nest a
				// second vertical bar inside the frame border.
				const line = allLines[index]!.replace("│", " ");
				const color = line.startsWith("+")
					? "toolDiffAdded"
					: line.startsWith("-")
						? "toolDiffRemoved"
						: "toolOutput";
				return uiTheme.fg(color, line);
			},
		});
		const changeGroups = groupsByFile(groupLineIndicesByBlank(allLines), contexts).filter(indices => {
			const first = allLines[indices[0]!]!;
			return !first.startsWith("Safety cap reached") && !first.startsWith("Parse issues:");
		});

		const header = renderStatusLine(
			{ icon: limitReached ? "warning" : "success", title: "AST Edit", description },
			uiTheme,
		);
		// An unapplied result is a staged proposal; the bottom rail leads with that state.
		const footerParts = summaryParts.map(part => uiTheme.fg("dim", part));
		if (!details?.applied) footerParts.unshift(uiTheme.fg("warning", "proposed"));
		const footerMeta = footerParts.join(uiTheme.fg("dim", uiTheme.sep.dot));

		const extraLines: string[] = [];
		if (limitReached) {
			extraLines.push(uiTheme.fg("warning", "limit reached; narrow path"));
		}
		if (details?.parseErrors?.length) {
			extraLines.push(
				uiTheme.fg("warning", formatParseErrorsCountLabel(details.parseErrors, details.parseErrorsTotal)),
			);
		}
		// The body is spinner-invariant: rebuild it only on expansion/width change.
		let bodyMemo: { expanded: boolean; width: number; lines: readonly string[] } | undefined;
		return framedToolCard(
			uiTheme,
			({ contentWidth }) => {
				const expanded = Boolean(options.expanded);
				if (bodyMemo === undefined || bodyMemo.expanded !== expanded || bodyMemo.width !== contentWidth) {
					const changeLines = buildChangeBody(
						changeGroups,
						styleLine,
						index => contexts[index]!.kind === "file",
						expanded ? Number.POSITIVE_INFINITY : COLLAPSED_CHANGE_LIMIT,
						uiTheme,
					);
					const lines = [...changeLines, ...extraLines].map(l => truncateToWidth(l, contentWidth, Ellipsis.Omit));
					while (lines.length > 0 && lines[0].trim() === "") lines.shift();
					bodyMemo = { expanded, width: contentWidth, lines };
				}
				const bodyLines = bodyMemo.lines;
				return {
					header,
					footerMeta,
					sections: bodyLines.length > 0 ? [{ content: bodyLines }] : [],
					phase: options.isPartial ? "partial" : "success",
					borderColor: "borderMuted",
				};
			},
			{ onInvalidate: () => (bodyMemo = undefined) },
		);
	},
	describeCall(args: AstEditRenderArgs): NativeToolView {
		return {
			tool: {
				title: "AST Edit",
				...astEditPatternHead(args),
				meta: args.paths?.length ? [`in ${args.paths.map(displayPath).join(", ")}`] : undefined,
			},
		};
	},

	describeResult(
		result: { content: Array<{ type: string; text?: string }>; details?: AstEditToolDetails; isError?: boolean },
		_options: RenderResultOptions,
		args?: AstEditRenderArgs,
	): NativeToolView {
		const details = result.details;
		const patternHead = astEditPatternHead(args);
		if (result.isError) {
			// A failed edit keeps the scope it ran in, as the terminal card does.
			const scope = details?.scopePath || args?.paths?.map(displayPath).join(", ");
			return {
				tool: { title: "AST Edit", ...patternHead, meta: scope ? [`in ${scope}`] : undefined },
				tone: "error",
				body: [errorText(resultText(result) || "Unknown error")],
			};
		}
		const parseErrors = details?.parseErrors ?? [];
		const parseNote: NativeChild | undefined =
			parseErrors.length > 0
				? node(
						"section",
						{
							head: [span(formatParseErrorsCountLabel(parseErrors, details?.parseErrorsTotal), "warning")],
							collapsible: true,
							collapsed: true,
						},
						[code(parseErrors.join("\n"))],
						"parse-errors",
					)
				: undefined;
		const totalReplacements = details?.totalReplacements ?? 0;
		if (totalReplacements === 0) {
			return {
				tool: { title: "AST Edit", ...patternHead, meta: ["0 replacements"] },
				tone: "warning",
				body: compact<NativeChild>([parseNote, astEditScopeStats(details)]),
			};
		}
		const limitReached = details?.limitReached ?? false;
		const allLines = (details?.displayContent ?? resultText(result)).split("\n");
		const kept = groupLineIndicesByBlank(allLines)
			.filter(indices => {
				const first = allLines[indices[0]!]!;
				return !first.startsWith("Safety cap reached") && !first.startsWith("Parse issues:");
			})
			.flatMap(indices => indices.map(index => allLines[index]!));
		const files = parseAstEditChanges(kept);
		const fileCount = Math.max(details?.filesTouched ?? 0, files.length);
		let added = 0;
		let removed = 0;
		for (const file of files) {
			added += file.added;
			removed += file.removed;
		}
		// Same shape as edit: one file heads the call by path with a bare diff;
		// several head it as `N files` with one borderless section per file.
		const single = fileCount === 1 && files.length === 1 ? files[0] : undefined;
		const changes: NativeChild[] = single
			? [astEditDiff(single)]
			: files.map(file => fileDiffSection(file, [astEditDiff(file)], { role: "omp.tool.ast_edit.file" }));
		// The head names the files, so a single rewrite's pattern moves to a quiet context line.
		const pattern = args?.ops?.length === 1 ? patternPreview(args.ops[0]?.pat) : undefined;
		return {
			tool: {
				title: "AST Edit",
				target: single ? displayPath(single.path) : formatCount("file", fileCount),
				targetKind: single ? "path" : "text",
				meta: compact([diffStatsMeta(added, removed), formatCount("replacement", totalReplacements)]),
				badges: details?.applied ? undefined : [{ text: "proposed", tone: "warning" }],
			},
			tone: limitReached ? "warning" : undefined,
			body: compact<NativeChild>([
				pattern !== undefined &&
					text([span(pattern, "code")], { lines: 1, truncate: "end", role: "omp.tool.context" }),
				...(changes.length > 0 ? changes : [noteText(kept.join("\n"))]),
				parseNote,
				astEditScopeStats(details),
			]),
			preview: { lines: COLLAPSED_CHANGE_LIMIT },
		};
	},
	mergeCallAndResult: true,
} satisfies ToolRenderer<AstEditRenderArgs, AstEditToolDetails>;
