import type { Component } from "../tui";
import { Text } from "../components/text";
import type { Theme } from "../theme/theme";
import { renderStatusLine, renderTreeList } from "../render";
import {
	appendParseErrorsBulletList,
	createCachedComponent,
	fitHeaderedRows,
	formatCount,
	formatErrorDetail,
	formatParseErrorsCountLabel,
	PREVIEW_LIMITS,
	toPathList,
} from "../render/render-utils";
import {
	classifyGroupedLines,
	createCodeFrameStyler,
	createGroupedRowStyler,
	describeGroupedOutput,
	fitGroupsToBudget,
	formatScopedSubject,
	groupedLinkTargets,
	groupLineIndicesByBlank,
	groupsByFile,
	isMatchRow,
} from "./grouped-file-output";
import { code, compact, node, span } from "../native/describe";
import type { NativeChild } from "../native/node";
import { errorText, noteText, resultText, toolHead } from "./native-view";
import type { OutputMeta } from "./output-meta";
import type { NativeToolView, RenderResultContextOptions, RenderResultOptions, ToolRenderer } from "./renderer";

/** Display metadata returned by ast-grep. */
export interface AstGrepToolDetails {
	matchCount: number;
	fileCount: number;
	filesSearched: number;
	limitReached: boolean;
	parseErrors?: string[];
	/** Total parse error count before {@link PARSE_ERRORS_LIMIT} capping. Omitted when no errors. */
	parseErrorsTotal?: number;
	scopePath?: string;
	files?: string[];
	fileMatches?: Array<{ path: string; count: number }>;
	meta?: OutputMeta;
	/** Pre-formatted text for the user-visible TUI render. Mirrors `result.text` lines but uses
	 * a `│` gutter and `*` to mark match lines. The TUI uses this directly so it never parses model-facing text. */
	displayContent?: string;
	/** Absolute base directory used during search. Used by the renderer to resolve
	 * display-relative paths to absolute paths for OSC 8 hyperlinks. */
	searchPath?: string;
	/** Session cwd at search time. Display header/match paths are cwd-relative, so
	 * the renderer resolves them against this; `searchPath` is the scope target. */
	cwd?: string;
}

interface AstGrepRenderArgs {
	pat?: string;
	path?: string | string[];
	/** Legacy pre-`path` argument name; kept so historical transcripts still render a scope. */
	paths?: string[];
	skip?: number;
	/** Language the search parsed the files as; highlighting follows it over the file extension. */
	lang?: string;
}

/** Header subject, `pattern in scope`: the result's display scope, or the call's requested paths. */
function astGrepSubject(
	pattern: string | undefined,
	args: AstGrepRenderArgs | undefined,
	uiTheme: Theme,
	scopePath?: string,
): string | undefined {
	const scope = scopePath || toPathList(args?.path ?? args?.paths).join(", ") || undefined;
	return formatScopedSubject(pattern || undefined, scope, uiTheme);
}

const COLLAPSED_MATCH_LIMIT = PREVIEW_LIMITS.COLLAPSED_LINES * 2;

/** Render AST grep calls and results. */
export const astGrepToolRenderer = {
	inline: true,
	renderCall(args: AstGrepRenderArgs, _options: RenderResultOptions, uiTheme: Theme): Component {
		const meta: string[] = [];
		if (args.skip !== undefined && args.skip > 0) meta.push(`skip:${args.skip}`);
		const description = astGrepSubject(args.pat || "?", args, uiTheme);
		const text = renderStatusLine({ icon: "pending", title: "AST Grep", description, meta }, uiTheme);
		return new Text(text, 0, 0);
	},

	renderResult(
		result: { content: Array<{ type: string; text?: string }>; details?: AstGrepToolDetails; isError?: boolean },
		options: RenderResultContextOptions,
		uiTheme: Theme,
		args?: AstGrepRenderArgs,
	): Component {
		const details = result.details;
		const description = astGrepSubject(args?.pat, args, uiTheme, details?.scopePath);

		if (result.isError) {
			const errorText = result.content?.find(c => c.type === "text")?.text || "Unknown error";
			const header = renderStatusLine({ icon: "error", title: "AST Grep", description }, uiTheme);
			return new Text(`${header}\n${formatErrorDetail(errorText, uiTheme)}`, 0, 0);
		}

		const matchCount = details?.matchCount ?? 0;
		const fileCount = details?.fileCount ?? 0;
		const filesSearched = details?.filesSearched ?? 0;
		const limitReached = details?.limitReached ?? false;

		if (matchCount === 0) {
			const meta = [uiTheme.fg("warning", "0 matches")];
			if (filesSearched > 0) meta.push(`searched ${filesSearched}`);
			const header = renderStatusLine({ icon: "warning", title: "AST Grep", description, meta }, uiTheme);
			const lines = [header];
			if (details?.parseErrors?.length) {
				lines.push(uiTheme.fg("warning", "Query may be mis-scoped; narrow `path` before concluding absence"));
				appendParseErrorsBulletList(lines, details.parseErrors, uiTheme, details.parseErrorsTotal);
			}
			return new Text(lines.join("\n"), 0, 0);
		}

		const meta = [formatCount("match", matchCount), formatCount("file", fileCount), `searched ${filesSearched}`];
		if (limitReached) meta.push(uiTheme.fg("warning", "limit reached"));
		const header = renderStatusLine(
			{
				...(limitReached
					? { icon: "warning" as const }
					: { iconOverride: uiTheme.fg("accent", uiTheme.symbol("icon.search")) }),
				title: "AST Grep",
				description,
				meta,
			},
			uiTheme,
		);

		const textContent = result.details?.displayContent ?? result.content?.find(c => c.type === "text")?.text ?? "";
		const allLines = textContent.split("\n");
		// Classify the whole output so nested directory headers resolve across blank-line groups.
		const contexts = classifyGroupedLines(allLines, details?.cwd ?? details?.searchPath, details?.searchPath);
		const styleCodeFrame = createCodeFrameStyler(allLines, contexts, "toolOutput", uiTheme, args?.lang);
		const styleLine = createGroupedRowStyler(allLines, contexts, uiTheme, {
			linkTarget: groupedLinkTargets(contexts, textContent, details, options.renderContext?.rawDetails),
			styleBody: index => {
				const line = allLines[index]!;
				return styleCodeFrame(index) ?? uiTheme.fg(line.startsWith("  meta:") ? "dim" : "toolOutput", line);
			},
			linkLines: true,
		});
		const matchGroups = groupsByFile(groupLineIndicesByBlank(allLines), contexts).filter(indices => {
			const first = allLines[indices[0]!]!;
			return !first.startsWith("Result limit reached") && !first.startsWith("Parse issues:");
		});
		// Collapsed previews drop the per-match `meta:` capture rows; a match keeps all its rows,
		// since only its first carries the `*` mark.
		const compactGroups = matchGroups.map(group => group.filter(index => !allLines[index]!.startsWith("  meta:")));

		const extraLines: string[] = [];
		if (limitReached) {
			extraLines.push(uiTheme.fg("warning", "limit reached; narrow path or use skip"));
		}
		if (details?.parseErrors?.length) {
			extraLines.push(
				uiTheme.fg("warning", formatParseErrorsCountLabel(details.parseErrors, details.parseErrorsTotal)),
			);
		}

		return createCachedComponent(
			() => options.expanded,
			width => {
				const { shown, summary } = fitGroupsToBudget(
					options.expanded ? matchGroups : compactGroups,
					options.expanded ? Number.POSITIVE_INFINITY : COLLAPSED_MATCH_LIMIT,
					{ isUnit: index => isMatchRow(allLines[index]!), unit: "match", total: matchCount },
				);
				const matchLines = renderTreeList(
					{ items: shown, trailingSummary: summary, renderItem: group => group.map(styleLine) },
					uiTheme,
				);
				return fitHeaderedRows(header, [...matchLines, ...extraLines], width);
			},
		);
	},
	describeCall(args: AstGrepRenderArgs): NativeToolView {
		const meta: string[] = [];
		const scopePaths = toPathList(args.path ?? args.paths);
		if (scopePaths.length) meta.push(`in ${scopePaths.join(", ")}`);
		if (args.skip !== undefined && args.skip > 0) meta.push(`skip:${args.skip}`);
		return { head: toolHead("AST Grep", span(args.pat ?? "?", "code"), ...meta) };
	},

	describeResult(
		result: { content: Array<{ type: string; text?: string }>; details?: AstGrepToolDetails; isError?: boolean },
		_options: RenderResultOptions,
		args?: AstGrepRenderArgs,
	): NativeToolView {
		const details = result.details;
		const pattern = span(args?.pat ?? "?", "code");
		if (result.isError) {
			// A failed search keeps the scope it ran in, as the terminal card does.
			const scope = details?.scopePath || toPathList(args?.path ?? args?.paths).join(", ");
			return {
				head: toolHead("AST Grep", pattern, ...compact([scope && `in ${scope}`])),
				tone: "error",
				body: [errorText(resultText(result) || "Unknown error")],
			};
		}
		const matchCount = details?.matchCount ?? 0;
		const filesSearched = details?.filesSearched ?? 0;
		const limitReached = details?.limitReached ?? false;
		const parseErrors = details?.parseErrors ?? [];
		const parseNote =
			parseErrors.length > 0
				? node(
						"section",
						{
							head: [span(formatParseErrorsCountLabel(parseErrors, details?.parseErrorsTotal), "warning")],
							collapsible: true,
							collapsed: true,
						},
						[code(parseErrors.join("\n"))],
						"parse-errors",
					)
				: undefined;
		if (matchCount === 0) {
			const meta = compact([details?.scopePath && `in ${details.scopePath}`, "0 matches"]);
			if (filesSearched > 0) meta.push(`searched ${filesSearched}`);
			return {
				head: toolHead("AST Grep", pattern, ...meta),
				tone: "warning",
				body: compact<NativeChild>([
					parseErrors.length > 0 &&
						noteText("Query may be mis-scoped; narrow `path` before concluding absence", "warning"),
					parseNote,
				]),
			};
		}
		const meta = compact([
			details?.scopePath && `in ${details.scopePath}`,
			formatCount("match", matchCount),
			formatCount("file", details?.fileCount ?? 0),
		]);
		meta.push(`searched ${filesSearched}`);
		const head = toolHead("AST Grep", pattern, ...meta);
		if (limitReached) head.push(span(" limit reached", "warning"));
		const allLines = (details?.displayContent ?? resultText(result)).split("\n");
		const kept = groupLineIndicesByBlank(allLines)
			.filter(indices => {
				const first = allLines[indices[0]!]!;
				return !first.startsWith("Result limit reached") && !first.startsWith("Parse issues:");
			})
			.flatMap(indices => [...indices.map(index => allLines[index]!), ""]);
		return {
			head,
			body: compact<NativeChild>([
				...describeGroupedOutput(kept),
				limitReached && noteText("limit reached; narrow path or use skip", "warning"),
				parseNote,
			]),
			preview: { lines: COLLAPSED_MATCH_LIMIT },
		};
	},
	mergeCallAndResult: true,
} satisfies ToolRenderer<AstGrepRenderArgs, AstGrepToolDetails>;
