import { isRecord } from "@oh-my-pi/pi-utils";
import type { Component } from "../tui";
import { Text } from "../components/text";
import type {
	NativeToolHead,
	NativeToolView,
	RenderResultContextOptions,
	RenderResultOptions,
	ToolRenderer,
} from "./renderer";
import { compact } from "../native/describe";
import type { NativeChild } from "../native/node";
import { compactText, styledSpans } from "../native/spans";
import { footnoteText, inlineErrorView, resultText } from "./native-view";
import { ensureThemeSync, highlightCode, type Theme } from "../theme/theme";
import type { OutputMeta } from "./output-meta";
import type { TruncationResult } from "./streaming-output";
import { fileHyperlink, renderStatusLine, renderTreeList } from "../render";
import {
	createCachedComponent,
	fitHeaderedRows,
	formatCount,
	formatEmptyMessage,
	formatErrorDetail,
	PREVIEW_LIMITS,
	replaceTabs,
	toPathList,
} from "../render/render-utils";
import {
	classifyGroupedLines,
	createCodeFrameStyler,
	createGroupedRowStyler,
	describeGroupedOutput,
	fitGroupsToBudget,
	formatScopedSubject,
	groupedLinkTargets,
	groupLineIndicesByBlank,
	groupsByFile,
	isGroupedHeader,
	isMatchRow,
} from "./grouped-file-output";

/** Display metadata for grep tool results. */
export interface GrepToolDetails {
	truncation?: TruncationResult;
	fileLimitReached?: number;
	perFileLimitReached?: number;
	linesTruncated?: boolean;
	meta?: OutputMeta;
	scopePath?: string;
	matchCount?: number;
	fileCount?: number;
	files?: string[];
	fileMatches?: Array<{ path: string; count: number }>;
	truncated?: boolean;
	error?: string;
	/** Pre-formatted text for the user-visible TUI render. Mirrors the model-facing
	 * `result.text` lines but uses a `│` gutter and `*` to mark match lines (vs space for
	 * context). The TUI uses this directly so it never parses model-facing hashline anchors. */
	displayContent?: string;
	/** Filesystem hyperlink targets resolved for internal URL headers at execution time. */
	displayTargets?: Record<string, string>;
	/** Absolute base directory used during search. Used by the renderer to resolve
	 * display-relative paths to absolute paths for OSC 8 hyperlinks. */
	searchPath?: string;
	/** Session cwd at search time. The renderer resolves the display-relative
	 * (cwd-relative) header/match paths against this for OSC 8 hyperlinks;
	 * `searchPath` is the scope label target, not the display-path base. */
	cwd?: string;
	/** User-supplied paths whose base directory was missing on disk. The tool
	 * skipped these and continued with the surviving entries; surfaced as a
	 * non-fatal warning in the renderer and in the model-facing text. */
	missingPaths?: string[];
	/** Files skipped as binary although their content matches (cwd-relative display paths). */
	binaryMatches?: string[];
}

// =============================================================================
// TUI Renderer
// =============================================================================

interface GrepRenderArgs {
	pattern: string;
	path?: string | string[];
	/** Legacy pre-`path` argument name; kept so historical transcripts still render a scope. */
	paths?: string | string[];
	case?: boolean;
	gitignore?: boolean;
	skip?: number;
}

const COLLAPSED_TEXT_LIMIT = PREVIEW_LIMITS.COLLAPSED_LINES * 2;
/** Line budget for the expanded view. Larger than collapsed so expanding
 * reveals more matches with context, but still bounded so a single hot file
 * whose matches span the whole file can't dump its entire length. */
const EXPANDED_TEXT_LIMIT = PREVIEW_LIMITS.EXPANDED_LINES * 2;

/** Files a collapsed native grep shows (§7.3). */
const NATIVE_COLLAPSED_FILES = 2;

/** Flag arguments that differ from the defaults: `case:insensitive`, `gitignore:false`, `skip:N`. */
function grepFlagMeta(args: GrepRenderArgs): string[] {
	const meta: string[] = [];
	if (args.case === false) meta.push("case:insensitive");
	if (args.gitignore === false) meta.push("gitignore:false");
	if (args.skip !== undefined && args.skip > 0) meta.push(`skip:${args.skip}`);
	return meta;
}

/**
 * Header subject, `pattern in scope`. A result names the tool's display scope
 * (linked to the original search path); a call falls back to the requested paths.
 * Callers pass the pattern already syntax-colored: the bundled regex grammar also
 * handles incomplete, still-streaming patterns.
 */
function grepSubject(
	subject: string | undefined,
	args: GrepRenderArgs | undefined,
	uiTheme: Theme,
	details?: GrepToolDetails,
	searchPath?: string,
): string | undefined {
	let scope = details?.scopePath || undefined;
	if (scope && searchPath) scope = fileHyperlink(searchPath, scope);
	scope ??= toPathList(args?.path ?? args?.paths).join(", ") || undefined;
	return formatScopedSubject(subject, scope, uiTheme);
}

function grepStatusIcon(uiTheme: Theme): string {
	return uiTheme.fg("toolTitle", uiTheme.symbol("icon.search"));
}

/** Render grep calls and results in the transcript. */
export const grepToolRenderer = {
	inline: true,
	renderCall(args: GrepRenderArgs, _options: RenderResultOptions, uiTheme: Theme): Component {
		const text = renderStatusLine(
			{
				icon: "pending",
				title: "Grep",
				titleColor: "toolTitle",
				description: grepSubject(
					args.pattern ? highlightCode(replaceTabs(args.pattern), "Regular Expression", uiTheme).join("\n") : "?",
					args,
					uiTheme,
				),
				meta: grepFlagMeta(args),
			},
			uiTheme,
		);
		return new Text(text, 0, 0);
	},

	renderResult(
		result: { content: Array<{ type: string; text?: string }>; details?: GrepToolDetails; isError?: boolean },
		options: RenderResultContextOptions,
		uiTheme: Theme,
		args?: GrepRenderArgs,
	): Component {
		const details = result.details;
		// The scope label links to the original (unsanitized) search path.
		const rawDetails = options.renderContext?.rawDetails;
		const searchPath =
			isRecord(rawDetails) && typeof rawDetails.searchPath === "string"
				? rawDetails.searchPath
				: details?.searchPath;
		const pattern = args?.pattern
			? highlightCode(replaceTabs(args.pattern), "Regular Expression", uiTheme).join("\n")
			: undefined;
		const description = grepSubject(pattern, args, uiTheme, details, searchPath);

		if (result.isError || details?.error) {
			const errorText = details?.error || result.content?.find(c => c.type === "text")?.text || "Unknown error";
			const header = renderStatusLine(
				{ icon: "error", title: "Grep", titleColor: "toolTitle", description },
				uiTheme,
			);
			return new Text(`${header}\n${formatErrorDetail(errorText, uiTheme)}`, 0, 0);
		}

		const hasDetailedData = details?.matchCount !== undefined || details?.fileCount !== undefined;

		if (!hasDetailedData) {
			const textContent = result.details?.displayContent ?? result.content?.find(c => c.type === "text")?.text;
			if (!textContent || textContent === "No matches found") {
				return new Text(formatEmptyMessage("No matches found", uiTheme), 0, 0);
			}
			const lines = textContent.split("\n").filter(line => line.trim() !== "");
			const header = renderStatusLine(
				{
					iconOverride: grepStatusIcon(uiTheme),
					title: "Grep",
					titleColor: "toolTitle",
					description,
					meta: [formatCount("item", lines.length)],
				},
				uiTheme,
			);
			return createCachedComponent(
				() => options.expanded,
				width => {
					const listLines = renderTreeList(
						{
							items: lines,
							expanded: options.expanded,
							maxCollapsed: COLLAPSED_TEXT_LIMIT,
							maxCollapsedLines: COLLAPSED_TEXT_LIMIT,
							itemType: "item",
							renderItem: line => uiTheme.fg("toolOutput", line),
						},
						uiTheme,
					);
					return fitHeaderedRows(header, listLines, width);
				},
			);
		}

		const matchCount = details?.matchCount ?? 0;
		const fileCount = details?.fileCount ?? 0;
		const truncation = details?.meta?.truncation;
		const limits = details?.meta?.limits;
		const truncated = Boolean(details?.truncated || truncation || limits?.columnTruncated);

		const missingPathsList = details?.missingPaths ?? [];
		const missingNote =
			missingPathsList.length > 0
				? uiTheme.fg("warning", `skipped missing: ${missingPathsList.join(", ")}`)
				: undefined;
		const binaryNote = details?.binaryMatches?.length
			? uiTheme.fg("warning", `binary matches: ${formatCount("file", details.binaryMatches.length)}`)
			: undefined;
		const extraLines = compact([missingNote, binaryNote]);

		if (matchCount === 0) {
			const header = renderStatusLine(
				{
					icon: "warning",
					title: "Grep",
					titleColor: "toolTitle",
					description,
					meta: [uiTheme.fg("warning", "0 matches")],
				},
				uiTheme,
			);
			return new Text([header, ...extraLines].join("\n"), 0, 0);
		}

		const textContent = result.details?.displayContent ?? result.content?.find(c => c.type === "text")?.text ?? "";
		const allLines = textContent.split("\n");
		// Classify the whole output so nested directory headers resolve across blank-line
		// groups. Display paths are cwd-relative (`searchPath` for results that predate
		// `cwd`); a single-file search's headerless lines belong to the searched file.
		const contexts = classifyGroupedLines(allLines, details?.cwd ?? details?.searchPath, details?.searchPath);
		const hasScope = Boolean(details?.scopePath || toPathList(args?.path ?? args?.paths).length > 0);
		const singleFileScope = hasScope && fileCount === 1 && !allLines.some(isGroupedHeader);
		const meta = [formatCount("match", matchCount)];
		if (!singleFileScope) meta.push(formatCount("file", fileCount));
		if (truncated) meta.push(uiTheme.fg("warning", "truncated"));
		const header = renderStatusLine(
			{
				...(truncated ? { icon: "warning" as const } : { iconOverride: grepStatusIcon(uiTheme) }),
				title: "Grep",
				titleColor: "toolTitle",
				description,
				meta,
			},
			uiTheme,
		);
		const styleCodeFrame = createCodeFrameStyler(allLines, contexts, "toolOutput", uiTheme);
		const styleLine = createGroupedRowStyler(allLines, contexts, uiTheme, {
			linkTarget: groupedLinkTargets(contexts, textContent, details, rawDetails),
			styleBody: index => styleCodeFrame(index) ?? uiTheme.fg("toolOutput", allLines[index]!),
			linkLines: true,
		});
		const matchGroups = groupsByFile(groupLineIndicesByBlank(allLines), contexts);
		// Output without `*` match marks (legacy results) counts its body rows as matches.
		const marked = allLines.some(isMatchRow);
		const isMatch = marked
			? (index: number) => isMatchRow(allLines[index]!)
			: (index: number) => contexts[index]!.kind === "content" && allLines[index]!.length > 0;
		// Collapsed previews drop context rows, keeping each file row and its matches.
		const compactGroups = marked
			? matchGroups.map(group => group.filter(index => contexts[index]!.kind === "file" || isMatch(index)))
			: matchGroups;

		return createCachedComponent(
			() => options.expanded,
			width => {
				const limit = options.expanded ? EXPANDED_TEXT_LIMIT : COLLAPSED_TEXT_LIMIT;
				const { shown, summary } = fitGroupsToBudget(
					options.expanded ? matchGroups : compactGroups,
					Math.max(limit - extraLines.length, 0),
					{ isUnit: isMatch, unit: "match", total: matchCount },
				);
				const matchLines = renderTreeList(
					{ items: shown, trailingSummary: summary, renderItem: group => group.map(styleLine) },
					uiTheme,
				);
				return fitHeaderedRows(header, [...matchLines, ...extraLines], width);
			},
		);
	},
	describeCall(args: GrepRenderArgs): NativeToolView {
		return { tool: grepNativeHead(args), inline: true };
	},

	/**
	 * Inline (§7.3 grep): `Grep “pattern”  in src  5 matches · 2 files`, the scope
	 * leading the counts as in the terminal card, then
	 * the matches grouped by file; collapsed shows the first two files.
	 */
	describeResult(
		result: { content: Array<{ type: string; text?: string }>; details?: GrepToolDetails; isError?: boolean },
		options: RenderResultOptions,
		args?: GrepRenderArgs,
	): NativeToolView {
		const details = result.details;
		if (result.isError || details?.error) {
			return inlineErrorView(grepNativeHead(args), details?.error || resultText(result) || "Unknown error");
		}
		const textContent = details?.displayContent ?? resultText(result);
		const missing = details?.missingPaths ?? [];
		const missingNote = missing.length > 0 ? `skipped missing: ${missing.join(", ")}` : undefined;
		const binaryNote = details?.binaryMatches?.length
			? `binary matches: ${formatCount("file", details.binaryMatches.length)}`
			: undefined;
		const scope = details?.scopePath ? `in ${details.scopePath}` : undefined;
		const hasDetailedData = details?.matchCount !== undefined || details?.fileCount !== undefined;
		const matchCount = details?.matchCount ?? 0;
		if (
			(!hasDetailedData && (!textContent || textContent === "No matches found")) ||
			(hasDetailedData && matchCount === 0)
		) {
			const foot = footnoteText(compact([missingNote, binaryNote]));
			return {
				tool: grepNativeHead(args, compact([scope, "0 matches"])),
				tone: "warning",
				inline: true,
				body: foot ? [foot] : undefined,
			};
		}
		const truncated = Boolean(
			details?.truncated || details?.meta?.truncation || details?.meta?.limits?.columnTruncated,
		);
		const lines = textContent.split("\n");
		const fileCount = details?.fileCount ?? 0;
		const singleFileScope = Boolean(scope) && fileCount === 1 && !lines.some(isGroupedHeader);
		const counts = hasDetailedData
			? singleFileScope
				? formatCount("match", matchCount)
				: `${formatCount("match", matchCount)} · ${formatCount("file", fileCount)}`
			: undefined;
		const head = grepNativeHead(args, compact([scope, counts]));
		const hiddenFiles = options.expanded ? 0 : Math.max(0, fileCount - NATIVE_COLLAPSED_FILES);
		const foot = footnoteText(
			compact([hiddenFiles > 0 && formatCount("more file", hiddenFiles), missingNote, binaryNote]),
			details?.meta,
		);
		return {
			tool: truncated ? { ...head, badges: [{ text: "truncated", tone: "warning" }] } : head,
			inline: true,
			body: compact<NativeChild>([
				...describeGroupedOutput(lines, {
					maxFiles: options.expanded ? undefined : NATIVE_COLLAPSED_FILES,
					file: details?.files?.length === 1 ? details.files[0] : undefined,
				}),
				foot,
			]),
			preview: { lines: PREVIEW_LIMITS.EXPANDED_LINES },
		};
	},
	mergeCallAndResult: true,
} satisfies ToolRenderer<GrepRenderArgs, GrepToolDetails>;

/** Native grep head: the pattern, then the result `meta` or, before a result, the scope/flag arguments. */
function grepNativeHead(args: GrepRenderArgs | undefined, meta?: readonly string[]): NativeToolHead {
	const parts = meta ? [...meta] : [];
	if (!meta && args) {
		const paths = toPathList(args.path ?? args.paths);
		if (paths.length) parts.push(`in ${paths.join(", ")}`);
		parts.push(...grepFlagMeta(args));
	}
	ensureThemeSync();
	const target = args?.pattern
		? compactText(styledSpans(highlightCode(args.pattern, "Regular Expression").join("\n")))
		: "?";
	return { title: "Grep", target, targetKind: "pattern", meta: parts };
}
