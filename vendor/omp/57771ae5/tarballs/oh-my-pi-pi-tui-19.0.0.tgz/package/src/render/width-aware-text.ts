import { Text } from "../components/text";
import { col } from "../native/describe";
import type { DescribeContext, NativeNode } from "../native/node";
import type { Component } from "../tui";
import { getPaddingX } from "../utils";

/**
 * Text whose content is (re)formatted against the actual render width.
 *
 * A plain `Text` receives an already-formatted string and only wraps it at
 * render time, so width-dependent layout (per-line truncation, inline previews)
 * has to be decided before the width is known. Renderers used to cope by
 * hard-capping output lines at a fixed column count (e.g. 80), which truncated
 * to roughly a third of a wide terminal. This defers formatting to
 * `render(width)`: it computes the same content width the inner `Text` uses
 * (mirroring its tight-layout flag so the budget can't desync), hands that to
 * the formatter, and delegates margins/background/vertical padding to the inner
 * `Text`. Lines the formatter caps at `contentWidth` fit exactly and so never
 * wrap.
 */
export class WidthAwareText implements Component {
	#format: (contentWidth: number) => string;
	readonly #paddingX: number;
	#inner: Text;
	#cachedContentWidth = -1;
	#cachedText: string | undefined;
	#ignoreTight = false;
	#native: NativeNode | undefined;

	constructor(format: (contentWidth: number) => string, paddingX = 1, paddingY = 1) {
		this.#format = format;
		this.#paddingX = paddingX;
		this.#inner = new Text("", paddingX, paddingY);
	}

	setCustomBgFn(customBgFn?: (text: string) => string): void {
		this.#inner.setCustomBgFn(customBgFn);
	}

	setIgnoreTight(ignore: boolean): this {
		this.#ignoreTight = ignore;
		this.#inner.setIgnoreTight(ignore);
		this.invalidate();
		return this;
	}

	invalidate(): void {
		this.#cachedContentWidth = -1;
		this.#cachedText = undefined;
		this.#inner.invalidate();
	}

	releaseRenderCaches(): void {
		this.#cachedContentWidth = -1;
		this.#cachedText = undefined;
		this.#inner.setText("");
		this.#inner.releaseRenderCaches();
	}

	/**
	 * Re-run the formatter on the next render because its inputs changed.
	 * Unlike {@link invalidate}, the inner `Text` keeps its wrap cache, so a
	 * reformat that yields the same string skips re-wrapping and re-tinting.
	 */
	reformat(): void {
		this.#cachedText = undefined;
	}

	/**
	 * The inner `Text` as the only child, fed the formatter's output. The
	 * formatter is width-bound by contract, so it runs once per surface width
	 * (the only width a describer knows) and again on `reformat()`.
	 */
	describe(cx: DescribeContext): NativeNode {
		// Native describe emits no padding, so the formatter gets the full
		// column budget — the same width a native Text.describe() would use.
		const contentWidth = Math.max(1, cx.cols);
		if (this.#cachedText === undefined || contentWidth !== this.#cachedContentWidth) {
			this.#cachedContentWidth = contentWidth;
			this.#cachedText = this.#format(contentWidth);
			this.#inner.setText(this.#cachedText);
		}
		this.#native ??= col([this.#inner]);
		return this.#native;
	}

	render(width: number): readonly string[] {
		const paddingX = this.#ignoreTight ? this.#paddingX : getPaddingX(this.#paddingX);
		const contentWidth = Math.max(1, width - paddingX * 2);
		if (this.#cachedText === undefined || contentWidth !== this.#cachedContentWidth) {
			this.#cachedContentWidth = contentWidth;
			this.#cachedText = this.#format(contentWidth);
			this.#inner.setText(this.#cachedText);
		}
		return this.#inner.render(width);
	}
}
